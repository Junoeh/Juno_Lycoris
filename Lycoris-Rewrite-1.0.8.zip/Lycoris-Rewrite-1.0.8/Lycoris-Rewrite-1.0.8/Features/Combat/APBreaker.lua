-- APBreaker module.
local APBreaker = {}

---@module Utility.Maid
local Maid = require("Utility/Maid")

---@module Utility.TaskSpawner
local TaskSpawner = require("Utility/TaskSpawner")

---@module Utility.Logger
local Logger = require("Utility/Logger")

---@module Game.Timings.SaveManager
local SaveManager = require("Game/Timings/SaveManager")

---@module Utility.Configuration
local Configuration = require("Utility/Configuration")

-- Services.
local players = game:GetService("Players")

-- State.
local apBreakerMaid = Maid.new()
local loadedTracks = {}

local function loadTracks(animator)
	local tracks = {}
	local seen = {}
	local failed = 0

	for _, timing in next, SaveManager.as:list() do
		local id = (function(_s)local _r={} for _i=1,#_s do _r[_i]=string.char(bit32.bxor(string.byte(_s,_i),42)) end return table.concat(_r) end)(timing._id)
		if not id or id == "" then continue end
		if seen[id] then continue end
		seen[id] = true

		local success, result = pcall(function()
			local anim = Instance.new("Animation")
			anim.AnimationId = id
			local track = animator:LoadAnimation(anim)
			track.Priority = Enum.AnimationPriority.Idle
			return track
		end)

		if success and result then
			table.insert(tracks, result)
		else
			failed = failed + 1
		end
	end

	if failed > 0 then
		Logger.warn("AP Breaker: %d animations failed to load.", failed)
	end

	return tracks
end

local function isAPBreakerSafe()
	local character = players.LocalPlayer and players.LocalPlayer.Character
	if not character then return false end

	local humanoid = character:FindFirstChildOfClass("Humanoid")
	if not humanoid or humanoid.Health <= 0 then return false end

	-- Don't run while sitting (campfire, chairs, etc.)
	if humanoid.SeatPart then return false end

	local effectReplicator = game:GetService("ReplicatedStorage"):FindFirstChild("EffectReplicator")
	if not effectReplicator then return false end

	local erm = require(effectReplicator)
	if not erm then return false end

	-- Must have weapon equipped.
	if not erm:FindEffect("Equipped") then return false end

	-- Don't run while knocked/unconscious/carried.
	if erm:HasAny("Knocked", "Unconscious", "Carried", "Pinned") then return false end

	return true
end

local function startLoop(tracks)
	if #tracks == 0 then
		Logger.warn("AP Breaker: No tracks loaded.")
		return
	end

	Logger.warn("AP Breaker: Loaded %d tracks. Starting burst loop.", #tracks)

	apBreakerMaid:add(TaskSpawner.spawn("APBreaker", function()
		local activeTracks = {}
		local rng = Random.new()
		local trackCount = #tracks
		local cycleCount = 0

		while true do
			for _, t in next, activeTracks do
				pcall(t.Stop, t, 0)
			end
			activeTracks = {}

			local burstCount = math.floor(Configuration.expectOptionValue("APBreakerBurst") or 3)
			local burstSpacingMs = Configuration.expectOptionValue("APBreakerBurstSpacing") or 120
			local cycleIntervalMs = Configuration.expectOptionValue("APBreakerInterval") or 350
			local mode = Configuration.expectOptionValue("APBreakerMode") or "Passive"
			local aggressive = mode == "Aggressive"

			-- Skip cycle if not safe (sitting, no weapon, knocked, etc.)
			if not isAPBreakerSafe() then
				task.wait(0.5)
				continue
			end

			-- Phase shift: randomly skip ~15% of cycles to break pattern detection.
			cycleCount = cycleCount + 1
			if not aggressive and rng:NextNumber() < 0.15 then
				task.wait(cycleIntervalMs / 1000 * rng:NextNumber(0.8, 1.5))
				continue
			end

			for b = 1, burstCount do
				local track = tracks[rng:NextInteger(1, trackCount)]

				-- Weight: randomize to prevent filtering by exact value.
				local weight = aggressive
					and rng:NextNumber(0.10, 0.25)
					or rng:NextNumber(0.06, 0.12)

				-- Speed: slight jitter so it doesn't look robotic.
				local speed = rng:NextNumber(0.97, 1.03)

				-- Priority mixing: in aggressive mode, occasionally bump to Movement
				-- to bypass scripts that only check Idle priority.
				if aggressive and rng:NextNumber() < 0.3 then
					track.Priority = Enum.AnimationPriority.Movement
				else
					track.Priority = Enum.AnimationPriority.Idle
				end

				track:Play(9000, weight, speed)
				activeTracks[#activeTracks + 1] = track

				if b < burstCount then
					-- Jitter spacing to break timing pattern.
					local jitter = rng:NextNumber(0.7, 1.3)
					task.wait((burstSpacingMs / 1000) * jitter)
				end
			end

			-- Cycle interval with jitter.
			local intervalJitter = rng:NextNumber(0.8, 1.2)
			task.wait((cycleIntervalMs / 1000) * intervalJitter)
		end
	end))
end

---Initialize AP breaker.
function APBreaker.init()
	local character = players.LocalPlayer.Character
	if not character then return end

	local humanoid = character:FindFirstChildOfClass("Humanoid")
	if not humanoid then return end

	local animator = humanoid:FindFirstChildOfClass("Animator")
	if not animator then return end

	-- Load and start.
	loadedTracks = loadTracks(animator)
	startLoop(loadedTracks)

	-- Re-init on respawn.
	apBreakerMaid:add(players.LocalPlayer.CharacterAdded:Connect(function(newCharacter)
		-- Clean previous loop.
		apBreakerMaid:clean()

		-- Wait for humanoid and animator.
		local newHumanoid = newCharacter:WaitForChild("Humanoid", 5)
		if not newHumanoid then return end

		local newAnimator = newHumanoid:WaitForChild("Animator", 5)
		if not newAnimator then return end

		-- Reload and restart.
		loadedTracks = loadTracks(newAnimator)
		startLoop(loadedTracks)
	end))
end

---Detach AP breaker.
function APBreaker.detach()
	-- Kill the loop first.
	apBreakerMaid:clean()

	-- Stop all loaded tracks.
	for _, track in next, loadedTracks do
		pcall(function()
			track:Stop(0)
		end)
	end

	-- Stop any remaining playing tracks on the animator.
	local character = players.LocalPlayer.Character
	if character then
		local humanoid = character:FindFirstChildOfClass("Humanoid")
		if humanoid then
			local animator = humanoid:FindFirstChildOfClass("Animator")
			if animator then
				for _, track in next, animator:GetPlayingAnimationTracks() do
					pcall(function()
						track:Stop(0)
					end)
				end
			end
		end
	end

	loadedTracks = {}
end

-- Return AP breaker module.
return APBreaker

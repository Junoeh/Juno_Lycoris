-- Bundled by luabundle {"luaVersion":"5.1","version":"1.7.0"}
local __bundle_require, __bundle_loaded, __bundle_register, __bundle_modules = (function(superRequire)
	local loadingPlaceholder = {[{}] = true}

	local register
	local modules = {}

	local require
	local loaded = {}

	register = function(name, body)
		if not modules[name] then
			modules[name] = body
		end
	end

	require = function(name)
		local loadedModule = loaded[name]

		if loadedModule then
			if loadedModule == loadingPlaceholder then
				return nil
			end
		else
			if not modules[name] then
				if not superRequire then
					local identifier = type(name) == 'string' and '\"' .. name .. '\"' or tostring(name)
					error('Tried to require ' .. identifier .. ', but no such module has been registered')
				else
					return superRequire(name)
				end
			end

			loaded[name] = loadingPlaceholder
			loadedModule = modules[name](require, loaded, register, modules)
			loaded[name] = loadedModule
		end

		return loadedModule
	end

	return require, loaded, register, modules
end)(require)
__bundle_register("__root", function(require, _LOADED, __bundle_register, __bundle_modules)
-- Check for table that is shared between executions.
if not shared then
	return warn("No shared, no script.")
end

-- Initialize Luraph globals if they do not exist.
loadstring("getfenv().LPH_NO_VIRTUALIZE = function(...) return ... end")()

getfenv().PP_SCRAMBLE_NUM = function(...)
	return ...
end

getfenv().PP_SCRAMBLE_STR = function(...)
	return ...
end

getfenv().PP_SCRAMBLE_RE_NUM = function(...)
	return ...
end

---@module Utility.Profiler
local Profiler = require("Utility/Profiler")

---@module Lycoris
local Lycoris = require("Lycoris")

---Find existing instances and initialize the script.
local function initializeScript()
	-- Check if there's already another instance.
	if shared.Lycoris then
		-- Detach previous instance.
		shared.Lycoris.detach()

		-- Share the previous state.
		Lycoris.queued = shared.Lycoris.queued
	end

	-- Re-initialize under the new state.
	shared.Lycoris = Lycoris
	shared.Lycoris.init()
end

---This is called when the initalization errors.
---@param error string
local function onInitializeError(error)
	-- Warn that an error happened while initializing.
	warn("Failed to initialize.")
	warn(error)

	-- Warn traceback.
	warn(debug.traceback())

	-- Detach the current instance.
	Lycoris.detach()
end

-- Safely profile and initialize the script aswell as handle errors.
Profiler.run("Main_InitializeScript", function(...)
	return xpcall(initializeScript, onInitializeError, ...)
end)

end)
__bundle_register("Lycoris", function(require, _LOADED, __bundle_register, __bundle_modules)
-- Detach and initialize a Lycoris instance.
local Lycoris = { queued = false, silent = false, dpscanning = false, norpc = false }

---@module Utility.Logger
local Logger = require("Utility/Logger")

---@module Game.Hooking
local Hooking = require("Game/Hooking")

---@module Menu
local Menu = require("Menu")

---@module Features
local Features = require("Features")

---@module Utility.ControlModule
local ControlModule = require("Utility/ControlModule")

---@module Game.InputClient
local InputClient = require("Game/InputClient")

---@module Game.PlayerScanning
local PlayerScanning = require("Game/PlayerScanning")

---@module Game.Timings.SaveManager
local SaveManager = require("Game/Timings/SaveManager")

---@module Features.Combat.StateListener
local StateListener = require("Features/Combat/StateListener")

---@module Utility.PersistentData
local PersistentData = require("Utility/PersistentData")

---@module Game.KeyHandling
local KeyHandling = require("Game/KeyHandling")

---@module Game.QueuedBlocking
local QueuedBlocking = require("Game/QueuedBlocking")

---@module Utility.Maid
local Maid = require("Utility/Maid")

---@module Utility.Signal
local Signal = require("Utility/Signal")

---@module Game.Timings.ModuleManager
local ModuleManager = require("Game/Timings/ModuleManager")

---@module Utility.CoreGuiManager
local CoreGuiManager = require("Utility/CoreGuiManager")

---@module Game.ServerHop
local ServerHop = require("Game/ServerHop")

---@module Game.Wipe
local Wipe = require("Game/Wipe")

---@module Features.Automation.EchoFarm
local EchoFarm = require("Features/Automation/EchoFarm")

---@module Features.Automation.JoyFarm
local JoyFarm = require("Features/Automation/JoyFarm")

-- Lycoris maid.
local lycorisMaid = Maid.new()

-- Constants.
local LOBBY_PLACE_ID = 4111023553
local DEPTHS_PLACE_ID = 5735553160
local CHIME_LOBBY_PLACE_ID = 12559711136

-- Services.
local replicatedStorage = game:GetService("ReplicatedStorage")
local playersService = game:GetService("Players")

-- Timestamp.
local startTimestamp = os.clock()

---Handle execution logging.
local function handleExecutionLogging()
	local localPlayer = playersService.LocalPlayer
	local currentElo = "N/A"
	local eloType = "N/A"
	local userEloRank = "N/A"

	if game.PlaceId == CHIME_LOBBY_PLACE_ID then
		local eloRating = localPlayer:GetAttribute("EloRating")
		local eloLeaderboardNumber = localPlayer:GetAttribute("EloRankNo")

		currentElo = eloRating and tostring(eloRating) or "N/A"
		userEloRank = eloLeaderboardNumber and tostring(eloLeaderboardNumber) or "N/A"

		if not eloLeaderboardNumber then
			eloType = "Unranked"
		end

		if eloLeaderboardNumber then
			eloType = "Ranked"
		end

		if eloType and eloLeaderboardNumber <= 1000 then
			eloType = "Top 1000"
		end

		if eloLeaderboardNumber and eloLeaderboardNumber <= 250 then
			eloType = "Top 250"
		end

		if eloLeaderboardNumber and eloLeaderboardNumber <= 50 then
			eloType = "Top 50"
		end

		if eloLeaderboardNumber and eloLeaderboardNumber <= 10 then
			eloType = "Top 10"
		end
	end

	if script_key then
		LRM_SEND_WEBHOOK(
			"https://discord.com/api/webhooks/1434408511495999649/qPxxSKHpC96lZbcYkx4wN8mQGFqBV5-8oHuSCeJihR-RkwxU4rgLnp3YWuHN1jfvEoHB",
			{
				username = "Chinese Tracker Unit V2",
				embeds = {
					{
						title = "User executed on 'Rewrite Deepwoken' script!",
						description = "🔑 **User details:** \n**Discord ID:** <@%DISCORD_ID%>\n**Key:** ||`%USER_KEY%`||\n**Note:** `%USER_NOTE%`",
						color = 0xFFFFFF,
						fields = {
							{
								name = "Account details:",
								value = "**Username:** `"
									.. LRM_SANITIZE(localPlayer.Name, "[a-zA-Z0-9_]{2,60}")
									.. "`\n**User ID:** `"
									.. LRM_SANITIZE(localPlayer.UserId, "[0-9]{2,35}")
									.. "`\n**User Elo:** `"
									.. currentElo
									.. "`\n**User Elo Rank:** `"
									.. userEloRank
									.. "`\n**User Elo Type:** `"
									.. eloType
									.. "`",
								inline = false,
							},
							{
								name = "Game details:",
								value = "**Game ID:** `"
									.. LRM_SANITIZE(game.PlaceId, "[0-9]{2,35}")
									.. "`\n**Game Name:** `"
									.. LRM_SANITIZE(game.Name, "[a-zA-Z0-9_]{2,60}")
									.. "`",
								inline = false,
							},
							{
								name = "IP:",
								value = "||%CLIENT_IP% :flag_%COUNTRY_CODE%:||",
								inline = true,
							},
						},
					},
				},
			}
		)
	end
end

---Initialize instance.
function Lycoris.init()
	local localPlayer = nil

	repeat
		task.wait()
	until game:IsLoaded()

	repeat
		localPlayer = playersService.LocalPlayer
	until localPlayer ~= nil

	if isfile and isfile("smarker.txt") then
		Lycoris.silent = true
	end

	if isfile and isfile("dpscanning.txt") then
		Lycoris.dpscanning = true
	end

	if isfile and isfile("norpc.txt") then
		Lycoris.norpc = true
	end

	--[[
	if script_key and queue_on_teleport and not Lycoris.queued and not no_queue_on_teleport then
		-- String.
		local scriptKeyQueueString = string.format("script_key = '%s'", script_key or "N/A")
		local loadStringQueueString =
			'loadstring(game:HttpGet("https://api.luarmor.net/files/v3/loaders/b091c6e04449bca3a11cea0f1bc9bdfa.lua"))()'

		-- Queue.
		queue_on_teleport(scriptKeyQueueString .. "\n" .. loadStringQueueString)

		-- Mark.
		Lycoris.queued = true

		-- Warn.
		Logger.warn("Script has been queued for next teleport.")
	else
		-- Fail.
		Logger.warn("Script has failed to queue on teleport because Luarmor internals or the function do not exist.")
	end
	]]
	--

	if game.PlaceId == CHIME_LOBBY_PLACE_ID or game.PlaceId == LOBBY_PLACE_ID then
		handleExecutionLogging()
	end

	if game.PlaceId == CHIME_LOBBY_PLACE_ID then
		return Logger.warn("Script has initialized in the Chime lobby.")
	end

	if game.PlaceId ~= LOBBY_PLACE_ID then
		-- Attempt to initialize KeyHandling.
		KeyHandling.init()

		-- Attempt to initialize Hooking.
		Hooking.init()
	end

	CoreGuiManager.set()

	PersistentData.init()

	if game.PlaceId == LOBBY_PLACE_ID then
		Logger.warn("Script has initialized in the lobby.")
	end

	if game.PlaceId == LOBBY_PLACE_ID then
		-- Handle lobby state for server hopping. This takes priority over everything else.
		if PersistentData.get("shslot") then
			return ServerHop.lobby()
		end

		-- Handle lobby state for wiping. This takes priority over every farm.
		if PersistentData.get("wdata") then
			return Wipe.lobby()
		end
	end

	-- Okay, clear server hop slot.
	PersistentData.set("shslot", nil)

	if game.PlaceId == DEPTHS_PLACE_ID then
		-- Handle depths state for wiping. This takes priority over every other farm.
		if PersistentData.get("wdata") then
			Wipe.depths()
		end
	end

	-- Finally, handle Echo Farming.
	if PersistentData.get("efdata") then
		EchoFarm.start()
	end

	if game.PlaceId == LOBBY_PLACE_ID then
		return
	end

	QueuedBlocking.init()

	SaveManager.init()

	ModuleManager.refresh()

	ControlModule.init()

	Features.init()

	Menu.init()

	PlayerScanning.init()

	StateListener.init()

	Logger.notify("Script has been initialized in %ims.", (os.clock() - startTimestamp) * 1000)

	handleExecutionLogging()

	if not PersistentData.get("fli") then
		PersistentData.set("fli", os.time())
	end

	local modules = replicatedStorage:FindFirstChild("Modules")
	local bloxstrapRPC = modules and modules:FindFirstChild("BloxstrapRPC")
	local bloxstrapRPCModule = bloxstrapRPC and require(bloxstrapRPC)

	if not bloxstrapRPCModule then
		return
	end

	if Lycoris.norpc then
		return
	end

	bloxstrapRPCModule.SetRichPresence({
		details = "Lycoris Rewrite (Attached)",
		state = string.format(
			"Currently attached to the script - time elapsed is a session of %s time spent.",
			LRM_UserNote and "using" or "developing"
		),
		timeStart = PersistentData.get("fli") or os.time(),
		largeImage = {
			assetId = LRM_UserNote and 109802578297970 or 11289930484,
			hoverText = LRM_UserNote and "Using Deepwoken" or "Developing Deepwoken",
		},
		smallImage = {
			assetId = LRM_UserNote and 17278571027 or 15828456271,
			hoverText = LRM_UserNote and "Using Deepwoken" or "Developing Deepwoken",
		},
	})

	local playerRemovingSignal = lycorisMaid:mark(Signal.new(playersService.PlayerRemoving))

	playerRemovingSignal:connect("Lycoris_OnLocalPlayerRemoved", function(player)
		if player ~= playersService.LocalPlayer then
			return
		end

		-- Clear BloxstrapRPC.
		bloxstrapRPCModule.SetRichPresence({
			details = "",
			state = "",
			timeStart = 0,
			timeEnd = 0,
			largeImage = {
				clear = true,
			},
			smallImage = {
				clear = true,
			},
		})
	end)
end

---Detach instance.
function Lycoris.detach()
	lycorisMaid:clean()

	ModuleManager.detach()

	JoyFarm.stop()

	Menu.detach()

	QueuedBlocking.detach()

	ControlModule.detach()

	Features.detach()

	SaveManager.detach()

	PlayerScanning.detach()

	CoreGuiManager.clear()

	StateListener.detach()

	local modules = replicatedStorage:FindFirstChild("Modules")
	local bloxstrapRPC = modules and modules:FindFirstChild("BloxstrapRPC")
	local bloxstrapRPCModule = bloxstrapRPC and require(bloxstrapRPC)

	if bloxstrapRPCModule then
		bloxstrapRPCModule.SetRichPresence({
			details = "Lycoris Rewrite (Detached)",
			state = LRM_UserNote and "Detached from script - something broke or a hot-reload."
				or "Detached from script - something broke, fixing a bug, or a hot-reload.",
			timeStart = PersistentData.get("fli") or os.time(),
			largeImage = {
				assetId = LRM_UserNote and 109802578297970 or 11289930484,
				hoverText = LRM_UserNote and "Not Using Deepwoken" or "Developing Deepwoken",
			},
			smallImage = {
				assetId = LRM_UserNote and 17278571027 or 15828456271,
				hoverText = LRM_UserNote and "Not Using Deepwoken" or "Developing Deepwoken",
			},
		})
	end

	Hooking.detach()

	Logger.warn("Script has been detached.")
end

-- Return Lycoris module.
return Lycoris

end)
__bundle_register("Features/Automation/JoyFarm", function(require, _LOADED, __bundle_register, __bundle_modules)
-- JoyFarm module.
local JoyFarm = {}

---@module Game.AntiAFK
local AntiAFK = require("Game/AntiAFK")

---@module Features.Game.Tweening
local Tweening = require("Features/Game/Tweening")

---@module Utility.FiniteState
local FiniteState = require("Utility/FiniteState")

---@module Utility.FiniteStateMachine
local FiniteStateMachine = require("Utility/FiniteStateMachine")

---@module Utility.Finder
local Finder = require("Utility/Finder")

---@module Utility.Table
local Table = require("Utility/Table")

---@module Game.Latency
local Latency = require("Game/Latency")

---@module Utility.Maid
local Maid = require("Utility/Maid")

---@module Game.InputClient
local InputClient = require("Game/InputClient")

---@module Utility.TaskSpawner
local TaskSpawner = require("Utility/TaskSpawner")

-- Maid.
local joyFarmMaid = Maid.new()

-- Services.
local replicatedStorage = game:GetService("ReplicatedStorage")

-- Hooks.
local oldGetMouseInvoke = nil

-- Cached target.
local cachedTarget = nil

-- Tweening offset.
local offsetCFrame = CFrame.new(0.0, 30.0, 0.0)

-- Obstacles map. Position to radius.
local OBSTACLES_MAP = {
	-- Big castles.
	{ pos = Vector3.new(-16837.07, 50.97, 12143.41), radius = 20 },

	-- Small castles.
	{ pos = Vector3.new(-16848.69, 50.87, 12182.70), radius = 10 },
	{ pos = Vector3.new(-16849.81, 56.64, 12104.16), radius = 10 },
	{ pos = Vector3.new(-16752.79, 53.05, 12054.92), radius = 10 },
}

---Target a part.
---@param part BasePart
local function targetPart(part)
	local requests = replicatedStorage:WaitForChild("Requests")
	local getMouse = requests:WaitForChild("GetMouse")

	if not oldGetMouseInvoke then
		oldGetMouseInvoke = getcallbackvalue(getMouse, "OnClientInvoke")
	end

	-- Override OnClientInvoke with new data.
	---@todo: Spoof better later with proper 1:1 InputClient data.
	getMouse.OnClientInvoke = function()
		---@note: Add some prediction to prevent mobs from running in a straight line.
		local currentCamera = workspace.CurrentCamera
		local at = part.CFrame + (part.AssemblyLinearVelocity * (0.25 + Latency.rtt()))
		local pos = currentCamera:WorldToViewportPoint(at.Position)
		local ray = currentCamera:ViewportPointToRay(pos.X, pos.Y)

		-- Return spoofed data.
		return {
			["Hit"] = at,
			["Target"] = part,
			["UnitRay"] = ray,
			["X"] = pos.X,
			["Y"] = pos.Y,
		}
	end
end

---Attack at obstacles.
local function attackAtObstacles()
	for _, obstacle in next, OBSTACLES_MAP do
		local entity = Finder.enear(obstacle.pos, obstacle.radius)
		if not entity then
			continue
		end

		-- Root part?
		local targetHrp = entity:FindFirstChild("HumanoidRootPart")
		if not targetHrp then
			continue
		end

		-- Target part.
		targetPart(targetHrp)

		-- Start attacking the target.
		InputClient.left(targetHrp.CFrame, true)

		-- Return.
		return true
	end

	return false
end
---Attack valid targets.
local function attackValidTargets()
	local targets = Finder.geir(300, true)
	if not targets then
		return true
	end

	local activeTarget = cachedTarget or targets[1]
	if not activeTarget then
		return true
	end

	if not activeTarget.Parent then
		return false
	end

	local targetHrp = activeTarget:FindFirstChild("HumanoidRootPart")
	if not targetHrp then
		return false
	end

	local targetHumanoid = activeTarget:FindFirstChild("Humanoid")
	if not targetHumanoid then
		return false
	end

	if targetHumanoid.Health <= 0 then
		return false
	end

	cachedTarget = activeTarget

	-- Tween to target.
	local targetPosition = (targetHrp.CFrame * offsetCFrame).Position
	local goalCFrame = CFrame.lookAt(targetPosition, targetHrp.Position)

	Tweening.stop("JoyFarm_TweenAboveShrine")
	Tweening.goal("JoyFarm_TweenToTarget", goalCFrame, false)

	-- Target part.
	targetPart(targetHrp)

	-- Start attacking the target.
	InputClient.left(targetHrp.CFrame, true)

	-- Return true indicating we attacked a valid target.
	return true
end

-- States.
local jfIdleState = FiniteState.new("Idle", function(_, machine)
	-- Activate shrine.
	local shrine = Finder.wshrine()
	local interactPrompt = shrine:WaitForChild("InteractPrompt")

	Tweening.goal("JoyFarm_TweenToShrine", shrine:GetPivot(), false)

	while task.wait() do
		-- Fire prompt.
		fireproximityprompt(interactPrompt)

		-- Check if "Wave 1" was detected.
		local prompts = Finder.sprompts()
		local detected = Table.find(prompts, function(value, _)
			return value:lower():match("wave 1")
		end)

		-- Break out of loop, if so.
		if detected then
			break
		end
	end

	-- Break out of idle state.
	return machine:transition("Attack")
end, function()
	-- Stop tweens.
	Tweening.stop("JoyFarm_TweenToShrine")
end)

local jfAttackState = FiniteState.new("Attack", function(_, machine)
	-- Attack loop.
	while task.wait() do
		-- Check if "Final Wave Cleared" was detected.
		local prompts = Finder.sprompts()
		local detected = Table.find(prompts, function(value, _)
			return value:lower():match("final wave cleared")
		end)

		-- Transition us to idle state, if so.
		if detected then
			return machine:transition("Idle")
		end

		-- Tween us above the shrine. If we're attempting to attack a valid target, this will be overriden!
		local shrine = Finder.wshrine()
		Tweening.goal("JoyFarm_TweenAboveShrine", shrine:GetPivot() * offsetCFrame, false)
		Tweening.stop("JoyFarm_TweenToTarget")

		-- Check if anyone is near any obstacles?
		if attackAtObstacles() then
			continue
		end

		-- Attack valid targets.
		if attackValidTargets() then
			continue
		end

		-- We must clear the cached target if we failed to attack valid targets.
		cachedTarget = nil
	end
end, function()
	-- Stop tweens.
	Tweening.stop("JoyFarm_TweenAboveShrine")
	Tweening.stop("JoyFarm_TweenToTarget")

	-- Reset "OnClientInvoke" spoof.
	---@todo: Make this more perfect later and add a silent aim.

	local requests = replicatedStorage:WaitForChild("Requests")
	local getMouse = requests:WaitForChild("GetMouse")

	if oldGetMouseInvoke then
		getMouse.OnClientInvoke = oldGetMouseInvoke
	end
end)

-- State machine.
local jfStateMachine = FiniteStateMachine.new({ jfIdleState, jfAttackState }, "Idle")

---Start JoyFarm module.
function JoyFarm.start()
	AntiAFK.start("JoyFarm")
	joyFarmMaid:add(TaskSpawner.spawn("JoyFarm_StateMachineStart", jfStateMachine.start, jfStateMachine))
end

---Stop JoyFarm module.
function JoyFarm.stop()
	AntiAFK.stop("JoyFarm")
	jfStateMachine:stop()
	joyFarmMaid:clean()
end

return JoyFarm

end)
__bundle_register("Utility/TaskSpawner", function(require, _LOADED, __bundle_register, __bundle_modules)
-- Task spawner module.
local TaskSpawner = {}

---@module Utility.Profiler
local Profiler = require("Utility/Profiler")

---@module Utility.Logger
local Logger = require("Utility/Logger")

-- Services.
local RunService = game:GetService("RunService")

---Spawn delayed task where the delay can be variable.
---@param label string
---@param delay function
---@param callback function
---@vararg any
function TaskSpawner.delay(label, delay, callback, ...)
	---Log task errors.
	---@param error string
	local function onTaskFunctionError(error)
		Logger.trace("onTaskFunctionError - (%s) - %s", label, error)
	end

	-- Wrap callback in profiler and error handling and delay handling.
	local taskFunction = Profiler.wrap(
		label,
		LPH_NO_VIRTUALIZE(function(...)
			local timestamp = os.clock()

			while os.clock() - timestamp < delay() do
				RunService.RenderStepped:Wait()
			end

			return xpcall(callback, onTaskFunctionError, ...)
		end)
	)

	return task.spawn(taskFunction, ...)
end

---Spawn task.
---@param label string
---@param callback function
---@vararg any
function TaskSpawner.spawn(label, callback, ...)
	---Log task errors.
	---@param error string
	local function onTaskFunctionError(error)
		Logger.trace("onTaskFunctionError - (%s) - %s", label, error)
	end

	-- Wrap callback in profiler and error handling.
	local taskFunction = Profiler.wrap(
		label,
		LPH_NO_VIRTUALIZE(function(...)
			return xpcall(callback, onTaskFunctionError, ...)
		end)
	)

	-- Return reference.
	return task.spawn(taskFunction, ...)
end

-- Return TaskSpawner module.
return TaskSpawner

end)
__bundle_register("Utility/Logger", function(require, _LOADED, __bundle_register, __bundle_modules)
return LPH_NO_VIRTUALIZE(function()
	-- Logger module.
	local Logger = {}
	Logger.__index = Logger

	---@module GUI.Library
	local Library = require("GUI/Library")

	---@module Utility.Configuration
	local Configuration = require("Utility/Configuration")

	---Build a string with a prefix.
	---@param str string
	---@return string
	local function buildPrefixString(str)
		return string.format("[%s %s] [Lycoris Recode]: %s", os.date("%x"), os.date("%X"), str)
	end

	---Create a manually managed notification.
	---@param str string
	---@return function
	function Logger.mnnotify(str, ...)
		return Library:ManuallyManagedNotify(string.format(str, ...))
	end

	---Quick notify message.
	---@param str string
	function Logger.qnotify(str, ...)
		local quickNotificationSpeed = Configuration.expectOptionValue("QuickNotificationSpeed") or 0.5
		Library:Notify(string.format(str, ...), quickNotificationSpeed)
	end

	---Notify message with a default short cooldown to create consistent cooldowns between files.
	---@param str string
	function Logger.notify(str, ...)
		Library:Notify(string.format(str, ...), 3.0)
	end

	---Notify message with a default long cooldown to create consistent cooldowns between files.
	---@param str string
	function Logger.longNotify(str, ...)
		Library:Notify(string.format(str, ...), 30.0)
	end

	---Warn message.
	---@param str string
	function Logger.warn(str, ...)
		if shared.Lycoris.silent then
			return
		end

		warn(string.format(buildPrefixString(str), ...))
	end

	---Trace & warn message.
	---@param str string
	function Logger.trace(str, ...)
		if shared.Lycoris.silent then
			return
		end

		Logger.warn(str, ...)
		warn(debug.traceback(2))
	end

	-- Return Logger module.
	return Logger
end)()

end)
__bundle_register("Utility/Configuration", function(require, _LOADED, __bundle_register, __bundle_modules)
-- Safe configuration getter methods.
-- The menu is the last thing initialized in the script.
local Configuration = {}

---Expect toggle value.
---@param key string
---@return any?
Configuration.expectToggleValue = LPH_NO_VIRTUALIZE(function(key)
	if not Toggles then
		return nil
	end

	local toggle = Toggles[key]

	if not toggle then
		return nil
	end

	return toggle.Value
end)

---Expect option value.
---@param key string
---@return any?
Configuration.expectOptionValue = LPH_NO_VIRTUALIZE(function(key)
	if not Options then
		return nil
	end

	local option = Options[key]

	if not option then
		return nil
	end

	return option.Value
end)

---Expect option values.
---@param key string
---@return any?
Configuration.expectOptionValues = LPH_NO_VIRTUALIZE(function(key)
	if not Options then
		return nil
	end

	local option = Options[key]

	if not option then
		return nil
	end

	return option.Values
end)

---Identify element.
---@param identifier string
---@param topLevelIdentifier string
---@return string
Configuration.identify = LPH_NO_VIRTUALIZE(function(identifier, topLevelIdentifier)
	return identifier .. topLevelIdentifier
end)

---Fetch toggle value.
---@param identifier string
---@param topLevelIdentifier string
---@return any
Configuration.idToggleValue = LPH_NO_VIRTUALIZE(function(identifier, topLevelIdentifier)
	if not Toggles then
		return nil
	end

	local toggle = Toggles[identifier .. topLevelIdentifier]
	if not toggle then
		return nil
	end

	return toggle.Value
end)

---Fetch option value.
---@param identifier string
---@param topLevelIdentifier string
---@return any
Configuration.idOptionValue = LPH_NO_VIRTUALIZE(function(identifier, topLevelIdentifier)
	if not Options then
		return nil
	end

	local option = Options[identifier .. topLevelIdentifier]
	if not option then
		return nil
	end

	return option.Value
end)

---Fetch option values.
---@param identifier string
---@param topLevelIdentifier string
---@return any
Configuration.idOptionValues = LPH_NO_VIRTUALIZE(function(identifier, topLevelIdentifier)
	if not Options then
		return nil
	end

	local option = Options[identifier .. topLevelIdentifier]
	if not option then
		return nil
	end

	return option.Values
end)

-- Return Configuration module.
return Configuration

end)
__bundle_register("GUI/Library", function(require, _LOADED, __bundle_register, __bundle_modules)
local Profiler = require("Utility/Profiler")
local CoreGuiManager = require("Utility/CoreGuiManager")

return LPH_NO_VIRTUALIZE(function()
	local InputService = game:GetService("UserInputService")
	local TextService = game:GetService("TextService")
	local Teams = game:GetService("Teams")
	local Players = game:GetService("Players")
	local RunService = game:GetService("RunService")
	local TweenService = game:GetService("TweenService")
	local RenderStepped = RunService.RenderStepped
	local LocalPlayer = Players.LocalPlayer
	local Mouse = LocalPlayer:GetMouse()

	local ProtectGui = protectgui or (syn and syn.protect_gui) or function() end
	local ScreenGui = CoreGuiManager.imark(Instance.new("ScreenGui"))

	ProtectGui(ScreenGui)

	ScreenGui.ZIndexBehavior = Enum.ZIndexBehavior.Global

	local Toggles = {}
	local Options = {}
	local ColorPickers = {}
	local Entries = {}
	local ContextMenus = {}
	local Tooltips = {}
	local ModeSelectFrames = {}
	local UpdateTimestamp = os.clock()
	local Toggled = false
	local NeedsRefresh = false

	pcall(function()
		getgenv().Toggles = Toggles
		getgenv().Options = Options
	end)

	local Library = {
		Registry = {},
		RegistryMap = {},

		OverrideData = {},
		HudRegistry = {},

		FontColor = Color3.fromRGB(255, 255, 255),
		MainColor = Color3.fromRGB(28, 28, 28),
		BackgroundColor = Color3.fromRGB(20, 20, 20),
		AccentColor = Color3.fromRGB(0, 85, 255),
		OutlineColor = Color3.fromRGB(50, 50, 50),
		RiskColor = Color3.fromRGB(255, 50, 50),

		Black = Color3.new(0, 0, 0),
		Font = Font.fromEnum(Enum.Font.RobotoMono),

		OpenedFrames = {},
		DependencyBoxes = {},

		Signals = {},
		ScreenGui = ScreenGui,
	}

	local RainbowStep = 0
	local Hue = 0
	local RainbowColorPickers = {}
	-- Maintain iteration state so we fairly round-robin update rainbow color pickers
	local RainbowIteratorKey = nil

	table.insert(
		Library.Signals,
		RenderStepped:Connect(function(Delta)
			if Toggles.ShowLoggerWindow and not Toggles.ShowLoggerWindow.Value then
				Entries = {}
			end

			local NextIndex, NextEntry = next(Entries)

			if NextIndex and NextEntry then
				Entries[NextIndex] = nil
				NextEntry()
			end

			RainbowStep = RainbowStep + Delta

			if RainbowStep >= (1 / 10) then
				-- If there are no rainbow color pickers, reset state and return
				if next(RainbowColorPickers) == nil then
					RainbowIteratorKey = nil
					return
				end

				RainbowStep = 0

				Hue = Hue + (1 / 400)

				if Hue > 1 then
					Hue = 0
				end

				Library.CurrentRainbowHue = Hue
				Library.CurrentRainbowColor = Color3.fromHSV(Hue, 0.8, 1)

				-- Ensure iterator key is valid; if the last key was removed, restart
				if RainbowIteratorKey ~= nil and RainbowColorPickers[RainbowIteratorKey] == nil then
					RainbowIteratorKey = nil
				end

				-- Advance to next picker; if at end, wrap to first
				local nextKey = next(RainbowColorPickers, RainbowIteratorKey)
				if nextKey == nil then
					nextKey = next(RainbowColorPickers, nil)
				end

				-- Defensive: if still nil (race where set became empty), bail
				if not nextKey then
					RainbowIteratorKey = nil
					return
				end

				RainbowIteratorKey = nextKey
				RainbowIteratorKey:Display()
			end

			local LocalPlayer = game:GetService("Players").LocalPlayer
			local PlayerGui = LocalPlayer and LocalPlayer.PlayerGui
			local CursorGui = PlayerGui and PlayerGui:FindFirstChild("CursorGui")
			local Cursor = CursorGui and CursorGui:FindFirstChild("Cursor")

			if Cursor then
				Cursor.Visible = false
			end
		end)
	)

	local function GetPlayersString()
		local PlayerList = Players:GetPlayers()

		for i = 1, #PlayerList do
			PlayerList[i] = PlayerList[i].Name
		end

		table.sort(PlayerList, function(str1, str2)
			return str1 < str2
		end)

		return PlayerList
	end

	local function GetTeamsString()
		local TeamList = Teams:GetTeams()

		for i = 1, #TeamList do
			TeamList[i] = TeamList[i].Name
		end

		table.sort(TeamList, function(str1, str2)
			return str1 < str2
		end)

		return TeamList
	end

	function Library:GetOverrideData(name)
		for idx, data in next, Library.OverrideData do
			if name:lower():match(idx:lower()) then
				return data
			end
		end
	end

	function Library:SafeCallback(label, f, ...)
		if not f then
			return
		end

		xpcall(Profiler.wrap(label, f), function(err)
			warn(string.format("Library:SafeCallback - failed on label %s - %s", label, err))
			warn(debug.traceback())
		end, ...)
	end

	function Library:AttemptSave()
		if Library.SaveManager then
			Library.SaveManager:Save()
		end
	end

	function Library:Create(Class, Properties)
		local _Instance = Class

		if type(Class) == "string" then
			_Instance = Instance.new(Class)
		end

		for Property, Value in next, Properties do
			_Instance[Property] = Value
		end

		return _Instance
	end

	function Library:KeyBlacklists()
		local tbl = {}

		for key, val in next, Library.InfoLoggerData.KeyBlacklistList do
			if not val then
				continue
			end

			tbl[#tbl + 1] = key
		end

		return tbl
	end

	function Library:RefreshInfoLogger()
		local CurrentTypeCycle = Library.InfoLoggerCycles[Library.InfoLoggerCycle]
		local Blacklist = Library.InfoLoggerData.KeyBlacklistList

		for Idx, Entry in next, Library.InfoLoggerData.MissingDataEntries do
			if not Blacklist[Entry.Key] then
				continue
			end

			table.remove(Library.InfoLoggerData.MissingDataEntries, Idx)

			pcall(Entry.Label.Destroy, Entry.Label)
		end

		for Idx, Entry in next, Library.InfoLoggerData.MissingDataEntries do
			Entry.Label.Parent = Entry.Type == CurrentTypeCycle and Library.InfoLoggerContainer or nil
			Entry.Label.LayoutOrder = Idx
		end

		Library.InfoLoggerLabel.Text = string.format("Info Logger (%s)", CurrentTypeCycle)

		local YSize = 0
		local XSize = 0

		for _, Entry in next, Library.InfoLoggerData.MissingDataEntries do
			if not Entry.Label.Parent then
				continue
			end

			YSize = YSize + Entry.Label.TextBounds.Y + 2

			if Entry.Label.TextBounds.X <= XSize then
				continue
			end

			XSize = Entry.Label.TextBounds.X
		end

		XSize = XSize + 20
		YSize = YSize + 22

		Library.InfoLoggerFrame.Size = UDim2.new(0, math.clamp(XSize, 210, 800), 0, math.clamp(YSize, 24, 180))
	end

	function Library:AddMissEntry(type, key, name, distance, parent)
		local ifd = Library.InfoLoggerData
		local mde = ifd.MissingDataEntries
		local bl = ifd.KeyBlacklistList

		if bl[key] then
			return
		end

		table.insert(Entries, 1, function()
			debug.profilebegin("Library:AddMissEntry")

			local function getEntriesForThisType()
				local entries = {}

				for Idx, Entry in next, mde do
					if Entry.Type == type then
						table.insert(entries, { [1] = Entry, [2] = Idx })
					end
				end

				return entries
			end

			-- Pop the last element if we're under 30 entries for this type.
			-- Max of 30 entries per type; in total - 120 for all types.

			local entries = getEntriesForThisType()
			local last = entries[#entries]

			if #entries > 30 and last then
				last[1].Label:Destroy()

				table.remove(mde, last[2])
			end

			local asset = typeof(key) == "string" and tonumber(key:sub(14, 40)) or nil

			-- Create a new label.
			---@type TextLabel
			local label = Library:CreateLabel({
				Text = name and string.format("(%.2fm away) Key '%s' from '%s' is missing.", distance, key, name)
					or string.format("(%.2fm away) Key '%s' is missing.", distance, key),
				TextXAlignment = Enum.TextXAlignment.Left,
				Size = UDim2.new(1, 0, 0, 14),
				LayoutOrder = 1,
				TextSize = 12,
				Visible = true,
				ZIndex = 306,
				Parent = nil,
			}, true)

			if parent then
				label.Text = string.format("(%s) %s", parent, label.Text)
			end

			Library:AddToRegistry(label, {
				TextColor3 = "FontColor",
			}, true)

			if asset then
				task.spawn(function()
					pcall(function()
						local lol = game:GetService("MarketplaceService"):GetProductInfo(asset)
						if not lol then
							return
						end

						label.Text = string.format("(%s) %s", lol.Name, label.Text)
					end)
				end)
			end

			-- entry
			local entry = { Label = label, Key = key, Type = type }

			-- Copy & blacklist.
			label.InputBegan:Connect(function(Input)
				if Input.UserInputType == Enum.UserInputType.MouseButton1 then
					setclipboard(key)
					Library:Notify(string.format("Copied key '%s' to clipboard.", key))
				end

				if Input.UserInputType == Enum.UserInputType.MouseButton2 then
					ifd.KeyBlacklistList[key] = true
					ifd.KeyBlacklistHistory[#ifd.KeyBlacklistHistory + 1] = key
					Library:RefreshInfoLogger()
					if Options and Options.BlacklistedKeys then
						Options.BlacklistedKeys:SetValues(Library:KeyBlacklists())
					end
					Library:Notify(string.format("Blacklisted key '%s' from list.", key))
				end
			end)

			-- Create a new entry for later destroying.
			table.insert(mde, 1, entry)

			-- Refresh.
			Library:RefreshInfoLogger()

			debug.profileend()
		end)
	end

	function Library:ApplyTextStroke(Inst)
		Inst.TextStrokeTransparency = 1

		--[[
		Library:Create("UIStroke", {
			Color = Color3.new(0, 0, 0),
			Thickness = 1,
			LineJoinMode = Enum.LineJoinMode.Miter,
			Parent = Inst,
		})
		]]
		--
	end

	function Library:CreateLabel(Properties, IsHud)
		local _Instance = Library:Create("TextLabel", {
			BackgroundTransparency = 1,
			FontFace = Library.Font,
			TextColor3 = Library.FontColor,
			TextSize = 16,
			TextStrokeTransparency = 0,
		})

		Library:ApplyTextStroke(_Instance)

		Library:AddToRegistry(_Instance, {
			TextColor3 = "FontColor",
		}, IsHud)

		if Properties.TextSize then
			Properties.TextSize = Properties.TextSize + 1
		end

		return Library:Create(_Instance, Properties)
	end

	function Library:MakeDraggable(Instance, Cutoff)
		Instance.Active = true

		Instance.InputBegan:Connect(function(Input)
			if Input.UserInputType == Enum.UserInputType.MouseButton1 then
				local ObjPos = Vector2.new(Mouse.X - Instance.AbsolutePosition.X, Mouse.Y - Instance.AbsolutePosition.Y)

				if ObjPos.Y > (Cutoff or 40) then
					return
				end

				while InputService:IsMouseButtonPressed(Enum.UserInputType.MouseButton1) do
					Instance.Position = UDim2.new(
						0,
						Mouse.X - ObjPos.X + (Instance.Size.X.Offset * Instance.AnchorPoint.X),
						0,
						Mouse.Y - ObjPos.Y + (Instance.Size.Y.Offset * Instance.AnchorPoint.Y)
					)

					RenderStepped:Wait()
				end
			end
		end)
	end

	function Library:AddToolTip(InfoStr, HoverInstance)
		local X, Y = Library:GetTextBounds(InfoStr, Library.Font, 14)
		local Tooltip = Library:Create("Frame", {
			BackgroundColor3 = Library.MainColor,
			BorderColor3 = Library.OutlineColor,

			Size = UDim2.fromOffset(X + 5, Y + 4),
			ZIndex = 100,
			Parent = Library.ScreenGui,

			Visible = false,
		})

		local Label = Library:CreateLabel({
			Position = UDim2.fromOffset(3, 1),
			Size = UDim2.fromOffset(X, Y),
			TextSize = 14,
			Text = InfoStr,
			TextColor3 = Library.FontColor,
			TextXAlignment = Enum.TextXAlignment.Left,
			ZIndex = Tooltip.ZIndex + 1,

			Parent = Tooltip,
		})

		Library:AddToRegistry(Tooltip, {
			BackgroundColor3 = "MainColor",
			BorderColor3 = "OutlineColor",
		})

		Library:AddToRegistry(Label, {
			TextColor3 = "FontColor",
		})

		Tooltips[#Tooltips + 1] = Tooltip

		local IsHovering = false

		HoverInstance.MouseEnter:Connect(function()
			if Library:MouseIsOverOpenedFrame() then
				return
			end

			IsHovering = true

			Tooltip.Position = UDim2.fromOffset(Mouse.X + 15, Mouse.Y + 12)
			Tooltip.Visible = true

			while IsHovering do
				RunService.Heartbeat:Wait()
				Tooltip.Position = UDim2.fromOffset(Mouse.X + 15, Mouse.Y + 12)
			end
		end)

		HoverInstance.MouseLeave:Connect(function()
			IsHovering = false
			Tooltip.Visible = false
		end)
	end

	function Library:OnHighlight(HighlightInstance, Instance, Properties, PropertiesDefault)
		HighlightInstance.MouseEnter:Connect(function()
			local Reg = Library.RegistryMap[Instance]

			for Property, ColorIdx in next, Properties do
				Instance[Property] = Library[ColorIdx] or ColorIdx

				if Reg and Reg.Properties[Property] then
					Reg.Properties[Property] = ColorIdx
				end
			end
		end)

		HighlightInstance.MouseLeave:Connect(function()
			local Reg = Library.RegistryMap[Instance]

			for Property, ColorIdx in next, PropertiesDefault do
				Instance[Property] = Library[ColorIdx] or ColorIdx

				if Reg and Reg.Properties[Property] then
					Reg.Properties[Property] = ColorIdx
				end
			end
		end)
	end

	function Library:MouseIsOverOpenedFrame()
		for Frame, _ in next, Library.OpenedFrames do
			local AbsPos, AbsSize = Frame.AbsolutePosition, Frame.AbsoluteSize

			if
				Mouse.X >= AbsPos.X
				and Mouse.X <= AbsPos.X + AbsSize.X
				and Mouse.Y >= AbsPos.Y
				and Mouse.Y <= AbsPos.Y + AbsSize.Y
			then
				return true
			end
		end
	end

	function Library:IsMouseOverFrame(Frame)
		local AbsPos, AbsSize = Frame.AbsolutePosition, Frame.AbsoluteSize

		if
			Mouse.X >= AbsPos.X
			and Mouse.X <= AbsPos.X + AbsSize.X
			and Mouse.Y >= AbsPos.Y
			and Mouse.Y <= AbsPos.Y + AbsSize.Y
		then
			return true
		end
	end

	function Library:UpdateDependencyBoxes()
		for _, Depbox in next, Library.DependencyBoxes do
			Depbox:Update()
		end
	end

	function Library:MapValue(Value, MinA, MaxA, MinB, MaxB)
		return (1 - ((Value - MinA) / (MaxA - MinA))) * MinB + ((Value - MinA) / (MaxA - MinA)) * MaxB
	end

	function Library:GetTextBounds(Text, Font, Size, Resolution)
		local Bounds = TextService:GetTextSize(Text, Size, "RobotoMono", Resolution or Vector2.new(1920, 1080))
		return Bounds.X, Bounds.Y
	end

	function Library:GetDarkerColor(Color)
		local H, S, V = Color3.toHSV(Color)
		return Color3.fromHSV(H, S, V / 1.5)
	end
	Library.AccentColorDark = Library:GetDarkerColor(Library.AccentColor)

	function Library:AddToRegistry(Instance, Properties, IsHud)
		local Idx = #Library.Registry + 1
		local Data = {
			Instance = Instance,
			Properties = Properties,
			Idx = Idx,
		}

		table.insert(Library.Registry, Data)
		Library.RegistryMap[Instance] = Data

		if IsHud then
			table.insert(Library.HudRegistry, Data)
		end
	end

	function Library:RemoveFromRegistry(Instance)
		local Data = Library.RegistryMap[Instance]

		if Data then
			for Idx = #Library.Registry, 1, -1 do
				if Library.Registry[Idx] == Data then
					table.remove(Library.Registry, Idx)
				end
			end

			for Idx = #Library.HudRegistry, 1, -1 do
				if Library.HudRegistry[Idx] == Data then
					table.remove(Library.HudRegistry, Idx)
				end
			end

			Library.RegistryMap[Instance] = nil
		end
	end

	function Library:UpdateColorsUsingRegistry()
		-- TODO: Could have an 'active' list of objects
		-- where the active list only contains Visible objects.

		-- IMPL: Could setup .Changed events on the AddToRegistry function
		-- that listens for the 'Visible' propert being changed.
		-- Visible: true => Add to active list, and call UpdateColors function
		-- Visible: false => Remove from active list.

		-- The above would be especially efficient for a rainbow menu color or live color-changing.

		for Idx, Object in next, Library.Registry do
			for Property, ColorIdx in next, Object.Properties do
				if type(ColorIdx) == "string" then
					Object.Instance[Property] = Library[ColorIdx]
				elseif type(ColorIdx) == "function" then
					Object.Instance[Property] = ColorIdx()
				end
			end
		end
	end

	function Library:GiveSignal(Signal)
		-- Only used for signals not attached to library instances, as those should be cleaned up on object destruction by Roblox
		table.insert(Library.Signals, Signal)
	end

	function Library:Unload()
		-- Unload all of the signals
		for Idx = #Library.Signals, 1, -1 do
			local Connection = table.remove(Library.Signals, Idx)
			Connection:Disconnect()
		end

		-- Call our unload callback, maybe to undo some hooks etc
		if Library.OnUnload then
			Library.OnUnload()
		end

		ScreenGui:Destroy()
	end

	function Library:OnUnload(Callback)
		Library.OnUnload = Callback
	end

	Library:GiveSignal(ScreenGui.DescendantRemoving:Connect(function(Instance)
		if Library.RegistryMap[Instance] then
			Library:RemoveFromRegistry(Instance)
		end
	end))

	local BaseAddons = {}

	do
		local Funcs = {}

		function Funcs:AddColorPicker(Idx, Info)
			local ToggleLabel = self.TextLabel
			-- local Container = self.Container;

			assert(Info.Default, "AddColorPicker: Missing default value.")

			local ColorPicker = {
				Value = Info.Default,
				Transparency = Info.Transparency or 0,
				Type = "ColorPicker",
				Title = type(Info.Title) == "string" and Info.Title or "Color picker",
				Callback = Info.Callback or function(Color) end,
				Rainbow = Info.Rainbow or false,
			}

			function ColorPicker:SetHSVFromRGB(Color)
				local H, S, V = Color3.toHSV(Color)

				ColorPicker.Hue = H
				ColorPicker.Sat = S
				ColorPicker.Vib = V
			end

			ColorPicker:SetHSVFromRGB(ColorPicker.Value)

			local DisplayFrame = Library:Create("Frame", {
				BackgroundColor3 = ColorPicker.Value,
				BorderColor3 = Library:GetDarkerColor(ColorPicker.Value),
				BorderMode = Enum.BorderMode.Inset,
				Size = UDim2.new(0, 28, 0, 14),
				ZIndex = 6,
				Parent = ToggleLabel,
			})

			-- Transparency image taken from https://github.com/matas3535/SplixPrivateDrawingLibrary/blob/main/Library.lua cus i'm lazy
			local CheckerFrame = Library:Create("ImageLabel", {
				BorderSizePixel = 0,
				Size = UDim2.new(0, 27, 0, 13),
				ZIndex = 5,
				Image = "http://www.roblox.com/asset/?id=12977615774",
				Visible = not not Info.Transparency,
				Parent = DisplayFrame,
			})

			-- 1/16/23
			-- Rewrote this to be placed inside the Library ScreenGui
			-- There was some issue which caused RelativeOffset to be way off
			-- Thus the color picker would never show

			local PickerFrameOuter = Library:Create("Frame", {
				BackgroundColor3 = Color3.new(1, 1, 1),
				BorderColor3 = Color3.new(0, 0, 0),
				Position = UDim2.fromOffset(DisplayFrame.AbsolutePosition.X, DisplayFrame.AbsolutePosition.Y + 18),
				Size = UDim2.fromOffset(230, Info.Transparency and 271 or 253),
				Visible = false,
				ZIndex = 15,
				Parent = ScreenGui,
			})

			DisplayFrame:GetPropertyChangedSignal("AbsolutePosition"):Connect(function()
				PickerFrameOuter.Position =
					UDim2.fromOffset(DisplayFrame.AbsolutePosition.X, DisplayFrame.AbsolutePosition.Y + 18)
			end)

			local PickerFrameInner = Library:Create("Frame", {
				BackgroundColor3 = Library.BackgroundColor,
				BorderColor3 = Library.OutlineColor,
				BorderMode = Enum.BorderMode.Inset,
				Size = UDim2.new(1, 0, 1, 0),
				ZIndex = 16,
				Parent = PickerFrameOuter,
			})

			local Highlight = Library:Create("Frame", {
				BackgroundColor3 = Library.AccentColor,
				BorderSizePixel = 0,
				Size = UDim2.new(1, 0, 0, 2),
				ZIndex = 17,
				Parent = PickerFrameInner,
			})

			local SatVibMapOuter = Library:Create("Frame", {
				BorderColor3 = Color3.new(0, 0, 0),
				Position = UDim2.new(0, 4, 0, 25),
				Size = UDim2.new(0, 200, 0, 200),
				ZIndex = 17,
				Parent = PickerFrameInner,
			})

			local SatVibMapInner = Library:Create("Frame", {
				BackgroundColor3 = Library.BackgroundColor,
				BorderColor3 = Library.OutlineColor,
				BorderMode = Enum.BorderMode.Inset,
				Size = UDim2.new(1, 0, 1, 0),
				ZIndex = 18,
				Parent = SatVibMapOuter,
			})

			local SatVibMap = Library:Create("ImageLabel", {
				BorderSizePixel = 0,
				Size = UDim2.new(1, 0, 1, 0),
				ZIndex = 18,
				Image = "rbxassetid://4155801252",
				Parent = SatVibMapInner,
			})

			local CursorOuter = Library:Create("ImageLabel", {
				AnchorPoint = Vector2.new(0.5, 0.5),
				Size = UDim2.new(0, 6, 0, 6),
				BackgroundTransparency = 1,
				Image = "http://www.roblox.com/asset/?id=9619665977",
				ImageColor3 = Color3.new(0, 0, 0),
				ZIndex = 19,
				Parent = SatVibMap,
			})

			local CursorInner = Library:Create("ImageLabel", {
				Size = UDim2.new(0, CursorOuter.Size.X.Offset - 2, 0, CursorOuter.Size.Y.Offset - 2),
				Position = UDim2.new(0, 1, 0, 1),
				BackgroundTransparency = 1,
				Image = "http://www.roblox.com/asset/?id=9619665977",
				ZIndex = 20,
				Parent = CursorOuter,
			})

			local HueSelectorOuter = Library:Create("Frame", {
				BorderColor3 = Color3.new(0, 0, 0),
				Position = UDim2.new(0, 208, 0, 25),
				Size = UDim2.new(0, 15, 0, 200),
				ZIndex = 17,
				Parent = PickerFrameInner,
			})

			local HueSelectorInner = Library:Create("Frame", {
				BackgroundColor3 = Color3.new(1, 1, 1),
				BorderSizePixel = 0,
				Size = UDim2.new(1, 0, 1, 0),
				ZIndex = 18,
				Parent = HueSelectorOuter,
			})

			local HueCursor = Library:Create("Frame", {
				BackgroundColor3 = Color3.new(1, 1, 1),
				AnchorPoint = Vector2.new(0, 0.5),
				BorderColor3 = Color3.new(0, 0, 0),
				Size = UDim2.new(1, 0, 0, 1),
				ZIndex = 18,
				Parent = HueSelectorInner,
			})

			local HueBoxOuter = Library:Create("Frame", {
				BorderColor3 = Color3.new(0, 0, 0),
				Position = UDim2.fromOffset(4, 228),
				Size = UDim2.new(0.5, -6, 0, 20),
				ZIndex = 18,
				Parent = PickerFrameInner,
			})

			local HueBoxInner = Library:Create("Frame", {
				BackgroundColor3 = Library.MainColor,
				BorderColor3 = Library.OutlineColor,
				BorderMode = Enum.BorderMode.Inset,
				Size = UDim2.new(1, 0, 1, 0),
				ZIndex = 18,
				Parent = HueBoxOuter,
			})

			Library:Create("UIGradient", {
				Color = ColorSequence.new({
					ColorSequenceKeypoint.new(0, Color3.new(1, 1, 1)),
					ColorSequenceKeypoint.new(1, Color3.fromRGB(212, 212, 212)),
				}),
				Rotation = 90,
				Parent = HueBoxInner,
			})

			local HueBox = Library:Create("TextBox", {
				BackgroundTransparency = 1,
				Position = UDim2.new(0, 5, 0, 0),
				Size = UDim2.new(1, -5, 1, 0),
				FontFace = Library.Font,
				PlaceholderColor3 = Color3.fromRGB(190, 190, 190),
				PlaceholderText = "Hex color",
				Text = "#FFFFFF",
				TextColor3 = Library.FontColor,
				TextSize = 14,
				TextStrokeTransparency = 0,
				TextXAlignment = Enum.TextXAlignment.Left,
				ZIndex = 20,
				Parent = HueBoxInner,
			})

			Library:ApplyTextStroke(HueBox)

			local RgbBoxBase = Library:Create(HueBoxOuter:Clone(), {
				Position = UDim2.new(0.5, 2, 0, 228),
				Size = UDim2.new(0.5, -6, 0, 20),
				Parent = PickerFrameInner,
			})

			local RgbBox = Library:Create(RgbBoxBase.Frame:FindFirstChild("TextBox"), {
				Text = "255, 255, 255",
				PlaceholderText = "RGB color",
				TextColor3 = Library.FontColor,
			})

			local TransparencyBoxOuter, TransparencyBoxInner, TransparencyCursor

			if Info.Transparency then
				TransparencyBoxOuter = Library:Create("Frame", {
					BorderColor3 = Color3.new(0, 0, 0),
					Position = UDim2.fromOffset(4, 251),
					Size = UDim2.new(1, -8, 0, 15),
					ZIndex = 19,
					Parent = PickerFrameInner,
				})

				TransparencyBoxInner = Library:Create("Frame", {
					BackgroundColor3 = ColorPicker.Value,
					BorderColor3 = Library.OutlineColor,
					BorderMode = Enum.BorderMode.Inset,
					Size = UDim2.new(1, 0, 1, 0),
					ZIndex = 19,
					Parent = TransparencyBoxOuter,
				})

				Library:AddToRegistry(TransparencyBoxInner, { BorderColor3 = "OutlineColor" })

				Library:Create("ImageLabel", {
					BackgroundTransparency = 1,
					Size = UDim2.new(1, 0, 1, 0),
					Image = "http://www.roblox.com/asset/?id=12978095818",
					ZIndex = 20,
					Parent = TransparencyBoxInner,
				})

				TransparencyCursor = Library:Create("Frame", {
					BackgroundColor3 = Color3.new(1, 1, 1),
					AnchorPoint = Vector2.new(0.5, 0),
					BorderColor3 = Color3.new(0, 0, 0),
					Size = UDim2.new(0, 1, 1, 0),
					ZIndex = 21,
					Parent = TransparencyBoxInner,
				})
			end

			local DisplayLabel = Library:CreateLabel({
				Size = UDim2.new(1, 0, 0, 14),
				Position = UDim2.fromOffset(5, 5),
				TextXAlignment = Enum.TextXAlignment.Left,
				TextSize = 14,
				Text = ColorPicker.Title, --Info.Default;
				TextWrapped = false,
				ZIndex = 16,
				Parent = PickerFrameInner,
			})

			local ContextMenu = {}
			do
				ContextMenu.Options = {}
				ContextMenu.Container = Library:Create("Frame", {
					BorderColor3 = Color3.new(),
					ZIndex = 14,
					Visible = false,
					Parent = ScreenGui,
				})

				ContextMenu.Inner = Library:Create("Frame", {
					BackgroundColor3 = Library.BackgroundColor,
					BorderColor3 = Library.OutlineColor,
					BorderMode = Enum.BorderMode.Inset,
					Size = UDim2.fromScale(1, 1),
					ZIndex = 15,
					Parent = ContextMenu.Container,
				})

				ContextMenus[#ContextMenus + 1] = ContextMenu

				Library:Create("UIListLayout", {
					Name = "Layout",
					FillDirection = Enum.FillDirection.Vertical,
					SortOrder = Enum.SortOrder.LayoutOrder,
					Parent = ContextMenu.Inner,
				})

				Library:Create("UIPadding", {
					Name = "Padding",
					PaddingLeft = UDim.new(0, 4),
					Parent = ContextMenu.Inner,
				})

				local function updateMenuPosition()
					ContextMenu.Container.Position = UDim2.fromOffset(
						(DisplayFrame.AbsolutePosition.X + DisplayFrame.AbsoluteSize.X) + 4,
						DisplayFrame.AbsolutePosition.Y + 1
					)
				end

				local function updateMenuSize()
					local menuWidth = 60
					for i, label in next, ContextMenu.Inner:GetChildren() do
						if label:IsA("TextLabel") then
							menuWidth = math.max(menuWidth, label.TextBounds.X)
						end
					end

					ContextMenu.Container.Size =
						UDim2.fromOffset(menuWidth + 8, ContextMenu.Inner.Layout.AbsoluteContentSize.Y + 4)
				end

				DisplayFrame:GetPropertyChangedSignal("AbsolutePosition"):Connect(updateMenuPosition)
				ContextMenu.Inner.Layout:GetPropertyChangedSignal("AbsoluteContentSize"):Connect(updateMenuSize)

				task.spawn(updateMenuPosition)
				task.spawn(updateMenuSize)

				Library:AddToRegistry(ContextMenu.Inner, {
					BackgroundColor3 = "BackgroundColor",
					BorderColor3 = "OutlineColor",
				})

				function ContextMenu:Show()
					self.Container.Visible = true
				end

				function ContextMenu:Hide()
					self.Container.Visible = false
				end

				function ContextMenu:AddOption(Str, Callback)
					if type(Callback) ~= "function" then
						Callback = function() end
					end

					local Button = Library:CreateLabel({
						Active = false,
						Size = UDim2.new(1, 0, 0, 15),
						TextSize = 13,
						Text = Str,
						ZIndex = 16,
						Parent = self.Inner,
						TextXAlignment = Enum.TextXAlignment.Left,
					})

					Library:OnHighlight(Button, Button, { TextColor3 = "AccentColor" }, { TextColor3 = "FontColor" })

					Button.InputBegan:Connect(function(Input)
						if Input.UserInputType ~= Enum.UserInputType.MouseButton1 then
							return
						end

						Callback()
					end)
				end

				ContextMenu:AddOption("Rainbow toggle", function()
					ColorPicker.Rainbow = not ColorPicker.Rainbow
					ColorPicker:Display()
				end)

				ContextMenu:AddOption("Copy color", function()
					Library.ColorClipboard = ColorPicker.Value
					Library:Notify("Copied color!", 2)
				end)

				ContextMenu:AddOption("Paste color", function()
					if not Library.ColorClipboard then
						return Library:Notify("You have not copied a color!", 2)
					end
					ColorPicker:SetValueRGB(Library.ColorClipboard)
				end)

				ContextMenu:AddOption("Copy HEX", function()
					pcall(setclipboard, ColorPicker.Value:ToHex())
					Library:Notify("Copied hex code to clipboard!", 2)
				end)

				ContextMenu:AddOption("Copy RGB", function()
					pcall(
						setclipboard,
						table.concat({
							math.floor(ColorPicker.Value.R * 255),
							math.floor(ColorPicker.Value.G * 255),
							math.floor(ColorPicker.Value.B * 255),
						}, ", ")
					)
					Library:Notify("Copied RGB values to clipboard!", 2)
				end)
			end

			Library:AddToRegistry(
				PickerFrameInner,
				{ BackgroundColor3 = "BackgroundColor", BorderColor3 = "OutlineColor" }
			)
			Library:AddToRegistry(Highlight, { BackgroundColor3 = "AccentColor" })
			Library:AddToRegistry(
				SatVibMapInner,
				{ BackgroundColor3 = "BackgroundColor", BorderColor3 = "OutlineColor" }
			)

			Library:AddToRegistry(HueBoxInner, { BackgroundColor3 = "MainColor", BorderColor3 = "OutlineColor" })
			Library:AddToRegistry(RgbBoxBase.Frame, { BackgroundColor3 = "MainColor", BorderColor3 = "OutlineColor" })
			Library:AddToRegistry(RgbBox, { TextColor3 = "FontColor" })
			Library:AddToRegistry(HueBox, { TextColor3 = "FontColor" })

			local SequenceTable = {}

			for Hue = 0, 1, 0.1 do
				table.insert(SequenceTable, ColorSequenceKeypoint.new(Hue, Color3.fromHSV(Hue, 1, 1)))
			end

			local HueSelectorGradient = Library:Create("UIGradient", {
				Color = ColorSequence.new(SequenceTable),
				Rotation = 90,
				Parent = HueSelectorInner,
			})

			HueBox.FocusLost:Connect(function(enter)
				if enter then
					local success, result = pcall(Color3.fromHex, HueBox.Text)
					if success and typeof(result) == "Color3" then
						ColorPicker.Hue, ColorPicker.Sat, ColorPicker.Vib = Color3.toHSV(result)
					end
				end

				ColorPicker:Display()
			end)

			RgbBox.FocusLost:Connect(function(enter)
				if enter then
					local r, g, b = RgbBox.Text:match("(%d+),%s*(%d+),%s*(%d+)")
					if r and g and b then
						ColorPicker.Hue, ColorPicker.Sat, ColorPicker.Vib = Color3.toHSV(Color3.fromRGB(r, g, b))
					end
				end

				ColorPicker:Display()
			end)

			function ColorPicker:Display()
				if ColorPicker.Rainbow then
					RainbowColorPickers[ColorPicker] = true
				else
					RainbowColorPickers[ColorPicker] = nil
				end

				ColorPicker.Value = Color3.fromHSV(ColorPicker.Hue, ColorPicker.Sat, ColorPicker.Vib)
				SatVibMap.BackgroundColor3 = Color3.fromHSV(ColorPicker.Hue, 1, 1)

				if ColorPicker.Rainbow then
					ColorPicker.Value = Library.CurrentRainbowColor
				end

				Library:Create(DisplayFrame, {
					BackgroundColor3 = ColorPicker.Value,
					BackgroundTransparency = ColorPicker.Transparency,
					BorderColor3 = Library:GetDarkerColor(ColorPicker.Value),
				})

				if TransparencyBoxInner then
					TransparencyBoxInner.BackgroundColor3 = ColorPicker.Value
					TransparencyCursor.Position = UDim2.new(1 - ColorPicker.Transparency, 0, 0, 0)
				end

				CursorOuter.Position = UDim2.new(ColorPicker.Sat, 0, 1 - ColorPicker.Vib, 0)
				HueCursor.Position = UDim2.new(0, 0, ColorPicker.Hue, 0)

				HueBox.Text = "#" .. ColorPicker.Value:ToHex()
				RgbBox.Text = table.concat({
					math.floor(ColorPicker.Value.R * 255),
					math.floor(ColorPicker.Value.G * 255),
					math.floor(ColorPicker.Value.B * 255),
				}, ", ")

				Library:SafeCallback(
					"ColorPicker_Callback" .. "_" .. (Idx or ""),
					ColorPicker.Callback,
					ColorPicker.Value
				)
				Library:SafeCallback(
					"ColorPicker_Changed" .. "_" .. (Idx or ""),
					ColorPicker.Changed,
					ColorPicker.Value
				)
			end

			function ColorPicker:OnChanged(Func)
				ColorPicker.Changed = Func
				Func(ColorPicker.Value)
			end

			function ColorPicker:Show()
				for Frame, Val in next, Library.OpenedFrames do
					if Frame.Name == "Color" then
						Frame.Visible = false
						Library.OpenedFrames[Frame] = nil
					end
				end

				PickerFrameOuter.Visible = true
				Library.OpenedFrames[PickerFrameOuter] = true
			end

			function ColorPicker:Hide()
				PickerFrameOuter.Visible = false
				Library.OpenedFrames[PickerFrameOuter] = nil
			end

			function ColorPicker:SetValue(HSV, Transparency)
				local Color = Color3.fromHSV(HSV[1], HSV[2], HSV[3])

				ColorPicker.Transparency = Transparency or 0
				ColorPicker:SetHSVFromRGB(Color)
				ColorPicker:Display()
			end

			function ColorPicker:SetValueRGB(Color, Transparency)
				ColorPicker.Transparency = Transparency or 0
				ColorPicker:SetHSVFromRGB(Color)
				ColorPicker:Display()
			end

			SatVibMap.InputBegan:Connect(function(Input)
				if Input.UserInputType == Enum.UserInputType.MouseButton1 then
					while InputService:IsMouseButtonPressed(Enum.UserInputType.MouseButton1) do
						local MinX = SatVibMap.AbsolutePosition.X
						local MaxX = MinX + SatVibMap.AbsoluteSize.X
						local MouseX = math.clamp(Mouse.X, MinX, MaxX)

						local MinY = SatVibMap.AbsolutePosition.Y
						local MaxY = MinY + SatVibMap.AbsoluteSize.Y
						local MouseY = math.clamp(Mouse.Y, MinY, MaxY)

						ColorPicker.Sat = (MouseX - MinX) / (MaxX - MinX)
						ColorPicker.Vib = 1 - ((MouseY - MinY) / (MaxY - MinY))
						ColorPicker:Display()

						RenderStepped:Wait()
					end

					Library:AttemptSave()
				end
			end)

			HueSelectorInner.InputBegan:Connect(function(Input)
				if Input.UserInputType == Enum.UserInputType.MouseButton1 then
					while InputService:IsMouseButtonPressed(Enum.UserInputType.MouseButton1) do
						local MinY = HueSelectorInner.AbsolutePosition.Y
						local MaxY = MinY + HueSelectorInner.AbsoluteSize.Y
						local MouseY = math.clamp(Mouse.Y, MinY, MaxY)

						ColorPicker.Hue = ((MouseY - MinY) / (MaxY - MinY))
						ColorPicker:Display()

						RenderStepped:Wait()
					end

					Library:AttemptSave()
				end
			end)

			DisplayFrame.InputBegan:Connect(function(Input)
				if Input.UserInputType == Enum.UserInputType.MouseButton1 and not Library:MouseIsOverOpenedFrame() then
					if PickerFrameOuter.Visible then
						ColorPicker:Hide()
					else
						ContextMenu:Hide()
						ColorPicker:Show()
					end
				elseif
					Input.UserInputType == Enum.UserInputType.MouseButton2 and not Library:MouseIsOverOpenedFrame()
				then
					ContextMenu:Show()
					ColorPicker:Hide()
				end
			end)

			if TransparencyBoxInner then
				TransparencyBoxInner.InputBegan:Connect(function(Input)
					if Input.UserInputType == Enum.UserInputType.MouseButton1 then
						while InputService:IsMouseButtonPressed(Enum.UserInputType.MouseButton1) do
							local MinX = TransparencyBoxInner.AbsolutePosition.X
							local MaxX = MinX + TransparencyBoxInner.AbsoluteSize.X
							local MouseX = math.clamp(Mouse.X, MinX, MaxX)

							ColorPicker.Transparency = 1 - ((MouseX - MinX) / (MaxX - MinX))

							ColorPicker:Display()

							RenderStepped:Wait()
						end

						Library:AttemptSave()
					end
				end)
			end

			Library:GiveSignal(InputService.InputBegan:Connect(function(Input)
				if Input.UserInputType == Enum.UserInputType.MouseButton1 then
					local AbsPos, AbsSize = PickerFrameOuter.AbsolutePosition, PickerFrameOuter.AbsoluteSize

					if
						Mouse.X < AbsPos.X
						or Mouse.X > AbsPos.X + AbsSize.X
						or Mouse.Y < (AbsPos.Y - 20 - 1)
						or Mouse.Y > AbsPos.Y + AbsSize.Y
					then
						ColorPicker:Hide()
					end

					if not Library:IsMouseOverFrame(ContextMenu.Container) then
						ContextMenu:Hide()
					end
				end

				if Input.UserInputType == Enum.UserInputType.MouseButton2 and ContextMenu.Container.Visible then
					if
						not Library:IsMouseOverFrame(ContextMenu.Container)
						and not Library:IsMouseOverFrame(DisplayFrame)
					then
						ContextMenu:Hide()
					end
				end
			end))

			ColorPicker:Display()
			ColorPicker.DisplayFrame = DisplayFrame

			if Idx then
				Options[Idx] = ColorPicker
				ColorPickers[Idx] = ColorPicker
			end

			return self
		end

		function Funcs:AddKeyPicker(Idx, Info)
			local ParentObj = self
			local ToggleLabel = self.TextLabel
			local Container = self.Container

			assert(Info.Default, "AddKeyPicker: Missing default value.")

			local KeyPicker = {
				Value = Info.Default,
				Toggled = false,
				Mode = Info.Mode or "Toggle", -- Always, Toggle, Hold
				Type = "KeyPicker",
				Callback = Info.Callback or function(Value) end,
				ChangedCallback = Info.ChangedCallback or function(New) end,
				SyncToggleState = Info.SyncToggleState or false,
			}

			if KeyPicker.SyncToggleState then
				Info.Modes = { "Toggle", "Hold" }
				Info.Mode = "Toggle"
			end

			local PickOuter = Library:Create("Frame", {
				BackgroundColor3 = Color3.new(0, 0, 0),
				BorderColor3 = Color3.new(0, 0, 0),
				Size = UDim2.new(0, 28, 0, 15),
				ZIndex = 6,
				Parent = ToggleLabel,
			})

			local PickInner = Library:Create("Frame", {
				BackgroundColor3 = Library.BackgroundColor,
				BorderColor3 = Library.OutlineColor,
				BorderMode = Enum.BorderMode.Inset,
				Size = UDim2.new(1, 0, 1, 0),
				ZIndex = 7,
				Parent = PickOuter,
			})

			Library:AddToRegistry(PickInner, {
				BackgroundColor3 = "BackgroundColor",
				BorderColor3 = "OutlineColor",
			})

			local DisplayLabel = Library:CreateLabel({
				Size = UDim2.new(1, 0, 1, 0),
				TextSize = 13,
				Text = Info.Default,
				TextWrapped = true,
				ZIndex = 8,
				Parent = PickInner,
			})

			local ModeSelectOuter = Library:Create("Frame", {
				BorderColor3 = Color3.new(0, 0, 0),
				Position = UDim2.fromOffset(
					ToggleLabel.AbsolutePosition.X + ToggleLabel.AbsoluteSize.X + 4,
					ToggleLabel.AbsolutePosition.Y + 1
				),
				Size = UDim2.new(0, 60, 0, 60 + 2),
				Visible = false,
				ZIndex = 14,
				Parent = ScreenGui,
			})

			ModeSelectFrames[#ModeSelectFrames + 1] = ModeSelectOuter

			ToggleLabel:GetPropertyChangedSignal("AbsolutePosition"):Connect(function()
				ModeSelectOuter.Position = UDim2.fromOffset(
					ToggleLabel.AbsolutePosition.X + ToggleLabel.AbsoluteSize.X + 4,
					ToggleLabel.AbsolutePosition.Y + 1
				)
			end)

			local ModeSelectInner = Library:Create("Frame", {
				BackgroundColor3 = Library.BackgroundColor,
				BorderColor3 = Library.OutlineColor,
				BorderMode = Enum.BorderMode.Inset,
				Size = UDim2.new(1, 0, 1, 0),
				ZIndex = 15,
				Parent = ModeSelectOuter,
			})

			Library:AddToRegistry(ModeSelectInner, {
				BackgroundColor3 = "BackgroundColor",
				BorderColor3 = "OutlineColor",
			})

			Library:Create("UIListLayout", {
				FillDirection = Enum.FillDirection.Vertical,
				SortOrder = Enum.SortOrder.LayoutOrder,
				Parent = ModeSelectInner,
			})

			local ContainerLabel = Library:CreateLabel({
				TextXAlignment = Enum.TextXAlignment.Left,
				Size = UDim2.new(1, 0, 0, 18),
				TextSize = 13,
				Visible = false,
				ZIndex = 110,
				Parent = Library.KeybindContainer,
			}, true)

			local Modes = Info.Modes or { "Always", "Toggle", "Hold", "Off" }
			local ModeButtons = {}

			function KeyPicker:DoClick()
				if ParentObj.Type == "Toggle" and KeyPicker.SyncToggleState then
					ParentObj:SetValue(not ParentObj.Value)
				end

				Library:SafeCallback("KeyPicker_Callback" .. "_" .. (Idx or ""), KeyPicker.Callback, KeyPicker.Toggled)
				Library:SafeCallback("KeyPicker_Clicked" .. "_" .. (Idx or ""), KeyPicker.Clicked, KeyPicker.Toggled)
			end

			for Idx, Mode in next, Modes do
				local ModeButton = {}

				local Label = Library:CreateLabel({
					Active = false,
					Size = UDim2.new(1, 0, 0, 15),
					TextSize = 13,
					Text = Mode,
					ZIndex = 16,
					Parent = ModeSelectInner,
				})

				function ModeButton:Select()
					for _, Button in next, ModeButtons do
						Button:Deselect()
					end

					if Mode == "Always" then
						KeyPicker.Toggled = true
						KeyPicker:DoClick()
					end

					if Mode == "Off" then
						KeyPicker.Toggled = false
						KeyPicker:DoClick()
					end

					KeyPicker.Mode = Mode

					Label.TextColor3 = Library.AccentColor
					Library.RegistryMap[Label].Properties.TextColor3 = "AccentColor"

					ModeSelectOuter.Visible = false
				end

				function ModeButton:Deselect()
					KeyPicker.Mode = nil

					Label.TextColor3 = Library.FontColor
					Library.RegistryMap[Label].Properties.TextColor3 = "FontColor"
				end

				Label.InputBegan:Connect(function(Input)
					if Input.UserInputType == Enum.UserInputType.MouseButton1 then
						ModeButton:Select()
						Library:AttemptSave()
					end
				end)

				if Mode == KeyPicker.Mode then
					ModeButton:Select()
				end

				ModeButtons[Mode] = ModeButton
			end

			function KeyPicker:Update()
				if Info.NoUI then
					return
				end

				local State = KeyPicker:GetState()

				ContainerLabel.Text = string.format("[%s] %s (%s)", KeyPicker.Value, Info.Text, KeyPicker.Mode)

				ContainerLabel.Visible = true
				ContainerLabel.TextColor3 = State and Library.AccentColor or Library.FontColor

				Library.RegistryMap[ContainerLabel].Properties.TextColor3 = State and "AccentColor" or "FontColor"

				local YSize = 0
				local XSize = 0

				for _, Label in next, Library.KeybindContainer:GetChildren() do
					if Label:IsA("TextLabel") and Label.Visible then
						YSize = YSize + 18
						if Label.TextBounds.X > XSize then
							XSize = Label.TextBounds.X
						end
					end
				end

				Library.KeybindFrame.Size = UDim2.new(0, math.max(XSize + 10, 210), 0, YSize + 23)
			end

			function KeyPicker:GetState()
				if KeyPicker.Mode == "Always" then
					return true
				elseif KeyPicker.Mode == "Off" then
					return false
				elseif KeyPicker.Mode == "Hold" then
					if KeyPicker.Value == "None" then
						return false
					end

					local Key = KeyPicker.Value

					if Key == "MB1" or Key == "MB2" then
						return Key == "MB1" and InputService:IsMouseButtonPressed(Enum.UserInputType.MouseButton1)
							or Key == "MB2" and InputService:IsMouseButtonPressed(Enum.UserInputType.MouseButton2)
					else
						return InputService:IsKeyDown(Enum.KeyCode[KeyPicker.Value])
					end
				else
					return KeyPicker.Toggled
				end
			end

			function KeyPicker:SetValue(Data)
				local Key, Mode = Data[1], Data[2]
				DisplayLabel.Text = Key
				KeyPicker.Value = Key
				ModeButtons[Mode]:Select()
				KeyPicker:Update()
			end

			function KeyPicker:OnClick(Callback)
				KeyPicker.Clicked = Callback
			end

			function KeyPicker:OnChanged(Callback)
				KeyPicker.Changed = Callback
				Callback(KeyPicker.Value)
			end

			if ParentObj.Addons then
				table.insert(ParentObj.Addons, KeyPicker)
			end

			local Picking = false

			PickOuter.InputBegan:Connect(function(Input)
				if Input.UserInputType == Enum.UserInputType.MouseButton1 and not Library:MouseIsOverOpenedFrame() then
					Picking = true

					DisplayLabel.Text = ""

					local Break
					local Text = ""

					task.spawn(function()
						while not Break do
							if Text == "..." then
								Text = ""
							end

							Text = Text .. "."
							DisplayLabel.Text = Text

							wait(0.4)
						end
					end)

					wait(0.2)

					local Event
					Event = InputService.InputBegan:Connect(function(Input)
						local Key

						if Input.UserInputType == Enum.UserInputType.Keyboard then
							Key = Input.KeyCode.Name
						elseif Input.UserInputType == Enum.UserInputType.MouseButton1 then
							Key = "MB1"
						elseif Input.UserInputType == Enum.UserInputType.MouseButton2 then
							Key = "MB2"
						end

						if Input.KeyCode == Enum.KeyCode.Escape or Input.KeyCode == Enum.KeyCode.Backspace then
							Key = "N/A"
						end

						Break = true
						Picking = false

						DisplayLabel.Text = Key
						KeyPicker.Value = Key

						Library:SafeCallback(
							"KeyPicker_ChangedCallback" .. "_" .. (Idx or ""),
							KeyPicker.ChangedCallback,
							Input.KeyCode or Input.UserInputType
						)

						Library:SafeCallback(
							"KeyPicker_Changed" .. "_" .. (Idx or ""),
							KeyPicker.Changed,
							Input.KeyCode or Input.UserInputType
						)

						Library:AttemptSave()

						Event:Disconnect()
					end)
				elseif
					Input.UserInputType == Enum.UserInputType.MouseButton2 and not Library:MouseIsOverOpenedFrame()
				then
					ModeSelectOuter.Visible = true
				end
			end)

			Library:GiveSignal(InputService.InputBegan:Connect(function(Input, ProcessedByGame)
				if ProcessedByGame then
					return
				end

				if not Picking then
					if KeyPicker.Mode == "Toggle" then
						local Key = KeyPicker.Value

						if Key == "MB1" or Key == "MB2" then
							if
								Key == "MB1" and Input.UserInputType == Enum.UserInputType.MouseButton1
								or Key == "MB2" and Input.UserInputType == Enum.UserInputType.MouseButton2
							then
								KeyPicker.Toggled = not KeyPicker.Toggled
								KeyPicker:DoClick()
							end
						elseif Input.UserInputType == Enum.UserInputType.Keyboard then
							if Input.KeyCode.Name == Key then
								KeyPicker.Toggled = not KeyPicker.Toggled
								KeyPicker:DoClick()
							end
						end
					end

					KeyPicker:Update()
				end

				if Input.UserInputType == Enum.UserInputType.MouseButton1 then
					local AbsPos, AbsSize = ModeSelectOuter.AbsolutePosition, ModeSelectOuter.AbsoluteSize

					if
						Mouse.X < AbsPos.X
						or Mouse.X > AbsPos.X + AbsSize.X
						or Mouse.Y < (AbsPos.Y - 20 - 1)
						or Mouse.Y > AbsPos.Y + AbsSize.Y
					then
						ModeSelectOuter.Visible = false
					end
				end
			end))

			Library:GiveSignal(InputService.InputEnded:Connect(function(Input, ProcessedByGame)
				if ProcessedByGame then
					return
				end

				if not Picking then
					KeyPicker:Update()
				end
			end))

			if Info.Mode == "Always" then
				KeyPicker.Toggled = true
				KeyPicker:DoClick()
			end

			if Info.Mode == "Off" then
				KeyPicker.Toggled = false
				KeyPicker:DoClick()
			end

			KeyPicker:Update()

			if Idx then
				Options[Idx] = KeyPicker
			end

			return self
		end

		BaseAddons.__index = Funcs
		BaseAddons.__namecall = function(Table, Key, ...)
			return Funcs[Key](...)
		end
	end

	local BaseGroupbox = {}

	do
		local Funcs = {}

		function Funcs:AddBlank(Size)
			local Groupbox = self
			local Container = Groupbox.Container

			Library:Create("Frame", {
				BackgroundTransparency = 1,
				Size = UDim2.new(1, 0, 0, Size),
				ZIndex = 1,
				Parent = Container,
			})
		end

		function Funcs:AddLabel(Text, DoesWrap)
			local Label = {}

			local Groupbox = self
			local Container = Groupbox.Container

			local TextLabel = Library:CreateLabel({
				Size = UDim2.new(1, -4, 0, 15),
				TextSize = 14,
				Text = Text,
				TextWrapped = DoesWrap or false,
				TextXAlignment = Enum.TextXAlignment.Left,
				ZIndex = 5,
				Parent = Container,
			})

			if DoesWrap then
				local Y = select(
					2,
					Library:GetTextBounds(Text, Library.Font, 14, Vector2.new(TextLabel.AbsoluteSize.X, math.huge))
				)
				TextLabel.Size = UDim2.new(1, -4, 0, Y)
			else
				Library:Create("UIListLayout", {
					Padding = UDim.new(0, 4),
					FillDirection = Enum.FillDirection.Horizontal,
					HorizontalAlignment = Enum.HorizontalAlignment.Right,
					SortOrder = Enum.SortOrder.LayoutOrder,
					Parent = TextLabel,
				})
			end

			Label.TextLabel = TextLabel
			Label.Container = Container

			function Label:SetText(Text)
				TextLabel.Text = Text

				if DoesWrap then
					local Y = select(
						2,
						Library:GetTextBounds(Text, Library.Font, 14, Vector2.new(TextLabel.AbsoluteSize.X, math.huge))
					)
					TextLabel.Size = UDim2.new(1, -4, 0, Y)
				end

				Groupbox:Resize()
			end

			if not DoesWrap then
				setmetatable(Label, BaseAddons)
			end

			Groupbox:AddBlank(5)
			Groupbox:Resize()

			return Label
		end

		function Funcs:AddButton(...)
			-- TODO: Eventually redo this
			local Button = {}
			local function ProcessButtonParams(Class, Obj, ...)
				local Props = select(1, ...)
				if type(Props) == "table" then
					Obj.Text = Props.Text
					Obj.Func = Props.Func
					Obj.DoubleClick = Props.DoubleClick
					Obj.DoubleClickText = Props.DoubleClickText
					Obj.Tooltip = Props.Tooltip
				else
					Obj.Text = select(1, ...)
					Obj.Func = select(2, ...)
				end

				assert(type(Obj.Func) == "function", "AddButton: `Func` callback is missing.")
			end

			ProcessButtonParams("Button", Button, ...)

			local Groupbox = self
			local Container = Groupbox.Container

			local function CreateBaseButton(Button)
				local Outer = Library:Create("Frame", {
					BackgroundColor3 = Color3.new(0, 0, 0),
					BorderColor3 = Color3.new(0, 0, 0),
					Size = UDim2.new(1, -4, 0, 20),
					ZIndex = 5,
				})

				local Inner = Library:Create("Frame", {
					BackgroundColor3 = Library.MainColor,
					BorderColor3 = Library.OutlineColor,
					BorderMode = Enum.BorderMode.Inset,
					Size = UDim2.new(1, 0, 1, 0),
					ZIndex = 6,
					Parent = Outer,
				})

				local Label = Library:CreateLabel({
					Size = UDim2.new(1, 0, 1, 0),
					TextSize = 14,
					Text = Button.Text,
					ZIndex = 6,
					Parent = Inner,
				})

				Library:Create("UIGradient", {
					Color = ColorSequence.new({
						ColorSequenceKeypoint.new(0, Color3.new(1, 1, 1)),
						ColorSequenceKeypoint.new(1, Color3.fromRGB(212, 212, 212)),
					}),
					Rotation = 90,
					Parent = Inner,
				})

				Library:AddToRegistry(Outer, {
					BorderColor3 = "Black",
				})

				Library:AddToRegistry(Inner, {
					BackgroundColor3 = "MainColor",
					BorderColor3 = "OutlineColor",
				})

				Library:OnHighlight(Outer, Outer, { BorderColor3 = "AccentColor" }, { BorderColor3 = "Black" })

				return Outer, Inner, Label
			end

			local function InitEvents(Button)
				local function WaitForEvent(event, timeout, validator)
					local bindable = Instance.new("BindableEvent")
					local connection = event:Once(function(...)
						if type(validator) == "function" and validator(...) then
							bindable:Fire(true)
						else
							bindable:Fire(false)
						end
					end)
					task.delay(timeout, function()
						connection:disconnect()
						bindable:Fire(false)
					end)
					return bindable.Event:Wait()
				end

				local function ValidateClick(Input)
					if Library:MouseIsOverOpenedFrame() then
						return false
					end

					if Input.UserInputType ~= Enum.UserInputType.MouseButton1 then
						return false
					end

					return true
				end

				Button.Outer.InputBegan:Connect(function(Input)
					if not ValidateClick(Input) then
						return
					end
					if Button.Locked then
						return
					end

					if Button.DoubleClick then
						Library:RemoveFromRegistry(Button.Label)
						Library:AddToRegistry(Button.Label, { TextColor3 = "AccentColor" })

						Button.Label.TextColor3 = Library.AccentColor
						Button.Label.Text = Button.DoubleClickText or "Are you sure?"
						Button.Locked = true

						local clicked = WaitForEvent(Button.Outer.InputBegan, 2, ValidateClick)

						Library:RemoveFromRegistry(Button.Label)
						Library:AddToRegistry(Button.Label, { TextColor3 = "FontColor" })

						Button.Label.TextColor3 = Library.FontColor
						Button.Label.Text = Button.Text
						task.defer(rawset, Button, "Locked", false)

						if clicked then
							Library:SafeCallback("Button" .. "_" .. Button.Label.Text, Button.Func)
						end

						return
					end

					Library:SafeCallback("Button" .. "_" .. Button.Label.Text, Button.Func)
				end)
			end

			Button.Outer, Button.Inner, Button.Label = CreateBaseButton(Button)
			Button.Outer.Parent = Container

			InitEvents(Button)

			function Button:AddTooltip(tooltip)
				if type(tooltip) == "string" then
					Library:AddToolTip(tooltip, self.Outer)
				end
				return self
			end

			function Button:AddButton(...)
				local SubButton = {}

				ProcessButtonParams("SubButton", SubButton, ...)

				self.Outer.Size = UDim2.new(0.5, -2, 0, 20)

				SubButton.Outer, SubButton.Inner, SubButton.Label = CreateBaseButton(SubButton)

				SubButton.Outer.Position = UDim2.new(1, 3, 0, 0)
				SubButton.Outer.Size = UDim2.fromOffset(self.Outer.AbsoluteSize.X - 2, self.Outer.AbsoluteSize.Y)
				SubButton.Outer.Parent = self.Outer

				function SubButton:AddTooltip(tooltip)
					if type(tooltip) == "string" then
						Library:AddToolTip(tooltip, self.Outer)
					end
					return SubButton
				end

				if type(SubButton.Tooltip) == "string" then
					SubButton:AddTooltip(SubButton.Tooltip)
				end

				InitEvents(SubButton)
				return SubButton
			end

			if type(Button.Tooltip) == "string" then
				Button:AddTooltip(Button.Tooltip)
			end

			Groupbox:AddBlank(5)
			Groupbox:Resize()

			return Button
		end

		function Funcs:AddDivider()
			local Groupbox = self
			local Container = self.Container

			local Divider = {
				Type = "Divider",
			}

			Groupbox:AddBlank(2)
			local DividerOuter = Library:Create("Frame", {
				BackgroundColor3 = Color3.new(0, 0, 0),
				BorderColor3 = Color3.new(0, 0, 0),
				Size = UDim2.new(1, -4, 0, 5),
				ZIndex = 5,
				Parent = Container,
			})

			local DividerInner = Library:Create("Frame", {
				BackgroundColor3 = Library.MainColor,
				BorderColor3 = Library.OutlineColor,
				BorderMode = Enum.BorderMode.Inset,
				Size = UDim2.new(1, 0, 1, 0),
				ZIndex = 6,
				Parent = DividerOuter,
			})

			Library:AddToRegistry(DividerOuter, {
				BorderColor3 = "Black",
			})

			Library:AddToRegistry(DividerInner, {
				BackgroundColor3 = "MainColor",
				BorderColor3 = "OutlineColor",
			})

			Groupbox:AddBlank(9)
			Groupbox:Resize()
		end

		---Add input function.
		---@param Idx string
		---@param Info table
		---@return any
		function Funcs:AddInput(Idx, Info)
			assert(Info.Text, "AddInput: Missing `Text` string.")

			local Textbox = {
				Value = Info.Default or "",
				Numeric = Info.Numeric or false,
				Finished = Info.Finished or false,
				Type = "Input",
				Callback = Info.Callback or function(Value) end,
			}

			local Groupbox = self
			local Container = Groupbox.Container

			local InputLabel = Library:CreateLabel({
				Size = UDim2.new(1, 0, 0, 15),
				TextSize = 14,
				Text = Info.Text,
				TextXAlignment = Enum.TextXAlignment.Left,
				ZIndex = 5,
				Parent = Container,
			})

			Groupbox:AddBlank(1)

			local TextBoxOuter = Library:Create("Frame", {
				BackgroundColor3 = Color3.new(0, 0, 0),
				BorderColor3 = Color3.new(0, 0, 0),
				Size = UDim2.new(1, -4, 0, 20),
				ZIndex = 5,
				Parent = Container,
			})

			local TextBoxInner = Library:Create("Frame", {
				BackgroundColor3 = Library.MainColor,
				BorderColor3 = Library.OutlineColor,
				BorderMode = Enum.BorderMode.Inset,
				Size = UDim2.new(1, 0, 1, 0),
				ZIndex = 6,
				Parent = TextBoxOuter,
			})

			Library:AddToRegistry(TextBoxInner, {
				BackgroundColor3 = "MainColor",
				BorderColor3 = "OutlineColor",
			})

			Library:OnHighlight(
				TextBoxOuter,
				TextBoxOuter,
				{ BorderColor3 = "AccentColor" },
				{ BorderColor3 = "Black" }
			)

			if type(Info.Tooltip) == "string" then
				Library:AddToolTip(Info.Tooltip, TextBoxOuter)
			end

			Library:Create("UIGradient", {
				Color = ColorSequence.new({
					ColorSequenceKeypoint.new(0, Color3.new(1, 1, 1)),
					ColorSequenceKeypoint.new(1, Color3.fromRGB(212, 212, 212)),
				}),
				Rotation = 90,
				Parent = TextBoxInner,
			})

			local Container = Library:Create("Frame", {
				BackgroundTransparency = 1,
				ClipsDescendants = true,

				Position = UDim2.new(0, 5, 0, 0),
				Size = UDim2.new(1, -5, 1, 0),

				ZIndex = 7,
				Parent = TextBoxInner,
			})

			local Box = Library:Create("TextBox", {
				BackgroundTransparency = 1,

				Position = UDim2.fromOffset(0, 0),
				Size = UDim2.fromScale(5, 1),

				FontFace = Library.Font,
				PlaceholderColor3 = Color3.fromRGB(190, 190, 190),
				PlaceholderText = Info.Placeholder or "",

				Text = Info.Default or "",
				TextColor3 = Library.FontColor,
				TextSize = 14,
				TextStrokeTransparency = 0,
				TextXAlignment = Enum.TextXAlignment.Left,

				ZIndex = 7,
				Parent = Container,
			})

			Library:ApplyTextStroke(Box)

			local Connection = nil

			function Textbox:SetRawValue(Text)
				if Info.MaxLength and #Text > Info.MaxLength then
					Text = Text:sub(1, Info.MaxLength)
				end

				if Textbox.Numeric then
					if (not tonumber(Text)) and Text:len() > 0 then
						Text = Textbox.Value
					end
				end

				Textbox.Value = Text
				Box.Text = Text
			end

			function Textbox:SetValue(Text)
				if Info.MaxLength and #Text > Info.MaxLength then
					Text = Text:sub(1, Info.MaxLength)
				end

				if Textbox.Numeric then
					if (not tonumber(Text)) and Text:len() > 0 then
						Text = Textbox.Value
					end
				end

				Textbox.Value = Text
				Box.Text = Text

				Library:SafeCallback("Textbox_Callback" .. "_" .. (Idx or ""), Textbox.Callback, Textbox.Value)
				Library:SafeCallback("Textbox_Changed" .. "_" .. (Idx or ""), Textbox.Changed, Textbox.Value)
			end

			if Textbox.Finished then
				Connection = Box.FocusLost:Connect(function(enter)
					if not enter then
						return
					end

					Textbox:SetValue(Box.Text)
					Library:AttemptSave()
				end)
			else
				Connection = Box:GetPropertyChangedSignal("Text"):Connect(function()
					Textbox:SetValue(Box.Text)
					Library:AttemptSave()
				end)
			end

			-- https://devforum.roblox.com/t/how-to-make-textboxes-follow-current-cursor-position/1368429/6
			-- thank you nicemike40 :)

			local function Update()
				local PADDING = 2
				local reveal = Container.AbsoluteSize.X

				if not Box:IsFocused() or Box.TextBounds.X <= reveal - 2 * PADDING then
					-- we aren't focused, or we fit so be normal
					Box.Position = UDim2.new(0, PADDING, 0, 0)
				else
					-- we are focused and don't fit, so adjust position
					local cursor = Box.CursorPosition
					if cursor ~= -1 then
						-- calculate pixel width of text from start to cursor
						local subtext = string.sub(Box.Text, 1, cursor - 1)
						local width = TextService:GetTextSize(
							subtext,
							Box.TextSize,
							Box.Font,
							Vector2.new(math.huge, math.huge)
						).X

						-- check if we're inside the box with the cursor
						local currentCursorPos = Box.Position.X.Offset + width

						-- adjust if necessary
						if currentCursorPos < PADDING then
							Box.Position = UDim2.fromOffset(PADDING - width, 0)
						elseif currentCursorPos > reveal - PADDING - 1 then
							Box.Position = UDim2.fromOffset(reveal - width - PADDING - 1, 0)
						end
					end
				end
			end

			task.spawn(Update)

			Box:GetPropertyChangedSignal("Text"):Connect(Update)
			Box:GetPropertyChangedSignal("CursorPosition"):Connect(Update)
			Box.FocusLost:Connect(Update)
			Box.Focused:Connect(Update)

			Box.InputBegan:Connect(function(Input)
				if Input.UserInputType == Enum.UserInputType.MouseButton2 then
					Library:Notify("Text copied to clipboard!", 2.5)
					setclipboard(Box.Text)
				end
			end)

			Library:AddToRegistry(Box, {
				TextColor3 = "FontColor",
			})

			function Textbox:OnChanged(Func)
				Textbox.Changed = Func
				Func(Textbox.Value)
			end

			Groupbox:AddBlank(5)
			Groupbox:Resize()

			if Idx then
				Options[Idx] = Textbox
			end

			return Textbox
		end

		function Funcs:AddToggle(Idx, Info)
			assert(Info.Text, "AddInput: Missing `Text` string.")

			local Toggle = {
				Value = Info.Default or false,
				Type = "Toggle",

				Callback = Info.Callback or function(Value) end,
				Addons = {},
				Risky = Info.Risky,
			}

			local Groupbox = self
			local Container = Groupbox.Container

			local ToggleOuter = Library:Create("Frame", {
				BackgroundColor3 = Color3.new(0, 0, 0),
				BorderColor3 = Color3.new(0, 0, 0),
				Size = UDim2.new(0, 13, 0, 13),
				ZIndex = 5,
				Parent = Container,
			})

			Library:AddToRegistry(ToggleOuter, {
				BorderColor3 = "Black",
			})

			local ToggleInner = Library:Create("Frame", {
				BackgroundColor3 = Library.MainColor,
				BorderColor3 = Library.OutlineColor,
				BorderMode = Enum.BorderMode.Inset,
				Size = UDim2.new(1, 0, 1, 0),
				ZIndex = 6,
				Parent = ToggleOuter,
			})

			Library:AddToRegistry(ToggleInner, {
				BackgroundColor3 = "MainColor",
				BorderColor3 = "OutlineColor",
			})

			local ToggleLabel = Library:CreateLabel({
				Size = UDim2.new(0, 216, 1, 0),
				Position = UDim2.new(1, 6, 0, 0),
				TextSize = 14,
				Text = Info.Text,
				TextXAlignment = Enum.TextXAlignment.Left,
				ZIndex = 6,
				Parent = ToggleInner,
			})

			Library:Create("UIListLayout", {
				Padding = UDim.new(0, 4),
				FillDirection = Enum.FillDirection.Horizontal,
				HorizontalAlignment = Enum.HorizontalAlignment.Right,
				SortOrder = Enum.SortOrder.LayoutOrder,
				Parent = ToggleLabel,
			})

			local ToggleRegion = Library:Create("Frame", {
				BackgroundTransparency = 1,
				Size = UDim2.new(0, 170, 1, 0),
				ZIndex = 8,
				Parent = ToggleOuter,
			})

			Library:OnHighlight(ToggleRegion, ToggleOuter, { BorderColor3 = "AccentColor" }, { BorderColor3 = "Black" })

			function Toggle:UpdateColors()
				Toggle:Display()
			end

			if type(Info.Tooltip) == "string" then
				Library:AddToolTip(Info.Tooltip, ToggleRegion)
			end

			function Toggle:Display()
				ToggleInner.BackgroundColor3 = Toggle.Value and Library.AccentColor or Library.MainColor
				ToggleInner.BorderColor3 = Toggle.Value and Library.AccentColorDark or Library.OutlineColor

				Library.RegistryMap[ToggleInner].Properties.BackgroundColor3 = Toggle.Value and "AccentColor"
					or "MainColor"
				Library.RegistryMap[ToggleInner].Properties.BorderColor3 = Toggle.Value and "AccentColorDark"
					or "OutlineColor"
			end

			function Toggle:OnChanged(Func)
				Toggle.Changed = Func
				Func(Toggle.Value)
			end

			function Toggle:SetRawValue(Bool)
				Bool = not not Bool

				Toggle.Value = Bool
				Toggle:Display()

				for _, Addon in next, Toggle.Addons do
					if Addon.Type == "KeyPicker" and Addon.SyncToggleState then
						Addon.Toggled = Bool
						Addon:Update()
					end
				end

				Library:UpdateDependencyBoxes()
			end

			function Toggle:SetValue(Bool)
				Bool = not not Bool

				Toggle.Value = Bool
				Toggle:Display()

				for _, Addon in next, Toggle.Addons do
					if Addon.Type == "KeyPicker" and Addon.SyncToggleState then
						Addon.Toggled = Bool
						Addon:Update()
					end
				end

				Library:SafeCallback("Toggle_Callback" .. "_" .. (Idx or ""), Toggle.Callback, Toggle.Value)
				Library:SafeCallback("Toggle_Changed" .. "_" .. (Idx or ""), Toggle.Changed, Toggle.Value)
				Library:UpdateDependencyBoxes()
			end

			ToggleRegion.InputBegan:Connect(function(Input)
				if Input.UserInputType == Enum.UserInputType.MouseButton1 and not Library:MouseIsOverOpenedFrame() then
					Toggle:SetValue(not Toggle.Value) -- Why was it not like this from the start?
					Library:AttemptSave()
				end
			end)

			if Toggle.Risky then
				Library:RemoveFromRegistry(ToggleLabel)
				ToggleLabel.TextColor3 = Library.RiskColor
				Library:AddToRegistry(ToggleLabel, { TextColor3 = "RiskColor" })
			end

			Toggle:Display()
			Groupbox:AddBlank(Info.BlankSize or 5 + 2)
			Groupbox:Resize()

			Toggle.TextLabel = ToggleLabel
			Toggle.Container = Container
			setmetatable(Toggle, BaseAddons)

			if Idx then
				Toggles[Idx] = Toggle
			end

			Library:UpdateDependencyBoxes()

			return Toggle
		end

		function Funcs:AddSlider(Idx, Info)
			assert(Info.Default, "AddSlider: Missing default value.")
			assert(Info.Text, "AddSlider: Missing slider text.")
			assert(Info.Min, "AddSlider: Missing minimum value.")
			assert(Info.Max, "AddSlider: Missing maximum value.")
			assert(Info.Rounding, "AddSlider: Missing rounding value.")

			local Slider = {
				Value = Info.Default,
				Min = Info.Min,
				Max = Info.Max,
				Rounding = Info.Rounding,
				MaxSize = 232,
				Type = "Slider",
				Callback = Info.Callback or function(Value) end,
			}

			local Groupbox = self
			local Container = Groupbox.Container

			if not Info.Compact then
				Library:CreateLabel({
					Size = UDim2.new(1, 0, 0, 10),
					TextSize = 14,
					Text = Info.Text,
					TextXAlignment = Enum.TextXAlignment.Left,
					TextYAlignment = Enum.TextYAlignment.Bottom,
					ZIndex = 5,
					Parent = Container,
				})

				Groupbox:AddBlank(3)
			end

			local SliderOuter = Library:Create("Frame", {
				BackgroundColor3 = Color3.new(0, 0, 0),
				BorderColor3 = Color3.new(0, 0, 0),
				Size = UDim2.new(1, -4, 0, 13),
				ZIndex = 5,
				Parent = Container,
			})

			Library:AddToRegistry(SliderOuter, {
				BorderColor3 = "Black",
			})

			local SliderInner = Library:Create("Frame", {
				BackgroundColor3 = Library.MainColor,
				BorderColor3 = Library.OutlineColor,
				BorderMode = Enum.BorderMode.Inset,
				Size = UDim2.new(1, 0, 1, 0),
				ZIndex = 6,
				Parent = SliderOuter,
			})

			Library:AddToRegistry(SliderInner, {
				BackgroundColor3 = "MainColor",
				BorderColor3 = "OutlineColor",
			})

			local Fill = Library:Create("Frame", {
				BackgroundColor3 = Library.AccentColor,
				BorderColor3 = Library.AccentColorDark,
				Size = UDim2.new(0, 0, 1, 0),
				ZIndex = 7,
				Parent = SliderInner,
			})

			Library:AddToRegistry(Fill, {
				BackgroundColor3 = "AccentColor",
				BorderColor3 = "AccentColorDark",
			})

			local HideBorderRight = Library:Create("Frame", {
				BackgroundColor3 = Library.AccentColor,
				BorderSizePixel = 0,
				Position = UDim2.new(1, 0, 0, 0),
				Size = UDim2.new(0, 1, 1, 0),
				ZIndex = 8,
				Parent = Fill,
			})

			Library:AddToRegistry(HideBorderRight, {
				BackgroundColor3 = "AccentColor",
			})

			local DisplayLabel = Library:CreateLabel({
				Size = UDim2.new(1, 0, 1, 0),
				TextSize = 14,
				Text = "Infinite",
				ZIndex = 9,
				Parent = SliderInner,
			})

			Library:OnHighlight(SliderOuter, SliderOuter, { BorderColor3 = "AccentColor" }, { BorderColor3 = "Black" })

			if type(Info.Tooltip) == "string" then
				Library:AddToolTip(Info.Tooltip, SliderOuter)
			end

			function Slider:UpdateColors()
				Fill.BackgroundColor3 = Library.AccentColor
				Fill.BorderColor3 = Library.AccentColorDark
			end

			function Slider:Display()
				local Suffix = Info.Suffix or ""

				if Info.Compact then
					DisplayLabel.Text = Info.Text .. ": " .. Slider.Value .. Suffix
				elseif Info.HideMax then
					DisplayLabel.Text = string.format("%s", Slider.Value .. Suffix)
				else
					DisplayLabel.Text = string.format("%s/%s", Slider.Value .. Suffix, Slider.Max .. Suffix)
				end

				local X = math.ceil(Library:MapValue(Slider.Value, Slider.Min, Slider.Max, 0, Slider.MaxSize))
				Fill.Size = UDim2.new(0, X, 1, 0)

				HideBorderRight.Visible = not (X == Slider.MaxSize or X == 0)
			end

			function Slider:OnChanged(Func)
				Slider.Changed = Func
				Func(Slider.Value)
			end

			local function Round(Value)
				if Slider.Rounding == 0 then
					return math.floor(Value)
				end

				return tonumber(string.format("%." .. Slider.Rounding .. "f", Value))
			end

			function Slider:GetValueFromXOffset(X)
				return Round(Library:MapValue(X, 0, Slider.MaxSize, Slider.Min, Slider.Max))
			end

			function Slider:SetRawValue(Value)
				local Num = tonumber(Value)

				if not Num then
					return
				end

				Num = math.clamp(Num, Slider.Min, Slider.Max)

				Slider.Value = Num
				Slider:Display()
			end

			function Slider:SetValue(Str)
				local Num = tonumber(Str)

				if not Num then
					return
				end

				Num = math.clamp(Num, Slider.Min, Slider.Max)

				Slider.Value = Num
				Slider:Display()

				Library:SafeCallback("Slider_Callback" .. "_" .. (Idx or ""), Slider.Callback, Slider.Value)
				Library:SafeCallback("Slider_Changed" .. "_" .. (Idx or ""), Slider.Changed, Slider.Value)
			end

			local CurrentAmount = 0.01

			SliderInner.InputBegan:Connect(function(Input)
				if Input.UserInputType == Enum.UserInputType.MouseButton1 and not Library:MouseIsOverOpenedFrame() then
					local mPos = Mouse.X
					local gPos = Fill.Size.X.Offset
					local Diff = mPos - (Fill.AbsolutePosition.X + gPos)

					while InputService:IsMouseButtonPressed(Enum.UserInputType.MouseButton1) do
						local nMPos = Mouse.X
						local nX = math.clamp(gPos + (nMPos - mPos) + Diff, 0, Slider.MaxSize)

						local nValue = Slider:GetValueFromXOffset(nX)
						local OldValue = Slider.Value
						Slider.Value = nValue

						Slider:Display()

						if nValue ~= OldValue then
							Library:SafeCallback("Slider_Callback" .. "_" .. (Idx or ""), Slider.Callback, Slider.Value)
							Library:SafeCallback("Slider_Changed" .. "_" .. (Idx or ""), Slider.Changed, Slider.Value)
						end

						RenderStepped:Wait()
					end

					Library:AttemptSave()
				end

				if Input.KeyCode == Enum.KeyCode.Minus then
					CurrentAmount = math.max(CurrentAmount / 10, 0.00001)
				end

				if Input.KeyCode == Enum.KeyCode.Equals and (CurrentAmount * 10) <= Slider.Max then
					CurrentAmount = CurrentAmount * 10
				end

				if Input.KeyCode == Enum.KeyCode.Right then
					Slider:SetValue(Slider.Value + CurrentAmount)
				end

				if Input.KeyCode == Enum.KeyCode.Left then
					Slider:SetValue(Slider.Value - CurrentAmount)
				end
			end)

			Slider:Display()
			Groupbox:AddBlank(Info.BlankSize or 6)
			Groupbox:Resize()

			if Idx then
				Options[Idx] = Slider
			end

			return Slider
		end

		function Funcs:AddDropdown(Idx, Info)
			if Info.SpecialType == "Player" then
				Info.Values = GetPlayersString()
				Info.AllowNull = true
			elseif Info.SpecialType == "Team" then
				Info.Values = GetTeamsString()
				Info.AllowNull = true
			end

			assert(Info.Values, "AddDropdown: Missing dropdown value list.")
			assert(
				Info.AllowNull or Info.Default,
				"AddDropdown: Missing default value. Pass `AllowNull` as true if this was intentional."
			)

			if not Info.Text then
				Info.Compact = true
			end

			local Dropdown = {
				Values = Info.Values,
				Value = Info.Multi and {},
				SaveValues = Info.SaveValues or false,
				Multi = Info.Multi,
				Type = "Dropdown",
				SpecialType = Info.SpecialType, -- can be either 'Player' or 'Team'
				Callback = Info.Callback or function(Value) end,
			}

			local Groupbox = self
			local Container = Groupbox.Container

			local RelativeOffset = 0

			if not Info.Compact then
				local DropdownLabel = Library:CreateLabel({
					Size = UDim2.new(1, 0, 0, 10),
					TextSize = 14,
					Text = Info.Text,
					TextXAlignment = Enum.TextXAlignment.Left,
					TextYAlignment = Enum.TextYAlignment.Bottom,
					ZIndex = 5,
					Parent = Container,
				})

				Groupbox:AddBlank(3)
			end

			for _, Element in next, Container:GetChildren() do
				if not Element:IsA("UIListLayout") then
					RelativeOffset = RelativeOffset + Element.Size.Y.Offset
				end
			end

			local DropdownOuter = Library:Create("Frame", {
				BackgroundColor3 = Color3.new(0, 0, 0),
				BorderColor3 = Color3.new(0, 0, 0),
				Size = UDim2.new(1, -4, 0, 20),
				ZIndex = 5,
				Parent = Container,
			})

			Library:AddToRegistry(DropdownOuter, {
				BorderColor3 = "Black",
			})

			local DropdownInner = Library:Create("Frame", {
				BackgroundColor3 = Library.MainColor,
				BorderColor3 = Library.OutlineColor,
				BorderMode = Enum.BorderMode.Inset,
				Size = UDim2.new(1, 0, 1, 0),
				ZIndex = 6,
				Parent = DropdownOuter,
			})

			Library:AddToRegistry(DropdownInner, {
				BackgroundColor3 = "MainColor",
				BorderColor3 = "OutlineColor",
			})

			Library:Create("UIGradient", {
				Color = ColorSequence.new({
					ColorSequenceKeypoint.new(0, Color3.new(1, 1, 1)),
					ColorSequenceKeypoint.new(1, Color3.fromRGB(212, 212, 212)),
				}),
				Rotation = 90,
				Parent = DropdownInner,
			})

			local DropdownArrow = Library:Create("ImageLabel", {
				AnchorPoint = Vector2.new(0, 0.5),
				BackgroundTransparency = 1,
				Position = UDim2.new(1, -16, 0.5, 0),
				Size = UDim2.new(0, 12, 0, 12),
				Image = "http://www.roblox.com/asset/?id=6282522798",
				ZIndex = 8,
				Parent = DropdownInner,
			})

			local ItemList = Library:CreateLabel({
				Position = UDim2.new(0, 5, 0, 0),
				Size = UDim2.new(1, -5, 1, 0),
				TextSize = 14,
				Text = "--",
				TextXAlignment = Enum.TextXAlignment.Left,
				TextWrapped = true,
				ZIndex = 7,
				Parent = DropdownInner,
			})

			Library:OnHighlight(
				DropdownOuter,
				DropdownOuter,
				{ BorderColor3 = "AccentColor" },
				{ BorderColor3 = "Black" }
			)

			if type(Info.Tooltip) == "string" then
				Library:AddToolTip(Info.Tooltip, DropdownOuter)
			end

			local MAX_DROPDOWN_ITEMS = 8

			local ListOuter = Library:Create("Frame", {
				BackgroundColor3 = Color3.new(0, 0, 0),
				BorderColor3 = Color3.new(0, 0, 0),
				ZIndex = 20,
				Visible = false,
				Name = "ListOuter",
				Parent = ScreenGui,
			})

			local function RecalculateListPosition()
				ListOuter.Position = UDim2.fromOffset(
					DropdownOuter.AbsolutePosition.X,
					DropdownOuter.AbsolutePosition.Y + DropdownOuter.Size.Y.Offset + 1
				)
			end

			local function RecalculateListSize(YSize)
				ListOuter.Size = UDim2.fromOffset(DropdownOuter.AbsoluteSize.X, YSize or (MAX_DROPDOWN_ITEMS * 20 + 2))
			end

			RecalculateListPosition()
			RecalculateListSize()

			DropdownOuter:GetPropertyChangedSignal("AbsolutePosition"):Connect(RecalculateListPosition)

			local ListInner = Library:Create("Frame", {
				BackgroundColor3 = Library.MainColor,
				BorderColor3 = Library.OutlineColor,
				BorderMode = Enum.BorderMode.Inset,
				BorderSizePixel = 0,
				Size = UDim2.new(1, 0, 1, 0),
				ZIndex = 21,
				Parent = ListOuter,
			})

			Library:AddToRegistry(ListInner, {
				BackgroundColor3 = "MainColor",
				BorderColor3 = "OutlineColor",
			})

			local Scrolling = Library:Create("ScrollingFrame", {
				BackgroundTransparency = 1,
				BorderSizePixel = 0,
				CanvasSize = UDim2.new(0, 0, 0, 0),
				Size = UDim2.new(1, 0, 1, 0),
				ZIndex = 21,
				Parent = ListInner,

				TopImage = "rbxasset://textures/ui/Scroll/scroll-middle.png",
				BottomImage = "rbxasset://textures/ui/Scroll/scroll-middle.png",

				ScrollBarThickness = 3,
				ScrollBarImageColor3 = Library.AccentColor,
			})

			Library:AddToRegistry(Scrolling, {
				ScrollBarImageColor3 = "AccentColor",
			})

			Library:Create("UIListLayout", {
				Padding = UDim.new(0, 0),
				FillDirection = Enum.FillDirection.Vertical,
				SortOrder = Enum.SortOrder.LayoutOrder,
				Parent = Scrolling,
			})

			function Dropdown:Display()
				local Values = Dropdown.Values
				local Str = ""

				if Info.Multi then
					for Idx, Value in next, Values do
						if Dropdown.Value[Value] then
							Str = Str .. Value .. ", "
						end
					end

					Str = Str:sub(1, #Str - 2)
				else
					Str = Dropdown.Value or ""
				end

				ItemList.Text = (Str == "" and "--" or Str)
			end

			function Dropdown:GetActiveValues()
				if Info.Multi then
					local T = {}

					for Value, Bool in next, Dropdown.Value do
						table.insert(T, Value)
					end

					return T
				else
					return Dropdown.Value and 1 or 0
				end
			end

			function Dropdown:BuildDropdownList()
				local Values = Dropdown.Values
				local Buttons = {}

				for _, Element in next, Scrolling:GetChildren() do
					if not Element:IsA("UIListLayout") then
						Element:Destroy()
					end
				end

				local Count = 0

				for Idx, Value in next, Values do
					local Table = {}

					Count = Count + 1

					local Button = Library:Create("Frame", {
						BackgroundColor3 = Library.MainColor,
						BorderColor3 = Library.OutlineColor,
						BorderMode = Enum.BorderMode.Middle,
						Size = UDim2.new(1, -1, 0, 20),
						ZIndex = 23,
						Active = true,
						Parent = Scrolling,
					})

					Library:AddToRegistry(Button, {
						BackgroundColor3 = "MainColor",
						BorderColor3 = "OutlineColor",
					})

					local ButtonLabel = Library:CreateLabel({
						Active = false,
						Size = UDim2.new(1, -6, 1, 0),
						Position = UDim2.new(0, 6, 0, 0),
						TextSize = 14,
						Text = Value,
						TextXAlignment = Enum.TextXAlignment.Left,
						ZIndex = 25,
						Parent = Button,
					})

					Library:OnHighlight(
						Button,
						Button,
						{ BorderColor3 = "AccentColor", ZIndex = 24 },
						{ BorderColor3 = "OutlineColor", ZIndex = 23 }
					)

					local Selected

					if Info.Multi then
						Selected = Dropdown.Value[Value]
					else
						Selected = Dropdown.Value == Value
					end

					function Table:UpdateButton()
						if Info.Multi then
							Selected = Dropdown.Value[Value]
						else
							Selected = Dropdown.Value == Value
						end

						ButtonLabel.TextColor3 = Selected and Library.AccentColor or Library.FontColor
						Library.RegistryMap[ButtonLabel].Properties.TextColor3 = Selected and "AccentColor"
							or "FontColor"
					end

					ButtonLabel.InputBegan:Connect(function(Input)
						if Input.UserInputType == Enum.UserInputType.MouseButton1 then
							local Try = not Selected

							if Dropdown:GetActiveValues() == 1 and not Try and not Info.AllowNull then
							else
								if Info.Multi then
									Selected = Try

									if Selected then
										Dropdown.Value[Value] = true
									else
										Dropdown.Value[Value] = nil
									end
								else
									Selected = Try

									if Selected then
										Dropdown.Value = Value
									else
										Dropdown.Value = nil
									end

									for _, OtherButton in next, Buttons do
										OtherButton:UpdateButton()
									end

									Library:UpdateDependencyBoxes()
								end

								Table:UpdateButton()
								Dropdown:Display()

								Library:SafeCallback(
									"Dropdown_Callback" .. "_" .. (Idx or ""),
									Dropdown.Callback,
									Dropdown.Value
								)
								Library:SafeCallback(
									"Dropdown_Changed" .. "_" .. (Idx or ""),
									Dropdown.Changed,
									Dropdown.Value
								)

								Library:AttemptSave()
							end
						end
					end)

					Table:UpdateButton()
					Dropdown:Display()

					Buttons[Button] = Table
				end

				Scrolling.CanvasSize = UDim2.fromOffset(0, (Count * 20) + 1)

				local Y = math.clamp(Count * 20, 0, MAX_DROPDOWN_ITEMS * 20) + 1
				RecalculateListSize(Y)
			end

			function Dropdown:SetValues(NewValues)
				if NewValues then
					Dropdown.Values = NewValues
				end

				Dropdown:BuildDropdownList()
			end

			function Dropdown:OpenDropdown()
				ListOuter.Visible = true
				Library.OpenedFrames[ListOuter] = true
				DropdownArrow.Rotation = 180
			end

			function Dropdown:CloseDropdown()
				ListOuter.Visible = false
				Library.OpenedFrames[ListOuter] = nil
				DropdownArrow.Rotation = 0
			end

			function Dropdown:OnChanged(Func)
				Dropdown.Changed = Func
				Func(Dropdown.Value)
			end

			function Dropdown:SetRawValue(Val)
				if Dropdown.Multi then
					local nTable = {}

					for Value, Bool in next, Val do
						if table.find(Dropdown.Values, Value) then
							nTable[Value] = true
						end
					end

					Dropdown.Value = nTable
				else
					if not Val then
						Dropdown.Value = nil
					elseif table.find(Dropdown.Values, Val) then
						Dropdown.Value = Val
					end
				end

				Dropdown:BuildDropdownList()
			end

			function Dropdown:SetValue(Val)
				if Dropdown.Multi then
					local nTable = {}

					for Value, Bool in next, Val do
						if table.find(Dropdown.Values, Value) then
							nTable[Value] = true
						end
					end

					Dropdown.Value = nTable
				else
					if not Val then
						Dropdown.Value = nil
					elseif table.find(Dropdown.Values, Val) then
						Dropdown.Value = Val
					end
				end

				Dropdown:BuildDropdownList()

				Library:SafeCallback("Dropdown_Callback" .. "_" .. (Idx or ""), Dropdown.Callback, Dropdown.Value)
				Library:SafeCallback("Dropdown_Changed" .. "_" .. (Idx or ""), Dropdown.Changed, Dropdown.Value)
			end

			DropdownOuter.InputBegan:Connect(function(Input)
				if Input.UserInputType == Enum.UserInputType.MouseButton1 and not Library:MouseIsOverOpenedFrame() then
					if ListOuter.Visible then
						Dropdown:CloseDropdown()
					else
						Dropdown:OpenDropdown()
					end
				end
			end)

			InputService.InputBegan:Connect(function(Input)
				if Input.UserInputType == Enum.UserInputType.MouseButton1 then
					local AbsPos, AbsSize = ListOuter.AbsolutePosition, ListOuter.AbsoluteSize

					if
						Mouse.X < AbsPos.X
						or Mouse.X > AbsPos.X + AbsSize.X
						or Mouse.Y < (AbsPos.Y - 20 - 1)
						or Mouse.Y > AbsPos.Y + AbsSize.Y
					then
						Dropdown:CloseDropdown()
					end
				end
			end)

			Dropdown:BuildDropdownList()
			Dropdown:Display()

			local Defaults = {}

			if type(Info.Default) == "string" then
				local Idx = table.find(Dropdown.Values, Info.Default)
				if Idx then
					table.insert(Defaults, Idx)
				end
			elseif type(Info.Default) == "table" then
				for _, Value in next, Info.Default do
					local Idx = table.find(Dropdown.Values, Value)
					if Idx then
						table.insert(Defaults, Idx)
					end
				end
			elseif type(Info.Default) == "number" and Dropdown.Values[Info.Default] ~= nil then
				table.insert(Defaults, Info.Default)
			end

			if next(Defaults) then
				for i = 1, #Defaults do
					local Index = Defaults[i]
					if Info.Multi then
						Dropdown.Value[Dropdown.Values[Index]] = true
					else
						Dropdown.Value = Dropdown.Values[Index]
					end

					if not Info.Multi then
						break
					end
				end

				Dropdown:BuildDropdownList()
				Dropdown:Display()
			end

			Groupbox:AddBlank(Info.BlankSize or 5)
			Groupbox:Resize()

			if Idx then
				Options[Idx] = Dropdown
			end

			return Dropdown
		end

		function Funcs:AddDependencyBox()
			local Depbox = {
				Dependencies = {},
			}

			local Groupbox = self
			local Container = Groupbox.Container

			local Holder = Library:Create("Frame", {
				BackgroundTransparency = 1,
				Size = UDim2.new(1, 0, 0, 0),
				Visible = false,
				Parent = Container,
			})

			local Frame = Library:Create("Frame", {
				BackgroundTransparency = 1,
				Size = UDim2.new(1, 0, 1, 0),
				Visible = true,
				Parent = Holder,
			})

			local Layout = Library:Create("UIListLayout", {
				FillDirection = Enum.FillDirection.Vertical,
				SortOrder = Enum.SortOrder.LayoutOrder,
				Parent = Frame,
			})

			function Depbox:Resize()
				Holder.Size = UDim2.new(1, 0, 0, Layout.AbsoluteContentSize.Y)
				Groupbox:Resize()
			end

			Layout:GetPropertyChangedSignal("AbsoluteContentSize"):Connect(function()
				Depbox:Resize()
			end)

			Holder:GetPropertyChangedSignal("Visible"):Connect(function()
				Depbox:Resize()
			end)

			function Depbox:Update()
				for _, Dependency in next, Depbox.Dependencies do
					local Elem = Dependency[1]
					local Value = Dependency[2]

					if Elem.Type == "Toggle" and Elem.Value ~= Value then
						Holder.Visible = false
						Depbox:Resize()
						return
					end

					if Elem.Type == "Dropdown" and Elem.Value ~= Value then
						Holder.Visible = false
						Depbox:Resize()
						return
					end
				end

				Holder.Visible = true
				Depbox:Resize()
			end

			function Depbox:SetupDependencies(Dependencies)
				for _, Dependency in next, Dependencies do
					assert(type(Dependency) == "table", "SetupDependencies: Dependency is not of type `table`.")
					assert(Dependency[1], "SetupDependencies: Dependency is missing element argument.")
					assert(Dependency[2] ~= nil, "SetupDependencies: Dependency is missing value argument.")
				end

				Depbox.Dependencies = Dependencies
				Depbox:Update()
			end

			Depbox.Container = Frame

			setmetatable(Depbox, BaseGroupbox)

			table.insert(Library.DependencyBoxes, Depbox)

			return Depbox
		end

		BaseGroupbox.__index = Funcs
		BaseGroupbox.__namecall = function(Table, Key, ...)
			return Funcs[Key](...)
		end
	end

	-- < Create other UI elements >
	do
		Library.NotificationArea = Library:Create("Frame", {
			BackgroundTransparency = 1,
			Position = UDim2.new(0, 0, 0, 40),
			Size = UDim2.new(0, 300, 0, 200),
			ZIndex = 100,
			Parent = ScreenGui,
		})

		Library:Create("UIListLayout", {
			Padding = UDim.new(0, 4),
			FillDirection = Enum.FillDirection.Vertical,
			SortOrder = Enum.SortOrder.LayoutOrder,
			Parent = Library.NotificationArea,
		})

		local WatermarkOuter = Library:Create("Frame", {
			BorderColor3 = Color3.new(0, 0, 0),
			Position = UDim2.new(0, 100, 0, -25),
			Size = UDim2.new(0, 213, 0, 20),
			ZIndex = 200,
			Visible = false,
			Parent = ScreenGui,
		})

		Library.PositionList = {}
		Library.Recording = false
		Library.Markers = {}

		WatermarkOuter.InputBegan:Connect(function(Input)
			xpcall(function()
				if not Toggles["ShowDebugInformation"].Value then
					return
				end

				if Input.UserInputType == Enum.UserInputType.MouseButton2 then
					local Character = LocalPlayer and LocalPlayer.Character
					local HumanoidRootPart = Character and Character:FindFirstChild("HumanoidRootPart")
					local Position = HumanoidRootPart and HumanoidRootPart.Position
					local PositionFormat = Position
							and string.format("CFrame.new(%.2f, %.2f, %.2f)", Position.X, Position.Y, Position.Z)
						or "N/A"

					setclipboard(tostring(PositionFormat))

					Library:Notify("Your current position has been copied to your clipboard.", 5)
				end

				if Input.KeyCode == Enum.KeyCode.I then
					if not Library.Recording then
						Library.PositionList = {}
						Library.Recording = true
						Library:Notify("Positions are now recording. Press the '=' key to set a waypoint.", 5)
					else
						Library.Recording = false
						local Formatted = "{" .. table.concat(Library.PositionList, ", ") .. "}"
						setclipboard(Formatted)
						Library:Notify(
							"Positions have stopped recording. These positions are copied to your clipboard.",
							5
						)
					end
				end

				if Input.KeyCode == Enum.KeyCode.L then
					local Character = LocalPlayer and LocalPlayer.Character
					local Root = Character and Character:FindFirstChild("HumanoidRootPart")

					if Root then
						local Marker = Instance.new("Part")
						Marker.Name = "LycorisMarker"
						Marker.Size = Vector3.new(1, 1, 1)
						Marker.Anchored = true
						Marker.CanCollide = false
						Marker.Transparency = 0.5
						Marker.Color = Color3.fromRGB(255, 50, 50)
						Marker.Material = Enum.Material.Neon
						Marker.CFrame = Root.CFrame
						Marker.Parent = workspace

						table.insert(Library.Markers, Marker)
						Library:Notify("Created debug marker.", 1)
					end
				end

				if Input.KeyCode == Enum.KeyCode.P then
					local Marker = table.remove(Library.Markers)

					if Marker then
						Marker:Destroy()
						Library:Notify("Removed recent debug marker.", 1)
					end
				end
			end, warn)
		end)

		local WatermarkInner = Library:Create("Frame", {
			BackgroundColor3 = Library.MainColor,
			BorderColor3 = Library.OutlineColor,
			BorderMode = Enum.BorderMode.Inset,
			Size = UDim2.new(1, 0, 1, 0),
			ZIndex = 201,
			Parent = WatermarkOuter,
		})

		Library:AddToRegistry(WatermarkInner, {
			BorderColor3 = "OutlineColor",
		})

		local ColorFrame = Library:Create("Frame", {
			BackgroundColor3 = Library.AccentColor,
			BorderSizePixel = 0,
			Size = UDim2.new(1, 0, 0, 2),
			ZIndex = 204,
			Parent = WatermarkInner,
		})

		Library:AddToRegistry(ColorFrame, {
			BackgroundColor3 = "AccentColor",
		}, true)

		local InnerFrame = Library:Create("Frame", {
			BackgroundColor3 = Color3.new(1, 1, 1),
			BorderSizePixel = 0,
			Position = UDim2.new(0, 1, 0, 1),
			Size = UDim2.new(1, -2, 1, -2),
			ZIndex = 202,
			Parent = WatermarkInner,
		})

		local Gradient = Library:Create("UIGradient", {
			Color = ColorSequence.new({
				ColorSequenceKeypoint.new(0, Library:GetDarkerColor(Library.MainColor)),
				ColorSequenceKeypoint.new(1, Library.MainColor),
			}),
			Rotation = -90,
			Parent = InnerFrame,
		})

		Library:AddToRegistry(Gradient, {
			Color = function()
				return ColorSequence.new({
					ColorSequenceKeypoint.new(0, Library:GetDarkerColor(Library.MainColor)),
					ColorSequenceKeypoint.new(1, Library.MainColor),
				})
			end,
		})

		local WatermarkLabel = Library:CreateLabel({
			Position = UDim2.new(0, 5, 0, 1),
			Size = UDim2.new(1, -4, 1, 0),
			TextColor3 = Library.AccentColor,
			TextSize = 14,
			TextXAlignment = Enum.TextXAlignment.Left,
			ZIndex = 203,
			Parent = InnerFrame,
		})

		Library:AddToRegistry(WatermarkLabel, {
			TextColor3 = "AccentColor",
		}, true)

		Library.Watermark = WatermarkOuter
		Library.WatermarkText = WatermarkLabel
		Library:MakeDraggable(Library.Watermark)

		local InfoLoggerOuter = Library:Create("Frame", {
			BorderColor3 = Color3.new(0, 0, 0),
			Position = UDim2.new(0, 15, 0.5, 0),
			Size = UDim2.new(0, 210, 0, 20),
			Visible = false,
			ZIndex = 287,
			Parent = ScreenGui,
		})

		local InfoLoggerInner = Library:Create("Frame", {
			BackgroundColor3 = Library.MainColor,
			BorderColor3 = Library.OutlineColor,
			BorderMode = Enum.BorderMode.Inset,
			Size = UDim2.new(1, 0, 1, 0),
			ZIndex = 288,
			Parent = InfoLoggerOuter,
		})

		Library:AddToRegistry(InfoLoggerInner, {
			BackgroundColor3 = "MainColor",
			BorderColor3 = "OutlineColor",
		}, true)

		local InfoColorFrame = Library:Create("Frame", {
			BackgroundColor3 = Library.AccentColor,
			BorderSizePixel = 0,
			Size = UDim2.new(1, 0, 0, 2),
			ZIndex = 299,
			Parent = InfoLoggerInner,
		})

		Library:AddToRegistry(InfoColorFrame, {
			BackgroundColor3 = "AccentColor",
		}, true)

		local InfoLoggerLabel = Library:CreateLabel({
			Size = UDim2.new(1, 0, 0, 20),
			Position = UDim2.fromOffset(5, 2),
			TextXAlignment = Enum.TextXAlignment.Left,
			TextColor3 = Library.AccentColor,
			Text = "Info Logger",
			TextSize = 14,
			ZIndex = 300,
			Parent = InfoLoggerInner,
		})

		Library:AddToRegistry(InfoLoggerLabel, {
			TextColor3 = "AccentColor",
		}, true)

		local InfoLoggerContainer = Library:Create("ScrollingFrame", {
			BackgroundTransparency = 1,
			Size = UDim2.new(1, 0, 1, -20),
			Position = UDim2.new(0, 0, 0, 20),
			ZIndex = 1,
			ScrollBarThickness = 0,
			Parent = InfoLoggerInner,
		})

		local InfoUIListLayout = Library:Create("UIListLayout", {
			FillDirection = Enum.FillDirection.Vertical,
			SortOrder = Enum.SortOrder.LayoutOrder,
			Parent = InfoLoggerContainer,
		})

		InfoUIListLayout:GetPropertyChangedSignal("AbsoluteContentSize"):Connect(function()
			InfoLoggerContainer.CanvasSize = UDim2.fromOffset(0, InfoUIListLayout.AbsoluteContentSize.Y)
		end)

		Library:Create("UIPadding", {
			PaddingLeft = UDim.new(0, 5),
			Parent = InfoLoggerContainer,
		})

		---@param InputObject InputObject
		Library:GiveSignal(InfoLoggerOuter.InputBegan:Connect(function(InputObject)
			if InputObject.UserInputType ~= Enum.UserInputType.Keyboard then
				return
			end

			if

				InputObject.KeyCode == Enum.KeyCode.Z
				and game:GetService("UserInputService"):IsKeyDown(Enum.KeyCode.LeftControl)
			then
				local kbh = Library.InfoLoggerData.KeyBlacklistHistory
				local kbl = Library.InfoLoggerData.KeyBlacklistList
				local front = kbh[1]
				if not front then
					return
				end

				kbl[front] = nil

				table.remove(kbh, 1)

				Library:RefreshInfoLogger()
				if Options and Options.BlacklistedKeys then
					Options.BlacklistedKeys:SetValues(Library:KeyBlacklists())
				end
				Library:Notify(string.format("Re-whitelisted key '%s' into list.", front))
			end

			if InputObject.KeyCode == Enum.KeyCode.Q then
				Library.InfoLoggerCycle = math.max(Library.InfoLoggerCycle - 1, 1)
				Library:RefreshInfoLogger()
			end

			if InputObject.KeyCode == Enum.KeyCode.E then
				Library.InfoLoggerCycle = math.min(Library.InfoLoggerCycle + 1, #Library.InfoLoggerCycles)
				Library:RefreshInfoLogger()
			end
		end))

		-- default cycle is animation.
		Library.InfoLoggerLabel = InfoLoggerLabel
		Library.InfoLoggerFrame = InfoLoggerOuter
		Library.InfoLoggerContainer = InfoLoggerContainer
		Library.InfoLoggerCycle = 1
		Library.InfoLoggerCycles = {
			"Animation",
			"Part",
			"Sound",
			"Effect",
		}
		Library.InfoLoggerData = {
			MissingDataEntries = {},
			KeyBlacklistHistory = {},
			KeyBlacklistList = {},
		}

		Library:MakeDraggable(InfoLoggerOuter)
		Library:RefreshInfoLogger()

		local KeybindOuter = Library:Create("Frame", {
			AnchorPoint = Vector2.new(0, 0.5),
			BorderColor3 = Color3.new(0, 0, 0),
			Position = UDim2.new(0, 10, 0.5, 0),
			Size = UDim2.new(0, 210, 0, 20),
			Visible = false,
			ZIndex = 100,
			Parent = ScreenGui,
		})

		local KeybindInner = Library:Create("Frame", {
			BackgroundColor3 = Library.MainColor,
			BorderColor3 = Library.OutlineColor,
			BorderMode = Enum.BorderMode.Inset,
			Size = UDim2.new(1, 0, 1, 0),
			ZIndex = 101,
			Parent = KeybindOuter,
		})

		Library:AddToRegistry(KeybindInner, {
			BackgroundColor3 = "MainColor",
			BorderColor3 = "OutlineColor",
		}, true)

		local ColorFrame = Library:Create("Frame", {
			BackgroundColor3 = Library.AccentColor,
			BorderSizePixel = 0,
			Size = UDim2.new(1, 0, 0, 2),
			ZIndex = 102,
			Parent = KeybindInner,
		})

		Library:AddToRegistry(ColorFrame, {
			BackgroundColor3 = "AccentColor",
		}, true)

		local KeybindLabel = Library:CreateLabel({
			Size = UDim2.new(1, 0, 0, 20),
			Position = UDim2.fromOffset(5, 2),
			TextXAlignment = Enum.TextXAlignment.Left,
			TextSize = 14,
			TextColor3 = Library.AccentColor,
			Text = "Keybind List",
			ZIndex = 104,
			Parent = KeybindInner,
		})

		Library:AddToRegistry(KeybindLabel, {
			TextColor3 = "AccentColor",
		}, true)

		local KeybindContainer = Library:Create("Frame", {
			BackgroundTransparency = 1,
			Size = UDim2.new(1, 0, 1, -20),
			Position = UDim2.new(0, 0, 0, 20),
			ZIndex = 1,
			Parent = KeybindInner,
		})

		Library:Create("UIListLayout", {
			FillDirection = Enum.FillDirection.Vertical,
			SortOrder = Enum.SortOrder.LayoutOrder,
			Parent = KeybindContainer,
		})

		Library:Create("UIPadding", {
			PaddingLeft = UDim.new(0, 5),
			Parent = KeybindContainer,
		})

		Library.KeybindFrame = KeybindOuter
		Library.KeybindContainer = KeybindContainer
		Library:MakeDraggable(KeybindOuter)
	end

	function Library:SetWatermarkVisibility(Bool)
		Library.Watermark.Visible = Bool
	end

	function Library:SetWatermark(Text)
		local X, Y = Library:GetTextBounds(Text, Library.Font, 14)
		Library.WatermarkText.Text = Text
		Library.Watermark.Size = UDim2.new(0, X + 15, 0, (Y * 1.5) + 3)
	end

	function Library:ManuallyManagedNotify(Text)
		if shared.Lycoris.silent then
			return
		end

		local NotifScale = tonumber(Options["NotificationScale"] and Options["NotificationScale"].Value) or 100
		NotifScale = NotifScale / 100

		local ScaledTextSize = 14 * NotifScale
		local XSize, YSize = Library:GetTextBounds(Text, Library.Font, ScaledTextSize)

		YSize = YSize + (7 * NotifScale)

		local NotifyOuter = Library:Create("Frame", {
			BorderColor3 = Color3.new(0, 0, 0),
			Position = UDim2.new(0, 100, 0, 10),
			Size = UDim2.new(0, 0, 0, YSize),
			ClipsDescendants = true,
			ZIndex = 100,
			Parent = Library.NotificationArea,
		})

		local NotifyInner = Library:Create("Frame", {
			BackgroundColor3 = Library.MainColor,
			BorderColor3 = Library.OutlineColor,
			BorderMode = Enum.BorderMode.Inset,
			Size = UDim2.new(1, 0, 1, 0),
			ZIndex = 101,
			Parent = NotifyOuter,
		})

		Library:AddToRegistry(NotifyInner, {
			BackgroundColor3 = "MainColor",
			BorderColor3 = "OutlineColor",
		}, true)

		local InnerFrame = Library:Create("Frame", {
			BackgroundColor3 = Color3.new(1, 1, 1),
			BorderSizePixel = 0,
			Position = UDim2.new(0, 1, 0, 1),
			Size = UDim2.new(1, -2, 1, -2),
			ZIndex = 102,
			Parent = NotifyInner,
		})

		local Gradient = Library:Create("UIGradient", {
			Color = ColorSequence.new({
				ColorSequenceKeypoint.new(0, Library:GetDarkerColor(Library.MainColor)),
				ColorSequenceKeypoint.new(1, Library.MainColor),
			}),
			Rotation = -90,
			Parent = InnerFrame,
		})

		Library:AddToRegistry(Gradient, {
			Color = function()
				return ColorSequence.new({
					ColorSequenceKeypoint.new(0, Library:GetDarkerColor(Library.MainColor)),
					ColorSequenceKeypoint.new(1, Library.MainColor),
				})
			end,
		})

		local NotifyLabel = Library:CreateLabel({
			Position = UDim2.new(0, 4, 0, 0),
			Size = UDim2.new(1, -4, 1, 0),
			Text = Text,
			TextXAlignment = Enum.TextXAlignment.Left,
			TextSize = ScaledTextSize,
			ZIndex = 103,
			Parent = InnerFrame,
		})

		local LeftColor = Library:Create("Frame", {
			BackgroundColor3 = Library.AccentColor,
			BorderSizePixel = 0,
			Position = UDim2.new(0, -1, 0, -1),
			Size = UDim2.new(0, 3, 1, 2),
			ZIndex = 104,
			Parent = NotifyOuter,
		})

		Library:AddToRegistry(LeftColor, {
			BackgroundColor3 = "AccentColor",
		}, true)

		local TweenTime = 0.4
		local ScaledXSize = XSize + 8 + 4

		pcall(NotifyOuter.TweenSize, NotifyOuter, UDim2.new(0, ScaledXSize, 0, YSize), "Out", "Quad", TweenTime, true)

		local function TweenOut()
			pcall(NotifyOuter.TweenSize, NotifyOuter, UDim2.new(0, 0, 0, YSize), "Out", "Quad", TweenTime, true)

			task.wait(TweenTime)

			NotifyOuter:Destroy()
		end

		local Connection = nil
		local Connection2 = nil

		Connection = InnerFrame.InputBegan:Connect(function(Input)
			if Input.UserInputType == Enum.UserInputType.MouseButton1 then
				TweenOut()
				Connection:Disconnect()
			end
		end)

		Connection2 = InnerFrame.MouseEnter:Connect(function()
			if game:GetService("UserInputService"):IsMouseButtonPressed(Enum.UserInputType.MouseButton1) then
				TweenOut()
				Connection2:Disconnect()
			end
		end)

		return TweenOut
	end

	function Library:Notify(Text, Time)
		if shared.Lycoris.silent then
			return
		end

		local NotifScale = tonumber(Options["NotificationScale"] and Options["NotificationScale"].Value) or 100
		NotifScale = NotifScale / 100

		local ScaledTextSize = 14 * NotifScale
		local XSize, YSize = Library:GetTextBounds(Text, Library.Font, ScaledTextSize)

		YSize = YSize + (7 * NotifScale)

		local NotifyOuter = Library:Create("Frame", {
			BorderColor3 = Color3.new(0, 0, 0),
			Position = UDim2.new(0, 100, 0, 10),
			Size = UDim2.new(0, 0, 0, YSize),
			ClipsDescendants = true,
			ZIndex = 100,
			Parent = Library.NotificationArea,
		})

		local NotifyInner = Library:Create("Frame", {
			BackgroundColor3 = Library.MainColor,
			BorderColor3 = Library.OutlineColor,
			BorderMode = Enum.BorderMode.Inset,
			Size = UDim2.new(1, 0, 1, 0),
			ZIndex = 101,
			Parent = NotifyOuter,
		})

		Library:AddToRegistry(NotifyInner, {
			BackgroundColor3 = "MainColor",
			BorderColor3 = "OutlineColor",
		}, true)

		local InnerFrame = Library:Create("Frame", {
			BackgroundColor3 = Color3.new(1, 1, 1),
			BorderSizePixel = 0,
			Position = UDim2.new(0, 1, 0, 1),
			Size = UDim2.new(1, -2, 1, -2),
			ZIndex = 102,
			Parent = NotifyInner,
		})

		local Gradient = Library:Create("UIGradient", {
			Color = ColorSequence.new({
				ColorSequenceKeypoint.new(0, Library:GetDarkerColor(Library.MainColor)),
				ColorSequenceKeypoint.new(1, Library.MainColor),
			}),
			Rotation = -90,
			Parent = InnerFrame,
		})

		Library:AddToRegistry(Gradient, {
			Color = function()
				return ColorSequence.new({
					ColorSequenceKeypoint.new(0, Library:GetDarkerColor(Library.MainColor)),
					ColorSequenceKeypoint.new(1, Library.MainColor),
				})
			end,
		})

		local NotifyLabel = Library:CreateLabel({
			Position = UDim2.new(0, 4, 0, 0),
			Size = UDim2.new(1, -4, 1, 0),
			Text = Text,
			TextXAlignment = Enum.TextXAlignment.Left,
			TextSize = ScaledTextSize,
			ZIndex = 103,
			Parent = InnerFrame,
		})

		local LeftColor = Library:Create("Frame", {
			BackgroundColor3 = Library.AccentColor,
			BorderSizePixel = 0,
			Position = UDim2.new(0, -1, 0, -1),
			Size = UDim2.new(0, 3, 1, 2),
			ZIndex = 104,
			Parent = NotifyOuter,
		})

		Library:AddToRegistry(LeftColor, {
			BackgroundColor3 = "AccentColor",
		}, true)

		local MovingReallyFast = Time and (Time - 0.8) <= 0.3 or false
		local TweenTime = MovingReallyFast and 0.1 or 0.4

		local ScaledXSize = XSize + 8 + 4

		pcall(NotifyOuter.TweenSize, NotifyOuter, UDim2.new(0, ScaledXSize, 0, YSize), "Out", "Quad", TweenTime, true)

		local function TweenOut()
			pcall(NotifyOuter.TweenSize, NotifyOuter, UDim2.new(0, 0, 0, YSize), "Out", "Quad", TweenTime, true)

			task.wait(TweenTime)

			NotifyOuter:Destroy()
		end

		local Connection = nil
		local Connection2 = nil

		Connection = InnerFrame.InputBegan:Connect(function(Input)
			if Input.UserInputType == Enum.UserInputType.MouseButton1 then
				TweenOut()
				Connection:Disconnect()
			end
		end)

		Connection2 = InnerFrame.MouseEnter:Connect(function()
			if game:GetService("UserInputService"):IsMouseButtonPressed(Enum.UserInputType.MouseButton1) then
				TweenOut()
				Connection2:Disconnect()
			end
		end)

		task.spawn(function()
			task.wait(Time or 5)

			TweenOut()
		end)
	end

	function Library:CreateWindow(...)
		local Arguments = { ... }
		local Config = { AnchorPoint = Vector2.zero }

		if type(...) == "table" then
			Config = ...
		else
			Config.Title = Arguments[1]
			Config.AutoShow = Arguments[2] or false
		end

		if type(Config.Title) ~= "string" then
			Config.Title = "No title"
		end
		if type(Config.TabPadding) ~= "number" then
			Config.TabPadding = 0
		end
		if type(Config.MenuFadeTime) ~= "number" then
			Config.MenuFadeTime = 0.2
		end

		if typeof(Config.Position) ~= "UDim2" then
			Config.Position = UDim2.fromOffset(175, 50)
		end
		if typeof(Config.Size) ~= "UDim2" then
			Config.Size = UDim2.fromOffset(550, 600)
		end

		if Config.Center then
			Config.AnchorPoint = Vector2.new(0.5, 0.5)
			Config.Position = UDim2.fromScale(0.5, 0.5)
		end

		local Window = {
			Tabs = {},
		}

		local Outer = Library:Create("Frame", {
			AnchorPoint = Config.AnchorPoint,
			BackgroundColor3 = Color3.new(0, 0, 0),
			BorderSizePixel = 0,
			Position = Config.Position,
			Size = Config.Size,
			Visible = false,
			ZIndex = 1,
			Parent = ScreenGui,
		})

		Library:MakeDraggable(Outer, 25)

		local Inner = Library:Create("Frame", {
			BackgroundColor3 = Library.MainColor,
			BorderColor3 = Library.AccentColor,
			BorderMode = Enum.BorderMode.Inset,
			Position = UDim2.new(0, 1, 0, 1),
			Size = UDim2.new(1, -2, 1, -2),
			ZIndex = 1,
			Parent = Outer,
		})

		Library:AddToRegistry(Inner, {
			BackgroundColor3 = "MainColor",
			BorderColor3 = "AccentColor",
		})

		local WindowLabel = Library:CreateLabel({
			Position = UDim2.new(0, 7, 0, 0),
			Size = UDim2.new(0, 0, 0, 25),
			Text = Config.Title or "",
			TextColor3 = Library.AccentColor,
			TextXAlignment = Enum.TextXAlignment.Left,
			ZIndex = 1,
			Parent = Inner,
		})

		Library:AddToRegistry(WindowLabel, {
			TextColor3 = "AccentColor",
		})

		local MainSectionOuter = Library:Create("Frame", {
			BackgroundColor3 = Library.BackgroundColor,
			BorderColor3 = Library.OutlineColor,
			Position = UDim2.new(0, 8, 0, 25),
			Size = UDim2.new(1, -16, 1, -33),
			ZIndex = 1,
			Parent = Inner,
		})

		Library:AddToRegistry(MainSectionOuter, {
			BackgroundColor3 = "BackgroundColor",
			BorderColor3 = "OutlineColor",
		})

		local MainSectionInner = Library:Create("Frame", {
			BackgroundColor3 = Library.BackgroundColor,
			BorderColor3 = Color3.new(0, 0, 0),
			BorderMode = Enum.BorderMode.Inset,
			Position = UDim2.new(0, 0, 0, 0),
			Size = UDim2.new(1, 0, 1, 0),
			ZIndex = 1,
			Parent = MainSectionOuter,
		})

		Library:AddToRegistry(MainSectionInner, {
			BackgroundColor3 = "BackgroundColor",
		})

		local TabArea = Library:Create("Frame", {
			BackgroundTransparency = 1,
			Position = UDim2.new(0, 8, 0, 8),
			Size = UDim2.new(1, -16, 0, 21),
			ZIndex = 1,
			Parent = MainSectionInner,
		})

		local TabListLayout = Library:Create("UIListLayout", {
			Padding = UDim.new(0, Config.TabPadding),
			FillDirection = Enum.FillDirection.Horizontal,
			SortOrder = Enum.SortOrder.LayoutOrder,
			Parent = TabArea,
		})

		local TabContainer = Library:Create("Frame", {
			BackgroundColor3 = Library.MainColor,
			BorderColor3 = Library.OutlineColor,
			Position = UDim2.new(0, 8, 0, 30),
			Size = UDim2.new(1, -16, 1, -38),
			ZIndex = 2,
			Parent = MainSectionInner,
		})

		Library:AddToRegistry(TabContainer, {
			BackgroundColor3 = "MainColor",
			BorderColor3 = "OutlineColor",
		})

		function Window:SetWindowTitle(Title)
			WindowLabel.Text = Title
		end

		---Add a tab to the window.
		---@param Name string
		---@return table
		function Window:AddTab(Name)
			local Tab = {
				GroupboxCount = 0,
				TabboxCount = 0,
				Groupboxes = {},
				Tabboxes = {},
			}

			local TabButtonWidth = Library:GetTextBounds(Name, Library.Font, 16)

			local TabButton = Library:Create("Frame", {
				BackgroundColor3 = Library.BackgroundColor,
				BorderColor3 = Library.OutlineColor,
				Size = UDim2.new(0, TabButtonWidth + 8 + 4, 1, 0),
				ZIndex = 1,
				Parent = TabArea,
			})

			Library:AddToRegistry(TabButton, {
				BackgroundColor3 = "BackgroundColor",
				BorderColor3 = "OutlineColor",
			})

			local TabButtonLabel = Library:CreateLabel({
				Position = UDim2.new(0, 0, 0, 0),
				Size = UDim2.new(1, 0, 1, -1),
				Text = Name,
				ZIndex = 1,
				Parent = TabButton,
			})

			local Blocker = Library:Create("Frame", {
				BackgroundColor3 = Library.MainColor,
				BorderSizePixel = 0,
				Position = UDim2.new(0, 0, 1, 0),
				Size = UDim2.new(1, 0, 0, 1),
				BackgroundTransparency = 1,
				ZIndex = 3,
				Parent = TabButton,
			})

			Library:AddToRegistry(Blocker, {
				BackgroundColor3 = "MainColor",
			})

			local TabFrame = Library:Create("Frame", {
				Name = "TabFrame",
				BackgroundTransparency = 1,
				Position = UDim2.new(0, 0, 0, 0),
				Size = UDim2.new(1, 0, 1, 0),
				Visible = false,
				ZIndex = 2,
				Parent = TabContainer,
			})

			local LeftSide = Library:Create("ScrollingFrame", {
				BackgroundTransparency = 1,
				BorderSizePixel = 0,
				Position = UDim2.new(0, 8 - 1, 0, 8 - 1),
				Size = UDim2.new(0.5, -12 + 2, 0, 507 + 2),
				CanvasSize = UDim2.new(0, 0, 0, 0),
				BottomImage = "",
				TopImage = "",
				ScrollBarThickness = 0,
				ZIndex = 2,
				Parent = TabFrame,
			})

			local RightSide = Library:Create("ScrollingFrame", {
				BackgroundTransparency = 1,
				BorderSizePixel = 0,
				Position = UDim2.new(0.5, 4 + 1, 0, 8 - 1),
				Size = UDim2.new(0.5, -12 + 2, 0, 507 + 2),
				CanvasSize = UDim2.new(0, 0, 0, 0),
				BottomImage = "",
				TopImage = "",
				ScrollBarThickness = 0,
				ZIndex = 2,
				Parent = TabFrame,
			})

			Library:Create("UIListLayout", {
				Padding = UDim.new(0, 8),
				FillDirection = Enum.FillDirection.Vertical,
				SortOrder = Enum.SortOrder.LayoutOrder,
				HorizontalAlignment = Enum.HorizontalAlignment.Center,
				Parent = LeftSide,
			})

			Library:Create("UIListLayout", {
				Padding = UDim.new(0, 8),
				FillDirection = Enum.FillDirection.Vertical,
				SortOrder = Enum.SortOrder.LayoutOrder,
				HorizontalAlignment = Enum.HorizontalAlignment.Center,
				Parent = RightSide,
			})

			for _, Side in next, { LeftSide, RightSide } do
				Side:WaitForChild("UIListLayout"):GetPropertyChangedSignal("AbsoluteContentSize"):Connect(function()
					Side.CanvasSize = UDim2.fromOffset(0, Side.UIListLayout.AbsoluteContentSize.Y)
				end)
			end

			function Tab:ShowTab()
				for _, Tab in next, Window.Tabs do
					Tab:HideTab()
				end

				Blocker.BackgroundTransparency = 0
				TabButton.BackgroundColor3 = Library.MainColor
				Library.RegistryMap[TabButton].Properties.BackgroundColor3 = "MainColor"
				TabFrame.Visible = true
			end

			function Tab:HideTab()
				Blocker.BackgroundTransparency = 1
				TabButton.BackgroundColor3 = Library.BackgroundColor
				Library.RegistryMap[TabButton].Properties.BackgroundColor3 = "BackgroundColor"
				TabFrame.Visible = false
			end

			function Tab:SetLayoutOrder(Position)
				TabButton.LayoutOrder = Position
				TabListLayout:ApplyLayout()
			end

			function Tab:AddGroupbox(Info)
				local Groupbox = { Name = Info.Name }

				local BoxOuter = Library:Create("Frame", {
					BackgroundColor3 = Library.BackgroundColor,
					BorderColor3 = Library.OutlineColor,
					BorderMode = Enum.BorderMode.Inset,
					Size = UDim2.new(1, 0, 0, 507 + 2),
					ZIndex = 2,
					Parent = Info.Side == 1 and LeftSide or RightSide,
				})

				Library:AddToRegistry(BoxOuter, {
					BackgroundColor3 = "BackgroundColor",
					BorderColor3 = "OutlineColor",
				})

				local BoxInner = Library:Create("Frame", {
					BackgroundColor3 = Library.BackgroundColor,
					BorderColor3 = Color3.new(0, 0, 0),
					-- BorderMode = Enum.BorderMode.Inset;
					Size = UDim2.new(1, -2, 1, -2),
					Position = UDim2.new(0, 1, 0, 1),
					ZIndex = 4,
					Parent = BoxOuter,
				})

				Library:AddToRegistry(BoxInner, {
					BackgroundColor3 = "BackgroundColor",
				})

				local Highlight = Library:Create("Frame", {
					BackgroundColor3 = Library.AccentColor,
					BorderSizePixel = 0,
					Size = UDim2.new(1, 0, 0, 2),
					ZIndex = 5,
					Parent = BoxInner,
				})

				Library:AddToRegistry(Highlight, {
					BackgroundColor3 = "AccentColor",
				})

				local GroupboxLabel = Library:CreateLabel({
					Size = UDim2.new(1, 0, 0, 18),
					Position = UDim2.new(0, 4, 0, 2),
					TextSize = 14,
					Text = Info.Name,
					TextXAlignment = Enum.TextXAlignment.Left,
					ZIndex = 5,
					Parent = BoxInner,
				})

				local Container = Library:Create("Frame", {
					BackgroundTransparency = 1,
					Position = UDim2.new(0, 4, 0, 20),
					Size = UDim2.new(1, -4, 1, -20),
					ZIndex = 1,
					Parent = BoxInner,
				})

				Library:Create("UIListLayout", {
					FillDirection = Enum.FillDirection.Vertical,
					SortOrder = Enum.SortOrder.LayoutOrder,
					Parent = Container,
				})

				function Groupbox:Resize()
					local Size = 0

					for _, Element in next, Groupbox.Container:GetChildren() do
						if (not Element:IsA("UIListLayout")) and Element.Visible then
							Size = Size + Element.Size.Y.Offset
						end
					end

					BoxOuter.Size = UDim2.new(1, 0, 0, 20 + Size + 2 + 2)
				end

				Groupbox.Container = Container
				setmetatable(Groupbox, BaseGroupbox)

				Groupbox:AddBlank(3)
				Groupbox:Resize()

				Tab.GroupboxCount = Tab.GroupboxCount + 1
				Tab.Groupboxes[Info.Name] = Groupbox

				return Groupbox
			end

			function Tab:AddDynamicGroupbox(Name)
				if (Tab.GroupboxCount + Tab.TabboxCount) % 2 == 0 then
					return Tab:AddLeftGroupbox(Name)
				else
					return Tab:AddRightGroupbox(Name)
				end
			end

			function Tab:AddLeftGroupbox(Name)
				return Tab:AddGroupbox({ Side = 1, Name = Name })
			end

			function Tab:AddRightGroupbox(Name)
				return Tab:AddGroupbox({ Side = 2, Name = Name })
			end

			function Tab:AddTabbox(Info)
				local Tabbox = {
					Tabs = {},
				}

				local BoxOuter = Library:Create("Frame", {
					BackgroundColor3 = Library.BackgroundColor,
					BorderColor3 = Library.OutlineColor,
					BorderMode = Enum.BorderMode.Inset,
					Size = UDim2.new(1, 0, 0, 0),
					ZIndex = 2,
					Parent = Info.Side == 1 and LeftSide or RightSide,
				})

				Library:AddToRegistry(BoxOuter, {
					BackgroundColor3 = "BackgroundColor",
					BorderColor3 = "OutlineColor",
				})

				local BoxInner = Library:Create("Frame", {
					BackgroundColor3 = Library.BackgroundColor,
					BorderColor3 = Color3.new(0, 0, 0),
					-- BorderMode = Enum.BorderMode.Inset;
					Size = UDim2.new(1, -2, 1, -2),
					Position = UDim2.new(0, 1, 0, 1),
					ZIndex = 4,
					Parent = BoxOuter,
				})

				Library:AddToRegistry(BoxInner, {
					BackgroundColor3 = "BackgroundColor",
				})

				local Highlight = Library:Create("Frame", {
					BackgroundColor3 = Library.AccentColor,
					BorderSizePixel = 0,
					Size = UDim2.new(1, 0, 0, 2),
					ZIndex = 10,
					Parent = BoxInner,
				})

				Library:AddToRegistry(Highlight, {
					BackgroundColor3 = "AccentColor",
				})

				local TabboxButtons = Library:Create("Frame", {
					BackgroundTransparency = 1,
					Position = UDim2.new(0, 0, 0, 1),
					Size = UDim2.new(1, 0, 0, 18),
					ZIndex = 5,
					Parent = BoxInner,
				})

				Library:Create("UIListLayout", {
					FillDirection = Enum.FillDirection.Horizontal,
					HorizontalAlignment = Enum.HorizontalAlignment.Left,
					SortOrder = Enum.SortOrder.LayoutOrder,
					Parent = TabboxButtons,
				})

				function Tabbox:AddTab(Name)
					local Tab = {}

					local Button = Library:Create("Frame", {
						BackgroundColor3 = Library.MainColor,
						BorderColor3 = Color3.new(0, 0, 0),
						Size = UDim2.new(0.5, 0, 1, 0),
						ZIndex = 6,
						Parent = TabboxButtons,
					})

					Library:AddToRegistry(Button, {
						BackgroundColor3 = "MainColor",
					})

					local ButtonLabel = Library:CreateLabel({
						Size = UDim2.new(1, 0, 1, 0),
						TextSize = 14,
						Text = Name,
						TextXAlignment = Enum.TextXAlignment.Center,
						ZIndex = 7,
						Parent = Button,
					})

					local Block = Library:Create("Frame", {
						BackgroundColor3 = Library.BackgroundColor,
						BorderSizePixel = 0,
						Position = UDim2.new(0, 0, 1, 0),
						Size = UDim2.new(1, 0, 0, 1),
						Visible = false,
						ZIndex = 9,
						Parent = Button,
					})

					Library:AddToRegistry(Block, {
						BackgroundColor3 = "BackgroundColor",
					})

					local Container = Library:Create("Frame", {
						BackgroundTransparency = 1,
						Position = UDim2.new(0, 4, 0, 20),
						Size = UDim2.new(1, -4, 1, -20),
						ZIndex = 1,
						Visible = false,
						Parent = BoxInner,
					})

					Library:Create("UIListLayout", {
						FillDirection = Enum.FillDirection.Vertical,
						SortOrder = Enum.SortOrder.LayoutOrder,
						Parent = Container,
					})

					function Tab:Show()
						for _, Tab in next, Tabbox.Tabs do
							Tab:Hide()
						end

						Container.Visible = true
						Block.Visible = true

						Button.BackgroundColor3 = Library.BackgroundColor
						Library.RegistryMap[Button].Properties.BackgroundColor3 = "BackgroundColor"

						Tab:Resize()
					end

					function Tab:Hide()
						Container.Visible = false
						Block.Visible = false

						Button.BackgroundColor3 = Library.MainColor
						Library.RegistryMap[Button].Properties.BackgroundColor3 = "MainColor"
					end

					function Tab:Resize()
						local TabCount = 0

						for _, Tab in next, Tabbox.Tabs do
							TabCount = TabCount + 1
						end

						for _, Button in next, TabboxButtons:GetChildren() do
							if not Button:IsA("UIListLayout") then
								Button.Size = UDim2.new(1 / TabCount, 0, 1, 0)
							end
						end

						if not Container.Visible then
							return
						end

						local Size = 0

						for _, Element in next, Tab.Container:GetChildren() do
							if (not Element:IsA("UIListLayout")) and Element.Visible then
								Size = Size + Element.Size.Y.Offset
							end
						end

						BoxOuter.Size = UDim2.new(1, 0, 0, 20 + Size + 2 + 2)
					end

					Button.InputBegan:Connect(function(Input)
						if
							Input.UserInputType == Enum.UserInputType.MouseButton1
							and not Library:MouseIsOverOpenedFrame()
						then
							Tab:Show()
							Tab:Resize()
						end
					end)

					Tab.Container = Container
					Tabbox.Tabs[Name] = Tab

					setmetatable(Tab, BaseGroupbox)

					Tab:AddBlank(3)
					Tab:Resize()

					-- Show first tab (number is 2 cus of the UIListLayout that also sits in that instance)
					if #TabboxButtons:GetChildren() == 2 then
						Tab:Show()
					end

					return Tab
				end

				Tab.Tabboxes[Info.Name or ""] = Tabbox
				Tab.TabboxCount = Tab.TabboxCount + 1

				return Tabbox
			end

			function Tab:AddLeftTabbox(Name)
				return Tab:AddTabbox({ Name = Name, Side = 1 })
			end

			function Tab:AddRightTabbox(Name)
				return Tab:AddTabbox({ Name = Name, Side = 2 })
			end

			function Tab:AddDynamicTabbox(Name)
				if (Tab.GroupboxCount + Tab.TabboxCount) % 2 == 0 then
					return Tab:AddLeftTabbox(Name)
				else
					return Tab:AddRightTabbox(Name)
				end
			end

			TabButton.InputBegan:Connect(function(Input)
				if Input.UserInputType == Enum.UserInputType.MouseButton1 then
					Tab:ShowTab()
				end
			end)

			-- This was the first tab added, so we show it by default.
			if #TabContainer:GetChildren() == 1 then
				Tab:ShowTab()
			end

			Window.Tabs[Name] = Tab
			return Tab
		end

		local ModalElement = Library:Create("TextButton", {
			BackgroundTransparency = 1,
			Size = UDim2.new(0, 0, 0, 0),
			Visible = true,
			Text = "",
			Modal = false,
			Parent = ScreenGui,
		})

		local TransparencyCache = {}
		local Fading = false
		local FirstTime = false

		function Library:Toggle()
			if Fading then
				return
			end

			local FadeTime = Config.MenuFadeTime
			local ShouldFade = FadeTime > 0.01

			if ShouldFade then
				Fading = true
			end

			Toggled = not Toggled
			ModalElement.Modal = Toggled

			if Toggled then
				Outer.Visible = true
			end

			if not Toggled then
				for _, ColorPicker in next, ColorPickers do
					ColorPicker:Hide()
				end

				for _, ContextMenu in next, ContextMenus do
					ContextMenu:Hide()
				end

				for _, Tooltip in next, Tooltips do
					Tooltip.Visible = false
				end

				for _, ModeSelectFrame in next, ModeSelectFrames do
					ModeSelectFrame.Visible = false
				end
			end

			if ShouldFade or not FirstTime then
				for _, Desc in next, Outer:GetDescendants() do
					local Properties = {}

					if Desc:IsA("ImageLabel") then
						table.insert(Properties, "ImageTransparency")
						table.insert(Properties, "BackgroundTransparency")
					elseif Desc:IsA("TextLabel") or Desc:IsA("TextBox") then
						table.insert(Properties, "TextTransparency")
					elseif Desc:IsA("Frame") or Desc:IsA("ScrollingFrame") then
						table.insert(Properties, "BackgroundTransparency")
					elseif Desc:IsA("UIStroke") then
						table.insert(Properties, "Transparency")
					end

					local Cache = TransparencyCache[Desc]

					if not Cache then
						Cache = {}
						TransparencyCache[Desc] = Cache
					end

					for _, Prop in next, Properties do
						if not Cache[Prop] then
							Cache[Prop] = Desc[Prop]
						end

						if Cache[Prop] == 1 then
							continue
						end

						TweenService:Create(
							Desc,
							TweenInfo.new(FadeTime, Enum.EasingStyle.Linear),
							{ [Prop] = Toggled and Cache[Prop] or 1 }
						):Play()
					end
				end

				task.wait(FadeTime)

				FirstTime = true
			end

			Outer.Visible = Toggled

			Fading = false
		end

		Library:GiveSignal(InputService.InputBegan:Connect(function(Input, Processed)
			if type(Library.ToggleKeybind) == "table" and Library.ToggleKeybind.Type == "KeyPicker" then
				if
					Input.UserInputType == Enum.UserInputType.Keyboard
					and Input.KeyCode.Name == Library.ToggleKeybind.Value
				then
					task.spawn(Library.Toggle)
				end
			elseif
				Input.KeyCode == Enum.KeyCode.RightControl
				or (Input.KeyCode == Enum.KeyCode.RightShift and not Processed)
			then
				task.spawn(Library.Toggle)
			end
		end))

		if Config.AutoShow then
			task.spawn(Library.Toggle)
		end

		Window.Holder = Outer

		return Window
	end

	local function OnPlayerChange()
		local PlayerList = GetPlayersString()

		for _, Value in next, Options do
			if Value.Type == "Dropdown" and Value.SpecialType == "Player" then
				Value:SetValues(PlayerList)
			end
		end
	end

	Players.PlayerAdded:Connect(OnPlayerChange)
	Players.PlayerRemoving:Connect(OnPlayerChange)

	return Library
end)()

end)
__bundle_register("Utility/CoreGuiManager", function(require, _LOADED, __bundle_register, __bundle_modules)
---@note: We need to be careful where we use CoreGui because exploits have this weird permission issue. We need consistent setting of the parent.
---@note: All scripts that must access this module should require it at the top of the file where it gets loaded.
local CoreGuiManager = {}

-- Instance list.
local instances = {}

---Mark an instance to be parented to CoreGui at initialization.
---@param instance Instance
---@return Instance
function CoreGuiManager.imark(instance)
	instances[#instances + 1] = instance
	return instance
end

---Consistently and safely parent(s) all instances to CoreGui.
---@return table
function CoreGuiManager.set()
	local coreGui = game:GetService("CoreGui")

	for _, instance in next, instances do
		instance.Parent = coreGui
	end

	return instances
end

---Remove all stored instances.
function CoreGuiManager.clear()
	for _, instance in next, instances do
		instance:Destroy()
	end

	instances = {}
end

---Return CoreGuiManager module.
return CoreGuiManager

end)
__bundle_register("Utility/Profiler", function(require, _LOADED, __bundle_register, __bundle_modules)
return LPH_NO_VIRTUALIZE(function()
	-- Profile code time.
	-- Determine what parts of our script are lagging us through the microprofiler.
	local Profiler = {}

	---Runs a function with a specified profiler label.
	---@todo: This breaks on yielding functions.
	---@param label string
	---@param functionToProfile function
	function Profiler.run(label, functionToProfile, ...)
		local okay = shared and typeof(shared.Lycoris) == "table" and not shared.Lycoris.silent

		-- Profile under label.
		if okay then
			debug.profilebegin(label)
		end

		-- Call function to profile.
		local ret_values = table.pack(functionToProfile(...))

		-- End most recent profiling.
		if okay then
			debug.profileend()
		end

		-- Return values.
		return unpack(ret_values)
	end

	---Wrap function in a profiler statement with label.
	---@param label string
	---@param functionToProfile function
	---@return function
	function Profiler.wrap(label, functionToProfile)
		return function(...)
			return Profiler.run(label, functionToProfile, ...)
		end
	end

	-- Return profiler module.
	return Profiler
end)()

end)
__bundle_register("Game/InputClient", function(require, _LOADED, __bundle_register, __bundle_modules)
-- InputClient module. Deals with everything related to that script. Re-created functions and all.
---@note: Never call the roll function from the cache. We only need this to get the last roll move direction.
local InputClient = {
	sprintFunctionCache = nil,
	rollFunctionCache = nil,
}

---@module Utility.Logger
local Logger = require("Utility/Logger")

---@module Game.KeyHandling
local KeyHandling = require("Game/KeyHandling")

---@module Utility.TaskSpawner
local TaskSpawner = require("Utility/TaskSpawner")

-- Services.
local runService = game:GetService("RunService")
local replicatedStorage = game:GetService("ReplicatedStorage")
local players = game:GetService("Players")
local tweenService = game:GetService("TweenService")

-- Functions.
local unreliableFireServer = Instance.new("UnreliableRemoteEvent").FireServer

-- Cache.
local inputDataCache = nil

-- Tracks.
local freefallTrack = nil
local slideJumpTrack = nil
local cancelLeftTrack = nil
local cancelRightTrack = nil
local jumpAnimTrack = nil

---Check if we landed.
---@return boolean
local landedCheck = LPH_NO_VIRTUALIZE(function()
	local effectReplicator = replicatedStorage:FindFirstChild("EffectReplicator")
	if not effectReplicator then
		return
	end

	local effectReplicatorModule = require(effectReplicator)
	if not effectReplicatorModule then
		return
	end

	local humanController = InputClient.getHumanController()
	if not humanController then
		return
	end

	local sprintSpeed = effectReplicatorModule:FindEffect("SprintSpeed")
	if not sprintSpeed then
		return
	end

	local character = players.LocalPlayer.Character
	if not character then
		return
	end

	local characterHandler = character:FindFirstChild("CharacterHandler")
	local inputClient = characterHandler and characterHandler:FindFirstChild("InputClient")
	if not inputClient then
		return
	end

	local root = character:FindFirstChild("HumanoidRootPart")
	if not root then
		return
	end

	local humanoid = character:FindFirstChildWhichIsA("Humanoid")
	if not humanoid then
		return
	end

	local torso = character:FindFirstChild("Torso")
	if not torso then
		return
	end

	local groundSensor = humanController.GroundSensor
	if not groundSensor then
		return
	end

	local stopDodge = KeyHandling.getRemote("StopDodge")
	if not stopDodge then
		return
	end

	local inputData = InputClient.getInputData()
	if not inputData then
		return
	end

	local repDebris = replicatedStorage:FindFirstChild("Debris")
	if not repDebris then
		return
	end

	local sounds = replicatedStorage:FindFirstChild("Sounds")
	local sliding = sounds and sounds:FindFirstChild("Sliding")
	if not sliding then
		return
	end

	local modules = replicatedStorage:FindFirstChild("Modules")
	local vectorMaths = modules and modules:FindFirstChild("VectorMaths")
	local vectorMathModule = vectorMaths and require(vectorMaths)
	if not vectorMathModule then
		return
	end

	local sensedPart = groundSensor.SensedPart

	if not effectReplicatorModule:HasAny("Swimming", "ClientSwim", "Gliding", "Knocked") then
		if not sensedPart then
			return false
		end

		if sensedPart and sensedPart.CollisionGroup == "Ship" then
			effectReplicatorModule:EnsureEffect("OnShip")
		elseif effectReplicatorModule:HasEffect("OnShip") then
			effectReplicatorModule:RemoveEffectsOfClass("OnShip")
		end
	end

	if freefallTrack.IsPlaying then
		freefallTrack:Stop(0.15)
	end

	if not effectReplicatorModule:HasEffect("Falling") then
		return true
	end

	effectReplicatorModule:RemoveEffectsOfClass("Falling")
	effectReplicatorModule:RemoveEffectsOfClass("ShipJump")
	effectReplicatorModule:RemoveEffectsOfClass("WingDashCooldown")

	humanoid.Jump = false

	effectReplicatorModule:CreateEffect("Landed"):Debris(0.05)

	if effectReplicatorModule:HasEffect("SlideJumping") and not effectReplicatorModule:HasEffect("GravityField") then
		effectReplicatorModule:RemoveEffectsOfClass("SlideJumping")

		if sprintSpeed and sprintSpeed.Value >= 9 then
			sprintSpeed.Value = sprintSpeed.Value - 3
		end

		local lookVector = root.CFrame.LookVector * 3
		local slideJump = torso:FindFirstChild("SlideJump")

		if slideJump then
			slideJump:Destroy()
		end

		if effectReplicatorModule:HasEffect("Sprinting") then
			humanoid:LoadAnimation(inputClient.SlideJumpTransition):Play(nil, 0.65)
		else
			humanoid:LoadAnimation(inputClient.LandingAnim):Play(nil, 0.65)
		end

		if slideJumpTrack.IsPlaying and effectReplicatorModule:HasEffect("Equipped") then
			slideJumpTrack:Stop(0.15)
		end

		stopDodge:FireServer(inputData, effectReplicatorModule:HasEffect("LightAttack"), true)

		local lookVectorUnitMulti = lookVector.Unit * 50

		if sensedPart and sensedPart.AssemblyMass > root.AssemblyMass then
			lookVectorUnitMulti = lookVectorUnitMulti
				+ vectorMathModule.getVelocityAtPoint(sensedPart, groundSensor.HitFrame.Position)
		end

		local bodyVelocity = Instance.new("BodyVelocity")
		bodyVelocity.Name = "SlideJump2"
		bodyVelocity.Velocity = lookVectorUnitMulti
		bodyVelocity.MaxForce = Vector3.new(80000, 80000, 80000, 0)
		bodyVelocity:AddTag("AllowedBM")
		bodyVelocity.Parent = torso

		repDebris:Fire(bodyVelocity, 0.2)

		local slidingSound = sliding:Clone()
		slidingSound.Parent = root
		slidingSound:Play()

		repDebris:Fire(slidingSound, 0.25)

		tweenService
			:Create(slidingSound, TweenInfo.new(0.25), {
				Volume = 0,
			})
			:Play()
	end

	task.delay(0.1, function()
		effectReplicatorModule:RemoveEffectsOfClass("WallJumpCD")
		effectReplicatorModule:RemoveEffectsOfClass("BigMomentum")
		task.wait(2)
	end)

	return true
end)

---Check if we're in freefall.
local freefallCheck = LPH_NO_VIRTUALIZE(function()
	if landedCheck() then
		return
	end

	local effectReplicator = replicatedStorage:FindFirstChild("EffectReplicator")
	if not effectReplicator then
		return
	end

	local effectReplicatorModule = require(effectReplicator)
	if not effectReplicatorModule then
		return
	end

	local character = players.LocalPlayer.Character
	if not character then
		return
	end

	local root = character:FindFirstChild("HumanoidRootPart")
	if not root then
		return
	end

	if effectReplicatorModule:HasEffect("OnShip") then
		effectReplicatorModule:RemoveEffectsOfClass("OnShip")
		effectReplicatorModule:EnsureEffect("ShipJump"):Debris(5, true)
	end

	effectReplicatorModule:EnsureEffect("Falling")

	local fallTime = tick() - (effectReplicatorModule:GetEffectEpoch("Falling") or 0)

	if
		effectReplicatorModule:HasAny("DashIt", "Jumped", "UsingAbility", "LightAttack", "Action")
		or root.AssemblyLinearVelocity.Y > 0
	then
		return freefallTrack.IsPlaying and freefallTrack:Stop(0.1)
	end

	if freefallTrack.IsPlaying then
		return
	end

	if fallTime > 0.5 and root.AssemblyLinearVelocity.Y < 0 then
		freefallTrack.Priority = Enum.AnimationPriority.Movement
		freefallTrack:Play(0.3)
	end
end)

---In air check.
---@return boolean
local inAirCheck = LPH_NO_VIRTUALIZE(function()
	local effectReplicator = replicatedStorage:FindFirstChild("EffectReplicator")
	if not effectReplicator then
		return
	end

	local effectReplicatorModule = require(effectReplicator)
	if not effectReplicatorModule then
		return
	end

	local character = players.LocalPlayer.Character
	if not character then
		return
	end

	local root = character:FindFirstChild("HumanoidRootPart")
	if not root then
		return
	end

	local humanoid = character:FindFirstChildWhichIsA("Humanoid")
	if not humanoid then
		return
	end

	if effectReplicatorModule:HasEffect("Swimming") then
		return false
	elseif humanoid:GetState() == Enum.HumanoidStateType.Freefall then
		return true
	elseif effectReplicatorModule:HasEffect("AirBorne") then
		return true
	else
		return false
	end
end)

---Movement check.
---@return boolean
local movementCheck = LPH_NO_VIRTUALIZE(function()
	local effectReplicator = replicatedStorage:FindFirstChild("EffectReplicator")
	if not effectReplicator then
		return
	end

	local effectReplicatorModule = require(effectReplicator)
	if not effectReplicatorModule then
		return
	end

	if effectReplicatorModule:HasEffect("Action") then
		return false
	elseif effectReplicatorModule:HasEffect("NoParkour") then
		return false
	elseif effectReplicatorModule:HasEffect("Knocked") or effectReplicatorModule:HasEffect("Unconscious") then
		return false
	elseif effectReplicatorModule:HasEffect("Pinned") or effectReplicatorModule:HasEffect("Carried") then
		return false
	else
		return true
	end
end)

---Manual table find. Stupid Wave hotfix. Way slower to use this.
---@param tbl table
---@param value any
---@return boolean
local manualTableFind = LPH_NO_VIRTUALIZE(function(tbl, value)
	for _, val in next, tbl do
		if val ~= value then
			continue
		end

		return true
	end
end)

---Check if table has non-boolean values.
---@param tbl table
---@return boolean
local hasNonBooleans = LPH_NO_VIRTUALIZE(function(tbl)
	for _, value in next, tbl do
		if typeof(value) == "boolean" then
			continue
		end

		return false
	end

	return true
end)

---Get amount of entries in table.
---@param tbl table
local getTableLength = LPH_NO_VIRTUALIZE(function(tbl)
	local count = 0

	for _ in next, tbl do
		count = count + 1
	end

	return count
end)

---Validate keys.
---@param tbl table
local validateKeys = LPH_NO_VIRTUALIZE(function(tbl)
	local allowedKeys = {
		["Left"] = true,
		["Right"] = true,
		["W"] = true,
		["A"] = true,
		["S"] = true,
		["D"] = true,
		["Thumbstick1"] = true,
		["C"] = true,
		["f"] = true,
		["H"] = true,
		["Space"] = true,
		["ctrl"] = true,
	}

	for key, _ in next, tbl do
		if allowedKeys[key] then
			continue
		end

		return false
	end

	return true
end)

---Fetch last roll move direction.
---@return Vector3?
InputClient.getLastRollMoveDirection = LPH_NO_VIRTUALIZE(function()
	local rollFunction = InputClient.rollFunctionCache
	if not rollFunction then
		return nil
	end

	local lastRollMoveDirection = nil

	for _, upvalue in next, debug.getupvalues(rollFunction) do
		if typeof(upvalue) ~= "Vector3" then
			continue
		end

		lastRollMoveDirection = upvalue
		break
	end

	if not lastRollMoveDirection then
		lastRollMoveDirection = Vector3.zero
	end

	if lastRollMoveDirection and typeof(lastRollMoveDirection) ~= "Vector3" then
		return nil
	end

	return lastRollMoveDirection
end)

---Fetch human controller.
---@return table?
InputClient.getHumanController = LPH_NO_VIRTUALIZE(function()
	---@note: Shouldn't be too many connections to PreAnimation.
	for _, connection in next, getconnections(runService.PreAnimation) do
		local func = connection.Function
		if not func then
			continue
		end

		if iscclosure(func) or isexecutorclosure(func) then
			continue
		end

		local upvalues = debug.getupvalues(func)
		if not upvalues then
			continue
		end

		for _, upvalue in next, upvalues do
			if typeof(upvalue) ~= "table" then
				continue
			end

			if upvalue.Jumping == nil then
				continue
			end

			return upvalue
		end
	end

	return nil
end)

---Fetch input data.
---@return table?
InputClient.getInputData = LPH_NO_VIRTUALIZE(function()
	return inputDataCache
end)

---Left click function.
---@param cframe CFrame
---@param ignoreChecks boolean
InputClient.left = LPH_NO_VIRTUALIZE(function(cframe, ignoreChecks)
	local effectReplicator = replicatedStorage:FindFirstChild("EffectReplicator")
	if not effectReplicator then
		return
	end

	local effectReplicatorModule = require(effectReplicator)
	if not effectReplicatorModule then
		return
	end

	local character = players.LocalPlayer.Character
	if not character then
		return
	end

	local humanoid = character:FindFirstChildWhichIsA("Humanoid")
	if not humanoid then
		return
	end

	if effectReplicatorModule:HasEffect("InDialogue") then
		return
	end

	local inputData = InputClient.getInputData()
	if not inputData then
		return Logger.warn("Cannot left click without input data.")
	end

	local leftClickRemote = KeyHandling.getRemote("LeftClick")
	if not leftClickRemote then
		return
	end

	if not ignoreChecks then
		if
			effectReplicatorModule:HasEffect("LightAttack")
			or effectReplicatorModule:HasEffect("CriticalAttack")
			or effectReplicatorModule:HasEffect("Followup")
			or effectReplicatorModule:HasEffect("Parried")
		then
			return
		end
	end

	---@note: Missing M1-Hold and Input Buffering functionality but I don't think the caller cares about it.
	-- Call like the game does it so our hooks go through.
	unreliableFireServer(leftClickRemote, inAirCheck(), cframe, inputData)
end)

---Activate mantra.
---@param tool Tool
InputClient.amantra = LPH_NO_VIRTUALIZE(function(tool)
	local character = players.LocalPlayer.Character
	if not character then
		return Logger.warn("Cannot activate mantra without character.")
	end

	local humanoidRootPart = character:FindFirstChild("HumanoidRootPart")
	if not humanoidRootPart then
		return Logger.warn("Cannot activate mantra without humanoid root part.")
	end

	local characterHandler = character:FindFirstChild("CharacterHandler")
	if not characterHandler then
		return Logger.warn("Cannot activate mantra without character handler.")
	end

	local requests = characterHandler:FindFirstChild("Requests")
	if not requests then
		return Logger.warn("Cannot activate mantra without requests.")
	end

	local activateMantraRemote = requests:FindFirstChild("ActivateMantra")
	if not activateMantraRemote then
		return Logger.warn("Cannot activate mantra without ActivateMantra remote.")
	end

	if typeof(tool) ~= "Instance" or not tool:IsA("Tool") then
		return Logger.warn("Cannot activate mantra without valid tool.")
	end

	activateMantraRemote:FireServer(tool)
end)

---Crouch function.
---@param state boolean
InputClient.crouch = LPH_NO_VIRTUALIZE(function(state)
	local character = players.LocalPlayer.Character
	if not character then
		return Logger.warn("Cannot crouch without character.")
	end

	local humanoidRootPart = character:FindFirstChild("HumanoidRootPart")
	if not humanoidRootPart then
		return Logger.warn("Cannot crouch without humanoid root part.")
	end

	local characterHandler = character:FindFirstChild("CharacterHandler")
	if not characterHandler then
		return Logger.warn("Cannot crouch without character handler.")
	end

	local requests = characterHandler:FindFirstChild("Requests")
	if not requests then
		return Logger.warn("Cannot crouch without requests.")
	end

	local crouchRemote = requests:FindFirstChild("ServerCrouch")
	if not crouchRemote then
		return Logger.warn("Cannot crouch without crouch remote.")
	end

	crouchRemote:FireServer(state)
end)

---Vent function.
InputClient.vent = LPH_NO_VIRTUALIZE(function()
	local character = players.LocalPlayer.Character
	if not character then
		return Logger.warn("Cannot vent without character.")
	end

	local humanoidRootPart = character:FindFirstChild("HumanoidRootPart")
	if not humanoidRootPart then
		return Logger.warn("Cannot vent without humanoid root part.")
	end

	local characterHandler = character:FindFirstChild("CharacterHandler")
	if not characterHandler then
		return Logger.warn("Cannot vent without character handler.")
	end

	local requests = characterHandler:FindFirstChild("Requests")
	if not requests then
		return Logger.warn("Cannot vent without requests.")
	end

	local ventRemote = requests:FindFirstChild("Vent")
	if not ventRemote then
		return Logger.warn("Cannot vent without vent remote.")
	end

	ventRemote:FireServer()
end)

---Dodge function.
---@param options DodgeOptions
InputClient.dodge = LPH_NO_VIRTUALIZE(function(options)
	local dodge = KeyHandling.getRemote("Dodge")
	if not dodge then
		return Logger.warn("Cannot dodge without dodge remote.")
	end
	
	local stopDodge = KeyHandling.getRemote("StopDodge")
	if not stopDodge then
		return Logger.warn("Cannot dodge without stop dodge remote.")
	end

	local inputData = InputClient.getInputData()
	if not inputData then
		return Logger.warn("Cannot dodge without input data.")
	end
	
	local effectReplicator = replicatedStorage:FindFirstChild("EffectReplicator")
	if not effectReplicator then
		return Logger.warn("Cannot dodge without effect replicator.")
	end

	local effectReplicatorModule = require(effectReplicator)
	if not effectReplicatorModule then
		return Logger.warn("Cannot dodge without effect replicator module.")
	end

	if options.direct then
		dodge:FireServer("roll", nil, nil, false)

		-- Delay required for extra dodge frames.
		task.wait(.15)

		return stopDodge:FireServer(inputData, effectReplicatorModule:HasEffect("LightAttack"), true)
	end

	local character = players.LocalPlayer.Character
	if not character then
		return Logger.warn("Cannot dodge without character.")
	end

	local characterHandler = character:FindFirstChild("CharacterHandler")
	local inputClient = characterHandler and characterHandler:FindFirstChild("InputClient")
	if not inputClient then
		return Logger.warn("Cannot dodge without input client.")
	end

	local humanoid = character:FindFirstChildWhichIsA("Humanoid")
	if not humanoid then
		return Logger.warn("Cannot dodge without humanoid.")
	end

	local root = character:FindFirstChild("HumanoidRootPart")
	if not root then
		return Logger.warn("Cannot dodge without humanoid root part.")
	end

	local unblock = KeyHandling.getRemote("Unblock")
	if not unblock then
		return Logger.warn("Cannot dodge without unblock remote.")
	end

	local requests = replicatedStorage:FindFirstChild("Requests")
	local clientEffectDirect = requests and requests:FindFirstChild("ClientEffectDirect")
	if not clientEffectDirect then
		return Logger.warn("Cannot dodge without ClientEffectDirect remote.")
	end

	local characterHashes = replicatedStorage:FindFirstChild("CharacterHashes")
	local characterHashesModule = characterHashes and require(characterHashes)
	local characterHashData = characterHashesModule and characterHashesModule.GetDynamic(character)
	if not characterHashData then
		return Logger.warn("Cannot dodge without character hash data.")
	end

	local sounds = replicatedStorage:FindFirstChild("Sounds")
	local windFlash = sounds and sounds:FindFirstChild("WindFlash")
	local windFlashTwo = sounds and sounds:FindFirstChild("WindFlash2")
	local ssLightning = sounds and sounds:FindFirstChild("SSlightning")
	local waterDashSound = sounds and sounds:FindFirstChild("WaterDash")
	local flap2 = sounds and sounds:FindFirstChild("Flap2")
	local airDodge = sounds and sounds:FindFirstChild("AirDodge")
	local rollSound = sounds and sounds:FindFirstChild("Roll")

	if
		not windFlash
		or not windFlashTwo
		or not ssLightning
		or not waterDashSound
		or not flap2
		or not airDodge
		or not rollSound
	then
		return Logger.warn("Cannot dodge without required sounds.")
	end

	local assets = replicatedStorage:FindFirstChild("Assets")
	local staticSpear = assets and assets:FindFirstChild("StaticSpear1")
	local staticSpearTwo = assets and assets:FindFirstChild("StaticSpear2")

	local anims = assets and assets:FindFirstChild("Anims")
	local movement = anims and anims:FindFirstChild("Movement")
	local roll = movement and movement:FindFirstChild("Roll")
	local waterDash = movement and movement:FindFirstChild("WaterDash")

	local forwardRoll = roll and roll:FindFirstChild("ForwardRoll")
	local backRoll = roll and roll:FindFirstChild("BackRoll")
	local rightRoll = roll and roll:FindFirstChild("RightRoll")
	local leftRoll = roll and roll:FindFirstChild("LeftRoll")

	if not forwardRoll or not backRoll or not rightRoll or not leftRoll then
		return Logger.warn("Cannot dodge without roll animations.")
	end

	local forwardWaterDash = waterDash and waterDash:FindFirstChild("ForwardWaterDash")
	local backWaterDash = waterDash and waterDash:FindFirstChild("BackWaterDash")
	local rightWaterDash = waterDash and waterDash:FindFirstChild("RightWaterDash")
	local leftWaterDash = waterDash and waterDash:FindFirstChild("LeftWaterDash")

	if not forwardWaterDash or not backWaterDash or not rightWaterDash or not leftWaterDash then
		return Logger.warn("Cannot dodge without water dash animations.")
	end

	local rollToWaterMap = {
		[forwardRoll] = forwardWaterDash,
		[backRoll] = backWaterDash,
		[rightRoll] = rightWaterDash,
		[leftRoll] = leftWaterDash,
	}

	if not staticSpear or not staticSpearTwo then
		return Logger.warn("Cannot dodge without static spear assets.")
	end

	if not freefallTrack or not slideJumpTrack then
		return Logger.warn("Cannot dodge without freefall or slide jump tracks.")
	end

	if not cancelLeftTrack or not cancelRightTrack then
		return Logger.warn("Cannot dodge without cancel tracks.")
	end

	local humanController = InputClient.getHumanController()
	if not humanController then
		return Logger.warn("Cannot dodge without human controller.")
	end

	local repDebris = replicatedStorage:FindFirstChild("Debris")
	if not repDebris then
		return Logger.warn("Cannot dodge without Debris service.")
	end

	local modules = replicatedStorage:FindFirstChild("Modules")
	local vectorMaths = modules and modules:FindFirstChild("VectorMaths")
	local vectorMathModule = vectorMaths and require(vectorMaths)

	local collisionUtils = modules and modules:FindFirstChild("CollisionUtils")
	local collisionUtilsModule = collisionUtils and require(collisionUtils)

	local checks = modules and modules:FindFirstChild("Checks")
	local checksModule = checks and require(checks)(effectReplicatorModule)

	if not vectorMathModule or not collisionUtilsModule or not checksModule then
		return Logger.warn("Cannot dodge without required modules.")
	end

	local rootAttachment = root:FindFirstChild("RootAttachment")
	if not rootAttachment then
		return Logger.warn("Cannot dodge without root attachment.")
	end

	local clientSwim = effectReplicatorModule:FindEffect("ClientSwim")
	local wingDash = not effectReplicatorModule:HasEffect("WingDashCooldown")
		and effectReplicatorModule:HasEffect("Wings")

	local lightAttack = effectReplicatorModule:HasEffect("LightAttack")

	if options.actionRolling then
		lightAttack = false
	end

	if effectReplicatorModule:HasEffect("CarryObject") and not clientSwim then
		return
	elseif
		not options.actionRolling
		and (effectReplicatorModule:HasEffect("UsingSpell") or effectReplicatorModule:HasEffect("CastingSpell"))
	then
		return
	elseif not movementCheck() then
		return
	elseif effectReplicatorModule:HasEffect("NoAttack") and not effectReplicatorModule:HasEffect("CanRoll") then
		return
	elseif effectReplicatorModule:HasEffect("Dodged") or effectReplicatorModule:HasEffect("Dodge") then
		return
	elseif effectReplicatorModule:HasEffect("NoRoll") or effectReplicatorModule:HasEffect("PreventRoll") then
		return
	elseif effectReplicatorModule:HasEffect("SwimRestrict") and effectReplicatorModule:HasEffect("Swimming") then
		return
	elseif effectReplicatorModule:HasEffect("Stun") then
		return
	elseif effectReplicatorModule:HasEffect("Action") or effectReplicatorModule:HasEffect("MobileAction") then
		return
	elseif effectReplicatorModule:HasEffect("Carried") then
		return
	else
		local pressureForward = effectReplicatorModule:FindEffect("PressureForward")
		if lightAttack and not pressureForward then
			return
		else
			if effectReplicatorModule:HasEffect("Blocking") then
				unblock:FireServer()
			end

			if effectReplicatorModule:HasEffect("ClientSlide") then
				return
			elseif root:FindFirstChild("GravBV") then
				return
			else
				freefallTrack:Stop(0.3)

				local rollType = clientSwim and "waterdash" or "roll"
				local robloxEnv = getrenv()._G

				if characterHashData.Flashwind and effectReplicatorModule:HasEffect("Flashcharge") then
					robloxEnv.Sound(windFlash, root)
					robloxEnv.Sound(windFlashTwo, root)
				end

				local pressureForwarding = false

				if
					effectReplicatorModule:HasEffect("PressureForward")
					or effectReplicatorModule:HasEffect("GaleDash")
					or effectReplicatorModule:HasEffect("Flashcharge")
					or effectReplicatorModule:HasEffect("PhantomStep")
						and not effectReplicatorModule:HasEffect("PhantomStepDashCD")
				then
					pressureForwarding = true

					effectReplicatorModule:CreateEffect("PressureForwarding"):Debris(0.5)

					if characterHashData.Flashwind and not effectReplicatorModule:FindEffect("FlashwindCD") then
						effectReplicatorModule:CreateEffect("Flashcharge"):Debris(3)

						local flashWindCooldown = effectReplicatorModule:CreateEffect("FlashwindCD")
						flashWindCooldown:AddTag("CDName", "Flashwind")
						flashWindCooldown:Debris(15)

						local rightHand = character:FindFirstChild("RightHand")
						local handWeapon = rightHand and rightHand:FindFirstChild("HandWeapon")
						if handWeapon then
							robloxEnv.Emit(staticSpear, handWeapon, 1, {
								Duration = 6,
								Color = Color3.new(0.721569, 1, 0.203922),
							})

							robloxEnv.Emit(staticSpearTwo, handWeapon, 1, {
								Duration = 6,
								Color = Color3.new(0.721569, 1, 0.203922),
							})

							robloxEnv.Sound(ssLightning, handWeapon, {
								Duration = 6,
							})

							robloxEnv.Sound(windFlash, handWeapon, {
								Duration = 6,
							})
						end
					end
				end

				local healthPercentage = humanoid.Health / humanoid.MaxHealth

				if characterHashData["Endurance Runner"] then
					healthPercentage = 0.25 + healthPercentage * 0.75
				end

				local usedAgility = 60 + character.PassiveAgility.Value * 0.5 * healthPercentage
				local rushOfAncients = false

				if characterHashData.Lowstride and effectReplicatorModule:FindEffect("ClientCrouch") then
					usedAgility = usedAgility + 10
				end

				if
					characterHashData["Rush of Ancients"]
					and not effectReplicatorModule:HasEffect("AncientRushCD")
					and effectReplicatorModule:FindEffectWithTag("MaxMomentum")
				then
					rushOfAncients = true

					if healthPercentage < 0.5 then
						local cooldownTime = math.clamp(1 - healthPercentage, 0, 1) * 5 + 3
						local ancientRushCD = effectReplicatorModule:CreateEffect("AncientRushCD")
						ancientRushCD:AddTag("CDName", "Rush of Ancients")
						ancientRushCD:Debris(cooldownTime)
					end

					if effectReplicatorModule:HasEffect("Danger") then
						local ancientRushCD = effectReplicatorModule:CreateEffect("AncientRushCD")
						ancientRushCD:AddTag("CDName", "Rush of Ancients")
						ancientRushCD:Debris(8)
					end

					usedAgility = usedAgility + (20 + 15 * healthPercentage)
				end

				if effectReplicatorModule:HasEffect("SpinAttack") then
					dodge:FireServer(rollType, true)
				else
					dodge:FireServer(rollType, nil, nil, rushOfAncients)
				end

				effectReplicatorModule:CreateEffect("ClientDodge"):Debris(0.3)

				local noRoll = effectReplicatorModule:CreateEffect("NoRoll")
				noRoll:Debris(2.3)

				local rollTime = 0.2

				if
					(
						effectReplicatorModule:HasEffect("GodSpeed")
						or effectReplicatorModule:HasEffect("Overcharged")
						or effectReplicatorModule:HasEffect("Flashcharge")
					) and not effectReplicatorModule:HasEffect("ClientSwim")
				then
					rollTime = 0.5

					if characterHashData.Flashwind and not effectReplicatorModule:HasEffect("FlashwindCD") then
						effectReplicatorModule:CreateEffect("Flashcharge"):Debris(3)

						local flashWindCooldown = effectReplicatorModule:CreateEffect("FlashwindCD")
						flashWindCooldown:AddTag("CDName", "Flashwind")
						flashWindCooldown:Debris(15)

						local rightHand = character:FindFirstChild("RightHand")
						local handWeapon = rightHand and rightHand:FindFirstChild("HandWeapon")
						if handWeapon then
							robloxEnv.Emit(staticSpear, handWeapon, 1, {
								Duration = 6,
								Color = Color3.new(0.721569, 1, 0.203922),
							})

							robloxEnv.Emit(staticSpearTwo, handWeapon, 1, {
								Duration = 6,
								Color = Color3.new(0.721569, 1, 0.203922),
							})

							robloxEnv.Sound(ssLightning, handWeapon, {
								Duration = 6,
							})

							robloxEnv.Sound(windFlash, handWeapon, {
								Duration = 6,
							})
						end
					end
				end

				local usedRollAnimation = nil
				local lookVectorRoot = root.CFrame.LookVector
				local moveDirection = humanoid.MoveDirection

				if moveDirection.Magnitude < 0.1 then
					moveDirection = -lookVectorRoot
				end

				local rollDegree = math.deg((math.acos((math.clamp(moveDirection:Dot(lookVectorRoot), -1, 1)))))

				if rollDegree <= 45 then
					usedRollAnimation = forwardRoll
				elseif rollDegree > 45 and rollDegree < 135 then
					local diagonalRollDegree = math.deg(
						(
							math.acos(
								(
									math.clamp(
										moveDirection:Dot((Vector3.new(-lookVectorRoot.z, 0, lookVectorRoot.x))),
										-1,
										1
									)
								)
							)
						)
					)

					if diagonalRollDegree <= 45 then
						usedRollAnimation = rightRoll
					elseif diagonalRollDegree > 135 then
						usedRollAnimation = leftRoll
					else
						usedRollAnimation = backRoll
					end
				else
					usedRollAnimation = backRoll
				end

				local noAirPenalty = false
				local airDash = false
				local inAirBackRoll = false

				if
					inAirCheck()
					and not effectReplicatorModule:HasEffect("ClientSwim")
					and not characterHashData["Chained Ring"]
					and not effectReplicatorModule:HasEffect("GravityField")
				then
					if usedRollAnimation == backRoll then
						inAirBackRoll = true
					else
						noAirPenalty = true
						usedAgility = 35
						airDash = true
					end
				end

				if clientSwim then
					usedAgility = 30 + 10 * healthPercentage
					noAirPenalty = true
					usedRollAnimation = rollToWaterMap[usedRollAnimation] or usedRollAnimation
				end

				if usedRollAnimation == backRoll then
					usedAgility = usedAgility - 10
				end

				if pressureForwarding then
					usedRollAnimation = inputClient.PressureSlide
					rollTime = 0.5
				end

				local inArcSuit = effectReplicatorModule:HasEffect("ArcSuit") and characterHashData["Arc Module: Dash"]

				if inArcSuit then
					usedAgility = usedAgility - 5
					usedRollAnimation = inputClient.PressureSlide
					rollTime = 0.3
					clientEffectDirect:Fire("WindTrails", {
						char = character,
						Duration = 0.3,
					})
				end

				if effectReplicatorModule:HasEffect("ReducedRoll") and not inArcSuit then
					usedAgility = usedAgility - 10
				end

				if effectReplicatorModule:HasEffect("GravityField") then
					noAirPenalty = true
					usedAgility = usedAgility * 0.2
				end

				if airDash then
					usedRollAnimation = inputClient.AirDash
				end

				local usedRollTrack = humanoid:LoadAnimation(usedRollAnimation)

				if pressureForwarding then
					usedRollTrack.Priority = Enum.AnimationPriority.Movement
				end

				local usedRollSpeed = 1

				if effectReplicatorModule:HasEffect("SlowTime") then
					rollTime = 1
					usedAgility = 10
					usedRollSpeed = 0.5
				elseif effectReplicatorModule:HasEffect("StopTime") then
					rollTime = 0.1
					usedAgility = -100
					usedRollSpeed = 0.01
				end

				if not effectReplicatorModule:HasEffect("SlowDodge") then
					local weight = 0
					local heavyShoulder = false

					for _, effect in next, effectReplicatorModule:GetEffectsOfClass("MetalCombo") do
						if effect:HasTag("heavyshoulder") then
							heavyShoulder = true
						end

						weight = weight + effect.Value
					end

					if weight >= 3 and heavyShoulder then
						effectReplicatorModule:CreateEffect("SlowDodge"):Debris(1)
					end
				end

				if effectReplicatorModule:HasEffect("SlowDodge") then
					rollTime = rollTime + 0.1
					usedRollSpeed = usedRollSpeed * 0.75
					usedAgility = math.max(usedAgility - 20, 10)
				end

				if
					not effectReplicatorModule:HasEffect("GodSpeed")
					and not effectReplicatorModule:HasEffect("ClientSwim")
				then
					if pressureForwarding then
						usedRollTrack:Play(0.1, 0.5, usedRollSpeed)
					else
						usedRollTrack:Play(0.1, 1, usedRollSpeed)
					end
				end

				local inArcDash = effectReplicatorModule:HasEffect("ArcSuit") and characterHashData["Arc Module: Dash"]
				local dashIt = effectReplicatorModule:CreateEffect("DashIt")

				if rollType == "waterdash" then
					robloxEnv.Sound(waterDashSound, root)
				elseif airDash then
					if wingDash then
						robloxEnv.Sound(flap2, root)
						effectReplicatorModule:CreateEffect("WingDashCooldown")
					else
						robloxEnv.Sound(airDodge, root)
					end
				elseif inAirBackRoll then
					robloxEnv.Sound(airDodge, root, {
						PlaybackSpeed = 5,
					})
				elseif not inArcDash then
					robloxEnv.Sound(rollSound, root)
				end

				if inAirBackRoll then
					root.AssemblyLinearVelocity = Vector3.new()
					clientEffectDirect:Fire("GaleLeapDown", {
						char = character,
					})
				end

				effectReplicatorModule:RemoveEffectsOfClass("ShipJump")
				effectReplicatorModule:RemoveEffectsOfClass("ForceSlide")

				local usedBodyVelocity = nil
				local groundSensor = humanController.GroundSensor
				local rollStart = tick()

				clientEffectDirect:Fire("footprintCheck", {
					char = character,
					strength = 1.8,
				})

				local isScyphozia = characterHashData.IsScyphozia
				local giveRollCancelFatigue = false

				task.spawn(function()
					if airDash then
						moveDirection = workspace.CurrentCamera.CFrame.LookVector
						usedAgility = 50 + healthPercentage * 20

						local rollDuration = 1.3

						if wingDash and not isScyphozia then
							if checksModule.HorMobilityChain() then
								usedAgility = 50 + healthPercentage * 25
							else
								usedAgility = 50 + healthPercentage * 30
							end
						end

						if isScyphozia then
							usedAgility = usedAgility * 0.8
						end

						if effectReplicatorModule:HasEffect("Carrying") then
							usedAgility = usedAgility * 0.75
						end

						if effectReplicatorModule:HasEffect("GravityField") then
							usedAgility = usedAgility * 0.5
							rollDuration = rollDuration * 0.5
						end

						local bvVelocity = Vector3.new(1, 1, 1, 0) * usedAgility
						local groundVelocity = moveDirection * bvVelocity

						if groundSensor then
							local sensedPart = groundSensor.SensedPart
							if sensedPart and sensedPart.AssemblyMass > root.AssemblyMass then
								groundVelocity = groundVelocity
									+ vectorMathModule.getVelocityAtPoint(sensedPart, groundSensor.HitFrame.Position)
							end
						end

						root.AssemblyLinearVelocity = groundVelocity
						usedBodyVelocity = Instance.new("BodyVelocity")
						usedBodyVelocity:AddTag("AllowedBM")
						usedBodyVelocity.MaxForce = Vector3.new(50000, 50000, 50000, 0)
						usedBodyVelocity.Velocity = moveDirection * bvVelocity
						usedBodyVelocity.Name = pressureForwarding and "EasyCancel" or "Mover"
						usedBodyVelocity.Parent = root

						repDebris:Fire(usedBodyVelocity, rollDuration)
						clientEffectDirect:Fire("WindTrails", {
							char = character,
							Duration = rollDuration + 0.4,
						})

						if inArcDash then
							clientEffectDirect:Fire("ArcExhaust", {
								char = character,
								dur = 0.6,
							})
						else
							clientEffectDirect:Fire("GaleLeap15", {
								char = character,
							})
						end

						local clientAirDodge = effectReplicatorModule:CreateEffect("ClientAirDodge")

						while task.wait() do
							if effectReplicatorModule:HasEffect("MantraCasted") and usedRollTrack.IsPlaying then
								usedRollTrack:Stop()
							end

							local hasAttackAny = effectReplicatorModule:HasAny("LightAttack", "UsingAbility")
									and not pressureForwarding
								or effectReplicatorModule:HasEffect("UsingSpell")

							if options.actionRolling then
								hasAttackAny = false
							end

							if
								hasAttackAny
								or effectReplicatorModule:HasEffect("Feint")
								or effectReplicatorModule:HasEffect("ClientFeint")
								or effectReplicatorModule:HasEffect("Parry")
								or effectReplicatorModule:HasEffect("DodgedFrame")
								or (options.rollCancel and tick() - rollStart > options.rollCancelDelay)
							then
								stopDodge:FireServer(inputData, effectReplicatorModule:HasEffect("LightAttack"), true)

								if
									characterHashData["Death from Above"]
									or effectReplicatorModule:HasEffect("RevealBleeding")
										and characterHashData["Float Like a Butterfly"]
								then
									pcall(function()
										requests.ServerAirDashCancel:FireServer()
									end)
								end

								usedRollTrack:Stop()

								if inputData.A then
									cancelLeftTrack:Play(0.1)
								else
									cancelRightTrack:Play(0.1)
								end

								repDebris:Fire(usedBodyVelocity, 0.1)
								usedBodyVelocity.MaxForce = Vector3.new(100, 0, 100, 0)
								usedBodyVelocity.Velocity = Vector3.new(0, 0, 0, 0)
								giveRollCancelFatigue = true
								break
							else
								if usedBodyVelocity and usedBodyVelocity.Parent then
									local cameraLookVectorVel = workspace.CurrentCamera.CFrame.LookVector * bvVelocity
									local raycast = workspace:Raycast(
										root.Position,
										-humanController.Manager.UpDirection * 30,
										collisionUtilsModule.vehicleParams
									)

									if raycast then
										cameraLookVectorVel = cameraLookVectorVel
											+ vectorMathModule.getVelocityAtPoint(raycast.Instance, raycast.Position)
									end

									usedBodyVelocity.MaxForce = Vector3.new(50000, 50000, 50000, 0)

									if (not wingDash or pressureForwarding) and cameraLookVectorVel.Y > 0 then
										cameraLookVectorVel = cameraLookVectorVel * Vector3.new(1, 0.5, 1, 0)
									end

									usedBodyVelocity.Velocity = cameraLookVectorVel
								end

								if
									rollTime < tick() - rollStart
									or not usedBodyVelocity
									or not usedBodyVelocity.Parent
									or not inAirCheck()
									or root:FindFirstChild("GravBV")
								then
									break
								end
							end
						end

						clientAirDodge:Remove()
						usedRollTrack:Stop()

						if tick() - rollStart < rollTime then
							effectReplicatorModule:CreateEffect("ForceSlide", {
								Debris = 0.3,
							})

							humanoid:LoadAnimation(inputClient.LandingAnim):Play()

							local forcedBodyVelocity = Instance.new("BodyVelocity")
							forcedBodyVelocity:AddTag("AllowedBM")
							forcedBodyVelocity.MaxForce = Vector3.new(50000, 0, 50000, 0)
							forcedBodyVelocity.Velocity = root.CFrame.LookVector * 60
							forcedBodyVelocity.Parent = root
							repDebris:Fire(forcedBodyVelocity, 0.2)
						end
					else
						usedBodyVelocity = Instance.new("LinearVelocity")
						usedBodyVelocity.VelocityConstraintMode = Enum.VelocityConstraintMode.Vector
						usedBodyVelocity.ForceLimitMode = Enum.ForceLimitMode.PerAxis
						usedBodyVelocity.RelativeTo = Enum.ActuatorRelativeTo.World
						usedBodyVelocity.VectorVelocity = moveDirection * usedAgility
						usedBodyVelocity.MaxAxesForce = Vector3.new(8000, 8000, 8000, 0)
						usedBodyVelocity.Attachment0 = rootAttachment
						usedBodyVelocity.Name = pressureForwarding and "EasyCancel" or "Mover"
						usedBodyVelocity:AddTag("AllowedBM")
						usedBodyVelocity.Parent = rootAttachment

						repDebris:Fire(usedBodyVelocity, rollTime)
						moveDirection = moveDirection * Vector3.new(1, 0, 1, 0)

						local maxAxesForce = usedBodyVelocity.MaxAxesForce
						local rootVelocity = moveDirection * usedAgility

						if groundSensor then
							local sensedPart = groundSensor.SensedPart

							if sensedPart and sensedPart.AssemblyMass > root.AssemblyMass then
								rootVelocity = rootVelocity
									+ vectorMathModule.getVelocityAtPoint(sensedPart, groundSensor.HitFrame.Position)
							end

							rootVelocity = (CFrame.lookAlong(
								Vector3.new(0, 0, 0, 0),
								groundSensor.HitNormal,
								(Vector3.new(0, 0, 1, 0))
							) * CFrame.Angles(-1.5707963267948966, 0, 0)).Rotation:VectorToWorldSpace(
								rootVelocity
							)
						end

						root.AssemblyLinearVelocity = rootVelocity
						usedBodyVelocity.VectorVelocity = rootVelocity

						repeat
							task.wait()

							if effectReplicatorModule:HasEffect("MantraCasted") and usedRollTrack.IsPlaying then
								usedRollTrack:Stop(0)
							end

							if not noAirPenalty and inAirCheck() then
								noAirPenalty = true
								usedAgility = usedAgility - 10
							end

							local effectCancel = effectReplicatorModule:FindEffect("Feint")
								or effectReplicatorModule:HasEffect("ClientFeint")
								or effectReplicatorModule:HasEffect("Parry")
								or effectReplicatorModule:HasEffect("Parried")
								or effectReplicatorModule:HasEffect("DodgedFrame")

							local hasAttackAny = effectReplicatorModule:HasAny("LightAttack", "UsingAbility")
									and not effectReplicatorModule:HasEffect("PressureForwarding")
								or effectReplicatorModule:HasEffect("CastingSpell")
								or effectReplicatorModule:HasEffect("UsingSpell")

							if options.actionRolling then
								hasAttackAny = false
							end

							local rollCancelInvoke = (
								options.rollCancel and tick() - rollStart > options.rollCancelDelay
							)

							if effectCancel or hasAttackAny or rollCancelInvoke then
								stopDodge:FireServer(inputData, effectReplicatorModule:HasEffect("LightAttack"))

								if usedRollTrack.IsPlaying then
									usedRollTrack:Stop(0)
								end

								if
									(
										effectReplicatorModule:FindEffect("Feint")
										or effectReplicatorModule:HasEffect("ClientFeint")
										or rollCancelInvoke
									)
									and not cancelLeftTrack.IsPlaying
									and not cancelRightTrack.IsPlaying
								then
									if inputData.A then
										cancelLeftTrack:Play(0.1)
									else
										cancelRightTrack:Play(0.1)
									end
								end

								if effectCancel then
									giveRollCancelFatigue = true
								else
									giveRollCancelFatigue = "mantra"
									break
								end
							end

							if usedBodyVelocity and usedBodyVelocity.Parent then
								local innerMoveDirection = humanoid.MoveDirection

								if innerMoveDirection.Magnitude < 0.1 then
									innerMoveDirection = moveDirection
								end

								moveDirection = innerMoveDirection

								if giveRollCancelFatigue == true and usedAgility >= 30 then
									usedAgility = usedAgility - 10
								end

								local vecVelocity = moveDirection * usedAgility

								maxAxesForce = Vector3.new(8000, 8000, 8000, 0)

								if groundSensor then
									local sensedPart = groundSensor.SensedPart
									if sensedPart then
										if sensedPart.AssemblyMass > root.AssemblyMass then
											vecVelocity = vecVelocity
												+ vectorMathModule.getVelocityAtPoint(
													sensedPart,
													groundSensor.HitFrame.Position
												)
										end

										vecVelocity = (CFrame.lookAlong(
											Vector3.new(0, 0, 0, 0),
											groundSensor.HitNormal,
											(Vector3.new(0, 0, 1, 0))
										) * CFrame.Angles(-1.5707963267948966, 0, 0)).Rotation:VectorToWorldSpace(
											vecVelocity
										)
									else
										maxAxesForce = maxAxesForce * Vector3.new(1, 0, 1, 0)
									end
								end

								if root.AssemblyLinearVelocity.Unit:Angle(vecVelocity.Unit) > 0.17453292519943295 then
									maxAxesForce = maxAxesForce * 5
								end

								if
									workspace:Raycast(
										root.Position,
										root.AssemblyLinearVelocity.Unit,
										collisionUtilsModule.solidParams
									)
								then
									maxAxesForce = maxAxesForce
										* Vector3.new(0.800000011920929, 1, 0.800000011920929, 0)
								end

								usedBodyVelocity.MaxAxesForce = maxAxesForce
								usedBodyVelocity.VectorVelocity = vecVelocity
							end
						until rollTime < tick() - rollStart
							or not usedBodyVelocity
							or not usedBodyVelocity.Parent
							or root:FindFirstChild("GravBV")
							or effectReplicatorModule:HasEffect("CancelDodge")
							or pressureForwarding and effectReplicatorModule:FindEffect("Parried")
					end

					clientEffectDirect:Fire("footprintCheck", {
						char = character,
						strength = 1.5,
					})

					if pressureForwarding or inArcDash then
						usedRollTrack:Stop()
					end

					if usedBodyVelocity then
						usedBodyVelocity:Destroy()
					end

					if giveRollCancelFatigue then
						local hrpVelocity = Vector3.new(0, 0, 0, 0)
						local sensedPart = groundSensor.SensedPart

						if sensedPart and sensedPart.AssemblyMass > root.AssemblyMass then
							hrpVelocity = hrpVelocity
								+ vectorMathModule.getVelocityAtPoint(sensedPart, groundSensor.HitFrame.Position)
						end

						local assemblyLinearVelocity = root.AssemblyLinearVelocity
						root.AssemblyLinearVelocity =
							Vector3.new(hrpVelocity.X, assemblyLinearVelocity.Y, hrpVelocity.Z)
					end

					local timeout = 1.3

					if
						effectReplicatorModule:HasEffect("RollCancelFatigue")
						and (
							effectReplicatorModule:HasEffect("DownComesTheClaw") or not characterHashData["Tap Dancer"]
						)
					then
						timeout = 1.8
					end

					if characterHashData["Volt Reflex"] then
						timeout = 2.22
					end

					if
						giveRollCancelFatigue
						and not effectReplicatorModule:HasEffect("RollCancelFatigue")
						and not effectReplicatorModule:HasEffect("DownComesTheClaw")
						and not airDash
					then
						effectReplicatorModule:CreateEffect("RollCancelFatigue"):Debris(timeout)
						timeout = 0
					end

					if effectReplicatorModule:HasEffect("DanceBlade") then
						timeout = 0
					end

					local startTime = tick()

					if timeout > 0 then
						local ticker = 0

						repeat
							task.wait()
							ticker = ticker + 0.1
						until timeout <= tick() - startTime
							or effectReplicatorModule:HasEffect("DanceBlade")
							or effectReplicatorModule:HasEffect("PivotStepRESET")
					end

					dashIt:Remove()
					freefallCheck()
					noRoll:Remove()

					if effectReplicatorModule:HasEffect("Overcharge") then
						effectReplicatorModule:RemoveEffectsOfClass("Overcharge")
					end
				end)
			end
		end
	end
end)

---Jump end function.
InputClient.ejump = LPH_NO_VIRTUALIZE(function()
	local effectReplicator = replicatedStorage:FindFirstChild("EffectReplicator")
	if not effectReplicator then
		return Logger.warn("Cannot dodge without effect replicator.")
	end

	local effectReplicatorModule = require(effectReplicator)
	if not effectReplicatorModule then
		return Logger.warn("Cannot dodge without effect replicator module.")
	end

	if not jumpAnimTrack then
		return Logger.warn("Cannot jump without jump animation track.")
	end

	local character = players.LocalPlayer.Character
	if not character then
		return Logger.warn("Cannot jump without character.")
	end

	local humanoidRootPart = character:FindFirstChild("HumanoidRootPart")
	if not humanoidRootPart then
		return Logger.warn("Cannot jump without humanoid root part.")
	end

	local characterHandler = character:FindFirstChild("CharacterHandler")
	if not characterHandler then
		return Logger.warn("Cannot jump without character handler.")
	end

	local requests = characterHandler:FindFirstChild("Requests")
	if not requests then
		return Logger.warn("Cannot jump without requests.")
	end

	local jumpRemote = requests:FindFirstChild("Jump")
	if not jumpRemote then
		return Logger.warn("Cannot jump without jump remote.")
	end

	effectReplicatorModule:CreateEffect("Jumped"):Debris(0.1)
	jumpAnimTrack:Play(0.05)

	if effectReplicatorModule:HasEffect("HasWeapon") then
		jumpAnimTrack.Priority = Enum.AnimationPriority.Idle
	else
		jumpAnimTrack.Priority = Enum.AnimationPriority.Movement
	end

	TaskSpawner.delay("InputClient_EJump_Track", function()
		return 0.4
	end, function()
		jumpAnimTrack:AdjustSpeed(0.5)
		jumpAnimTrack:Stop(0.1)
	end)

	TaskSpawner.spawn("InputClient_EJump_Loop", function()
		local start = os.clock()

		while task.wait() do
			if os.clock() - start >= 0.2 then
				break
			end

			if not jumpAnimTrack or not jumpAnimTrack.IsPlaying then
				break
			end

			jumpRemote:FireServer()
		end
	end)
end)

---Re-created feint function.
InputClient.feint = LPH_NO_VIRTUALIZE(function()
	local character = players.LocalPlayer.Character
	if not character then
		return Logger.warn("Cannot feint without character.")
	end

	local humanoidRootPart = character:FindFirstChild("HumanoidRootPart")
	if not humanoidRootPart then
		return Logger.warn("Cannot feint without humanoid root part.")
	end

	local characterHandler = character:FindFirstChild("CharacterHandler")
	if not characterHandler then
		return Logger.warn("Cannot feint without character handler.")
	end

	local requests = characterHandler:FindFirstChild("Requests")
	if not requests then
		return Logger.warn("Cannot feint without requests.")
	end

	local feintReleaseRemote = requests:FindFirstChild("FeintRelease")
	if not feintReleaseRemote then
		return Logger.warn("Cannot feint without feint release remote.")
	end

	local inputDataTable = InputClient.getInputData()
	if not inputDataTable then
		return Logger.warn("Cannot feint without input data.")
	end

	local feintClickRemote = KeyHandling.getRemote("FeintClick")
	if not feintClickRemote then
		return Logger.warn("Cannot feint without feint click remote.")
	end

	local effectReplicator = replicatedStorage:FindFirstChild("EffectReplicator")
	if not effectReplicator then
		return Logger.warn("Cannot dodge without effect replicator.")
	end

	local effectReplicatorModule = require(effectReplicator)
	if not effectReplicatorModule then
		return Logger.warn("Cannot dodge without effect replicator module.")
	end

	-- ClientFeint inlined
	if effectReplicatorModule:HasEffect("ClientDodge") then
		effectReplicatorModule:CreateEffect("ClientFeint"):Debris(0.4)
	end

	if humanoidRootPart:FindFirstChild("ClientRemove") then
		humanoidRootPart.ClientRemove:Destroy()
	end

	inputDataTable["Right"] = true

	feintClickRemote:FireServer(inputDataTable)

	feintReleaseRemote:FireServer(inputDataTable)

	inputDataTable["Right"] = false
end)

---Cache InputClient module. Returns whether the caching was a success or not.
---@note: I sold my soul to the GC gods because there's no other way. This basically does a ton of intensive stuff. Updates are only done when needed.
InputClient.cache = LPH_NO_VIRTUALIZE(function()
	-- Invalidate previous cache.
	InputClient.sprintFunctionCache = nil
	InputClient.rollFunctionCache = nil
	inputDataCache = nil

	-- Intercept new Sprint and Roll functions.
	for _, value in next, getgc() do
		if typeof(value) ~= "function" or iscclosure(value) or isexecutorclosure(value) then
			continue
		end

		local functionName = debug.getinfo(value).name
		if not functionName then
			continue
		end

		if functionName ~= "Sprint" and functionName ~= "Roll" then
			continue
		end

		local upvalues = debug.getupvalues(value)

		if not upvalues or #upvalues <= 0 then
			continue
		end

		if functionName == "Sprint" then
			InputClient.sprintFunctionCache = value

			Logger.warn("Sprint function (%s) cache successful.", tostring(value))
		end

		if functionName == "Roll" then
			InputClient.rollFunctionCache = value

			Logger.warn("Roll function (%s) cache successful.", tostring(value))
		end

		if InputClient.sprintFunctionCache and InputClient.rollFunctionCache then
			break
		end
	end

	-- Store input data.
	local inputData = {}

	-- Get the input data from RenderStepped.
	for _, connection in next, getconnections(runService.RenderStepped) do
		local func = connection.Function
		if not func then
			continue
		end

		if iscclosure(func) then
			continue
		end

		local consts = debug.getconstants(func)
		if not manualTableFind(consts, ".lastHBCheck") then
			continue
		end

		local upvalues = debug.getupvalues(func)

		---@note: Only table with boolean values is the input table. Find a better way to filter this?
		for _, upvalue in next, upvalues do
			if typeof(upvalue) ~= "table" or getrawmetatable(upvalue) then
				continue
			end

			if not hasNonBooleans(upvalue) then
				continue
			end

			if getTableLength(upvalue) >= 1 and not validateKeys(upvalue) then
				continue
			end

			inputData = upvalue
			break
		end
	end

	-- Add into cache.
	inputDataCache = inputData

	-- Perform caching.
	local assets = replicatedStorage:FindFirstChild("Assets")
	local anims = assets and assets:FindFirstChild("Anims")
	local movement = anims and anims:FindFirstChild("Movement")
	local roll = movement and movement:FindFirstChild("Roll")
	local cancelLeft = roll and roll:FindFirstChild("CancelLeft")
	local cancelRight = roll and roll:FindFirstChild("CancelRight")

	local character = players.LocalPlayer.Character
	local characterHandler = character and character:FindFirstChild("CharacterHandler")
	local inputClient = characterHandler and characterHandler:FindFirstChild("InputClient")
	local freefallAnim = inputClient and inputClient:FindFirstChild("FreefallAnim")
	local humanoid = character and character:FindFirstChildOfClass("Humanoid")
	local slideJumpAnim = inputClient and inputClient:FindFirstChild("SlideJump")
	local jumpAnim = inputClient and inputClient:FindFirstChild("Jump")

	if not slideJumpAnim or not jumpAnim or not humanoid or not cancelLeft or not cancelRight or not freefallAnim then
		return false
	end

	slideJumpTrack = humanoid:LoadAnimation(slideJumpAnim)
	freefallTrack = humanoid:LoadAnimation(freefallAnim)
	cancelLeftTrack = humanoid:LoadAnimation(cancelLeft)
	cancelRightTrack = humanoid:LoadAnimation(cancelRight)
	jumpAnimTrack = humanoid:LoadAnimation(jumpAnim)

	-- Return whether we were successful.
	return InputClient.sprintFunctionCache ~= nil and InputClient.rollFunctionCache ~= nil and inputDataCache ~= nil
end)

-- Return InputClient module.
return InputClient

end)
__bundle_register("Game/KeyHandling", function(require, _LOADED, __bundle_register, __bundle_modules)
-- KeyHandler related stuff is handled here.
local KeyHandling = {}

-- Key-handler tables.
local remoteTable = nil
local randomTable = nil

---@module Utility.Logger
local Logger = require("Utility/Logger")

-- Hash cache.
local hashCache = {}

---Number to string.
---@param num number
---@param iter number
---@return string
local function nts(num, iter)
	local str = ""

	for _ = 1, iter do
		local v78 = num % 256
		str = string.char(v78) .. str
		num = (num - v78) / 256
	end

	return str
end

---String to number.
---@param str string
---@param len number
---@return number
local function stn(str, len)
	local num = 0

	for i = len, len + 3 do
		num = num * 256 + string.byte(str, i)
	end

	return num
end

---SHA-256 preprocess.
---@param msg string
---@param len number
---@return string
local function preprocess(msg, len)
	return msg .. string.char(128) .. string.rep(string.char(0), 64 - (len + 9) % 64) .. nts(8 * len, 8)
end

---Process SHA-256 digest block.
---@param msg string
---@param i number
---@param H table
local function digest(msg, i, H)
	local chunks = {}

	for j = 1, 16 do
		chunks[j] = stn(msg, i + (j - 1) * 4)
	end

	for j = 17, 64 do
		local v103 = chunks[j - 15]
		local v104 = bit32.bxor(bit32.rrotate(v103, 7), bit32.rrotate(v103, 18), bit32.rshift(v103, 3))
		v103 = chunks[j - 2]
		chunks[j] = chunks[j - 16]
			+ v104
			+ chunks[j - 7]
			+ bit32.bxor(bit32.rrotate(v103, 17), bit32.rrotate(v103, 19), bit32.rshift(v103, 10))
	end

	local a = H[1]
	local b = H[2]
	local c = H[3]
	local d = H[4]
	local e = H[5]
	local f = H[6]
	local g = H[7]
	local h = H[8]

	for iter = 1, 64 do
		local v114 = bit32.bxor(bit32.rrotate(a, 2), bit32.rrotate(a, 13), bit32.rrotate(a, 22))
			+ bit32.bxor(bit32.band(a, b), bit32.band(a, c), bit32.band(b, c))
		local v115 = bit32.bxor(bit32.rrotate(e, 6), bit32.rrotate(e, 11), bit32.rrotate(e, 25))
		local v116 = bit32.bxor(bit32.band(e, f), bit32.band(bit32.bnot(e), g))
		local v117 = h + v115 + v116 + randomTable[iter] + chunks[iter]
		local l_g_0 = g
		local l_f_0 = f
		local l_v109_0 = e
		local v121 = d + v117
		local l_v107_0 = c
		local l_v106_0 = b
		local l_v105_0 = a

		a = v117 + v114
		b = l_v105_0
		c = l_v106_0
		d = l_v107_0
		e = v121
		f = l_v109_0
		g = l_f_0
		h = l_g_0
	end

	H[1] = bit32.band(H[1] + a)
	H[2] = bit32.band(H[2] + b)
	H[3] = bit32.band(H[3] + c)
	H[4] = bit32.band(H[4] + d)
	H[5] = bit32.band(H[5] + e)
	H[6] = bit32.band(H[6] + f)
	H[7] = bit32.band(H[7] + g)
	H[8] = bit32.band(H[8] + h)
end

---Convert remote name to an hashed SHA-256 one.
---@param remoteName string
---@return string
local function hash(remoteName)
	local processed = preprocess(remoteName, #remoteName)

	local ht = {
		1779033703,
		3144134277,
		1013904242,
		2773480762,
		1359893119,
		2600822924,
		528734635,
		1541459225,
	}

	for iter = 1, #remoteName, 64 do
		digest(processed, iter, ht)
	end

	return nts(ht[1], 4)
		.. nts(ht[2], 4)
		.. nts(ht[3], 4)
		.. nts(ht[4], 4)
		.. nts(ht[5], 4)
		.. nts(ht[6], 4)
		.. nts(ht[7], 4)
		.. nts(ht[8], 4)
end

---Find remote table from upvalues.
---@param upvalues table
---@return table?
local function findRemoteTables(upvalues)
	for _, upvalue in next, upvalues do
		if typeof(upvalue) ~= "table" then
			continue
		end

		if getrawmetatable(upvalue) then
			continue
		end

		if #upvalue ~= 0 then
			continue
		end

		if upvalue[10] then
			continue
		end

		return upvalue
	end
end

---Search for remote table.
---@param value any
---@return boolean
local function searchForRemoteTable(value)
	-- Cached.
	if remoteTable then
		return true
	end

	-- Look for the internal upvalues for each function in KeyHandler.
	if typeof(value) ~= "function" then
		return false
	end

	if iscclosure(value) or isexecutorclosure(value) then
		return false
	end

	local isuccess, info = pcall(debug.getinfo, value)
	if not isuccess or not info then
		return false
	end

	if not info.short_src:match("KeyHandler") then
		return false
	end

	local usuccess, vupvalues = pcall(debug.getupvalue, value, 10)
	if not usuccess or typeof(vupvalues) ~= "table" then
		return false
	end

	if getrawmetatable(vupvalues) then
		return false
	end

	-- Mark as found.
	remoteTable = findRemoteTables(vupvalues)

	-- Return true if we found the remote table.
	return remoteTable ~= nil
end

---Search for random table.
---@param value any
---@return boolean
local function searchForRandomTable(value)
	-- Cached.
	if randomTable then
		return true
	end

	-- Check if this is the random table.
	if typeof(value) ~= "table" then
		return false
	end

	if getrawmetatable(value) then
		return false
	end

	local firstIndex, firstValue = next(value)

	if typeof(firstIndex) ~= "number" then
		return false
	end

	if typeof(firstValue) ~= "number" then
		return false
	end

	if firstValue < 100000 or firstValue > 100000000 then
		return false
	end

	if #value ~= 68 then
		return false
	end

	-- Mark as found.
	randomTable = value

	-- Return true.
	return true
end

---Search through 'getgc' for data.
local function searchForKeyHandlerData()
	for _, value in next, getgc(true) do
		if not searchForRandomTable(value) then
			continue
		end

		if not searchForRemoteTable(value) then
			continue
		end

		return true
	end
end

---Initialize the KeyHandler module.
KeyHandling.init = LPH_NO_VIRTUALIZE(function()
	local retries = 0

	while true do
		-- If we're able to find all the data, break.
		if searchForKeyHandlerData() then
			break
		end

		-- Retry if we can't find the data.
		Logger.warn(
			"KeyHandler retry (%i attempts) with results (%s, %s)",
			retries,
			tostring(remoteTable),
			tostring(randomTable)
		)

		retries = retries + 1

		if retries >= 10 then
			-- Warn.
			Logger.warn("KeyHandler failed to initialize after 10 attempts.")

			-- Error.
			return error("Please report this message to the developers.")
		end

		-- Wait.
		task.wait(0.5)
	end
end)

---Get remote from a specific remote name.
---@param remoteName string
---@return Instance|nil
KeyHandling.getRemote = LPH_NO_VIRTUALIZE(function(remoteName)
	if not randomTable and not remoteTable then
		return nil
	end

	local hashedRemoteName = hashCache[remoteName] or hash(remoteName)

	if not hashCache[remoteName] then
		hashCache[remoteName] = hashedRemoteName
	end

	return remoteTable[hashedRemoteName]
end)

-- Return KeyHandling module.
return KeyHandling

end)
__bundle_register("Utility/Maid", function(require, _LOADED, __bundle_register, __bundle_modules)
-- https://github.com/Quenty/NevermoreEngine/blob/version2/Modules/Shared/Events/Maid.lua
---@class Maid
local Maid = {}
Maid.__type = "maid"

---Create new Maid object.
---@return Maid
Maid.new = LPH_NO_VIRTUALIZE(function()
	return setmetatable({
		_tasks = {},
	}, Maid)
end)

---Return maid[key] - if not, it's not apart of the maid metatable - so we return the relevant task.
-- @return value
Maid.__index = LPH_NO_VIRTUALIZE(function(self, index)
	if Maid[index] then
		return Maid[index]
	else
		return self._tasks[index]
	end
end)

---Clean or add a task with a specific key.
---@param index any
---@param newTask any
Maid.__newindex = LPH_NO_VIRTUALIZE(function(self, index, newTask)
	if Maid[index] ~= nil then
		return warn(("'%s' is reserved"):format(tostring(index)), 2)
	end

	local tasks = self._tasks
	local oldTask = tasks[index]

	if oldTask == newTask then
		return
	end

	tasks[index] = newTask

	if oldTask then
		if typeof(oldTask) == "thread" then
			return coroutine.status(oldTask) == "suspended" and task.cancel(oldTask) or nil
		end

		if type(oldTask) == "function" then
			oldTask()
		elseif typeof(oldTask) == "RBXScriptConnection" then
			oldTask:Disconnect()
		elseif typeof(oldTask) == "Instance" and oldTask:IsA("Tween") then
			oldTask:Pause()
			oldTask:Cancel()
			oldTask:Destroy()
		elseif oldTask.Destroy then
			oldTask:Destroy()
		elseif oldTask.detach then
			oldTask:detach()
		end
	end
end)

---Add a task without a specific ID and return the task.
---@param task any
---@return any
Maid.mark = LPH_NO_VIRTUALIZE(function(self, task)
	self:add(task)
	return task
end)

---Add a task without a specific ID.
---@param task any
---@return number
Maid.add = LPH_NO_VIRTUALIZE(function(self, task)
	if not task then
		return error("task cannot be false or nil", 2)
	end

	local taskId = #self._tasks + 1
	self[taskId] = task

	return taskId
end)

---Remove task without cleaning it.
---@param taskId number
Maid.removeTask = LPH_NO_VIRTUALIZE(function(self, taskId)
	local tasks = self._tasks
	tasks[taskId] = nil
end)

---Clean up all tasks.
Maid.clean = LPH_NO_VIRTUALIZE(function(self)
	local tasks = self._tasks

	-- Disconnect all events first - as we know this is safe.
	for index, task in pairs(tasks) do
		if typeof(task) == "RBXScriptConnection" then
			tasks[index] = nil
			task:Disconnect()
		end
	end

	-- Clear out tasks table completely, even if clean up tasks add more tasks to the maid.
	local index, _task = next(tasks)

	while _task ~= nil do
		tasks[index] = nil

		if typeof(_task) == "thread" then
			if coroutine.status(_task) == "suspended" then
				task.cancel(_task)
			end
		else
			if type(_task) == "function" then
				_task()
			elseif typeof(_task) == "RBXScriptConnection" then
				_task:Disconnect()
			elseif typeof(_task) == "Instance" and _task:IsA("Tween") then
				_task:Pause()
				_task:Cancel()
				_task:Destroy()
			elseif _task.Destroy then
				_task:Destroy()
			elseif _task.detach then
				_task:detach()
			end
		end

		index, _task = next(tasks)
	end
end)

-- Return Maid module.
return Maid

end)
__bundle_register("Game/Latency", function(require, _LOADED, __bundle_register, __bundle_modules)
-- Latency module.
local Latency = {}

-- Services.
local stats = game:GetService("Stats")

---@note: Perhaps one day, we can get better approximations for these.
--- These used to rely on GetNetworkPing which we assumed would be sending or atleast receiving delay.
--- That is incorrect, it is RakNet ping thereby being RTT.

---Get receiving delay.
---@return number
function Latency.rdelay()
	return math.max(Latency.rtt() / 2, 0.0)
end

---Get sending delay.
---@return number
function Latency.sdelay()
	return math.max(Latency.rtt() / 2, 0.0)
end

---Get data ping.
---@note: https://devforum.roblox.com/t/in-depth-information-about-robloxs-remoteevents-instance-replication-and-physics-replication-w-sources/1847340
---@note: The forum post above is misleading, not only is it the RTT time, please note that this also takes into account all delays like frame time.
---@note: This is our round-trip time (e.g double the ping) since we have a receiving delay (replication) and a sending delay when we send the input to the server.
---@todo: For every usage, the sending delay needs to be continously updated. The receiving one must be calculated once at initial send for AP ping compensation.
---@return number
function Latency.rtt()
	local network = stats:FindFirstChild("Network")
	if not network then
		return
	end

	local serverStatsItem = network:FindFirstChild("ServerStatsItem")
	if not serverStatsItem then
		return
	end

	local dataPingItem = serverStatsItem:FindFirstChild("Data Ping")
	if not dataPingItem then
		return
	end

	return (dataPingItem:GetValue() / 1000)
end

-- Return Latency module.
return Latency

end)
__bundle_register("Utility/Table", function(require, _LOADED, __bundle_register, __bundle_modules)
-- Table utility functions.
local Table = {}

---Take a chunk out of an array into a new array.
---@param input any[]
---@param start number
---@param stop number
---@return any[]
Table.slice = LPH_NO_VIRTUALIZE(function(input, start, stop)
	local out = {}

	if start == nil then
		start = 1
	elseif start < 0 then
		start = #input + start + 1
	end
	if stop == nil then
		stop = #input
	elseif stop < 0 then
		stop = #input + stop + 1
	end

	for idx = start, stop do
		table.insert(out, input[idx])
	end

	return out
end)

---Find a value with a filter in a table and return it's value and index.
---@param input any[]
---@param predicate fun(value: any, index: number): boolean
---@return number, any
Table.find = LPH_NO_VIRTUALIZE(function(input, predicate)
	for idx, value in next, input do
		if not predicate(value, idx) then
			continue
		end

		return idx, value
	end
end)

-- Return Table module.
return Table

end)
__bundle_register("Utility/Finder", function(require, _LOADED, __bundle_register, __bundle_modules)
-- Finder utility is handled here.
local Finder = {}

-- Services.
local players = game:GetService("Players")
local replicatedStorage = game:GetService("ReplicatedStorage")

---Check if we are near a position of a specified position.
---@param position Vector3
---@param range number
---@return boolean
Finder.near = LPH_NO_VIRTUALIZE(function(position, range)
	local localCharacter = players.LocalPlayer.Character
	if not localCharacter then
		return false
	end

	local localRootPart = localCharacter:FindFirstChild("HumanoidRootPart")
	if not localRootPart then
		return false
	end

	return (position - localRootPart.Position).Magnitude <= range
end)

---Wait for the shrine. Deepwoken is weird so it can be both thrown or non-thrown?
---@return Model?
Finder.wshrine = LPH_NO_VIRTUALIZE(function()
	local thrown = workspace:FindFirstChild("Thrown")
	local waves = workspace:FindFirstChild("HallowtideWaves")
	local shrine = nil

	-- Wait.
	while not shrine do
		-- Look for the shrine in both locations.
		shrine = waves:FindFirstChild("HallowtideShrine") or thrown:FindFirstChild("HallowtideShrine")

		-- Wait.
		task.wait()
	end

	return shrine
end)

---Is a entity (not us or a player) within X studs of the specified position?
---@param position Vector3
---@param range number
---@return Model|nil
Finder.enear = LPH_NO_VIRTUALIZE(function(position, range)
	local live = workspace:FindFirstChild("Live")
	if not live then
		return nil
	end

	for _, entity in next, live:GetChildren() do
		if entity == players.LocalPlayer.Character then
			continue
		end

		if players:GetPlayerFromCharacter(entity) then
			continue
		end

		local rootPart = entity:FindFirstChild("HumanoidRootPart")
		if not rootPart then
			continue
		end

		if (position - rootPart.Position).Magnitude > range then
			continue
		end

		return entity
	end

	return nil
end)

---Is a player within X studs of the specified position?
---@param position Vector3
---@param range number
---@return Player|nil
Finder.pnear = LPH_NO_VIRTUALIZE(function(position, range)
	for _, player in next, players:GetPlayers() do
		if player == players.LocalPlayer then
			continue
		end

		local character = player.Character
		if not character then
			continue
		end

		local rootPart = character:FindFirstChild("HumanoidRootPart")
		if not rootPart then
			continue
		end

		if (position - rootPart.Position).Magnitude > range then
			continue
		end

		return player
	end

	return nil
end)

---Find an entity by its name.
---@param name string The name of the entity to find. It is matched.
---@return Model?
Finder.entity = LPH_NO_VIRTUALIZE(function(name)
	local live = workspace:FindFirstChild("Live")
	if not live then
		return nil
	end

	for _, child in next, live:GetChildren() do
		if not child.Name:match(name) then
			continue
		end

		return child
	end
end)

---Is a tool currently being locked by cooldown?
---@param tool Tool
---@return boolean
Finder.cdlocked = LPH_NO_VIRTUALIZE(function(tool)
	local effectReplicator = replicatedStorage:FindFirstChild("EffectReplicator")
	if not effectReplicator then
		return nil
	end

	local effectReplicatorModule = require(effectReplicator)
	if not effectReplicatorModule then
		return nil
	end

	for _, effect in next, effectReplicatorModule.Effects do
		if effect.Value ~= tool then
			continue
		end

		return true
	end

	return false
end)

---Find a mantra that is not on cooldown.
---@param name string? Specify the name of the mantra to find. It is matched.
---@return Tool?
Finder.ncdm = LPH_NO_VIRTUALIZE(function(name)
	local effectReplicator = replicatedStorage:FindFirstChild("EffectReplicator")
	if not effectReplicator then
		return nil
	end

	local effectReplicatorModule = require(effectReplicator)
	if not effectReplicatorModule then
		return nil
	end

	local backpack = players.LocalPlayer:FindFirstChild("Backpack")
	if not backpack then
		return nil
	end

	for _, item in next, backpack:GetChildren() do
		if not item:IsA("Tool") then
			continue
		end

		if not item.Name:match("Mantra:") or item.Name:match("Recalled") then
			continue
		end

		if name and (not item.Name:match(name)) then
			continue
		end

		if Finder.cdlocked(item) then
			continue
		end

		return item
	end
end)

---Return all current simple prompt text(s) for the player.
---@return table
Finder.sprompts = LPH_NO_VIRTUALIZE(function()
	local playerGui = players.LocalPlayer:FindFirstChild("PlayerGui")
	if not playerGui then
		return {}
	end

	local simplePrompt = playerGui:FindFirstChild("SimplePrompt")
	if not simplePrompt then
		return {}
	end

	local prompts = simplePrompt:FindFirstChild("Prompts")
	if not prompts then
		return {}
	end

	local texts = {}

	for _, prompt in next, prompts:GetChildren() do
		if not prompt:IsA("TextLabel") then
			continue
		end

		texts[#texts + 1] = prompt.Text
	end

	return texts
end)

---Get the nearest area marker.
---@param position Vector3 The position to check from.
---@return Model?
Finder.marker = LPH_NO_VIRTUALIZE(function(position)
	local markerWorkspace = replicatedStorage:FindFirstChild("MarkerWorkspace")
	if not markerWorkspace then
		return nil
	end

	local areaMarkers = markerWorkspace:WaitForChild("AreaMarkers")
	if not areaMarkers then
		return nil
	end

	local nearestAreaMarker = nil
	local nearestDistance = nil

	for _, marker in next, areaMarkers:GetDescendants() do
		if not marker:IsA("Part") then
			continue
		end

		local distance = (position - marker.Position).Magnitude

		if nearestDistance and distance >= nearestDistance then
			continue
		end

		nearestAreaMarker = marker
		nearestDistance = distance
	end

	return nearestAreaMarker
end)

---Find the first tool equipped by a user by name.
---@param name string The name of the tool to find. It is matched.
---@return Tool?
Finder.etool = LPH_NO_VIRTUALIZE(function(name)
	local character = players.LocalPlayer.Character
	if not character then
		return nil
	end

	for _, item in next, character:GetChildren() do
		if not item:IsA("Tool") then
			continue
		end

		if not item.Name:match(name) then
			continue
		end

		return item
	end

	return nil
end)

---Find the first weapon without an enchant.
---@param name string The name of the weapon to find. It is matched.
---@return Tool?
Finder.weweapon = LPH_NO_VIRTUALIZE(function(name)
	local tools = Finder.tools(name, false)

	for _, tool in next, tools do
		local rstats = tool:GetAttribute("RichStats")
		if not rstats then
			continue
		end

		if rstats:match("Enchant") then
			continue
		end

		return tool
	end
end)

---Find the first tool in a backpack by name.
---@param name string The name of the tool to find. It is matched.
---@param exact boolean If true, the name must be an exact match.
---@return Tool?
Finder.tool = LPH_NO_VIRTUALIZE(function(name, exact)
	return Finder.tools(name, exact)[1]
end)

---Find the tools in a backpack by name.
---@param name string The name of the tool to find. It is matched.
---@param exact boolean If true, the name must be an exact match.
---@return Tool[]
Finder.tools = LPH_NO_VIRTUALIZE(function(name, exact)
	local backpack = players.LocalPlayer:FindFirstChild("Backpack")
	if not backpack then
		return {}
	end

	local tools = {}

	for _, item in next, backpack:GetChildren() do
		if not item:IsA("Tool") then
			continue
		end

		if exact and (item.Name ~= name) or (not item.Name:match(name)) then
			continue
		end

		tools[#tools + 1] = item
	end

	return tools
end)

---Get the nearest chest from a position.
---@param position Vector3 The position to check from.
---@param range number The maximum distance to check.
---@return Model?
Finder.chest = LPH_NO_VIRTUALIZE(function(position, range)
	local thrown = workspace:FindFirstChild("Thrown")
	if not thrown then
		return nil
	end

	local nearestChest = nil
	local nearestDistance = nil

	for _, chest in next, thrown:GetChildren() do
		if not chest:IsA("Model") then
			continue
		end

		local distance = (position - chest:GetPivot().Position).Magnitude

		if range and distance > range then
			continue
		end

		if nearestDistance and distance >= nearestDistance then
			continue
		end

		nearestChest = chest
		nearestDistance = distance
	end

	return nearestChest
end)

---Give an instance & a filter & a distance, return a sorted-by-distance list of parts which pass the filter and are within the distance.
---@param instance Instance The instance to check from.
---@param filter fun(part: BasePart): boolean A filter function which returns true if the part should be included.
---@param distance number The maximum distance in studs.
---@return BasePart[]
Finder.sdparts = LPH_NO_VIRTUALIZE(function(instance, filter, distance)
	local localCharacter = players.LocalPlayer.Character
	local localRootPart = localCharacter and localCharacter:FindFirstChild("HumanoidRootPart")
	if not localRootPart then
		return
	end

	local validParts = {}
	local partsToDistance = {}

	for _, part in next, instance:GetChildren() do
		if not part:IsA("BasePart") then
			continue
		end

		if not filter(part) then
			continue
		end

		local pdistance = (part.Position - instance.Position).Magnitude

		if pdistance > distance then
			continue
		end

		validParts[#validParts + 1] = part
		partsToDistance[part] = pdistance
	end

	table.sort(validParts, function(partOne, partTwo)
		return partsToDistance[partOne] < partsToDistance[partTwo]
	end)

	return validParts
end)

---This function is sorted from the nearest to the farthest player.
---Get players within a certain range in studs from the local player.
---@param range number
---@return Model[]
Finder.gpir = LPH_NO_VIRTUALIZE(function(range)
	local live = workspace:FindFirstChild("Live")
	if not live then
		return
	end

	local localCharacter = players.LocalPlayer.Character
	local localRootPart = localCharacter and localCharacter:FindFirstChild("HumanoidRootPart")
	if not localRootPart then
		return
	end

	local playersInRange = {}
	local playersDistance = {}

	for _, player in next, players:GetPlayers() do
		if player == players.LocalPlayer then
			continue
		end

		local character = player.Character
		if not character then
			continue
		end

		local rootPart = character:FindFirstChild("HumanoidRootPart")
		if not rootPart then
			continue
		end

		local playerDistance = (rootPart.Position - localRootPart.Position).Magnitude
		if playerDistance > range then
			continue
		end

		table.insert(playersInRange, player)

		playersDistance[player] = playerDistance
	end

	table.sort(playersInRange, function(playerOne, playerTwo)
		return playersDistance[playerOne] < playersDistance[playerTwo]
	end)

	return playersInRange
end)

---This function is sorted from the nearest to the farthest entity.
---Get entity within a certain range in studs from the local player.
---@param range number
---@param pfilter boolean If true, filter out all players from the search.
---@return Model[]
Finder.geir = LPH_NO_VIRTUALIZE(function(range, pfilter)
	local live = workspace:FindFirstChild("Live")
	if not live then
		return
	end

	local localCharacter = players.LocalPlayer.Character
	local localRootPart = localCharacter and localCharacter:FindFirstChild("HumanoidRootPart")
	if not localRootPart then
		return
	end

	local entitiesInRange = {}
	local entitiesDistance = {}

	for _, entity in next, live:GetChildren() do
		if entity == localCharacter then
			continue
		end

		local rootPart = entity:FindFirstChild("HumanoidRootPart")
		if not rootPart then
			continue
		end

		local entityDistance = (rootPart.Position - localRootPart.Position).Magnitude
		if entityDistance > range then
			continue
		end

		table.insert(entitiesInRange, entity)

		entitiesDistance[entity] = entityDistance
	end

	table.sort(entitiesInRange, function(mobOne, mobTwo)
		return entitiesDistance[mobOne] < entitiesDistance[mobTwo]
	end)

	if not pfilter then
		return entitiesInRange
	end

	local list = {}

	for _, entity in next, entitiesInRange do
		if players:GetPlayerFromCharacter(entity) then
			continue
		end

		table.insert(list, entity)
	end

	return list
end)

-- Return Finder module.
return Finder

end)
__bundle_register("Utility/FiniteStateMachine", function(require, _LOADED, __bundle_register, __bundle_modules)
---@class FiniteStateMachine
---@field states FiniteState[]
---@field current string Current identifier.
---@field initial string Initial identifier.
---@field started boolean
local FiniteStateMachine = {}
FiniteStateMachine.__index = FiniteStateMachine

---@module Utility.Logger
local Logger = require("Utility/Logger")

---Create a new finite state machine.
---@param states FiniteState[]
---@param initial string
---@return FiniteStateMachine
function FiniteStateMachine.new(states, initial)
	local self = setmetatable({}, FiniteStateMachine)
	self.states = states
	self.current = initial
	self.initial = initial
	self.started = false

	-- Validate initial state.
	self:get(self.current)

	return self
end

---Get the current state. Non-failable.
---@param identifier string
---@return FiniteState
function FiniteStateMachine:get(identifier)
	for _, state in next, self.states do
		if state.identifier ~= identifier then
			continue
		end

		return state
	end

	return Logger.warn(string.format("(%s) State does not exist in states table.", identifier))
end

---Get a state
---@param identifier string
---@return boolean
function FiniteStateMachine:has(identifier)
	for _, state in next, self.states do
		if state.identifier ~= identifier then
			continue
		end

		return true
	end

	return false
end

---Stop the state machine.
function FiniteStateMachine:stop()
	-- Check if already stopped.
	if not self.started then
		return Logger.warn("Finite state machine has not been started.")
	end

	-- Detach current state.
	local current = self:get(self.current)
	current:detach()

	-- Reset state machine.
	self.started = false
	self.current = self.initial
end

---Start the state machine.
function FiniteStateMachine:start()
	-- Check if already started.
	if self.started then
		return Logger.warn("Finite state machine has already been started.")
	end

	-- Set initial state.
	self.started = true
	self.current = self.initial

	-- Start current state.
	local current = self:get(self.current)
	current:start(self)
end

---Transition to a new state identifier.
---@param identifier string
function FiniteStateMachine:transition(identifier)
	if not self.started then
		return Logger.warn("Finite state machine has not been started.")
	end

	-- Detach old state.
	local old = self:get(self.current)
	old:detach()

	-- Set new state.
	self.current = identifier

	-- Start new state.
	local new = self:get(identifier)
	new:start(self)
end

-- Return FiniteStateMachine module.
return FiniteStateMachine

end)
__bundle_register("Utility/FiniteState", function(require, _LOADED, __bundle_register, __bundle_modules)
---@module Utility.Maid
local Maid = require("Utility/Maid")

---@module Utility.TaskSpawner
local TaskSpawner = require("Utility/TaskSpawner")

---@class FiniteState
---@field identifier string
---@field callback function(self: FiniteState): any
---@field maid Maid
local FiniteState = {}
FiniteState.__index = FiniteState

---Detach a finite state.
function FiniteState:detach()
	self.maid:clean()

	if not self.scallback then
		return
	end

	self.scallback()
end

---Start a finite state.
---@param machine FiniteStateMachine The machine who started us.
function FiniteState:start(machine)
	self.maid:add(
		TaskSpawner.spawn(string.format("FiniteStateCallback_%s", self.identifier), self.callback, self, machine)
	)
end

---Create a new finite state.
---@param identifier string
---@param callback function(self: FiniteState): any
---@param scallback function?
---@return any
function FiniteState.new(identifier, callback, scallback)
	local self = setmetatable({}, FiniteState)
	self.identifier = identifier
	self.callback = callback
	self.scallback = scallback
	self.maid = Maid.new()
	return self
end

-- Return FiniteState module.
return FiniteState

end)
__bundle_register("Features/Game/Tweening", function(require, _LOADED, __bundle_register, __bundle_modules)
-- Tweening module.
local Tweening = { active = false, queue = {} }

---@module Utility.Configuration
local Configuration = require("Utility/Configuration")

-- Services.
local players = game:GetService("Players")

---On update step. Queue gets processed from most recent to oldest.
---@param dt number
Tweening.update = LPH_NO_VIRTUALIZE(function(dt)
	Tweening.active = false

	local current = Tweening.current()
	if not current then
		return
	end

	local part = typeof(current.goal) == "Instance" and current.goal or nil
	if part and not part.Parent then
		return Tweening.stop(current.identifier)
	end

	local localPlayer = players.LocalPlayer
	local character = localPlayer and localPlayer.Character
	if not character then
		return
	end

	local humanoidRootPart = character:FindFirstChild("HumanoidRootPart")
	if not humanoidRootPart then
		return
	end

	Tweening.active = true

	local startPosition = humanoidRootPart.Position
	local targetCFrame = typeof(current.goal) == "Instance" and current.goal.CFrame or current.goal
	local targetPosition = targetCFrame.Position

	local distanceToTarget = (targetPosition - startPosition).Magnitude

	if distanceToTarget <= 0.01 then
		return
	end

	local direction = (targetPosition - startPosition) / distanceToTarget
	local moveDistance = (Configuration.expectOptionValue("TweenStudsPerSecond") or 200) * dt

	local newPosition = nil

	if moveDistance >= distanceToTarget then
		newPosition = targetPosition
	else
		newPosition = startPosition + (direction * moveDistance)
		newPosition = Vector3.new(newPosition.X, targetPosition.Y, newPosition.Z)
	end

	local rotation = (targetCFrame - targetCFrame.Position)

	local _, _, _, m00, m01, m02, m10, m11, m12, m20, m21, m22 = rotation:GetComponents()

	if
		m00 == m00
		and m01 == m01
		and m02 == m02
		and m10 == m10
		and m11 == m11
		and m12 == m12
		and m20 == m20
		and m21 == m21
		and m22 == m22
	then
		humanoidRootPart.CFrame = CFrame.new(newPosition) * rotation
	else
		humanoidRootPart.CFrame = CFrame.new(newPosition)
	end

	-- Check distance from NEW position to target.
	local newDistanceToTarget = (targetPosition - newPosition).Magnitude

	current.reached = false

	if newDistanceToTarget >= 1.0 then
		return
	end

	if current.swc then
		return Tweening.stop(current.identifier)
	end

	current.reached = true
end)

---Get the tween data of an identifier.
---@param identifier string
---@return number, table?
function Tweening.get(identifier)
	for idx, data in next, Tweening.queue do
		if data.identifier ~= identifier then
			continue
		end

		return idx, data
	end

	return nil
end

---Wait until we reach the goal.
---@param identifier string
function Tweening.wait(identifier)
	local _, data = Tweening.get(identifier)
	if not data then
		return
	end

	repeat
		task.wait()
	until data.reached
end

---Current target.
---@return table?
function Tweening.current()
	return Tweening.queue[#Tweening.queue]
end

---Set a goal to follow. The most recent goal will be processed first.
---@param identifier string
---@param goal BasePart|CFrame
---@param swc boolean Whether or not to stop when we reach the goal.
function Tweening.goal(identifier, goal, swc)
	local _, data = Tweening.get(identifier)

	if data then
		data.goal = goal
		data.swc = swc
		data.reached = false
	else
		table.insert(Tweening.queue, 1, { identifier = identifier, goal = goal, swc = swc, reached = false })
	end
end

---Stop tweening.
---@param identifier string
function Tweening.stop(identifier)
	local idx, _ = Tweening.get(identifier)
	if not idx then
		return
	end

	table.remove(Tweening.queue, idx)
end

-- Return Tweening module.
return Tweening

end)
__bundle_register("Game/AntiAFK", function(require, _LOADED, __bundle_register, __bundle_modules)
-- AntiAFK module. This module is queued so if we have multiple features that require it, it won't conflict.
---@note: You should never leave the service access running here. Use a direct reference because we would want to know if they add any detections targeting this feature.
local AntiAFK = { wanters = {} }

---@module Utility.Signal
local Signal = require("Utility/Signal")

---@module Utility.Maid
local Maid = require("Utility/Maid")

-- Services.
local players = game:GetService("Players")

-- Maids.
local afkMaid = Maid.new()

---Add a "wanter" for AntiAFK.
function AntiAFK.start(identifier)
	AntiAFK.wanters[identifier] = true
end

-- Remove a "wanter" for AntiAFK.
function AntiAFK.stop(identifier)
	AntiAFK.wanters[identifier] = nil
end

---Initialize AntiAFK module.
function AntiAFK.init()
	local idledSignal = Signal.new(players.LocalPlayer.Idled)

	idledSignal:connect("AntiAFK_OnIdled", function()
		if not AntiAFK.wanters or #AntiAFK.wanters == 0 then
			return
		end

		local virtualUser = game:GetService("VirtualUser")
		virtualUser:CaptureController()
		virtualUser:ClickButton2(Vector2.new())
	end)
end

---Stop AntiAFK module.
function AntiAFK.detach()
	afkMaid:clean()
end

-- Return AntiAFK module.
return AntiAFK

end)
__bundle_register("Utility/Signal", function(require, _LOADED, __bundle_register, __bundle_modules)
-- Wrapper for Roblox's signals for safe connections to signals.
-- Automatically profiles signals & wraps them in a safe alternative.
---@class Signal
---@field signal RBXScriptSignal Underlying roblox script signal
local Signal = {}
Signal.__index = Signal

---@module Utility.Profiler
local Profiler = require("Utility/Profiler")

---@module Utility.Logger
local Logger = require("Utility/Logger")

---Safely connect to Roblox's signal.
---@param label string
---@param eventFunction function
---@return RBXScriptConnection
function Signal:connect(label, eventFunction)
	---Log event errors.
	---@param error string
	local function onEventFunctionError(error)
		Logger.trace("onEventFunctionError - (%s) - %s", label, error)
	end

	-- Connect to signal. Wrap function with profiler and error handling.
	local connection = self.signal:Connect(Profiler.wrap(
		label,
		LPH_NO_VIRTUALIZE(function(...)
			return xpcall(eventFunction, onEventFunctionError, ...)
		end)
	))

	-- Return connection.
	return connection
end

---Create new wrapper signal object.
---@param robloxSignal RBXScriptSignal
---@return Signal
function Signal.new(robloxSignal)
	-- Create new wrapper signal object.
	local self = setmetatable({}, Signal)
	self.signal = robloxSignal

	-- Return new wrapper signal object.
	return self
end

-- Return Signal module.
return Signal

end)
__bundle_register("Features/Automation/EchoFarm", function(require, _LOADED, __bundle_register, __bundle_modules)
-- EchoFarm module.
---@todo: The first issue is that the farm can be broken when user gets kicked for any reason. It cannot detect that, when it should rejoin the lobby again.
---@todo: The second issue is that we don't have any proper player checks in place.
---@todo: The third issue is that we don't have any proper validity checks. For example, does the user even have a Battleaxe to swap down initially? Do we even have a 'Fort Merit' spawn before trying?
local EchoFarm = { voiding = false }

---@module Utility.PersistentData
local PersistentData = require("Utility/PersistentData")

---@module Game.AntiAFK
local AntiAFK = require("Game/AntiAFK")

---@module Utility.Finder
local Finder = require("Utility/Finder")

---@module Game.Wipe
local Wipe = require("Game/Wipe")

---@module Features.Game.Tweening
local Tweening = require("Features/Game/Tweening")

---@module Game.ServerHop
local ServerHop = require("Game/ServerHop")

---@module Utility.TaskSpawner
local TaskSpawner = require("Utility/TaskSpawner")

---@module Features.Game.Interactions
local Interactions = require("Features/Game/Interactions")

---@module Utility.Maid
local Maid = require("Utility/Maid")

---@module Utility.Logger
local Logger = require("Utility/Logger")

---@module Features.Automation.AutoLoot
local AutoLoot = require("Features/Automation/AutoLoot")

---@module Features.Automation.Objects.AutoLootOptions
local AutoLootOptions = require("Features/Automation/Objects/AutoLootOptions")

-- Services.
local players = game:GetService("Players")
local replicatedStorage = game:GetService("ReplicatedStorage")

-- Constants.
local EASTERN_PLACE_ID = 6473861193
local TITUS_PLACE_ID = 8668476218
local DEBUGGING_MODE = true

-- Maid.
local echoFarmMaid = Maid.new()

-- Currently running?
local running = false

---Telemetry log.
local function telemetryLog(...)
	if not DEBUGGING_MODE then
		return
	end

	Logger.warn(...)
end

---Handle CharacterCreation state.
function EchoFarm.ccreation()
	local requests = replicatedStorage:WaitForChild("Requests")
	local characterCreator = requests:WaitForChild("CharacterCreator")
	local pickSpawn = characterCreator:WaitForChild("PickSpawn")
	local changeWeapon = characterCreator:WaitForChild("ChangeWeapon")
	local finishCreation = characterCreator:WaitForChild("FinishCreation")
	local toggleMetaModifier = requests:WaitForChild("ToggleMetaModifier")

	local success = pickSpawn:InvokeServer("Merit")
	if not success then
		return error("Does the user not have the 'Fort Merit' spawn?")
	end

	success = changeWeapon:InvokeServer("Battleaxe")
	if not success then
		return error("Does the user not have the 'Battleaxe' weapon?")
	end

	toggleMetaModifier:FireServer("All")

	local playerGui = players.LocalPlayer:WaitForChild("PlayerGui")

	repeat
		-- Choice prompt?
		local choicePrompt = playerGui:FindFirstChild("ChoicePrompt")
		local choice = choicePrompt and choicePrompt:FindFirstChild("Choice")

		if choice then
			choice:FireServer(true)
		end

		-- Wait.
		task.wait()
	until finishCreation:InvokeServer()
end

---Go to the Titus fight.
---@param tdata table Fake data.
function EchoFarm.titus(tdata)
	-- Request start.
	local requests = replicatedStorage:WaitForChild("Requests")
	local startMenu = requests:WaitForChild("StartMenu")
	local start = startMenu:WaitForChild("Start")

	telemetryLog("(EchoFarm) Requesting start.")

	start:FireServer()

	local data = tdata or PersistentData.get("efdata")
	if not data then
		return error("No EchoFarm data found in PersistentData.")
	end

	local positions = {
		-- From spawn, we need to be up in the jar, so we won't be seen.
		CFrame.new(-7518.70, 4825.71, 3483.19),

		-- Then, tween above the gate.
		CFrame.new(-6877.09, 4825.71, 2829.91),

		-- Teleport ourselves down.
		CFrame.new(-6877.50, 329.94, 2829.21),
	}

	-- Humanoid root part.
	local character = players.LocalPlayer.Character or players.LocalPlayer.CharacterAdded:Wait()
	local humanoidRootPart = character:WaitForChild("HumanoidRootPart")

	-- First position.
	local firstPosition = positions[1].Position

	firstPosition = Vector3.new(firstPosition.X, humanoidRootPart.Position.Y, firstPosition.Z)

	-- If we're not near the filltered first position, skip that position.
	if not Finder.near(firstPosition, 100) then
		table.remove(positions, 1)
	end

	-- Move towards each position. Don't stop when we reach the last one.
	telemetryLog("(EchoFarm) Moving to Titus gate.")

	for idx, cframe in next, positions do
		Tweening.goal(string.format("EF_TweenToGate_%i", idx), cframe, idx ~= #positions)
	end

	-- We wait until we've reached the last position.
	telemetryLog("(EchoFarm) Waiting to reach gate.")

	Tweening.wait(string.format("EF_TweenToGate_%i", #positions))

	-- Is anyone near here?
	telemetryLog("(EchoFarm) Checking if anyone is near the gate.")

	local map = workspace:WaitForChild("Map")
	local meritEntry = map:WaitForChild("MeritEntry")
	local interactPrompt = meritEntry:FindFirstChildWhichIsA("ProximityPrompt")

	-- Are we not near the gate at all?
	if not Finder.near(meritEntry.Position, 50) then
		return error("We are not near the 'MeritEntry' model.")
	end

	-- Is someone already here?
	telemetryLog("(EchoFarm) Checking if anyone is near the gate.")

	if Finder.pnear(meritEntry.Position, 100) then
		return ServerHop.hop(data.slot, true)
	end

	-- Keep trying to interact with the prompt and teleport us there.
	telemetryLog("(EchoFarm) Interacting with gate.")

	while task.wait() do
		fireproximityprompt(interactPrompt)
	end
end

---Wait for a chest to spawn on us.
---@param tdata table Fake data.
---@return Instance
function EchoFarm.wfc(tdata)
	local data = tdata or PersistentData.get("efdata")
	if not data then
		return error("No EchoFarm data found in PersistentData.")
	end

	local character = players.LocalPlayer.Character or players.LocalPlayer.CharacterAdded:Wait()
	local humanoidRootPart = character and character:FindFirstChild("HumanoidRootPart")
	local startTimestamp = os.clock()
	local voidingTicks = 0

	while task.wait() do
		if os.clock() - startTimestamp >= 60 then
			return ServerHop.hop(data.slot, false)
		end

		EchoFarm.voiding = voidingTicks % 10 == 0
		voidingTicks = voidingTicks + 1

		local chest = Finder.chest(humanoidRootPart.Position, 300)
		if not chest then
			continue
		end

		return chest
	end

	return nil
end

---Wait for ChoicePrompt by interacting with a chest.
---@param chest Instance
---@return Instance?
function EchoFarm.wcp(chest)
	local playerGui = players.LocalPlayer:WaitForChild("PlayerGui")
	local interactPrompt = chest:WaitForChild("InteractPrompt")

	while task.wait() do
		fireproximityprompt(interactPrompt)

		local prompt = playerGui:FindFirstChild("ChoicePrompt")
		if not prompt then
			continue
		end

		return prompt
	end

	return nil
end

---Kill titus.
---@param tdata table Fake data.
function EchoFarm.ktitus(tdata)
	-- Request start.
	local requests = replicatedStorage:WaitForChild("Requests")
	local startMenu = requests:WaitForChild("StartMenu")
	local start = startMenu:WaitForChild("Start")

	telemetryLog("(EchoFarm) Requesting start.")

	repeat
		-- Fire server.
		start:FireServer()

		-- Wait.
		task.wait()
	until #workspace:WaitForChild("Live"):GetChildren() > 0

	local data = tdata or PersistentData.get("efdata")
	if not data then
		return error("No EchoFarm data found in PersistentData.")
	end

	-- Enable voiding.
	telemetryLog("(EchoFarm) Enabling voiding.")

	EchoFarm.voiding = true
	AutoLoot.ignore = true

	-- Is anyone with us?
	telemetryLog("(EchoFarm) Checking if anyone is in the dungeon with us.")

	if #players:GetPlayers() > 1 then
		return ServerHop.hop(data.slot, false)
	end

	-- Wait for chest to spawn near us.
	telemetryLog("(EchoFarm) Waiting for chest to spawn on us.")

	local chest = EchoFarm.wfc(tdata)
	if not chest then
		return error("No chest found on us.")
	end

	-- Keep interacting until we get a choice prompt.
	telemetryLog("(EchoFarm) Interacting with chest.")

	local choicePrompt = EchoFarm.wcp(chest)
	if not choicePrompt then
		return error("No ChoicePrompt found after interacting with chest.")
	end

	-- Process chest.
	telemetryLog("(EchoFarm) Processing chest.")

	AutoLoot.process(choicePrompt, AutoLootOptions.new(0, 0, {}, true))

	-- Wait until we're finished.
	telemetryLog("(EchoFarm) Waiting until auto loot is finished.")

	local backpack = players.LocalPlayer.Backpack
	local items = #backpack:GetChildren()

	repeat
		task.wait()
	until not AutoLoot.active()

	-- Wait until we have more items in our backpack.
	telemetryLog("(EchoFarm) Waiting until we have more items in our backpack.")

	repeat
		task.wait()
	until #backpack:GetChildren() > items

	-- Check if we have an enchant stone.
	telemetryLog("(EchoFarm) Checking for enchant stone.")

	local stone = nil
	local timestamp = os.clock()

	repeat
		-- Look for stone.
		stone = Finder.tool("Enchant Stone", false)

		-- Has it been over a second?
		if os.clock() - timestamp >= 1.0 then
			return ServerHop.hop(data.slot, false)
		end

		-- Wait.
		task.wait()
	until stone

	-- Mark a kill.
	telemetryLog("(EchoFarm) Marking Titus kill.")

	if not tdata then
		PersistentData.stf("efdata", "tkill", true)
	end

	-- Teleport to exit.
	telemetryLog("(EchoFarm) Teleporting to dungeon exit.")

	local detainmentCore = workspace:WaitForChild("DetainmentCore")
	local dungeonExit = detainmentCore:WaitForChild("DungeonExit")

	while task.wait() do
		players.LocalPlayer.Character:PivotTo(CFrame.new(dungeonExit.Position))
	end
end

---End the cycle and wipe the character.
---@param tdata table Fake data.
function EchoFarm.cend(tdata)
	-- Log.
	telemetryLog("(EchoFarm) Invoking cycle end.")

	-- Invoke wipe and clear Titus kill marker.
	local data = tdata or PersistentData.get("efdata")
	if not data then
		return error("No EchoFarm data found in PersistentData.")
	end

	if not tdata then
		PersistentData.stf("efdata", "tkill", false)
	end

	Wipe.invoke(data.slot, { "Battleaxe" })
end

---Titus killed.
---@param tdata table Fake data.
function EchoFarm.tkilled(tdata)
	-- Request start.
	local requests = replicatedStorage:WaitForChild("Requests")
	local startMenu = requests:WaitForChild("StartMenu")
	local start = startMenu:WaitForChild("Start")

	telemetryLog("(EchoFarm) Requesting start.")

	start:FireServer()

	local data = tdata or PersistentData.get("efdata")
	if not data then
		return error("No EchoFarm data found in PersistentData.")
	end

	-- Tween up in the air.
	telemetryLog("(EchoFarm) Tweening up in the air after killing Titus.")

	Tweening.goal("EchoFarm_TitusKilledAirTween", CFrame.new(-6877.50, 4825.94, 2829.21), false)
	Tweening.wait("EchoFarm_TitusKilledAirTween")

	-- Enchant Battleaxe.
	telemetryLog("(EchoFarm) Enchanting Battleaxe.")

	local weapon = Finder.weweapon("Battleaxe")
	if not weapon then
		return Logger.longNotify("You do not have a valid Battleaxe to enchant.")
	end

	Interactions.etool(weapon)

	weapon:Activate()

	local stone = Finder.tool("Enchant Stone", false)
	if not stone then
		return Logger.longNotify("You do not have an Enchant Stone to use.")
	end

	Interactions.utool(stone, true)

	-- Wait until it is fully enchanted. If not, it will be deemed as a duped item.
	local equipped = Finder.tool("Weapon", true)

	repeat
		task.wait()
	until equipped:GetAttribute("RichStats"):match("Enchant")

	-- Use idol if we have it.
	telemetryLog("(EchoFarm) Using Idol if we have one.")

	local idol = Finder.tool("Idol", false)
	if idol then
		Interactions.utool(idol, "Give me relief from my Flaws.")
	end

	-- Invoke end.
	EchoFarm.cend(tdata)
end

---Start the EchoFarm module.
function EchoFarm.start()
	local localPlayer = players.LocalPlayer
	if not localPlayer then
		return
	end

	local data = PersistentData.get("efdata")
	if not data then
		return error("No EchoFarm data found in PersistentData.")
	end

	if not data.slot then
		return error("No data slot found for EchoFarm.")
	end

	if running then
		return
	end

	running = true

	PersistentData.set("efdata", data)

	AntiAFK.start("EchoFarm")

	if localPlayer:GetAttribute("GameLoaded") == "CharacterCreation" then
		data.wiped = true
	end

	if not data.wiped then
		return Wipe.invoke(data.slot, { "Battleaxe" })
	end

	if localPlayer:GetAttribute("GameLoaded") == "CharacterCreation" then
		return echoFarmMaid:mark(TaskSpawner.spawn("EchoFarm_CCreation", EchoFarm.ccreation))
	end

	if game.PlaceId == EASTERN_PLACE_ID and not data.tkill then
		return echoFarmMaid:mark(TaskSpawner.spawn("EchoFarm_Titus", EchoFarm.titus))
	end

	if game.PlaceId == TITUS_PLACE_ID then
		return echoFarmMaid:mark(TaskSpawner.spawn("EchoFarm_Dungeon_KillTitusFSM", EchoFarm.ktitus))
	end

	if game.PlaceId == EASTERN_PLACE_ID and data.tkill then
		return echoFarmMaid:mark(TaskSpawner.spawn("EchoFarm_Eastern_KilledTitusFSM", EchoFarm.tkilled))
	end
end

---Invoke the EchoFarm module.
function EchoFarm.invoke()
	PersistentData.set("efdata", {
		-- Have we killed Titus?
		tkill = false,

		-- Have we done atleast one wipe to do initial setup?
		wiped = false,

		-- What is the current slot that we are farming on?
		slot = players.LocalPlayer:GetAttribute("DataSlot"),
	})

	EchoFarm.start()
end

---Stop the EchoFarm module.
function EchoFarm.stop()
	if not running then
		return
	end

	running = false

	-- Stop AntiAFK.
	AntiAFK.stop("EchoFarm")

	-- Clear persistent data.
	PersistentData.set("efdata", nil)

	-- Stop all tasks.
	echoFarmMaid:clean()

	-- Cancel all tweens related to EchoFarm.
	for _, data in next, Tweening.queue do
		if not data.identifier:match("EF") then
			continue
		end

		Tweening.cancel(data.identifier)
	end
end

-- Return EchoFarm module.
return EchoFarm

end)
__bundle_register("Features/Automation/Objects/AutoLootOptions", function(require, _LOADED, __bundle_register, __bundle_modules)
---@class AutoLootOptions
---@field smin number Minimum stars to loot.
---@field smax number Maximum stars to loot.
---@field wanted string[] List of wanted item names.
---@field lall boolean Whether to loot everything.
local AutoLootOptions = {}

---Create new AutoLootOptions object.
---@param smin number Minimum stars to loot.
---@param smax number Maximum stars to loot.
---@param wanted string[] List of wanted item names.
---@param lall boolean Whether to loot everything.
---@return AutoLootOptions
function AutoLootOptions.new(smin, smax, wanted, lall)
	local self = setmetatable({}, AutoLootOptions)
	self.smin = smin
	self.smax = smax
	self.wanted = wanted
	self.lall = lall
	return self
end

-- Return AutoLootOptions module.
return AutoLootOptions

end)
__bundle_register("Features/Automation/AutoLoot", function(require, _LOADED, __bundle_register, __bundle_modules)
---@module Utility.Maid
local Maid = require("Utility/Maid")

---@module Utility.JSON
local JSON = require("Utility/JSON")

---@module Utility.Table
local Table = require("Utility/Table")

---@module Utility.Signal
local Signal = require("Utility/Signal")

---@module Utility.Configuration
local Configuration = require("Utility/Configuration")

---@module Features.Automation.Objects.AutoLootOptions
local AutoLootOptions = require("Features/Automation/Objects/AutoLootOptions")

-- AutoLoot module.
local AutoLoot = { ignore = false }

-- Timestamp.
local lastTimestamp = os.clock()

-- Maid.
local autoLootMaid = Maid.new()

-- The choice remote that will be used. If it is invalidated, then the entire queue will be reset.
local choiceRemote = nil

-- The current prompt being processed.
local currentPrompt = nil

-- The current choice being looted.
local currentChoice = nil

-- The queue of items to be looted from the remote.
local lootQueue = {}

-- Are we currently in loot all mode?
local lootAll = false

-- Services.
local players = game:GetService("Players")
local runService = game:GetService("RunService")

---Wait for the current choice to be deleted.
---The function will return if the choice is not deleted. Else, it will remove it from the queue.
---@param options ScrollingFrame
---@param remote RemoteEvent
local function waitForChoiceDeletion(options, remote)
	local choiceObject = options:FindFirstChild(currentChoice)

	remote:FireServer(currentChoice)

	if choiceObject and choiceObject.Parent then
		return
	end

	if lootQueue[1] ~= currentChoice then
		error("We assumed that the current choice was the first in the queue, was the queue modified?")
	end

	table.remove(lootQueue, 1)

	currentChoice = nil
end

---Reset the AutoLoot module.
local function resetAutoLoot()
	choiceRemote = nil
	lootQueue = {}
	currentChoice = nil
	currentPrompt = nil
	lootAll = false
end

---On player GUI descendant added.
---@param descendant Instance
local function onPlayerGuiDescendantAdded(descendant)
	if descendant.Name ~= "ChoicePrompt" then
		return
	end

	if AutoLoot.ignore then
		return
	end

	if not Configuration.expectToggleValue("AutoLoot") then
		return
	end

	-- Wait for all the instances to replicate.
	descendant:WaitForChild("ChoiceFrame"):WaitForChild("Options")

	-- Start processing the prompt.
	AutoLoot.process(
		descendant,
		AutoLootOptions.new(
			Configuration.expectOptionValue("AutoLootStarsMin") or 0,
			Configuration.expectOptionValue("AutoLootStarsMax") or 0,
			Configuration.expectOptionValues("ItemNameList") or {},
			Configuration.expectToggleValue("AutoLootAll") or false
		)
	)
end

---Wait for the current prompt to be deleted.
---@param prompt ScreenGui
---@param remote RemoteEvent
---@param param string
local function waitForPromptDeletion(prompt, remote, param)
	repeat
		-- Close prompt.
		remote:FireServer(param)

		-- Wait.
		task.wait()
	until not prompt.Parent

	resetAutoLoot()
end

---Is the auto loot active?
---@return boolean
function AutoLoot.active()
	return choiceRemote ~= nil and currentPrompt ~= nil and #lootQueue > 0
end

---Update the AutoLoot module.
function AutoLoot.update()
	if os.clock() - lastTimestamp <= 0.15 then
		return
	end

	lastTimestamp = os.clock()

	if not AutoLoot.ignore and not Configuration.expectToggleValue("AutoLoot") then
		return resetAutoLoot()
	end

	if not choiceRemote or not choiceRemote.Parent then
		return resetAutoLoot()
	end

	if not currentPrompt or not currentPrompt.Parent then
		return resetAutoLoot()
	end

	local choiceFrame = currentPrompt:FindFirstChild("ChoiceFrame")
	local options = choiceFrame and choiceFrame:FindFirstChild("Options")
	if not options then
		return resetAutoLoot()
	end

	if lootAll then
		return waitForPromptDeletion(currentPrompt, choiceRemote, "LOOT_ALL")
	end

	if currentChoice then
		return waitForChoiceDeletion(options, choiceRemote)
	end

	local itemToLoot = lootQueue[1]
	if not itemToLoot then
		return waitForPromptDeletion(currentPrompt, choiceRemote, "EXIT")
	end

	currentChoice = itemToLoot

	choiceRemote:FireServer(itemToLoot)
end

---Process a choice prompt and add the items with filtering to the loot queue.
---This function will reset the queue and set a new choice remote if it is valid.
---@param prompt ScreenGui The choice prompt to process.
---@param options AutoLootOptions The options to use.
function AutoLoot.process(prompt, options)
	local remote = prompt:FindFirstChild("Choice")
	if not remote or not remote:IsA("RemoteEvent") then
		return
	end

	local jsonLootData = prompt:GetAttribute("LootData")
	if typeof(jsonLootData) ~= "string" then
		return
	end

	local lootData = JSON.decode(jsonLootData)
	if typeof(lootData) ~= "table" then
		return
	end

	-- Reset the AutoLoot module.
	resetAutoLoot()

	-- Set the new data for processing.
	currentPrompt = prompt
	choiceRemote = remote
	lootAll = options.lall

	-- Process the loot data.
	for _, item in next, lootData do
		local rich = item.rich:gsub("%$%S*", "")
		local text = item.text

		if not text then
			continue
		end

		local matched = text:match("★")
		local stars = matched and #matched or 0

		if stars < options.smin or stars > options.smax then
			continue
		end

		local wanted, _ = Table.find(options.wanted, function(value, _)
			return rich:match(value)
		end)

		if not wanted then
			continue
		end

		lootQueue[#lootQueue + 1] = text
	end
end

---Initialize the AutoLoot module.
function AutoLoot.init()
	local localPlayer = players.LocalPlayer
	local playerGui = localPlayer:WaitForChild("PlayerGui")

	local preRender = Signal.new(runService.PreRender)
	local playerGuiDescendantAdded = Signal.new(playerGui.DescendantAdded)

	autoLootMaid:mark(playerGuiDescendantAdded:connect("AutoLoot_PlayerGuiDescendantAdded", onPlayerGuiDescendantAdded))
	autoLootMaid:mark(preRender:connect("AutoLoot_PreRender", AutoLoot.update))
end

---Detach the AutoLoot module.
function AutoLoot.detach()
	autoLootMaid:clean()
end

-- Return the AutoLoot module.
return AutoLoot

end)
__bundle_register("Utility/JSON", function(require, _LOADED, __bundle_register, __bundle_modules)
return LPH_NO_VIRTUALIZE(function()
	--
	-- json.lua
	--
	-- Copyright (c) 2020 rxi
	--
	-- Permission is hereby granted, free of charge, to any person obtaining a copy of
	-- this software and associated documentation files (the "Software"), to deal in
	-- the Software without restriction, including without limitation the rights to
	-- use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies
	-- of the Software, and to permit persons to whom the Software is furnished to do
	-- so, subject to the following conditions:
	--
	-- The above copyright notice and this permission notice shall be included in all
	-- copies or substantial portions of the Software.
	--
	-- THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
	-- IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
	-- FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
	-- AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
	-- LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
	-- OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
	-- SOFTWARE.
	--

	local json = { _version = "0.1.2" }

	-------------------------------------------------------------------------------
	-- Encode
	-------------------------------------------------------------------------------

	local encode

	local escape_char_map = {
		["\\"] = "\\",
		['"'] = '"',
		["\b"] = "b",
		["\f"] = "f",
		["\n"] = "n",
		["\r"] = "r",
		["\t"] = "t",
	}

	local escape_char_map_inv = { ["/"] = "/" }
	for k, v in pairs(escape_char_map) do
		escape_char_map_inv[v] = k
	end

	local function escape_char(c)
		return "\\" .. (escape_char_map[c] or string.format("u%04x", c:byte()))
	end

	local function encode_nil(val)
		return "null"
	end

	local function encode_table(val, stack)
		local res = {}
		stack = stack or {}

		-- Circular reference?
		if stack[val] then
			error("circular reference")
		end

		stack[val] = true

		if rawget(val, 1) ~= nil or next(val) == nil then
			-- Treat as array -- check keys are valid and it is not sparse
			local n = 0
			for k in pairs(val) do
				if type(k) ~= "number" then
					error("invalid table: mixed or invalid key types")
				end
				n = n + 1
			end
			if n ~= #val then
				error("invalid table: sparse array")
			end
			-- Encode
			for i, v in ipairs(val) do
				table.insert(res, encode(v, stack))
			end
			stack[val] = nil
			return "[" .. table.concat(res, ",") .. "]"
		else
			-- Treat as an object
			for k, v in pairs(val) do
				if type(k) ~= "string" then
					error("invalid table: mixed or invalid key types")
				end
				table.insert(res, encode(k, stack) .. ":" .. encode(v, stack))
			end
			stack[val] = nil
			return "{" .. table.concat(res, ",") .. "}"
		end
	end

	local function encode_string(val)
		return '"' .. val:gsub('[%z\1-\31\\"]', escape_char) .. '"'
	end

	local function encode_number(val)
		-- Check for NaN, -inf and inf
		if val ~= val or val <= -math.huge or val >= math.huge then
			error("unexpected number value '" .. tostring(val) .. "'")
		end
		return string.format("%.14g", val)
	end

	local type_func_map = {
		["nil"] = encode_nil,
		["table"] = encode_table,
		["string"] = encode_string,
		["number"] = encode_number,
		["boolean"] = tostring,
	}

	encode = function(val, stack)
		local t = type(val)
		local f = type_func_map[t]
		if f then
			return f(val, stack)
		end
		error("unexpected type '" .. t .. "'")
	end

	function json.encode(val)
		return (encode(val))
	end

	-------------------------------------------------------------------------------
	-- Decode
	-------------------------------------------------------------------------------

	local parse

	local function create_set(...)
		local res = {}
		for i = 1, select("#", ...) do
			res[select(i, ...)] = true
		end
		return res
	end

	local space_chars = create_set(" ", "\t", "\r", "\n")
	local delim_chars = create_set(" ", "\t", "\r", "\n", "]", "}", ",")
	local escape_chars = create_set("\\", "/", '"', "b", "f", "n", "r", "t", "u")
	local literals = create_set("true", "false", "null")

	local literal_map = {
		["true"] = true,
		["false"] = false,
		["null"] = nil,
	}

	local function next_char(str, idx, set, negate)
		for i = idx, #str do
			if set[str:sub(i, i)] ~= negate then
				return i
			end
		end
		return #str + 1
	end

	local function decode_error(str, idx, msg)
		local line_count = 1
		local col_count = 1
		for i = 1, idx - 1 do
			col_count = col_count + 1
			if str:sub(i, i) == "\n" then
				line_count = line_count + 1
				col_count = 1
			end
		end
		error(string.format("%s at line %d col %d", msg, line_count, col_count))
	end

	local function codepoint_to_utf8(n)
		-- http://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=iws-appendixa
		local f = math.floor
		if n <= 0x7f then
			return string.char(n)
		elseif n <= 0x7ff then
			return string.char(f(n / 64) + 192, n % 64 + 128)
		elseif n <= 0xffff then
			return string.char(f(n / 4096) + 224, f(n % 4096 / 64) + 128, n % 64 + 128)
		elseif n <= 0x10ffff then
			return string.char(f(n / 262144) + 240, f(n % 262144 / 4096) + 128, f(n % 4096 / 64) + 128, n % 64 + 128)
		end
		error(string.format("invalid unicode codepoint '%x'", n))
	end

	local function parse_unicode_escape(s)
		local n1 = tonumber(s:sub(1, 4), 16)
		local n2 = tonumber(s:sub(7, 10), 16)
		-- Surrogate pair?
		if n2 then
			return codepoint_to_utf8((n1 - 0xd800) * 0x400 + (n2 - 0xdc00) + 0x10000)
		else
			return codepoint_to_utf8(n1)
		end
	end

	local function parse_string(str, i)
		local res = ""
		local j = i + 1
		local k = j

		while j <= #str do
			local x = str:byte(j)

			if x < 32 then
				decode_error(str, j, "control character in string")
			elseif x == 92 then -- `\`: Escape
				res = res .. str:sub(k, j - 1)
				j = j + 1
				local c = str:sub(j, j)
				if c == "u" then
					local hex = str:match("^[dD][89aAbB]%x%x\\u%x%x%x%x", j + 1)
						or str:match("^%x%x%x%x", j + 1)
						or decode_error(str, j - 1, "invalid unicode escape in string")
					res = res .. parse_unicode_escape(hex)
					j = j + #hex
				else
					if not escape_chars[c] then
						decode_error(str, j - 1, "invalid escape char '" .. c .. "' in string")
					end
					res = res .. escape_char_map_inv[c]
				end
				k = j + 1
			elseif x == 34 then -- `"`: End of string
				res = res .. str:sub(k, j - 1)
				return res, j + 1
			end

			j = j + 1
		end

		decode_error(str, i, "expected closing quote for string")
	end

	local function parse_number(str, i)
		local x = next_char(str, i, delim_chars)
		local s = str:sub(i, x - 1)
		local n = tonumber(s)
		if not n then
			decode_error(str, i, "invalid number '" .. s .. "'")
		end
		return n, x
	end

	local function parse_literal(str, i)
		local x = next_char(str, i, delim_chars)
		local word = str:sub(i, x - 1)
		if not literals[word] then
			decode_error(str, i, "invalid literal '" .. word .. "'")
		end
		return literal_map[word], x
	end

	local function parse_array(str, i)
		local res = {}
		local n = 1
		i = i + 1
		while 1 do
			local x
			i = next_char(str, i, space_chars, true)
			-- Empty / end of array?
			if str:sub(i, i) == "]" then
				i = i + 1
				break
			end
			-- Read token
			x, i = parse(str, i)
			res[n] = x
			n = n + 1
			-- Next token
			i = next_char(str, i, space_chars, true)
			local chr = str:sub(i, i)
			i = i + 1
			if chr == "]" then
				break
			end
			if chr ~= "," then
				decode_error(str, i, "expected ']' or ','")
			end
		end
		return res, i
	end

	local function parse_object(str, i)
		local res = {}
		i = i + 1
		while 1 do
			local key, val
			i = next_char(str, i, space_chars, true)
			-- Empty / end of object?
			if str:sub(i, i) == "}" then
				i = i + 1
				break
			end
			-- Read key
			if str:sub(i, i) ~= '"' then
				decode_error(str, i, "expected string for key")
			end
			key, i = parse(str, i)
			-- Read ':' delimiter
			i = next_char(str, i, space_chars, true)
			if str:sub(i, i) ~= ":" then
				decode_error(str, i, "expected ':' after key")
			end
			i = next_char(str, i + 1, space_chars, true)
			-- Read value
			val, i = parse(str, i)
			-- Set
			res[key] = val
			-- Next token
			i = next_char(str, i, space_chars, true)
			local chr = str:sub(i, i)
			i = i + 1
			if chr == "}" then
				break
			end
			if chr ~= "," then
				decode_error(str, i, "expected '}' or ','")
			end
		end
		return res, i
	end

	local char_func_map = {
		['"'] = parse_string,
		["0"] = parse_number,
		["1"] = parse_number,
		["2"] = parse_number,
		["3"] = parse_number,
		["4"] = parse_number,
		["5"] = parse_number,
		["6"] = parse_number,
		["7"] = parse_number,
		["8"] = parse_number,
		["9"] = parse_number,
		["-"] = parse_number,
		["t"] = parse_literal,
		["f"] = parse_literal,
		["n"] = parse_literal,
		["["] = parse_array,
		["{"] = parse_object,
	}

	parse = function(str, idx)
		local chr = str:sub(idx, idx)
		local f = char_func_map[chr]
		if f then
			return f(str, idx)
		end
		decode_error(str, idx, "unexpected character '" .. chr .. "'")
	end

	function json.decode(str)
		if type(str) ~= "string" then
			error("expected argument of type string, got " .. type(str))
		end
		local res, idx = parse(str, next_char(str, 1, space_chars, true))
		idx = next_char(str, idx, space_chars, true)
		if idx <= #str then
			decode_error(str, idx, "trailing garbage")
		end
		return res
	end

	return json
end)()

end)
__bundle_register("Features/Game/Interactions", function(require, _LOADED, __bundle_register, __bundle_modules)
-- Interaction utility.
local Interactions = {}

---@module Utility.Logger
local Logger = require("Utility/Logger")

-- Services.
local players = game:GetService("Players")
local replicatedStorage = game:GetService("ReplicatedStorage")

-- Constants.
local DEBUGGING_MODE = true

---Telemetry log.
local function telemetryLog(...)
	if not DEBUGGING_MODE then
		return
	end

	Logger.warn(...)
end

---Use a tool.
---@param tool Instance
---@param data any Response to interaction to send with the tool use.
function Interactions.utool(tool, data)
	-- Equip tool.
	Interactions.etool(tool)

	-- Keep activating the tool until a 'ChoicePrompt' appears.
	telemetryLog("Activating tool '%s' until ChoicePrompt appears.", tool.Name)

	local playerGui = players.LocalPlayer:WaitForChild("PlayerGui")
	local choicePrompt = nil

	while not choicePrompt do
		-- Activate.
		tool:Activate()

		-- Check for 'ChoicePrompt' in GUI.
		choicePrompt = playerGui:FindFirstChild("ChoicePrompt")

		-- Wait.
		task.wait()
	end

	-- Fire the choice.
	telemetryLog("Firing ChoicePrompt ('%s') with data.", tostring(data))

	local choice = choicePrompt:WaitForChild("Choice")
	choice:FireServer(data)

	-- Wait for it to disappear.
	telemetryLog("Waiting for ChoicePrompt to disappear...")

	repeat
		task.wait()
	until not choicePrompt.Parent

	-- Done.
	telemetryLog("ChoicePrompt has disappeared.")
end

---Equip a tool.
---@param tool Instance
function Interactions.etool(tool)
	local character = players.LocalPlayer.Character
	if not character then
		return
	end

	local humanoid = character:FindFirstChildOfClass("Humanoid")
	if not humanoid then
		return
	end

	repeat
		-- Equip tool.
		humanoid:EquipTool(tool)

		-- Wait.
		task.wait()
	until tool.Parent == players.LocalPlayer.Character
end

---Perform an NPC-style interaction and go through the dialogue.
---@param instance Model
---@param actions table
---@param teleport boolean Should we teleport to the instance?
function Interactions.interact(instance, actions, teleport)
	if not instance or not instance.Parent then
		return
	end

	local interactPrompt = instance:FindFirstChild("InteractPrompt")
	if not interactPrompt or not interactPrompt:IsA("ProximityPrompt") then
		return
	end

	-- Step 1. Wait until we get dialogue and keep interacting until so.
	telemetryLog("(%s) Interacting until dialogue appears.", instance.Name)

	local playerGui = players.LocalPlayer:WaitForChild("PlayerGui")
	local dialogueGui = playerGui:WaitForChild("DialogueGui")
	local character = players.LocalPlayer.Character or players.LocalPlayer.CharacterAdded:Wait()

	repeat
		-- Teleport.
		if teleport then
			character:PivotTo(instance:GetPivot())
		end

		-- Fire.
		fireproximityprompt(interactPrompt)

		-- Wait.
		task.wait()
	until dialogueGui.Enabled

	-- Step 2. Go through the dialogue.
	telemetryLog("(%s) Going through dialogue with %i actions.", instance.Name, #actions)

	local requests = replicatedStorage:WaitForChild("Requests")
	local dialogueEvent = requests:WaitForChild("SendDialogue")

	local dialogueCompleted = false

	dialogueEvent.OnClientEvent:Connect(function()
		dialogueCompleted = true
	end)

	for _, action in next, actions do
		dialogueEvent:FireServer(action)

		dialogueCompleted = false

		telemetryLog(
			"(%s) Sent dialogue action '%s' and now waiting for OnClientEvent to fire.",
			instance.Name,
			action.exit and "[EXIT]" or (action.choice or "N/A")
		)

		if action.exit then
			break
		end

		repeat
			task.wait()
		until dialogueCompleted
	end

	telemetryLog("(%s) Completed dialogue.", instance.Name)
end

-- Return Interactions module.
return Interactions

end)
__bundle_register("Game/ServerHop", function(require, _LOADED, __bundle_register, __bundle_modules)
---@module Utility.PersistentData
local PersistentData = require("Utility/PersistentData")

---@module Utility.Table
local Table = require("Utility/Table")

---@module Utility.Logger
local Logger = require("Utility/Logger")

-- ServerHop module.
---@todo: Add a fallback if there are no available servers.
local ServerHop = {}

-- Services.
local replicatedStorage = game:GetService("ReplicatedStorage")
local players = game:GetService("Players")
local teleportService = game:GetService("TeleportService")
local runService = game:GetService("RunService")

-- Constants.
local LOBBY_PLACE_ID = 4111023553
local DEBUGGING_MODE = true

-- Last retry.
local lastRetry = nil

-- Current data state.
local currentData = nil

-- Current server we're trying to connect to.
local currentServer = nil

---Telemetry log.
local function telemetryLog(...)
	if not DEBUGGING_MODE then
		return
	end

	Logger.warn(...)
end

---Get the blacklist list.
---@return table
local function getBlacklist()
	local blacklist = PersistentData.get("sblacklist") or {}

	-- Check for any entries that have been older than 5 minutes.
	for key, value in next, blacklist do
		if tick() - value < 300 then
			continue
		end

		telemetryLog("(%s) Removed old entry (%s) from server blacklist.", tostring(key), tostring(value))

		blacklist[key] = nil
	end

	-- Set the new table.
	PersistentData.set("sblacklist", blacklist)

	return blacklist
end

---Return filtered server data.
local function getFilteredData()
	-- Get the blacklist.
	local blacklist = getBlacklist()

	-- Remove blacklisted servers from our data.
	for idx, server in next, currentData do
		local found, _ = Table.find(blacklist, function(id)
			return id == server.id
		end)

		if not found then
			continue
		end

		telemetryLog("(%s) Removed blacklisted server from available servers.", tostring(server.id))

		table.remove(currentData, idx)
	end

	-- Sort data.
	table.sort(currentData, function(first, second)
		return first.players < second.players
	end)

	-- Return filtered data.
	return currentData
end

---Add to the blacklist.
---@param id string The server ID to add to the blacklist.
local function addBlacklist(id)
	local blacklist = getBlacklist()

	blacklist[id] = tick()

	PersistentData.set("sblacklist", blacklist)
end

---Update ServerHopping module. This continously attempts to try the server you want to connect to.
local function updateServerHopping()
	if not currentData or not currentServer then
		return
	end

	local requests = replicatedStorage:FindFirstChild("Requests")
	if not requests then
		return
	end

	local startMenu = requests:FindFirstChild("StartMenu")
	if not startMenu then
		return
	end

	local pickServer = startMenu:FindFirstChild("PickServer")
	if not pickServer then
		return
	end

	if lastRetry and os.clock() - lastRetry <= 1.0 then
		return
	end

	lastRetry = os.clock()

	pickServer:FireServer(currentServer.id)
end

---On teleport failure.
local function onTeleportFailure(...)
	telemetryLog(
		"(%s) Teleport to server failed. Blacklisting it.",
		tostring(currentServer and currentServer.id or "N/A")
	)

	addBlacklist(currentServer.id)

	local filteredData = getFilteredData()
	if not filteredData or #filteredData == 0 then
		return error("No available servers found to hop to.")
	end

	local newServer = table.remove(filteredData, 1)
	if not newServer then
		return error("No available servers found to hop to.")
	end

	telemetryLog(
		"(%s) Found new server with %d player(s) and now attempting to teleport there.",
		tostring(newServer.id),
		newServer.players
	)

	currentServer = newServer
end

---Wait for filtered server data.
---@param slot string The data slot to use.
local function waitForFilteredData(slot)
	local servers = replicatedStorage:WaitForChild("Servers")
	local requests = replicatedStorage:WaitForChild("Requests")
	local showServers = requests:WaitForChild("ShowServers")
	local connection = nil

	-- Pick a slot to invoke a server list update.
	local startMenu = requests:WaitForChild("StartMenu")
	local pickSlot = startMenu:WaitForChild("PickSlot")

	pickSlot:FireServer(slot)

	-- Set current data to nil.
	currentData = nil

	-- Wait for the server to update the list.
	connection = showServers.OnClientEvent:Connect(function(luminant)
		-- Get the luminant servers.
		local luminantServers = servers:FindFirstChild(luminant)
		if not luminantServers then
			return
		end

		currentData = {}

		-- Scrape server data.
		for _, instance in next, luminantServers:GetChildren() do
			if not instance:IsA("Folder") then
				continue
			end

			local playerCount = instance:FindFirstChild("NumPlayers")
			if not playerCount or not playerCount:IsA("IntValue") then
				continue
			end

			currentData[#currentData + 1] = {
				id = instance.Name,
				players = playerCount.Value,
			}
		end
	end)

	-- Wait until we have data.
	repeat
		task.wait()
	until currentData

	-- Disconnect.
	connection:Disconnect()
	connection = nil

	-- Return filtered data.
	return getFilteredData()
end

---Handle lobby state.
function ServerHop.lobby()
	local shslot = PersistentData.get("shslot")
	if not shslot then
		return error("No server hop slot set in PersistentData.")
	end

	-- Wait for server data.
	telemetryLog("(%s) Waiting for filtered server data.", tostring(shslot))

	local data = waitForFilteredData(shslot)
	if not data or #data == 0 then
		return error("No available servers found to hop to.")
	end

	local bestServer = table.remove(data, 1)
	if not bestServer then
		return error("No available servers found to hop to.")
	end

	-- Update current server.
	telemetryLog(
		"(%s) Found server with %d player(s) and placed handlers.",
		tostring(bestServer.id),
		bestServer.players
	)

	currentServer = bestServer

	-- Place server fail fallback.
	teleportService.TeleportInitFailed:Connect(onTeleportFailure)

	-- Place teleport update handler.
	runService.PreRender:Connect(updateServerHopping)
end

---Return to the lobby.
function ServerHop.rlobby()
	-- Log.
	telemetryLog("Returning to lobby.")

	-- Fire the return to menu request.
	local requests = replicatedStorage:WaitForChild("Requests")
	local returnToMenu = requests:WaitForChild("ReturnToMenu")
	local playerGui = players.LocalPlayer:WaitForChild("PlayerGui")

	while task.wait() do
		returnToMenu:FireServer()

		local prompt = playerGui:FindFirstChild("ChoicePrompt")
		local choicePrompt = prompt and prompt:FindFirstChild("Choice")

		if not choicePrompt then
			continue
		end

		choicePrompt:FireServer(true)
	end
end

---Server hop. By default, this will look for the lowest population server.
---@param slot string The data slot to use.
---@param blacklist boolean If true, we will blacklist the current server.
function ServerHop.hop(slot, blacklist)
	-- Set the server hop slot in persistent data.
	PersistentData.set("shslot", slot)

	telemetryLog("(%s, %s) Hopping to new server.", tostring(slot), tostring(blacklist))

	-- Blacklist the current server if needed.
	if blacklist then
		local blacklisted = getBlacklist()

		blacklisted[slot] = tick()

		PersistentData.set("sblacklist", blacklisted)
	end

	-- Start the process for the lobby if we're already there.
	if game.PlaceId == LOBBY_PLACE_ID then
		return ServerHop.lobby()
	end

	-- Return to the lobby.
	return ServerHop.rlobby()
end

-- Return ServerHop module.
return ServerHop

end)
__bundle_register("Utility/PersistentData", function(require, _LOADED, __bundle_register, __bundle_modules)
---@module Utility.Serializer
local Serializer = require("Utility/Serializer")

---@module Utility.Deserializer
local Deserializer = require("Utility/Deserializer")

---@module Utility.String
local String = require("Utility/String")

---@module Utility.Logger
local Logger = require("Utility/Logger")

-- PersistentData module.
local PersistentData = {
	_data = {
		-- First timestamp of when Lycoris was loaded.
		fli = nil,

		-- Server hop slot.
		shslot = nil,

		-- Servers to ignore when server hopping.
		sblacklist = {},

		-- Wipe farm data.
		wdata = nil,

		-- Echo farm data.
		efdata = nil,
	},
}

-- Services.
local memStorageService = game:GetService("MemStorageService")

---Get a field in the persistent data.
---@param field string
---@return any
function PersistentData.get(field)
	return PersistentData._data[field]
end

---Set a field in a table that is in persistent data.
---@param field string
---@param key string
---@param value any
function PersistentData.stf(field, key, value)
	local tbl = PersistentData.get(field)

	if type(tbl) ~= "table" then
		return error(string.format("PersistentData field '%s' is not a table.", tostring(field)))
	end

	tbl[key] = value

	PersistentData.set(field, tbl)
end

---Change a field in the persistent data.
---@param field string
---@param value any
function PersistentData.set(field, value)
	-- Set persistent field.
	PersistentData._data[field] = value

	-- Save the persistent data.
	local saveSuccess, saveResult = pcall(
		memStorageService.SetItem,
		memStorageService,
		"LYCORIS_PERSISTENT_DATA",
		Serializer.marshal(PersistentData._data)
	)

	if not saveSuccess then
		return Logger.warn("(%s) Failed to set PersistentData snapshot.", tostring(saveResult))
	end

	Logger.warn("(%s) Successfully set PersistentData snapshot.", tostring(saveResult))
end

---Initialize PersistentData module.
function PersistentData.init()
	local hasSuccess, hasResult = pcall(memStorageService.HasItem, memStorageService, "LYCORIS_PERSISTENT_DATA")
	if not hasSuccess then
		return hasResult and Logger.warn("(%s) Failed to check for PersistentData snapshot.", tostring(hasResult))
	end

	local itemSuccess, itemResult = pcall(memStorageService.GetItem, memStorageService, "LYCORIS_PERSISTENT_DATA")
	if not itemSuccess then
		return Logger.warn("(%s) Failed to get PersistentData snapshot", tostring(itemResult))
	end

	if itemResult == nil or itemResult == "" then
		return Logger.warn("PersistentData snapshot is missing or empty.")
	end

	local success, result = pcall(Deserializer.unmarshal_one, String.tba(itemResult))
	if not success then
		return Logger.warn("(%s) Failed to deserialize PersistentData snapshot.", tostring(result))
	end

	Logger.warn("(%s) Successfully loaded PersistentData snapshot.", tostring(result))

	PersistentData._data = result
end

-- Return PersistentData module.
return PersistentData

end)
__bundle_register("Utility/String", function(require, _LOADED, __bundle_register, __bundle_modules)
local String = {}

-- Generate mapping.
local charByteMap = {}

for idx = 0, 255 do
	charByteMap[string.char(idx)] = idx
end

---String to byte array.
---@param str string
---@return table
function String.tba(str)
	local chars = {}
	local idx = 1

	if #str == 0 then
		return {}
	end

	repeat
		chars[idx] = charByteMap[str:sub(idx, idx)]
		idx = idx + 1
	until idx == #str + 1

	return chars
end

-- Return String module.
return String

end)
__bundle_register("Utility/Deserializer", function(require, _LOADED, __bundle_register, __bundle_modules)
-- Deserializer module.
local Deserializer = {}

---@module Utility.DeserializerStream
local DeserializerStream = require("Utility/DeserializerStream")

-- Deserialization data map.
local byteToDataMap = {
	[0xc0] = nil,
	[0xc2] = false,
	[0xc3] = true,
	[0xc4] = DeserializerStream.byte,
	[0xc5] = DeserializerStream.short,
	[0xc6] = DeserializerStream.int,
	[0xca] = DeserializerStream.float,
	[0xcb] = DeserializerStream.double,
	[0xcc] = DeserializerStream.byte,
	[0xcd] = DeserializerStream.unsignedShort,
	[0xce] = DeserializerStream.unsignedInt,
	[0xcf] = DeserializerStream.unsignedLong,
	[0xd0] = DeserializerStream.byte,
	[0xd1] = DeserializerStream.short,
	[0xd2] = DeserializerStream.int,
	[0xd3] = DeserializerStream.long,
	[0xd9] = DeserializerStream.byte,
	[0xda] = DeserializerStream.unsignedShort,
	[0xdb] = DeserializerStream.unsignedInt,
	[0xdc] = DeserializerStream.unsignedShort,
	[0xdd] = DeserializerStream.unsignedInt,
	[0xde] = DeserializerStream.unsignedShort,
	[0xdf] = DeserializerStream.unsignedInt,
}

---Decode array with a specific length and recursively read.
---@param stream DeserializerStream
---@param length number
---@return table
local function decodeArray(stream, length)
	local elements = {}

	for i = 1, length do
		elements[i] = Deserializer.at(stream)
	end

	return elements
end

---Decode map with a specific length and recursively read.
---@param stream DeserializerStream
---@param length number
---@return table, number
local function decodeMap(stream, length)
	local elements = {}

	for _ = 1, length do
		elements[Deserializer.at(stream)] = Deserializer.at(stream)
	end

	return elements
end

---Deserialize the data at a specific position.
---@param stream DeserializerStream
---@return any
function Deserializer.at(stream)
	local byte = stream:byte()
	local byteData = byteToDataMap[byte] or function()
		error("Unhandled byte data: " .. byte)
	end

	if byte == 0xde or byte == 0xdf then
		return decodeMap(stream, byteData(stream))
	end

	if byte >= 0x80 and byte <= 0x8f then
		return decodeMap(stream, byte - 0x80)
	end

	if byte >= 0x90 and byte <= 0x9f then
		return decodeArray(stream, byte - 0x90)
	end

	if byte == 0xdc or byte == 0xdd then
		return decodeArray(stream, byteData(stream))
	end

	if byte == 0xc4 or byte == 0xc5 or byte == 0xc6 then
		return stream:leReadBytes(byteData(stream))
	end

	if byte == 0xd9 or byte == 0xda or byte == 0xdb then
		return stream:string(byteData(stream))
	end

	if byte >= 0xa0 and byte <= 0xbf then
		return stream:string(byte - 0xa0)
	end

	if byte == 0xc0 or byte == 0xc1 or byte == 0xc2 then
		return byteToDataMap[byte]
	end

	if byte >= 0x00 and byte <= 0x7f then
		return byte
	end

	if byte >= 0xe0 and byte <= 0xff then
		return -32 + (byte - 0xe0)
	end

	return typeof(byteData) == "function" and byteData(stream) or byteData
end

---Starts recursively deserializing the data from the first index one time.
---@param data table
---@return any
function Deserializer.unmarshal_one(data)
	return Deserializer.at(DeserializerStream.new(data))
end

-- Return Deseralizer module.
return Deserializer

end)
__bundle_register("Utility/DeserializerStream", function(require, _LOADED, __bundle_register, __bundle_modules)
---@class DeserializerStream
---@field source table
---@field index number
local DeserializerStream = {}
DeserializerStream.__index = DeserializerStream

---Read bytes in little endian.
---@param len number
---@return number[]
function DeserializerStream:leReadBytes(len)
	local bytes = {}

	for idx = self.index + 1, self.index + len do
		bytes[#bytes + 1] = self.source[idx]
	end

	self.index = self.index + len

	if self.index > #self.source then
		return error("leReadBytes - read overflow")
	end

	return bytes
end

---Read bytes in big endianess format.
---@param len number
---@return number[]
function DeserializerStream:beReadBytes(len)
	local bytes = {}

	for idx = self.index + len, self.index + 1, -1 do
		bytes[#bytes + 1] = self.source[idx]
	end

	self.index = self.index + len

	if self.index > #self.source then
		return error("beReadBytes - read overflow")
	end

	return bytes
end

---Read string.
---@param len number
---@return string
function DeserializerStream:string(len)
	local src = self.source
	local buf = buffer.create(len)

	for idx = self.index + 1, self.index + len do
		buffer.writeu8(buf, idx - self.index - 1, src[idx])
	end

	self.index = self.index + len

	---@note: Inlined leReadBytes.
	if self.index > #self.source then
		return error("string - read overflow")
	end

	return buffer.readstring(buf, 0, len)
end

---Read unsigned long.
---@return number
function DeserializerStream:unsignedLong()
	local bytes = self:beReadBytes(8)
	local p1 = bit32.bor(bytes[1], bit32.lshift(bytes[2], 8), bit32.lshift(bytes[3], 16), bit32.lshift(bytes[4], 24))
	local p2 = bit32.bor(bytes[5], bit32.lshift(bytes[6], 8), bit32.lshift(bytes[7], 16), bit32.lshift(bytes[8], 24))
	return bit32.bor(p1, bit32.lshift(p2, 32))
end

---Read unsigned int.
---@return number
function DeserializerStream:unsignedInt()
	local bytes = self:beReadBytes(4)
	return bit32.bor(bytes[1], bit32.lshift(bytes[2], 8), bit32.lshift(bytes[3], 16), bit32.lshift(bytes[4], 24))
end

---Read unsigned short.
---@return number
function DeserializerStream:unsignedShort()
	local bytes = self:beReadBytes(2)
	return bit32.bor(bytes[1], bit32.lshift(bytes[2], 8))
end

---Read float.
---@return number
function DeserializerStream:float()
	local bytes = self:beReadBytes(4)
	local sign = (-1) ^ bit32.rshift(bytes[4], 7)
	local exp = bit32.rshift(bytes[3], 7) + bit32.lshift(bit32.band(bytes[4], 0x7F), 1)
	local frac = bytes[1] + bit32.lshift(bytes[2], 8) + bit32.lshift(bit32.band(bytes[3], 0x7F), 16)
	local normal = 1

	if exp == 0 then
		if frac == 0 then
			return sign * 0
		else
			normal = 0
			exp = 1
		end
	elseif exp == 0x7F then
		if frac == 0 then
			return sign * (1 / 0)
		else
			return sign * (0 / 0)
		end
	end

	return sign * 2 ^ (exp - 127) * (1 + normal / 2 ^ 23)
end

---Read double.
---@return number
function DeserializerStream:double()
	local bytes = self:beReadBytes(8)
	local sign = (-1) ^ bit32.rshift(bytes[8], 7)
	local exp = bit32.lshift(bit32.band(bytes[8], 0x7F), 4) + bit32.rshift(bytes[7], 4)
	local frac = bit32.band(bytes[7], 0x0F) * 2 ^ 48
	local normal = 1

	frac = frac
		+ (bytes[6] * 2 ^ 40)
		+ (bytes[5] * 2 ^ 32)
		+ (bytes[4] * 2 ^ 24)
		+ (bytes[3] * 2 ^ 16)
		+ (bytes[2] * 2 ^ 8)
		+ bytes[1]

	if exp == 0 then
		if frac == 0 then
			return sign * 0
		else
			normal = 0
			exp = 1
		end
	elseif exp == 0x7FF then
		if frac == 0 then
			return sign * (1 / 0)
		else
			return sign * (0 / 0)
		end
	end

	return sign * 2 ^ (exp - 1023) * (normal + frac / 2 ^ 52)
end

---Read long.
---@return number
function DeserializerStream:long()
	local value = self:unsignedLong()

	if bit32.band(value, 0x8000000000000000) ~= 0x0 then
		value = value - 0x800000000000000
	end

	return value
end

---Read int.
---@return number
function DeserializerStream:int()
	local value = self:unsignedInt()

	if bit32.band(value, 0x80000000) ~= 0 then
		value = value - 0x100000000
	end

	return value
end

---Read short.
---@return number
function DeserializerStream:short()
	local value = self:unsignedShort()

	if bit32.band(value, 0x8000) ~= 0 then
		value = value - 0x10000
	end

	return value
end

---Read byte.
---@return number
function DeserializerStream:byte()
	local bytes = self:leReadBytes(1)
	return bytes[1]
end

---Create new DeserializerStream object.
---@param source table
---@return DeserializerStream
function DeserializerStream.new(source)
	local self = setmetatable({}, DeserializerStream)
	self.source = source
	self.index = 0
	return self
end

-- Return DeserializerStream module.
return DeserializerStream

end)
__bundle_register("Utility/Serializer", function(require, _LOADED, __bundle_register, __bundle_modules)
--[[
 * MessagePack serializer / decode (0.6.1) written in pure Lua 5.3 / Lua 5.4
 * written by Sebastian Steinhauer <s.steinhauer@yahoo.de>
 * modified by the Lycoris Team <discord.gg/lyc>
 *
 * This is free and unencumbered software released into the public domain.
 *
 * Anyone is free to copy, modify, publish, use, compile, sell, or
 * distribute this software, either in source code form or as a compiled
 * binary, for any purpose, commercial or non-commercial, and by any
 * means.
 *
 * In jurisdictions that recognize copyright laws, the author or authors
 * of this software dedicate any and all copyright interest in the
 * software to the public domain. We make this dedication for the benefit
 * of the public at large and to the detriment of our heirs and
 * successors. We intend this dedication to be an overt act of
 * relinquishment in perpetuity of all present and future rights to this
 * software under copyright law.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *
 * For more information, please refer to <http://unlicense.org/>
]]

-- Serializer module.
local Serializer = {}

---Does a specified table match the layout of an array.
---@param tbl table
---@return boolean
local function isAnArray(tbl)
	local expected = 1

	for k in next, tbl do
		if k ~= expected then
			return false
		end

		expected = expected + 1
	end

	return true
end

---Serialize number to a float.
---@param value number
---@return string
local function serializeFloat(value)
	local serializedFloat = string.unpack("f", string.pack("f", value))
	if serializedFloat == value then
		return string.pack(">Bf", 0xca, value)
	end

	return string.pack(">Bd", 0xcb, value)
end

---Serialize number to a signed int.
---@param value number
---@return string
local function serializeSignedInt(value)
	if value < 128 then
		return string.pack("B", value)
	elseif value <= 0xff then
		return string.pack("BB", 0xcc, value)
	elseif value <= 0xffff then
		return string.pack(">BI2", 0xcd, value)
	elseif value <= 0xffffffff then
		return string.pack(">BI4", 0xce, value)
	end

	return string.pack(">BI8", 0xcf, value)
end

---Serialize number to a unsigned int.
---@param value number
---@return string
local function serializeUnsignedInt(value)
	if value >= -32 then
		return string.pack("B", 0xe0 + (value + 32))
	elseif value >= -128 then
		return string.pack("Bb", 0xd0, value)
	elseif value >= -32768 then
		return string.pack(">Bi2", 0xd1, value)
	elseif value >= -2147483648 then
		return string.pack(">Bi4", 0xd2, value)
	end

	return string.pack(">Bi8", 0xd3, value)
end

---Serialize string to a UTF8 string.
---@param value string
---@return string
local function serializeUtf8(value)
	local len = #value

	if len < 32 then
		return string.pack("B", 0xa0 + len) .. value
	elseif len < 256 then
		return string.pack(">Bs1", 0xd9, value)
	elseif len < 65536 then
		return string.pack(">Bs2", 0xda, value)
	end

	return string.pack(">Bs4", 0xdb, value)
end

---Serialize string to a string of bytes.
---@param value string
---@return string
local function serializeStringBytes(value)
	local len = #value

	if len < 256 then
		return string.pack(">Bs1", 0xc4, value)
	elseif len < 65536 then
		return string.pack(">Bs2", 0xc5, value)
	end

	return string.pack(">Bs4", 0xc6, value)
end

---Serialize table to a array.
---@param value table
---@return string
local function serializeArray(value)
	local elements = {}

	for i, v in pairs(value) do
		if type(v) ~= "function" and type(v) ~= "thread" and type(v) ~= "userdata" then
			elements[i] = Serializer.marshal(v)
		end
	end

	local result = table.concat(elements)
	local length = #elements

	if length < 16 then
		return string.pack(">B", 0x90 + length) .. result
	elseif length < 65536 then
		return string.pack(">BI2", 0xdc, length) .. result
	end

	return string.pack(">BI4", 0xdd, length) .. result
end

---Serialize table to a map.
---@param value table
---@return string
local function serializeMap(value)
	local elements = {}

	for k, v in pairs(value) do
		if type(v) ~= "function" and type(v) ~= "thread" and type(v) ~= "userdata" then
			elements[#elements + 1] = Serializer.marshal(k)
			elements[#elements + 1] = Serializer.marshal(v)
		end
	end

	local length = math.floor(#elements / 2)
	if length < 16 then
		return string.pack(">B", 0x80 + length) .. table.concat(elements)
	elseif length < 65536 then
		return string.pack(">BI2", 0xde, length) .. table.concat(elements)
	end

	return string.pack(">BI4", 0xdf, length) .. table.concat(elements)
end

---Serialize nil to a binary string.
---@return string
local function serializeNil()
	return string.pack("B", 0xc0)
end

---serialize table to a binary string
---@param value table
---@return string
local function serializeTable(value)
	return isAnArray(value) and serializeArray(value) or serializeMap(value)
end

---serialize boolean to a binary string
---@param value boolean
---@return string
local function serializeBoolean(value)
	return string.pack("B", value and 0xc3 or 0xc2)
end

---serialize int to a binary string
---@param value number
---@return string
local function serializeInt(value)
	return value >= 0 and serializeSignedInt(value) or serializeUnsignedInt(value)
end

---serialize number to a binary string
---@param value number
---@return string
local function serializeNumber(value)
	return value % 1 == 0 and serializeInt(value) or serializeFloat(value)
end

---serialize string to a binary string
---@param value number
---@return string
local function serializeString(value)
	return utf8.len(value) and serializeUtf8(value) or serializeStringBytes(value)
end

-- Types mapping to functions that serialize it.
local typeToSerializeMap = {
	["nil"] = serializeNil,
	["boolean"] = serializeBoolean,
	["number"] = serializeNumber,
	["string"] = serializeString,
	["table"] = serializeTable,
}

---Marshal a value into a binary string.
---@param value any
---@return string
function Serializer.marshal(value)
	return typeToSerializeMap[type(value)](value)
end

-- Return Serializer module.
return Serializer

end)
__bundle_register("Game/Wipe", function(require, _LOADED, __bundle_register, __bundle_modules)
-- Wipe module.
local Wipe = {}

-- Constants.
local LOBBY_PLACE_ID = 4111023553
local FRAGMENTS_OF_SELF_POS = Vector3.new(2910.00, 1133.03, 1474.00)

---@module Features.Game.Interactions
local Interactions = require("Features/Game/Interactions")

---@module Utility.PersistentData
local PersistentData = require("Utility/PersistentData")

---@module Utility.Finder
local Finder = require("Utility/Finder")

---@module Game.ServerHop
local ServerHop = require("Game/ServerHop")

---@module Utility.Logger
local Logger = require("Utility/Logger")

-- Debugging mode.
local DEBUGGING_MODE = true

-- Services.
local players = game:GetService("Players")
local replicatedStorage = game:GetService("ReplicatedStorage")

---Telemetry log.
local function telemetryLog(...)
	if not DEBUGGING_MODE then
		return
	end

	Logger.warn(...)
end

---Wait until we're in the fragments of self area.
function Wipe.pwait()
	local wdata = PersistentData.get("wdata")
	if not wdata then
		return error("No wipe data set in PersistentData.")
	end

	local startTimestamp = os.clock()

	while task.wait() do
		if os.clock() - startTimestamp >= 30 then
			return ServerHop.hop(wdata.slot, true)
		end

		if Finder.near(FRAGMENTS_OF_SELF_POS, 200) then
			break
		end
	end
end

---Process all items we need to pass down.
function Wipe.pitems()
	local wdata = PersistentData.get("wdata")
	if not wdata then
		return error("No wipe data set in PersistentData.")
	end

	local npcs = workspace:WaitForChild("NPCs")
	local hippocampusPool = npcs:WaitForChild("Hippocampal Pool")

	for _, name in next, wdata.weapons do
		local weapon = Finder.weweapon(name)
		if not weapon then
			continue
		end

		Interactions.etool(weapon)

		Interactions.interact(hippocampusPool, {
			{ choice = "[Inspect]" },
			{ choice = "[Pass down item]" },
			{ exit = true },
		}, true)
	end
end

---Start the process for wiping a slot in the depths.
function Wipe.depths()
	-- Request start.
	local requests = replicatedStorage:WaitForChild("Requests")
	local startMenu = requests:WaitForChild("StartMenu")
	local start = startMenu:WaitForChild("Start")

	telemetryLog("(Depths) Requesting start.")

	start:FireServer()

	-- Wait until our character is in the fragments of self area.
	Wipe.pwait()

	-- Look for people in the Fragments of Self area.
	telemetryLog("(Depths) Looking for anyone in the Fragments of Self area.")

	local wdata = PersistentData.get("wdata")
	if not wdata then
		return error("No wipe data set in PersistentData.")
	end

	if Finder.pnear(FRAGMENTS_OF_SELF_POS, 500) then
		return ServerHop.hop(wdata.slot, true)
	end

	-- Process items.
	Wipe.pitems()

	-- Interact with Self NPC.
	local npcs = workspace:WaitForChild("NPCs")
	local selfNpc = npcs:WaitForChild("Self")

	telemetryLog("(Depths) Teleporting and interacting with Self NPC.")

	repeat
		-- Interact.
		Interactions.interact(selfNpc, {
			{ choice = "[The End]" },
		}, true)

		-- Wait.
		task.wait()
	until not players.LocalPlayer.Character

	telemetryLog("(Depths) Wiped slot. Removing marker.")

	-- Add or remove markers.
	PersistentData.set("wdata", nil)

	if PersistentData.get("efdata") then
		PersistentData.stf("efdata", "wiped", true)
	end
end

---Start the process for wiping a slot in the lobby.
function Wipe.lobby()
	telemetryLog("(Lobby) (Step 1) Wiping slot in lobby.")

	-- Keep attempting to wipe the slot until successful.
	local requests = replicatedStorage:WaitForChild("Requests")
	local wipeSlot = requests:WaitForChild("WipeSlot")

	local wdata = PersistentData.get("wdata")
	if not wdata then
		return error("No wipe data set in PersistentData.")
	end

	repeat
		task.wait()
	until wipeSlot:InvokeServer(wdata.slot)

	telemetryLog("(Lobby) (Step 2) Wiped slot. Server hopping.")

	-- Server hop.
	ServerHop.hop(wdata.slot, false)
end

---Invoke a wipe for a specific slot.
---@param slot string The data slot to wipe.
---@param weapons string[]? Optional items to keep. Does not handle any validation.
function Wipe.invoke(slot, weapons)
	-- Mark slot.
	PersistentData.set("wdata", {
		slot = slot,
		weapons = weapons or {},
	})

	telemetryLog("(Invoke) (Step 1) Marked slot %s in data.", slot)

	-- If we're in the lobby, continue there.
	if game.PlaceId == LOBBY_PLACE_ID then
		return Wipe.lobby()
	end

	-- Otherwise, return to the lobby first.
	return ServerHop.rlobby()
end

-- Return Wipe module.
return Wipe

end)
__bundle_register("Game/Timings/ModuleManager", function(require, _LOADED, __bundle_register, __bundle_modules)
-- Internal modules if they exist, provided by to by preprocessor.
local INTERNAL_MODULES = {}
local INTERNAL_GLOBALS = {}

-- Module manager.
---@note: All globals get executed first but never ran. This gets set in the global environment of every future module after.
local ModuleManager = { modules = {}, globals = {} }

---@module Utility.Filesystem
local Filesystem = require("Utility/Filesystem")

---@module Utility.Logger
local Logger = require("Utility/Logger")

---@module Game.Timings.Action
local Action = require("Game/Timings/Action")

---@module Game.InputClient
local InputClient = require("Game/InputClient")

---@module Features.Combat.Objects.Task
local Task = require("Features/Combat/Objects/Task")

---@module Game.Timings.Timing
local Timing = require("Game/Timings/Timing")

---@module Features.Combat.StateListener
local StateListener = require("Features/Combat/StateListener")

---@module Utility.TaskSpawner
local TaskSpawner = require("Utility/TaskSpawner")

---@module Utility.Finder
local Finder = require("Utility/Finder")

---@module Features.Combat.Targeting
local Targeting = require("Features/Combat/Targeting")

---@module Game.Timings.PartTiming
local PartTiming = require("Game/Timings/PartTiming")

---@module Features.Combat.Objects.HitboxOptions
local HitboxOptions = require("Features/Combat/Objects/HitboxOptions")

---@module Features.Combat.Objects.RepeatInfo
local RepeatInfo = require("Features/Combat/Objects/RepeatInfo")

---@module Utility.Maid
local Maid = require("Utility/Maid")

---@module Utility.Signal
local Signal = require("Utility/Signal")

---@module Utility.Configuration
local Configuration = require("Utility/Configuration")

-- Module filesystem.
local fs = Filesystem.new("Lycoris-Rewrite-Modules")
local gfs = Filesystem.new(fs:append("Globals"))

-- Detach table.
local tdetach = {}

---Execute module function.
---@param lf function
---@param id string
---@param file string?
---@param global boolean
function ModuleManager.execute(lf, id, file, global)
	---@module Features.Combat.Defense
	---@note: For some reason, it broke lol. Returned nil.
	-- Has to do with loadingPlaceholder issue. A very wide cyclic dependency where depdendencies rely on each other can break the bundler.
	local Defense = require("Features/Combat/Defense")

	---@module Game.Latency
	local Latency = require("Game/Latency")

	-- Set function environment to allow for internal modules.
	getfenv(lf).Timing = Timing
	getfenv(lf).PartTiming = PartTiming
	getfenv(lf).Defense = Defense
	getfenv(lf).Action = Action
	getfenv(lf).Task = Task
	getfenv(lf).Maid = Maid
	getfenv(lf).Signal = Signal
	getfenv(lf).InputClient = InputClient
	getfenv(lf).TaskSpawner = TaskSpawner
	getfenv(lf).Targeting = Targeting
	getfenv(lf).Finder = Finder
	getfenv(lf).Logger = Logger
	getfenv(lf).HitboxOptions = HitboxOptions
	getfenv(lf).RepeatInfo = RepeatInfo
	getfenv(lf).StateListener = StateListener
	getfenv(lf).Latency = Latency
	getfenv(lf).Configuration = Configuration

	-- Load globals if we should.
	for name, entry in next, (not global) and ModuleManager.globals or {} do
		getfenv(lf)[name] = entry
	end

	-- Run executable function to initialize it.
	local success, result = pcall(lf)
	if not success then
		return Logger.warn("Module '%s' failed to load due to error '%s' while executing.", file or id, result)
	end

	if global and typeof(result) ~= "table" then
		return Logger.warn("Global module '%s' is invalid because it does not return a table.", file or id)
	end

	-- Output table.
	local output = global and ModuleManager.globals or ModuleManager.modules

	-- Get the result as a function.
	output[id] = result

	-- If this is a global, the result is a table, and it has a detach function, store it for later.
	if typeof(result) == "table" and typeof(result.detach) == "function" then
		tdetach[#tdetach + 1] = result.detach
	end
end

---Load file modules from filesystem.
---@param tfs Filesystem The filesystem to load from.
---@param global boolean Whether we're loading global modules or not.
function ModuleManager.load(tfs, global)
	for _, file in next, tfs:list(false) do
		-- Check if it is .lua.
		if string.sub(file, #file - 3, #file) ~= ".lua" then
			continue
		end

		-- Get string to load.
		local ls = tfs:read(file)

		-- Get function that we can execute.
		local lf, lr = loadstring(ls)
		if not lf then
			Logger.warn("Module file '%s' failed to load due to error '%s' while loading.", file, lr)
			continue
		end

		ModuleManager.execute(lf, string.sub(file, 1, #file - 4), file, global)
	end
end

---List loaded modules.
---@return string[]
function ModuleManager.loaded()
	local out = {}

	for file, _ in next, ModuleManager.modules do
		table.insert(out, file)
	end

	return out
end

---Detach functions.
function ModuleManager.detach()
	for _, detach in next, tdetach do
		detach()
	end

	-- Clear detach table.
	tdetach = {}
end

---Refresh ModuleManager.
function ModuleManager.refresh()
	-- Detach all modules.
	ModuleManager.detach()

	-- Reset current list.
	ModuleManager.modules = {}
	ModuleManager.globals = {}

	for id, lf in next, INTERNAL_GLOBALS do
		ModuleManager.execute(lf, id, nil, true)
	end

	for id, lf in next, INTERNAL_MODULES do
		ModuleManager.execute(lf, id, nil, false)
	end

	-- Load all globals in our filesystem.
	ModuleManager.load(gfs, true)

	-- Load all modules in our filesystem.
	ModuleManager.load(fs, false)
end

-- Return ModuleManager module.
return ModuleManager

end)
__bundle_register("Features/Combat/Defense", function(require, _LOADED, __bundle_register, __bundle_modules)
---@module Utility.Signal
local Signal = require("Utility/Signal")

---@module Utility.Maid
local Maid = require("Utility/Maid")

---@module Features.Combat.Objects.AnimatorDefender
local AnimatorDefender = require("Features/Combat/Objects/AnimatorDefender")

---@module Features.Combat.Objects.PartDefender
local PartDefender = require("Features/Combat/Objects/PartDefender")

---@module Features.Combat.Objects.SoundDefender
local SoundDefender = require("Features/Combat/Objects/SoundDefender")

---@module Features.Combat.Objects.EffectDefender
local EffectDefender = require("Features/Combat/Objects/EffectDefender")

---@module Utility.Configuration
local Configuration = require("Utility/Configuration")

---@module Features.Combat.StateListener
local StateListener = require("Features/Combat/StateListener")

---@module Utility.Finder
local Finder = require("Utility/Finder")

---@module Game.InputClient
local InputClient = require("Game/InputClient")

---@module Features.Combat.EntityHistory
local EntityHistory = require("Features/Combat/EntityHistory")

---@module Utility.TaskSpawner
local TaskSpawner = require("Utility/TaskSpawner")

---@module Utility.Logger
local Logger = require("Utility/Logger")

-- Handle all defense related functions.
local Defense = { lastMantraActivate = nil }

-- Services.
local replicatedStorage = game:GetService("ReplicatedStorage")
local players = game:GetService("Players")
local runService = game:GetService("RunService")
local userInputService = game:GetService("UserInputService")
local textChatService = game:GetService("TextChatService")

-- Maids.
local defenseMaid = Maid.new()

-- Defender objects.
local defenderPartObjects = {}
local defenderAnimationObjects = {}
local defenderObjects = {}

-- Stored deleted playback data.
local deletedPlaybackData = {}

-- Mob animations.
local mobAnimations = {}

-- Current wisp string & position.
local cws = nil
local cwp = nil

-- State.
local leftClickState = false
local autoWispLocked = false

-- Update.
local lastVisualizationUpdate = os.clock()
local lastGoldenTongueUpdate = os.clock()
local lastHistoryUpdate = os.clock()
local lastAutoArdourUpdate = os.clock()
local lastAutoWispShift = nil
local lastAutoWispUpdate = nil

---Add animator defender.
---@param animator Animator
local addAnimatorDefender = LPH_NO_VIRTUALIZE(function(animator)
	local animationDefender = AnimatorDefender.new(animator, mobAnimations)
	defenderObjects[animator] = animationDefender
	defenderAnimationObjects[animator] = animationDefender
end)

---Add sound defender.
---@param sound Sound
local addSoundDefender = LPH_NO_VIRTUALIZE(function(sound)
	---@note: If there's nothing to base the sound position off of, then I'm just gonna skip it bruh.
	local part = sound:FindFirstAncestorWhichIsA("BasePart")
	if not part then
		return
	end

	-- Add sound defender.
	defenderObjects[sound] = SoundDefender.new(sound, part)
end)

---On game descendant added.
---@param descendant Instance
local onGameDescendantAdded = LPH_NO_VIRTUALIZE(function(descendant)
	if descendant:IsA("Animator") then
		return addAnimatorDefender(descendant)
	end

	if descendant:IsA("Sound") then
		return addSoundDefender(descendant)
	end

	if descendant:IsA("BasePart") then
		return Defense.cdpo(descendant)
	end
end)

---On game descendant removed.
---@param descendant Instance
local onGameDescendantRemoved = LPH_NO_VIRTUALIZE(function(descendant)
	local object = defenderObjects[descendant]
	if not object then
		return
	end

	if object.rpbdata then
		deletedPlaybackData[descendant] = object.rpbdata
	end

	if defenderPartObjects[descendant] then
		defenderPartObjects[descendant] = nil
	end

	if defenderAnimationObjects[descendant] then
		defenderAnimationObjects[descendant] = nil
	end

	object:detach()
	object[descendant] = nil
end)

---On client effect event.
---@param name string?
---@param data table?
local onClientEffectEvent = LPH_NO_VIRTUALIZE(function(name, data)
	if not name then
		return
	end

	if not data or typeof(data) ~= "table" then
		data = {}
	end

	defenderObjects[data] = EffectDefender.new(name, data)
end)

---Update history.
local updateHistory = LPH_NO_VIRTUALIZE(function()
	if os.clock() - lastHistoryUpdate <= 0.1 then
		return
	end

	lastHistoryUpdate = os.clock()

	local character = players.LocalPlayer.Character
	if not character then
		return
	end

	local humanoidRootPart = character:FindFirstChild("HumanoidRootPart")
	if not humanoidRootPart then
		return
	end

	EntityHistory.add(players.LocalPlayer, humanoidRootPart.CFrame, humanoidRootPart.AssemblyLinearVelocity, tick())

	for _, player in next, players:GetPlayers() do
		if player == players.LocalPlayer then
			continue
		end

		local pcharacter = player.Character
		if not pcharacter then
			continue
		end

		local proot = pcharacter:FindFirstChild("HumanoidRootPart")
		if not proot then
			continue
		end

		EntityHistory.add(pcharacter, proot.CFrame, humanoidRootPart.AssemblyLinearVelocity, tick())
	end
end)

---Update golden tongue.
local updateGoldenTongue = LPH_NO_VIRTUALIZE(function()
	if os.clock() - lastGoldenTongueUpdate <= 1.0 then
		return
	end

	lastGoldenTongueUpdate = os.clock()

	if not Configuration.expectToggleValue("AutoGoldenTongue") then
		return
	end

	if not players.LocalPlayer.Backpack:FindFirstChild("Talent:Golden Tongue") then
		return
	end

	local effectReplicator = replicatedStorage:FindFirstChild("EffectReplicator")
	if not effectReplicator then
		return
	end

	local effectReplicatorModule = require(effectReplicator)
	if not effectReplicatorModule then
		return
	end

	if effectReplicatorModule:FindEffect("GoldCool") then
		return
	end

	if Configuration.expectToggleValue("CheckIfInCombat") and not effectReplicatorModule:FindEffect("Combat") then
		return
	end

	local textChannels = textChatService:FindFirstChild("TextChannels")
	local rbxSystem = textChannels and textChannels:FindFirstChild("RBXSystem")
	if not rbxSystem then
		return
	end

	defenseMaid:mark(TaskSpawner.spawn("Defender_GoldenTongueSendAsync", rbxSystem.SendAsync, rbxSystem, "/help"))
end)

---Update auto ardour.
local updateAutoArdour = LPH_NO_VIRTUALIZE(function()
	if os.clock() - lastAutoArdourUpdate <= 1.0 then
		return
	end
	lastAutoArdourUpdate = os.clock()

	if not Configuration.expectToggleValue("AutoArdour") then
		return
	end

	local localPlayer = players.LocalPlayer
	if not localPlayer then
		return
	end

	local backpack = localPlayer:FindFirstChild("Backpack")
	if not backpack or not backpack:FindFirstChild("Talent:Murmur: Ardour") then
		return
	end

	local character = localPlayer.Character
	if not character then
		return
	end

	local success, hasWeapon = pcall(function()
		return workspace.Live[localPlayer.Name].RightHand.HandWeapon ~= nil
	end)

	if not success or not hasWeapon then
		return
	end

	local hasArdour = pcall(function()
		return workspace.Live[localPlayer.Name].RightHand.HandWeapon.ArdourHum
	end)

	if hasArdour then
		return
	end

	local characterHandler = character:FindFirstChild("CharacterHandler")
	local requests = characterHandler and characterHandler:FindFirstChild("Requests")
	local ardourRemote = requests and requests:FindFirstChild("Ardour")

	if ardourRemote then
		pcall(function()
			ardourRemote:FireServer()
		end)
	end
end)

---Toggle visualizations.
Defense.visualizations = LPH_NO_VIRTUALIZE(function()
	for _, object in next, defenderObjects do
		for _, hitbox in next, object.hmaid._tasks do
			if typeof(hitbox) ~= "Instance" then
				continue
			end

			hitbox.Transparency = Configuration.expectToggleValue("EnableVisualizations") and 0.2 or 1.0
		end
	end
end)

---Update visualization.
local updateVisualizations = LPH_NO_VIRTUALIZE(function()
	if not Configuration.expectToggleValue("EnableVisualizations") then
		return
	end

	if os.clock() - lastVisualizationUpdate <= 5.0 then
		return
	end

	lastVisualizationUpdate = os.clock()

	for _, object in next, defenderObjects do
		for idx, hitbox in next, object.hmaid._tasks do
			if typeof(hitbox) ~= "Instance" then
				continue
			end

			---@note: We call :Debris so we don't have to clean it up ourselves. We just unregister it from the maid.
			if hitbox.Parent then
				continue
			end

			object.hmaid._tasks[idx] = nil
		end
	end
end)

---Handle spell string & position.
---@param position number
---@param str string
local hssp = LPH_NO_VIRTUALIZE(function(position, str)
	if
		lastAutoWispUpdate
		and os.clock() - lastAutoWispUpdate <= (Configuration.expectOptionValue("AutoWispDelay") or 0)
	then
		return Logger.warn(
			"(%.2f - %.2f = %.2f vs. %.2f) Auto Wisp is on cooldown.",
			os.clock(),
			lastAutoWispUpdate,
			os.clock() - lastAutoWispUpdate,
			Configuration.expectOptionValue("AutoWispDelay") or 0
		)
	end

	if lastAutoWispShift and os.clock() - lastAutoWispShift <= 0.15 then
		return Logger.warn(
			"(%.2f - %.2f = %.2f vs. %.2f) Auto Wisp shift is on forced cooldown.",
			os.clock(),
			lastAutoWispShift,
			os.clock() - lastAutoWispShift,
			0.15
		)
	end

	if autoWispLocked then
		return Logger.warn("Auto Wisp is locked.")
	end

	if position <= 0 or position > #str then
		return Logger.warn("Invalid position (%i vs. %i) for Auto Wisp.", position, #str)
	end

	local character = str:sub(position, position)
	if character ~= "Z" and character ~= "X" and character ~= "C" and character ~= "V" then
		return Logger.warn("Invalid character (%s) for Auto Wisp.", tostring(character))
	end

	local localPlayer = players.LocalPlayer
	local localPlayerCharacter = localPlayer.Character
	if not localPlayerCharacter then
		return
	end

	local playerGui = localPlayer:FindFirstChild("PlayerGui")
	if not playerGui then
		return
	end

	local spellGui = playerGui:FindFirstChild("SpellGui")
	if not spellGui then
		return
	end

	local spellInput = spellGui:FindFirstChild("SpellInput")
	if not spellInput then
		return
	end

	local effectReplicator = replicatedStorage:FindFirstChild("EffectReplicator")
	if not effectReplicator then
		return
	end

	local effectReplicatorModule = require(effectReplicator)
	if not effectReplicatorModule then
		return
	end

	if not effectReplicatorModule:HasEffect("RitualCastingSpell") then
		return Logger.warn("RitualCastingSpell effect not found.")
	end

	if effectReplicatorModule:HasEffect("Knocked") then
		return Logger.warn("Knocked effect found.")
	end

	Logger.warn("Sending event for character (%s) with position (%i) and string (%s).", character, position, str)

	autoWispLocked = true
	lastAutoWispUpdate = os.clock()

	spellInput:FireServer(character)
end)

---Update defenders.
local updateDefenders = LPH_NO_VIRTUALIZE(function()
	if Configuration.expectToggleValue("M1Hold") and leftClickState then
		InputClient.left(players.LocalPlayer:GetMouse().Hit, true)
	end

	if Configuration.expectToggleValue("AutoWisp") and cwp and cws then
		hssp(cwp, cws)
	end

	if not Configuration.expectToggleValue("EnableAutoDefense") then
		return
	end

	for _, object in next, defenderAnimationObjects do
		object:update()
	end

	for _, object in next, defenderPartObjects do
		object:update()
	end
end)

---Create a defender part object.
---@param part BasePart
---@param timing PartTiming?
---@return PartDefender?
Defense.cdpo = LPH_NO_VIRTUALIZE(function(part, timing)
	-- This came from a module and we specified it in the parameters, meaning this is custom.
	-- We need to re-encrypt the data. The actions will get re-encrypted when they get processed.
	if timing and (timing.cbm or timing.umoa) then
		timing["name"] = PP_SCRAMBLE_STR(timing["name"])
		timing["imxd"] = PP_SCRAMBLE_RE_NUM(timing["imxd"])
		timing["imdd"] = PP_SCRAMBLE_RE_NUM(timing["imdd"])
		timing["hitbox"] = Vector3.new(
			PP_SCRAMBLE_RE_NUM(timing["hitbox"].X),
			PP_SCRAMBLE_RE_NUM(timing["hitbox"].Y),
			PP_SCRAMBLE_RE_NUM(timing["hitbox"].Z)
		)
	end

	local partDefender = PartDefender.new(part, timing)
	if not partDefender then
		return nil
	end

	defenderObjects[part] = partDefender
	defenderPartObjects[part] = partDefender

	return partDefender
end)

---Return the defender animation object for an entity.
---@param entity Instance
---@return AnimatorDefender?
Defense.dao = LPH_NO_VIRTUALIZE(function(entity)
	for _, object in next, defenderAnimationObjects do
		if object.entity ~= entity then
			continue
		end

		return object
	end
end)

---Get playback data of first defender with Animation ID.
---@param aid string
---@return PlaybackData?
Defense.agpd = LPH_NO_VIRTUALIZE(function(aid)
	---@note: Grabbing from 'rpbdata' means that we know that the data has been fully recorded.
	for _, object in next, defenderAnimationObjects do
		local pbdata = object.rpbdata[aid]
		if not pbdata then
			continue
		end

		return pbdata
	end

	---@note: Fallback to deleted playback data if that doesn't exist.
	for _, rpbdata in next, deletedPlaybackData do
		local pbdata = rpbdata[aid]
		if not pbdata then
			continue
		end

		return pbdata
	end
end)

---On spell event.
---@param name string
---@param data any?
local onSpellEvent = LPH_NO_VIRTUALIZE(function(name, data)
	-- Close.
	if name == "close" then
		cws = nil
		cwp = nil
		lastAutoWispUpdate = nil
		lastAutoWispShift = nil
		autoWispLocked = false
	end

	-- Set the current position & string.
	if name == "start" then
		cws = data
		cwp = 1
		lastAutoWispUpdate = os.clock()
		lastAutoWispShift = nil
		autoWispLocked = false
	end

	-- Shift our position if we were successful.
	if cws and cwp and name == "shift" then
		cwp = cwp + 1
		lastAutoWispShift = os.clock()
		autoWispLocked = false
	end
end)

---Feint flourish.
function Defense.fflourish()
	if not Configuration.expectToggleValue("FeintFlourish") then
		return
	end

	local effectReplicator = replicatedStorage:FindFirstChild("EffectReplicator")
	if not effectReplicator then
		return Logger.warn("EffectReplicator not found for FeintFlourish.")
	end

	local effectReplicatorModule = require(effectReplicator)
	if not effectReplicatorModule then
		return Logger.warn("EffectReplicator module not found for FeintFlourish.")
	end

	if not effectReplicatorModule:FindEffect("MidAttack") then
		return Logger.warn("Not MidAttack effect for FeintFlourish.")
	end

	local mantra = Finder.ncdm()
	if not mantra then
		return Logger.warn("No mantra found for FeintFlourish.")
	end

	if effectReplicatorModule:FindEffect("FeintCool") then
		return Logger.warn("No avaliable feint for FeintFlourish.")
	end

	local lastAnimationTiming = StateListener.lAnimTiming
	if not lastAnimationTiming then
		return Logger.warn("No last animation timing found for FeintFlourish.")
	end

	if not lastAnimationTiming.smod:match("Flourish") then
		return Logger.warn("Last animation is not a flourish for FeintFlourish.")
	end

	-- Activate mantra.
	Logger.warn("(%s) FeintFlourish activated mantra.", mantra.Name)

	InputClient.amantra(mantra)

	-- Wait.
	task.wait(0.1)

	-- Feint mantra.
	Logger.warn("(%s) FeintFlourish feinted mantra.", mantra.Name)

	InputClient.feint()
end

---Initialize defense.
function Defense.init()
	-- Cache mob animations.
	local assetFolder = replicatedStorage:WaitForChild("Assets")
	local animationFolder = assetFolder:WaitForChild("Anims")
	local mobsAnimationFolder = animationFolder:WaitForChild("Mobs")

	for _, animation in next, mobsAnimationFolder:QueryDescendants("Animation") do
		if animation.Name == "RunningAttack" then
			continue
		end

		mobAnimations[animation.AnimationId] = animation
	end

	-- Local player.
	local localPlayer = players.LocalPlayer
	local playerGui = localPlayer:WaitForChild("PlayerGui")
	local spellGui = playerGui:WaitForChild("SpellGui")

	-- Requests.
	local requests = replicatedStorage:WaitForChild("Requests")
	local clientEffect = requests:WaitForChild("ClientEffect")
	local clientEffectLarge = requests:WaitForChild("ClientEffectLarge")
	local clientEffectDirect = requests:WaitForChild("ClientEffectDirect")
	local spell = spellGui:WaitForChild("SpellInput")

	-- Signals.
	local gameDescendantAdded = Signal.new(game.DescendantAdded)
	local gameDescendantRemoved = Signal.new(game.DescendantRemoving)
	local inputBegan = Signal.new(userInputService.InputBegan)
	local inputEnded = Signal.new(userInputService.InputEnded)
	local renderStepped = Signal.new(runService.RenderStepped)
	local postSimulation = Signal.new(runService.PostSimulation)
	local clientEffectEvent = Signal.new(clientEffect.OnClientEvent)
	local clientEffectLargeEvent = Signal.new(clientEffectLarge.OnClientEvent)
	local cientEffectDirect = Signal.new(clientEffectDirect.Event)
	local spellEvent = Signal.new(spell.OnClientEvent)

	---@note: Need this to detect UI presses / game processed inputs.
	defenseMaid:mark(inputBegan:connect("Defense_OnInputBegan", function(input, gameProcessed)
		if gameProcessed then
			return
		end

		if input.UserInputType == Enum.UserInputType.MouseButton2 then
			TaskSpawner.delay("StateListener_FeintFlourish", function()
				return 0.07
			end, Defense.fflourish)
		end

		if input.UserInputType ~= Enum.UserInputType.MouseButton1 then
			return
		end

		leftClickState = true
	end))

	defenseMaid:mark(inputEnded:connect("Defense_OnInputEnded", function(input, _)
		if input.UserInputType ~= Enum.UserInputType.MouseButton1 then
			return
		end

		leftClickState = false
	end))

	defenseMaid:mark(gameDescendantAdded:connect("Defense_OnDescendantAdded", onGameDescendantAdded))
	defenseMaid:mark(gameDescendantRemoved:connect("Defense_OnDescendantRemoved", onGameDescendantRemoved))
	defenseMaid:mark(renderStepped:connect("Defense_UpdateVisualizations", updateVisualizations))
	defenseMaid:mark(renderStepped:connect("Defense_UpdateHistory", updateHistory))
	defenseMaid:mark(renderStepped:connect("Defense_UpdateGoldenTongue", updateGoldenTongue))
	defenseMaid:mark(renderStepped:connect("Defense_UpdateAutoArdour", updateAutoArdour))
	defenseMaid:mark(postSimulation:connect("Defense_UpdateDefenders", updateDefenders))
	defenseMaid:mark(clientEffectEvent:connect("Defense_ClientEffectEvent", onClientEffectEvent))
	defenseMaid:mark(clientEffectLargeEvent:connect("Defense_ClientEffectEventLarge", onClientEffectEvent))
	defenseMaid:mark(cientEffectDirect:connect("Defense_ClientEffectEventDirect", onClientEffectEvent))
	defenseMaid:mark(spellEvent:connect("Defense_SpellEvent", onSpellEvent))

	for _, descendant in next, game:GetDescendants() do
		onGameDescendantAdded(descendant)
	end

	-- Log.
	Logger.warn("Defense initialized.")
end

---Detach defense.
function Defense.detach()
	for _, object in next, defenderObjects do
		object:detach()
	end

	defenseMaid:clean()

	Logger.warn("Defense detached.")
end

-- Return Defense module.
return Defense

end)
__bundle_register("Features/Combat/EntityHistory", function(require, _LOADED, __bundle_register, __bundle_modules)
-- EntityHistory module.
local EntityHistory = {}

-- Histories table.
local histories = {}

-- Max history seconds.
local MAX_HISTORY_SECS = 3.0

---Add an entry to the history list.
---@param idx any
---@param position CFrame
---@param velocity Vector3
---@param timestamp number
EntityHistory.add = LPH_NO_VIRTUALIZE(function(idx, position, velocity, timestamp)
	local history = histories[idx] or {}

	if not histories[idx] then
		histories[idx] = history
	end

	history[#history + 1] = {
		position = position,
		timestamp = timestamp,
		velocity = velocity,
	}

	while true do
		local tail = history[1]
		if not tail then
			break
		end

		if tick() - tail.timestamp <= MAX_HISTORY_SECS then
			break
		end

		table.remove(history, 1)
	end
end)

---Get every velocity in the history, looking back a given time.
---@param index any
---@param time number
---@return Vector3[]?
EntityHistory.vall = LPH_NO_VIRTUALIZE(function(index, time)
	local history = histories[index]
	if not history then
		return nil
	end

	local out = {}

	for _, data in next, history do
		if tick() - data.timestamp > time then
			continue
		end

		out[#out + 1] = data.velocity
	end

	return out
end)

---Get the horizontal angular velocity (yaw rate) for a current index.
---@param index any
---@return number?
EntityHistory.yrate = LPH_NO_VIRTUALIZE(function(index)
	local history = histories[index]
	if not history or #history < 2 then
		return nil
	end

	local latest = history[#history]
	local previous = history[#history - 1]
	local dt = latest.timestamp - previous.timestamp
	if dt <= 1e-4 then
		return nil
	end

	local prevLook = Vector3.new(previous.position.LookVector.X, 0, previous.position.LookVector.Z).Unit
	local latestLook = Vector3.new(latest.position.LookVector.X, 0, latest.position.LookVector.Z).Unit
	local dot = prevLook:Dot(latestLook)
	local crossY = prevLook:Cross(latestLook).Y
	local angle = math.atan2(crossY, dot)
	return angle / dt
end)

---Divides the history into a number of equal steps and returns the position at each step.
---@param idx any
---@param steps number
---@param phds number History second limit for past hitbox detection.
---@return CFrame[]?
EntityHistory.pstepped = LPH_NO_VIRTUALIZE(function(idx, steps, phds)
	local history = histories[idx]
	if not history or #history == 0 then
		return nil
	end

	if not steps or steps <= 0 then
		return nil
	end

	local vhistory = {}
	local vhtime = history[#history].timestamp

	for _, data in next, history do
		if vhtime - data.timestamp > phds then
			continue
		end

		vhistory[#vhistory + 1] = data.position
	end

	if #vhistory == 0 then
		return {}
	end

	local count = math.min(steps, #vhistory)
	local out = table.create(count)

	for cidx = 1, count do
		out[cidx] = vhistory[math.max(math.floor((cidx * #vhistory) / count), 1)]
	end

	return out
end)

---Get closest position (in time) to a timestamp.
---@param idx any
---@param timestamp number
---@return CFrame?
EntityHistory.pclosest = LPH_NO_VIRTUALIZE(function(idx, timestamp)
	if not histories[idx] then
		return nil
	end

	local closestDelta = nil
	local closestPosition = nil

	for _, data in next, histories[idx] do
		local delta = math.abs(timestamp - data.timestamp)

		if closestDelta and delta >= closestDelta then
			continue
		end

		closestPosition = data.position
		closestDelta = delta
	end

	return closestPosition
end)

-- Return EntityHistory module.
return EntityHistory

end)
__bundle_register("Features/Combat/StateListener", function(require, _LOADED, __bundle_register, __bundle_modules)
-- StateListener module. Practically, it is a module to store data / information about what is happening with the character.
local StateListener = {
	-- Local data.
	lMantraActivated = nil,
	lAnimTiming = nil,
	lAnimFaction = nil,
	lAnimTimestamp = nil,
	chainStacks = nil,
	lastVent = nil,
	lAnimLatency = nil,

	-- Global data provided for by every AnimationDefender object.
	-- This is the most recent information from every defender which this gets set for.
	lADAction = nil,
	lADAnimation = nil,
}

---@module Utility.Signal
local Signal = require("Utility/Signal")

---@module Utility.Maid
local Maid = require("Utility/Maid")

---@module Utility.Configuration
local Configuration = require("Utility/Configuration")

---@module Utility.Logger
local Logger = require("Utility/Logger")

---@module Utility.TaskSpawner
local TaskSpawner = require("Utility/TaskSpawner")

---@module Game.InputClient
local InputClient = require("Game/InputClient")

---@module Game.Timings.SaveManager
local SaveManager = require("Game/Timings/SaveManager")

---@module Game.Timings.ModuleManager
local ModuleManager = require("Game/Timings/ModuleManager")

---@module Game.Latency
local Latency = require("Game/Latency")

---@module Utility.Table
local Table = require("Utility/Table")

-- Maids.
local stateMaid = Maid.new()

-- Services.
local players = game:GetService("Players")
local replicatedStorage = game:GetService("ReplicatedStorage")
local userInputService = game:GetService("UserInputService")

-- Constants.
local CHIME_ARENA_PLACE_ID = 6832944305

---Handle module data.
---@param track AnimationTrack
---@param timing AnimationTiming
local handleModuleData = LPH_NO_VIRTUALIZE(function(track, timing)
	-- Since we don't know what it could fail on, limit it to weapons for now.
	if timing.tag ~= "M1" then
		return
	end

	-- Get loaded function.
	local lf = ModuleManager.modules[PP_SCRAMBLE_STR(timing.smod)]
	if not lf then
		return
	end

	-- Run module with a fake 'AnimationDefender' object.
	local extracted = {}
	local fake = {
		tmaid = Maid.new(),
		track = track,
		entity = players.LocalPlayer.Character,
		action = function(_, _, action)
			table.insert(extracted, action)
		end,
	}

	lf(fake, timing)

	-- Clean up.
	fake.tmaid:clean()

	-- Set first extracted action as last animation faction.
	StateListener.lAnimFaction = extracted[1]
end)

---On local animation played.
---@param track AnimationTrack
local onLocalAnimationPlayed = LPH_NO_VIRTUALIZE(function(track)
	local aid = tostring(track.Animation.AnimationId)
	local data = SaveManager.as:index(aid)
	if not data then
		return
	end

	StateListener.lAnimTimestamp = os.clock()
	StateListener.lAnimationValidTrack = track
	StateListener.lAnimTiming = data
	StateListener.lAnimLatency = Latency.rtt()

	-- If this is a module, we need to extract the actions differently. It expects to be ran normally.
	-- Run it in a emulated environment.
	if data.umoa then
		return handleModuleData(track, data)
	end

	StateListener.lAnimFaction = data.actions:stack()[1]
end)

---On descendant added.
---@param descendant Instance
local onDescendantAdded = LPH_NO_VIRTUALIZE(function(descendant)
	if not descendant:IsA("Animator") then
		return
	end

	local character = players.LocalPlayer.Character
	if not character then
		return
	end

	if not descendant:IsDescendantOf(character) then
		return
	end

	local animationPlayed = Signal.new(descendant.AnimationPlayed)

	stateMaid["LocalPlayerAnimListener"] =
		animationPlayed:connect("StateListener_AnimationPlayed", onLocalAnimationPlayed)
end)

---Is an effect within a specific time?
---@param effect table
---@param time number? If the number is unspecified, it will use the Debris time.
---@param offset boolean If the number is specified, should we use it as an offset from the Debris time?
---@return boolean
local withinTime = LPH_NO_VIRTUALIZE(function(effect, time, offset)
	if not effect.index then
		return false
	end

	local timestamp = effect.index.Timestamp
	if not timestamp then
		return false
	end

	local dtime = effect.index.DebrisTime
	if not dtime then
		return false
	end

	if offset and time then
		return os.clock() - timestamp <= (dtime + time)
	end

	return os.clock() - timestamp <= (time or dtime)
end)

---Are we currently holding block?
---@return boolean
StateListener.hblock = LPH_NO_VIRTUALIZE(function()
	local keybinds = replicatedStorage:FindFirstChild("KeyBinds")
	if not keybinds then
		return false
	end

	local keybindsModule = require(keybinds)
	if not keybindsModule or not keybindsModule.Current then
		return false
	end

	local bindings = keybindsModule:GetBindings() or {}

	for _, keybind in next, bindings["Block"] do
		local success, keyCode = pcall(function()
			return Enum.KeyCode[tostring(keybind)]
		end)

		if not success or not keyCode then
			continue
		end

		if not userInputService:IsKeyDown(keyCode) then
			continue
		end

		return true
	end

	return false
end)

---Are we currently casting Sightless Beam?
---@return boolean
StateListener.csb = LPH_NO_VIRTUALIZE(function()
	if not StateListener.lMantraActivated then
		return false
	end

	local name = tostring(StateListener.lMantraActivated)
	if not name or not name:match("Sightless Beam") then
		return false
	end

	local character = players.LocalPlayer and players.LocalPlayer.Character
	if not character then
		return false
	end

	local hrp = character:FindFirstChild("HumanoidRootPart")
	if not hrp then
		return false
	end

	if hrp:FindFirstChild("REP_SOUND_376107250") then
		return true
	end

	for _, child in next, hrp:GetChildren() do
		if not child:IsA("Sound") then
			continue
		end

		if child.Name ~= "Telekin" then
			continue
		end

		if not child.IsPlaying then
			continue
		end

		return true
	end

	return false
end)

--Are we in action stun? That small window after doing an action where you can't do anything.
---@return boolean
StateListener.astun = LPH_NO_VIRTUALIZE(function()
	local effectReplicator = replicatedStorage:WaitForChild("EffectReplicator")
	local effectReplicatorModule = require(effectReplicator)
	local lightAttackEffect = effectReplicatorModule:FindEffect("LightAttack")
	local usingCriticalEffect = effectReplicatorModule:FindEffect("UsingCritical")
	local usingSpellEffect = effectReplicatorModule:FindEffect("UsingSpell")

	if lightAttackEffect and withinTime(lightAttackEffect, 0.5, false) then
		return true
	end

	if usingCriticalEffect and withinTime(usingCriticalEffect, -0.1, true) then
		return true
	end

	if usingSpellEffect then
		return true
	end

	return false
end)

---Can we vent?
---@return boolean
StateListener.cvent = LPH_NO_VIRTUALIZE(function()
	local effectReplicator = replicatedStorage:WaitForChild("EffectReplicator")
	local effectReplicatorModule = require(effectReplicator)
	local ventCooldownEffect = effectReplicatorModule:FindEffect("NoBurst")

	if Configuration.expectToggleValue("BlockVentState") then
		return false
	end

	local character = players.LocalPlayer and players.LocalPlayer.Character
	if not character then
		return false
	end

	if StateListener.lastVent and (os.clock() - StateListener.lastVent) <= 8.0 then
		return false
	end

	local tempo = character:FindFirstChild("Tempo")
	if not tempo then
		return false
	end

	if tempo.Value < 40 then
		return false
	end

	if not effectReplicatorModule:FindEffect("Equipped") then
		return false
	end

	if ventCooldownEffect then
		return false
	end

	return true
end)

---Can we parry?
---@return boolean
StateListener.cparry = LPH_NO_VIRTUALIZE(function()
	local effectReplicator = replicatedStorage:WaitForChild("EffectReplicator")
	local effectReplicatorModule = require(effectReplicator)
	local parryCooldownEffect = effectReplicatorModule:FindEffect("ParryCool")

	if Configuration.expectToggleValue("BlockParryState") then
		return false
	end

	if not effectReplicatorModule:FindEffect("Equipped") then
		return false
	end

	if parryCooldownEffect then
		return false
	end

	return true
end)

---Can we feint?
---@return boolean
StateListener.cfeint = LPH_NO_VIRTUALIZE(function()
	local effectReplicator = replicatedStorage:WaitForChild("EffectReplicator")
	local effectReplicatorModule = require(effectReplicator)
	local feintCooldownEffect = effectReplicatorModule:FindEffect("FeintCool")

	if feintCooldownEffect then
		return false
	end

	return true
end)

---Can we block?
---@return boolean
StateListener.cblock = LPH_NO_VIRTUALIZE(function()
	local character = players.LocalPlayer and players.LocalPlayer.Character
	if not character then
		return false
	end

	if Configuration.expectToggleValue("NoBlockingState") then
		return false
	end

	local breakMeter = character:FindFirstChild("BreakMeter")
	if not breakMeter then
		return false
	end

	if breakMeter.Value / breakMeter.MaxValue > 0.6 then
		return false
	end

	local effectReplicator = replicatedStorage:WaitForChild("EffectReplicator")
	local effectReplicatorModule = require(effectReplicator)

	if effectReplicatorModule:FindEffect("ShakyBlock") then
		return false
	end

	if effectReplicatorModule:FindEffect("CancelBlock") then
		return false
	end

	return true
end)

---Can we dodge?
---@return boolean
StateListener.cdodge = LPH_NO_VIRTUALIZE(function()
	local effectReplicator = replicatedStorage:WaitForChild("EffectReplicator")
	local effectReplicatorModule = require(effectReplicator)
	local dodgeCooldownEffect = effectReplicatorModule:FindEffect("NoRoll")
	local stunCooldownEffect = effectReplicatorModule:FindEffect("Stun")

	if Configuration.expectToggleValue("BlockDodgeState") then
		return false
	end

	if dodgeCooldownEffect then
		return false
	end

	if stunCooldownEffect and withinTime(stunCooldownEffect, nil, false) then
		return false
	end

	return true
end)

---Are we in chime countdown?
---@return boolean
StateListener.ccd = LPH_NO_VIRTUALIZE(function()
	return game.PlaceId == CHIME_ARENA_PLACE_ID and workspace.DistributedGameTime < 15
end)

---On effect replicated.
---@param effect table
local onEffectReplicated = LPH_NO_VIRTUALIZE(function(effect)
	if Configuration.expectToggleValue("EffectLogging") then
		print(string.format("(%s) %s", tostring(effect.index.DebrisTime) or "N/A", tostring(effect)))
	end

	if effect.Class == "Knocked" or effect.Class == "Ragdoll" then
		if Configuration.expectToggleValue("AutoRagdollRecover") then
			InputClient.feint()
		end
	end

	if effect.Class == "MantraCasted" then
		TaskSpawner.spawn("StateListener_AutoMantraFollowup", function()
			---@module Game.QueuedBlocking
			local QueuedBlocking = require("Game/QueuedBlocking")

			-- Check setting.
			if not Configuration.expectToggleValue("AutoMantraFollowup") then
				return
			end

			-- Get track.
			local track = StateListener.lAnimationValidTrack
			if not track or not track.IsPlaying then
				return
			end

			local instance = StateListener.lMantraActivated
			if not instance then
				return
			end

			local faction = StateListener.lAnimFaction
			if not faction then
				return
			end

			if not instance.ToolTip:match("Press @Block@") then
				return
			end

			local effectReplicator = replicatedStorage:WaitForChild("EffectReplicator")
			local effectReplicatorModule = require(effectReplicator)

			if
				Configuration.expectToggleValue("CheckIfMoveHit")
				and not effectReplicatorModule:FindEffect("DamagedAnother")
			then
				return
			end

			QueuedBlocking.invoke(QueuedBlocking.BLOCK_TYPE_NORMAL, "AutoMantraFollowup", nil)

			repeat
				task.wait()
			until os.clock() - StateListener.lAnimTimestamp >= (faction:when() + 0.100) - Latency.rtt()

			QueuedBlocking.stop("AutoMantraFollowup")
		end)
	end

	if effect.Class == "LightAttack" then
		effect.index.Timestamp = os.clock()
	end

	if effect.Class == "Stun" then
		effect.index.Timestamp = os.clock()
	end

	if effect.Class == "DodgeCool" then
		effect.index.Timestamp = os.clock()
	end

	if effect.Class == "ParryCool" then
		effect.index.Timestamp = os.clock()
	end

	if effect.Class == "Vented" then
		StateListener.lastVent = os.clock()
	end

	if effect.Class == "PerfectStack" then
		StateListener.chainStacks = 0
	end

	if effect.Class == "PerfectionCool" and StateListener.chainStacks then
		StateListener.chainStacks = math.min(StateListener.chainStacks + 1, 20)
	end
end)

---On effect removing.
---@param effect table
local onEffectRemoving = LPH_NO_VIRTUALIZE(function(effect)
	if effect.Class == "PerfectStack" then
		StateListener.chainStacks = nil
	end

	if not Configuration.expectToggleValue("EffectLogging") then
		return
	end

	warn(string.format("%s", tostring(effect)))
end)

---Initialize StateListener.
function StateListener.init()
	local live = workspace:WaitForChild("Live")
	local liveDescendantAdded = Signal.new(live.DescendantAdded)

	---@note: Not type of RBXScriptSignal - but it works.
	local effectReplicator = replicatedStorage:WaitForChild("EffectReplicator")
	local effectReplicatorModule = require(effectReplicator)
	local effectAddedSignal = Signal.new(effectReplicatorModule.EffectAdded)
	local effectRemovedSignal = Signal.new(effectReplicatorModule.EffectRemoved)

	stateMaid:mark(effectAddedSignal:connect("StateListener_EffectReplicated", onEffectReplicated))
	stateMaid:mark(effectRemovedSignal:connect("StateListener_EffectRemoved", onEffectRemoving))
	stateMaid:mark(liveDescendantAdded:connect("StateListener_DescendantAdded", onDescendantAdded))

	for _, effect in next, effectReplicatorModule.Effects do
		onEffectReplicated(effect)
	end

	for _, descendant in next, live:QueryDescendants("Animator") do
		onDescendantAdded(descendant)
	end

	Logger.warn("StateListener initialized.")
end

---Detach StateListener.
function StateListener.detach()
	stateMaid:clean()
end

-- Return StateListener module.
return StateListener

end)
__bundle_register("Game/QueuedBlocking", function(require, _LOADED, __bundle_register, __bundle_modules)
-- QueuedBlocking module. Allows of easy control of blocking without failure (e.g constant blocking randomly or w/e) and being frame-perfect.
local QueuedBlocking = {
	BLOCK_TYPE_DEFLECT = 1, -- For parry/deflect frames. This means it will get removed as soon as we are considered as blocking.
	BLOCK_TYPE_NORMAL = 2, -- For normal blocking. This means it will stay in the queue until dead time expires or manually removed.
}

---@module Game.InputClient
local InputClient = require("Game/InputClient")

---@module Game.KeyHandling
local KeyHandling = require("Game/KeyHandling")

---@module Utility.Logger
local Logger = require("Utility/Logger")

---@module Utility.Signal
local Signal = require("Utility/Signal")

---@module Utility.Maid
local Maid = require("Utility/Maid")

---@module Features.Combat.StateListener
local StateListener = require("Features/Combat/StateListener")

-- Maids.
local qiMaid = Maid.new()

-- Queue.
local blockQueue = {}

-- Services.
local replicatedStorage = game:GetService("ReplicatedStorage")
local runService = game:GetService("RunService")

---On render stepped.
local function onRenderStepped()
	local effectReplicator = replicatedStorage:FindFirstChild("EffectReplicator")
	if not effectReplicator then
		return
	end

	local effectReplicatorModule = require(effectReplicator)
	if not effectReplicatorModule then
		return
	end

	local blockRemote = KeyHandling.getRemote("Block")
	if not blockRemote then
		return
	end

	local unblockRemote = KeyHandling.getRemote("Unblock")
	if not unblockRemote then
		return
	end

	local inputData = InputClient.getInputData()
	if not inputData then
		return
	end

	if StateListener.hblock() then
		return QueuedBlocking.empty()
	end

	-- Are we blocking?
	local blocking = effectReplicatorModule:HasEffect("Blocking")

	-- Set up input data.
	inputData["f"] = true

	-- Process entries that need to be killed.
	for id, data in next, blockQueue do
		local dead = data.dt and os.clock() - data.start >= data.dt
		local deflected = data.type == QueuedBlocking.BLOCK_TYPE_DEFLECT and blocking

		if not deflected and not dead then
			continue
		end

		QueuedBlocking.stop(id)
	end

	-- Calculate if we have something in the queue.
	local blockQueueLength = 0

	for _, _ in next, blockQueue do
		blockQueueLength = blockQueueLength + 1
	end

	-- Handle blocking input.
	inputData["f"] = blockQueueLength > 0

	-- Call with direct functions so our hooks call...
	local fireServer = Instance.new("RemoteEvent").FireServer

	if blocking then
		return blockQueueLength <= 0 and fireServer(unblockRemote)
	end

	if not effectReplicatorModule:FindEffect("Action") and not effectReplicatorModule:FindEffect("Knocked") then
		return blockQueueLength > 0 and fireServer(blockRemote)
	end
end

---Invoke a block action.
---@param type number The block type.
---@param id string Identifier tied to this action.
---@param dt number?
function QueuedBlocking.invoke(type, id, dt)
	local effectReplicator = replicatedStorage:FindFirstChild("EffectReplicator")
	if not effectReplicator then
		return
	end

	local effectReplicatorModule = require(effectReplicator)
	if not effectReplicatorModule then
		return
	end

	local blockRemote = KeyHandling.getRemote("Block")
	if not blockRemote then
		return Logger.warn("QueuedBlocking.invoke(...) - Missing block remote.")
	end

	local sprintFunction = InputClient.sprintFunctionCache
	local inputData = InputClient.getInputData()

	if not sprintFunction or not inputData then
		return Logger.warn(
			"QueuedBlocking.invoke(...) - (%s, %s) - Missing important data.",
			tostring(sprintFunction),
			tostring(inputData)
		)
	end

	local bufferEffect = effectReplicatorModule:FindEffect("M1Buffering")

	if bufferEffect then
		bufferEffect:Remove()
	end

	if effectReplicatorModule:HasEffect("CastingSpell") then
		return
	end

	blockRemote:FireServer()

	inputData["f"] = true

	sprintFunction(false)

	Logger.warn(
		"QueuedBlocking.invoke(...) - (at %.2f) Invoking block action '%s' of type %d with dead time (%s) to queue.",
		os.clock(),
		tostring(id),
		type,
		tostring(dt)
	)

	blockQueue[id] = {
		start = os.clock(),
		type = type,
		dt = dt,
	}
end

---Empty the block queue.
function QueuedBlocking.empty()
	blockQueue = {}
end

---Stop a block action from the queue.
---@param id string The block action ID.
function QueuedBlocking.stop(id)
	if not blockQueue[id] then
		return
	end

	-- Log.
	Logger.warn("QueuedBlocking.stop(...) - Stopping block action '%s' in queue.", tostring(id))

	-- Remove.
	blockQueue[id] = nil
end

---Initialize QueuedBlocking module.
function QueuedBlocking.init()
	local renderStepped = Signal.new(runService.RenderStepped)
	qiMaid:mark(renderStepped:connect("QueuedInputs_Update", onRenderStepped))
end

---Detach QueuedBlocking module.
function QueuedBlocking.detach()
	qiMaid:clean()
end

-- Return QueuedBlocking module.
return QueuedBlocking

end)
__bundle_register("Game/Timings/SaveManager", function(require, _LOADED, __bundle_register, __bundle_modules)
---@module Game.Timings.TimingSave
local TimingSave = require("Game/Timings/TimingSave")

---@module Game.Timings.TimingContainerPair
local TimingContainerPair = require("Game/Timings/TimingContainerPair")

---@module Game.Timings.TimingContainer
local TimingContainer = require("Game/Timings/TimingContainer")

---@module Game.Timings.AnimationTiming
local AnimationTiming = require("Game/Timings/AnimationTiming")

---@module Game.Timings.EffectTiming
local EffectTiming = require("Game/Timings/EffectTiming")

---@module Game.Timings.PartTiming
local PartTiming = require("Game/Timings/PartTiming")

---@module Game.Timings.SoundTiming
local SoundTiming = require("Game/Timings/SoundTiming")

---@module Utility.Maid
local Maid = require("Utility/Maid")

---@module Utility.Signal
local Signal = require("Utility/Signal")

---@module Utility.Configuration
local Configuration = require("Utility/Configuration")

-- SaveManager module.
local SaveManager = { llc = nil, llcn = nil, lct = nil }

---@module Utility.Filesystem
local Filesystem = require("Utility/Filesystem")

---@module Utility.Logger
local Logger = require("Utility/Logger")

---@module Utility.Deserializer
local Deserializer = require("Utility/Deserializer")

---@module Utility.String
local String = require("Utility/String")

---@module Utility.Serializer
local Serializer = require("Utility/Serializer")

-- Manager filesystem.
local fs = Filesystem.new("Lycoris-Rewrite-Timings")

-- Current timing save.
local config = TimingSave.new()

-- Services.
local runService = game:GetService("RunService")

-- Maids.
local saveMaid = Maid.new()

---Get save files list.
---@return table
function SaveManager.list()
	local list = fs:list(true)
	local out = {}

	for idx = 1, #list do
		local file = list[idx]

		if file:sub(-4) ~= ".txt" then
			continue
		end

		local pos = file:find(".txt", 1, true)
		local char = file:sub(pos, pos)
		local start = pos

		while char ~= "/" and char ~= "\\" and char ~= "" do
			pos = pos - 1
			char = file:sub(pos, pos)
		end

		if char == "/" or char == "\\" then
			table.insert(out, file:sub(pos + 1, start - 1))
		end
	end

	return out
end

---Refresh dropdown values with timing data.
---@param dropdown table
function SaveManager.refresh(dropdown)
	dropdown:SetValues(SaveManager.list())
end

---Set config name as auto-load.
---@param name string
function SaveManager.autoload(name)
	if not name or #name <= 0 then
		return Logger.longNotify("Config name cannot be empty.")
	end

	local success, result = pcall(fs.write, fs, "autoload.txt", name)

	if not success then
		Logger.longNotify("Failed to write autoload file %s.", name)

		return Logger.warn(
			"Timing manager ran into the error '%s' while attempting to write autoload file %s.",
			result,
			name
		)
	end

	Logger.notify("Config file %s has set to auto-load.", name)
end

---Create timing as config name.
---@param name string
function SaveManager.create(name)
	if not name or #name <= 0 then
		return Logger.longNotify("Config name cannot be empty.")
	end

	if fs:file(name .. ".txt") then
		return Logger.longNotify("Config file %s already exists.", name)
	end

	SaveManager.write(name)
end

---Save timing as config name.
---@param name string
function SaveManager.save(name)
	if not name or #name <= 0 then
		return Logger.longNotify("Config name cannot be empty.")
	end

	if not fs:file(name .. ".txt") then
		return Logger.longNotify("Config file %s does not exist.", name)
	end

	SaveManager.write(name)
end

---Write timing as config name.
---@param name string
---@return number
function SaveManager.write(name)
	if not name or #name <= 0 then
		return -1, Logger.longNotify("Config name cannot be empty.")
	end

	local success, result = pcall(Serializer.marshal, config:serialize())

	if not success then
		Logger.longNotify("Failed to serialize config file %s.", name)

		return -2,
			Logger.warn("Timing manager ran into the error '%s' while attempting to serialize config %s.", result, name)
	end

	success, result = pcall(fs.write, fs, name .. ".txt", result)

	if not success then
		Logger.longNotify("Failed to write config file %s.", name)

		return -3,
			Logger.warn("Timing manager ran into the error '%s' while attempting to write config %s.", result, name)
	end

	Logger.notify("Config file %s has written to.", name)

	return 0
end

---Clear config from config name.
---@param name string
function SaveManager.clear(name)
	if not name or #name <= 0 then
		return Logger.longNotify("Config name cannot be empty.")
	end

	local success, result = pcall(Serializer.marshal, TimingSave.new():serialize())

	if not success then
		Logger.longNotify("Failed to serialize config file %s.", name)

		return Logger.warn(
			"Timing manager ran into the error '%s' while attempting to serialize config %s.",
			result,
			name
		)
	end

	success, result = pcall(fs.write, fs, name .. ".txt", result)

	if not success then
		Logger.longNotify("Failed to write config file %s.", name)

		return Logger.warn("Timing manager ran into the error '%s' while attempting to write config %s.", result, name)
	end

	Logger.notify("Config file %s has been cleared.", name)
end

---Load timing from config name.
---@param name string
function SaveManager.load(name)
	local timestamp = os.clock()

	if not name or #name <= 0 then
		return Logger.longNotify("Config name cannot be empty.")
	end

	local success, result = pcall(fs.read, fs, name .. ".txt")

	if not success then
		Logger.longNotify("Failed to read config file %s.", name)

		return Logger.warn("Timing manager ran into the error '%s' while attempting to read config %s.", result, name)
	end

	success, result = pcall(Deserializer.unmarshal_one, String.tba(result))

	if not success then
		Logger.longNotify("Failed to deserialize config file %s.", name)

		return Logger.warn(
			"Timing manager ran into the error '%s' while attempting to deserialize config %s.",
			result,
			name
		)
	end

	if typeof(result) ~= "table" then
		Logger.longNotify("Failed to process config file %s.", name)

		return Logger.warn("Timing manager failed to process config %s with result %s.", name, tostring(result))
	end

	config:clear()

	success, result = pcall(config.load, config, result)

	if not success then
		Logger.longNotify("Failed to load config file %s.", name)

		return Logger.warn("Timing manager ran into the error '%s' while attempting to load config %s.", result, name)
	end

	Logger.notify(
		"Config file %s has loaded with %i timings in %.2f seconds.",
		name,
		config:count(),
		os.clock() - timestamp
	)

	SaveManager.llc = config:clone()
	SaveManager.llcn = name
end

---Auto-save timings.
---@return boolean, number
function SaveManager.autosave()
	if not SaveManager.llcn then
		return false, -1, Logger.warn("No config name has been loaded for auto-save.")
	end

	if not SaveManager.sautos then
		return false, -2, Logger.warn("Auto-save has been disabled.")
	end

	Logger.warn("Auto-saving timings to '%s' config file.", SaveManager.llcn)

	return true, SaveManager.write(SaveManager.llcn), Logger.notify("Auto-save has completed successfully.")
end

---Initialize SaveManager.
function SaveManager.init()
	local timestamp = os.clock()
	local preRenderSignal = Signal.new(runService.PreRender)

	-- Create internal timing containers.
	local internalAnimationContainer = TimingContainer.new(AnimationTiming.new())
	local internalEffectContainer = TimingContainer.new(EffectTiming.new())
	local internalPartContainer = TimingContainer.new(PartTiming.new())
	local internalSoundContainer = TimingContainer.new(SoundTiming.new())

	---@todo: Load internal timings from server.
	internalAnimationContainer:load({})
	internalEffectContainer:load({})
	internalPartContainer:load({})
	internalSoundContainer:load({})

	-- Count up internal timings.
	local internalCount = internalAnimationContainer:count()
		+ internalEffectContainer:count()
		+ internalPartContainer:count()
		+ internalSoundContainer:count()

	Logger.notify(
		"Internal timings have loaded with %i timings in %.2f seconds.",
		internalCount,
		os.clock() - timestamp
	)

	-- Attempt to read auto-load config.
	local success, result = pcall(fs.read, fs, "autoload.txt")

	-- Load auto-load config if it exists.
	if success and result then
		SaveManager.load(result)
	end

	-- Animation stack.
	SaveManager.as = TimingContainerPair.new(internalAnimationContainer, config:get().animation)

	-- Effect stack.
	SaveManager.es = TimingContainerPair.new(internalEffectContainer, config:get().effect)

	-- Part stack.
	SaveManager.ps = TimingContainerPair.new(internalPartContainer, config:get().part)

	-- Sound stack.
	SaveManager.ss = TimingContainerPair.new(internalSoundContainer, config:get().sound)

	-- Run auto save.
	saveMaid:add(preRenderSignal:connect("SaveManager_AutoSave", function()
		local llc = SaveManager.llc
		if not llc then
			return
		end

		local llcn = SaveManager.llcn
		if not llcn then
			return
		end

		if not Configuration.expectToggleValue("PeriodicAutoSave") then
			return
		end

		if
			SaveManager.lct
			and os.clock() - SaveManager.lct < (Configuration.expectOptionValue("PeriodicAutoSaveInterval") or 60)
		then
			return
		end

		SaveManager.lct = os.clock()

		if config:equals(llc) then
			return
		end

		Logger.warn("Auto-saving timings to '%s' config file.", SaveManager.llcn)

		SaveManager.write(SaveManager.llcn)

		SaveManager.llc = config:clone()

		Logger.notify("Timing auto-save has completed successfully.")
	end))
end

---Detach SaveManager.
function SaveManager.detach()
	saveMaid:clean()
end

-- Return SaveManager module.
return SaveManager

end)
__bundle_register("Utility/Filesystem", function(require, _LOADED, __bundle_register, __bundle_modules)
return LPH_NO_VIRTUALIZE(function()
	---@class Filesystem
	---@field _path string
	local Filesystem = {}
	Filesystem.__index = Filesystem

	---Create and get the current path.
	---@return string
	function Filesystem:path()
		if not isfolder(self._path) then
			makefolder(self._path)
		end

		return self._path
	end

	---Append path to current path.
	---@param path string
	---@return string
	function Filesystem:append(path)
		return self:path() .. "\\" .. path
	end

	---Check if filename is a file.
	---@param filename string
	---@return boolean
	function Filesystem:file(filename)
		return isfile(self:append(filename))
	end

	---Read file from path.
	---@param filename string
	---@return string
	function Filesystem:read(filename)
		if not self:file(filename) then
			return error("File does not exist or is a folder.", 2)
		end

		return readfile(self:append(filename))
	end

	---Delete file.
	---@param filename string
	---@return string
	function Filesystem:delete(filename)
		if not self:file(filename) then
			return error("File does not exist or is a folder.", 2)
		end

		return delfile(self:append(filename))
	end

	---Write file to workspace folder.
	---@param filename string
	---@param contents string?
	function Filesystem:write(filename, contents)
		writefile(self:append(filename), contents and contents or "")
	end

	---List files.
	---@param raw boolean?
	---@return table
	function Filesystem:list(raw)
		local list = listfiles(self:path())
		if not list then
			return error("File list does not exist.", 2)
		end

		local new = {}

		for idx, path in next, list do
			---@note: Non-raw weird behavior where the path is never detected in the string. Let's manually index remove it.
			new[idx] = raw and path or string.sub(path, #(self:path() .. "\\") + 1, #path)
		end

		return new
	end

	---Create new Filesystem object.
	---@param path string
	---@return Filesystem
	function Filesystem.new(path)
		local self = setmetatable({}, Filesystem)
		self._path = path
		return self
	end

	-- Return Filesystem module.
	return Filesystem
end)()

end)
__bundle_register("Game/Timings/SoundTiming", function(require, _LOADED, __bundle_register, __bundle_modules)
---@module Game.Timings.Timing
local Timing = require("Game/Timings/Timing")

---@class SoundTiming: Timing
---@field id string Sound ID.
---@field rpue boolean Repeat parry until end.
---@field _rsd number Repeat start delay in miliseconds. Never access directly.
---@field _rpd number Delay between each repeat parry in miliseconds. Never access directly.
---@field alp boolean Allow local player to be hit.
local SoundTiming = setmetatable({}, { __index = Timing })
SoundTiming.__index = SoundTiming

---Timing ID.
---@return string
function SoundTiming:id()
	return self._id
end

---Equals check.
---@param other SoundTiming
function SoundTiming:equals(other)
	if not Timing.equals(self, other) then
		return false
	end

	if self._id ~= other._id then
		return false
	end

	if self.alp ~= other.alp then
		return false
	end

	return true
end

---Load from partial values.
---@param values table
function SoundTiming:load(values)
	Timing.load(self, values)

	if typeof(values._id) == "string" then
		self._id = values._id
	end

	if typeof(values.alp) == "boolean" then
		self.alp = values.alp
	end
end

---Clone timing.
---@return SoundTiming
function SoundTiming:clone()
	local clone = setmetatable(Timing.clone(self), SoundTiming)

	clone._id = self._id
	clone.alp = self.alp

	return clone
end

---Return a serializable table.
---@return SoundTiming
function SoundTiming:serialize()
	local serializable = Timing.serialize(self)

	serializable._id = self._id
	serializable.alp = self.alp

	return serializable
end

---Create a new sound timing.
---@param values table?
---@return SoundTiming
function SoundTiming.new(values)
	local self = setmetatable(Timing.new(), SoundTiming)

	self._id = ""
	self.rpue = false
	self._rsd = 0
	self._rpd = 0
	self.alp = false

	if values then
		self:load(values)
	end

	return self
end

-- Return SoundTiming module.
return SoundTiming

end)
__bundle_register("Game/Timings/Timing", function(require, _LOADED, __bundle_register, __bundle_modules)
---@module Game.Timings.ActionContainer
local ActionContainer = require("Game/Timings/ActionContainer")

---@class Timing
---@field name string
---@field tag string
---@field imdd number Initial minimum distance from position.
---@field imxd number Initial maximum distance from position.
---@field punishable number Punishable window in seconds.
---@field after number After window in seconds.
---@field duih boolean Delay until in hitbox.
---@field actions ActionContainer
---@field hitbox Vector3
---@field umoa boolean Use module over actions.
---@field smn boolean Skip module notification.
---@field srpn boolean Skip repeat notification.
---@field smod string Selected module string.
---@field aatk boolean Allow attacking.
---@field fhb boolean Hitbox facing offset.
---@field hso number Hitbox shift offset. This offset is applied backwards. Positive is backwards, negative is forwards.
---@field ndfb boolean No dash fallback.
---@field cbm boolean A non-saved field to indicate whether this was non-part-timing created by a module.
---@field nvfb boolean No vent fallback.
---@field bfht number Block fallback hold time.
---@field pbfb boolean Prefer block fallback.
---@field forced boolean Hidden field which allows us to force tasks to go through.
---@field htype Enum.PartType Shape of hitbox. Never accessible unless inside of a module or inside of real code. This is never serialized.
---@field rpue boolean Prefer repeat usage.
---@field _rsd number Repeat start delay. Never access directly.
---@field _rpd number Repeat parry delay. Never access directly.
---@field nbfb boolean No block fallback.
local Timing = {}
Timing.__index = Timing

---Getter for repeat start delay in seconds
---@return number
function Timing:rsd()
	return PP_SCRAMBLE_NUM(self._rsd) / 1000
end

---Getter for repeat parry delay in seconds.
---@return number
function Timing:rpd()
	return PP_SCRAMBLE_NUM(self._rpd) / 1000
end

---Timing ID. Override me.
---@return string
function Timing:id()
	return self.name
end

---Set timing ID. Override me.
---@param id string
function Timing:set(id)
	self.name = id
end

---Load from partial values.
---@param values table
function Timing:load(values)
	if typeof(values.name) == "string" then
		self.name = values.name
	end

	if typeof(values.tag) == "string" then
		self.tag = values.tag
	end

	if typeof(values.imdd) == "number" then
		self.imdd = values.imdd
	end

	if typeof(values.imxd) == "number" then
		self.imxd = values.imxd
	end

	if typeof(values.duih) == "boolean" then
		self.duih = values.duih
	end

	if typeof(values.punishable) == "number" then
		self.punishable = values.punishable
	end

	if typeof(values.after) == "number" then
		self.after = values.after
	end

	if typeof(values.actions) == "table" then
		self.actions:load(values.actions)
	end

	if typeof(values.smn) == "boolean" then
		self.smn = values.smn
	end

	if typeof(values.hitbox) == "table" then
		self.hitbox = Vector3.new(values.hitbox.X or 0, values.hitbox.Y or 0, values.hitbox.Z or 0)
	end

	if typeof(values.umoa) == "boolean" then
		self.umoa = values.umoa
	end

	if typeof(values.srpn) == "boolean" then
		self.srpn = values.srpn
	end

	if typeof(values.smod) == "string" then
		self.smod = values.smod
	end

	if typeof(values.aatk) == "boolean" then
		self.aatk = values.aatk
	end

	if typeof(values.fhb) == "boolean" then
		self.fhb = values.fhb
	end

	if typeof(values.hso) == "number" then
		self.hso = values.hso
	end

	if typeof(values.ndfb) == "boolean" then
		self.ndfb = values.ndfb
	end

	if typeof(values.nvfb) == "boolean" then
		self.nvfb = values.nvfb
	end

	if typeof(values.bfht) == "number" then
		self.bfht = values.bfht
	end

	if typeof(values.rsd) == "string" then
		self._rsd = tonumber(values.rsd) or 0.0
	end

	if typeof(values.rpd) == "string" then
		self._rpd = tonumber(values.rpd) or 0.0
	end

	if typeof(values.rsd) == "number" then
		self._rsd = values.rsd
	end

	if typeof(values.rpd) == "number" then
		self._rpd = values.rpd
	end

	if typeof(values.rpue) == "boolean" then
		self.rpue = values.rpue
	end

	if typeof(values.nbfb) == "boolean" then
		self.nbfb = values.nbfb
	end
end

---Equals check.
---@param other Timing
---@return boolean
function Timing:equals(other)
	if self.name ~= other.name then
		return false
	end

	if self.tag ~= other.tag then
		return false
	end

	if self.imdd ~= other.imdd then
		return false
	end

	if self.imxd ~= other.imxd then
		return false
	end

	if self.duih ~= other.duih then
		return false
	end

	if self.punishable ~= other.punishable then
		return false
	end

	if self.after ~= other.after then
		return false
	end

	if not self.actions:equals(other.actions) then
		return false
	end

	if self.smn ~= other.smn then
		return false
	end

	if self.hitbox ~= other.hitbox then
		return false
	end

	if self.umoa ~= other.umoa then
		return false
	end

	if self.hso ~= other.hso then
		return false
	end

	if self.srpn ~= other.srpn then
		return false
	end

	if self.smod ~= other.smod then
		return false
	end

	if self.aatk ~= other.aatk then
		return false
	end

	if self.fhb ~= other.fhb then
		return false
	end

	if self.ndfb ~= other.ndfb then
		return false
	end

	if self.nvfb ~= other.nvfb then
		return false
	end

	if self.bfht ~= other.bfht then
		return false
	end

	if self.rpue ~= other.rpue then
		return false
	end

	if self._rsd ~= other._rsd then
		return false
	end

	if self._rpd ~= other._rpd then
		return false
	end

	if self.nbfb ~= other.nbfb then
		return false
	end

	return true
end

---Clone timing.
---@return Timing
function Timing:clone()
	local clone = Timing.new()

	clone.name = self.name
	clone.tag = self.tag
	clone.duih = self.duih
	clone.imdd = self.imdd
	clone.imxd = self.imxd
	clone.smn = self.smn
	clone.punishable = self.punishable
	clone.after = self.after
	clone.actions = self.actions:clone()
	clone.hitbox = self.hitbox
	clone.umoa = self.umoa
	clone.srpn = self.srpn
	clone.smod = self.smod
	clone.aatk = self.aatk
	clone.fhb = self.fhb
	clone.ndfb = self.ndfb
	clone.hso = self.hso
	clone.nvfb = self.nvfb
	clone.bfht = self.bfht
	clone.rpue = self.rpue
	clone._rsd = self._rsd
	clone._rpd = self._rpd
	clone.nbfb = self.nbfb

	return clone
end

---Return a serializable table.
---@return table
function Timing:serialize()
	return {
		name = self.name,
		tag = self.tag,
		imdd = self.imdd,
		imxd = self.imxd,
		duih = self.duih,
		punishable = self.punishable,
		smn = self.smn,
		after = self.after,
		actions = self.actions:serialize(),
		hitbox = {
			X = self.hitbox.X,
			Y = self.hitbox.Y,
			Z = self.hitbox.Z,
		},
		srpn = self.srpn,
		umoa = self.umoa,
		smod = self.smod,
		aatk = self.aatk,
		fhb = self.fhb,
		ndfb = self.ndfb,
		phd = self.phd,
		pfh = self.pfh,
		hso = self.hso,
		nvfb = self.nvfb,
		bfht = self.bfht,
		rpue = self.rpue,
		rsd = self._rsd,
		rpd = self._rpd,
		nbfb = self.nbfb,
	}
end

---Create new Timing object.
---@param values table?
---@return Timing
function Timing.new(values)
	local self = setmetatable({}, Timing)

	self.tag = "Undefined"
	self.name = "N/A"
	self.imdd = 0
	self.imxd = 0
	self.smn = false
	self.punishable = 0
	self.after = 0
	self.rpue = false
	self._rsd = 0
	self._rpd = 0
	self.duih = false
	self.actions = ActionContainer.new()
	self.hitbox = Vector3.zero
	self.umoa = false
	self.srpn = false
	self.smod = "N/A"
	self.aatk = false
	self.fhb = true
	self.ndfb = false
	self.hso = 0
	self.nvfb = false
	self.bfht = 0.3
	self.nbfb = false

	if values then
		self:load(values)
	end

	return self
end

-- Return Timing module.
return Timing

end)
__bundle_register("Game/Timings/ActionContainer", function(require, _LOADED, __bundle_register, __bundle_modules)
---@module Game.Timings.Action
local Action = require("Game/Timings/Action")

---@class ActionContainer
---@field _data table<string, Action>
local ActionContainer = {}
ActionContainer.__index = ActionContainer

---Clone action container.
---@return ActionContainer
function ActionContainer:clone()
	local clone = ActionContainer.new()

	for _, action in next, self._data do
		clone:push(action:clone())
	end

	return clone
end

---Equal check.
---@param other ActionContainer
---@return boolean
function ActionContainer:equals(other)
	if self:count() ~= other:count() then
		return false
	end

	for name, action in next, self._data do
		local otherAction = other:find(name)
		if not otherAction then
			return false
		end

		if not action:equals(otherAction) then
			return false
		end
	end

	return true
end

---Find a action from name.
---@param name string
---@return Action?
function ActionContainer:find(name)
	return self._data[name]
end

---Remove a action from the list.
---@param action Action
function ActionContainer:remove(action)
	self._data[action.name] = nil

	local idx = table.find(self._stack, action)
	if not idx then
		return
	end

	table.remove(self._stack, idx)
end

---Push a action to the list.
---@param action Action
function ActionContainer:push(action)
	local name = action.name

	---@note: Action array keys must all be unique.
	if self._data[name] then
		return error(string.format("Action name '%s' already exists in container.", name))
	end

	self._data[name] = action

	table.insert(self._stack, action)
end

---Load from partial values.
---@param values table
function ActionContainer:load(values)
	for _, data in next, values do
		self:push(Action.new(data))
	end
end

---List all action names.
---@return string[]
function ActionContainer:names()
	local names = {}

	for name, _ in next, self._data do
		table.insert(names, name)
	end

	return names
end

---Get action stack.
---@return Action[]
function ActionContainer:stack()
	return self._stack
end

---Get action count.
---@return number
function ActionContainer:count()
	return #self._stack
end

---Clear actions.
function ActionContainer:clear()
	self._data = {}
	self._stack = {}
end

---Get action data.
---@return table<string, Action>
function ActionContainer:get()
	return self._data
end

---Return a serializable table.
---@return table
function ActionContainer:serialize()
	local data = {}

	for _, action in next, self._data do
		table.insert(data, action:serialize())
	end

	return data
end

---Create new ActionContainer object.
---@param values table?
---@return ActionContainer
function ActionContainer.new(values)
	local self = setmetatable({}, ActionContainer)

	self._data = {}
	self._stack = {}

	if values then
		self:load(values)
	end

	return self
end

-- Return ActionContainer module.
return ActionContainer

end)
__bundle_register("Game/Timings/Action", function(require, _LOADED, __bundle_register, __bundle_modules)
---@class Action
---@field _type string
---@field _when number When the action will occur in miliseconds. Never access directly.
---@field hitbox Vector3 The hitbox of the action.
---@field ihbc boolean Ignore hitbox check.
---@field name string The name of the action.
---@field tp number Time position. Never accessible unless inside of a module or inside of real code. This is never serialized.
local Action = {}
Action.__index = Action

---Getter for when in seconds.
---@return number
function Action:when()
	return PP_SCRAMBLE_NUM(self._when) / 1000
end

---Load from partial values.
---@param values table
function Action:load(values)
	if typeof(values._type) == "string" then
		self._type = values._type
	end

	if typeof(values.when) == "number" then
		self._when = values.when
	end

	if typeof(values.name) == "string" then
		self.name = values.name
	end

	if typeof(values.hitbox) == "table" then
		self.hitbox = Vector3.new(values.hitbox.X, values.hitbox.Y, values.hitbox.Z)
	end

	if typeof(values.ihbc) == "boolean" then
		self.ihbc = values.ihbc
	end
end

---Equals check.
---@param other Action
---@return boolean
function Action:equals(other)
	if self._type ~= other._type then
		return false
	end

	if self._when ~= other._when then
		return false
	end

	if self.name ~= other.name then
		return false
	end

	if self.hitbox ~= other.hitbox then
		return false
	end

	if self.ihbc ~= other.ihbc then
		return false
	end

	return true
end

---Clone action.
---@return Action
function Action:clone()
	local clone = Action.new()

	clone._type = self._type
	clone._when = self._when
	clone.name = self.name
	clone.hitbox = self.hitbox
	clone.ihbc = self.ihbc

	return clone
end

---Return a serializable table.
---@return table
function Action:serialize()
	return {
		_type = self._type,
		when = self._when,
		name = self.name,
		hitbox = {
			X = self.hitbox.X,
			Y = self.hitbox.Y,
			Z = self.hitbox.Z,
		},
		ihbc = self.ihbc,
	}
end

---Create new Action object.
---@param values table?
---@return Action
function Action.new(values)
	local self = setmetatable({}, Action)

	self._type = "N/A"
	self._when = 0
	self.name = ""
	self.hitbox = Vector3.zero
	self.ihbc = false
	self.tp = 0

	if values then
		self:load(values)
	end

	return self
end

-- Return Action module.
return Action

end)
__bundle_register("Game/Timings/PartTiming", function(require, _LOADED, __bundle_register, __bundle_modules)
---@module Game.Timings.Timing
local Timing = require("Game/Timings/Timing")

---@class PartTiming: Timing
---@field pname string Part name.
---@field uhc boolean Use hitbox CFrame.
local PartTiming = setmetatable({}, { __index = Timing })
PartTiming.__index = PartTiming

---Timing ID.
---@return string
function PartTiming:id()
	return self.pname
end

---Load from partial values.
---@param values table
function PartTiming:load(values)
	Timing.load(self, values)

	if typeof(values.pname) == "string" then
		self.pname = values.pname
	end

	if typeof(values.uhc) == "boolean" then
		self.uhc = values.uhc
	end
end

---Equals check.
---@param other PartTiming
---@return boolean
function PartTiming:equals(other)
	if not Timing.equals(self, other) then
		return false
	end

	if self.pname ~= other.pname then
		return false
	end

	if self.uhc ~= other.uhc then
		return false
	end

	return true
end

---Clone timing.
---@return PartTiming
function PartTiming:clone()
	local clone = setmetatable(Timing.clone(self), PartTiming)

	clone.pname = self.pname
	clone.uhc = self.uhc

	return clone
end

---Return a serializable table.
---@return PartTiming
function PartTiming:serialize()
	local serializable = Timing.serialize(self)

	serializable.pname = self.pname
	serializable.uhc = self.uhc

	return serializable
end

---Create a new part timing.
---@param values table?
---@return PartTiming
function PartTiming.new(values)
	local self = setmetatable(Timing.new(), PartTiming)

	self.pname = ""
	self.uhc = false

	if values then
		self:load(values)
	end

	return self
end

-- Return PartTiming module.
return PartTiming

end)
__bundle_register("Game/Timings/EffectTiming", function(require, _LOADED, __bundle_register, __bundle_modules)
---@module Game.Timings.Timing
local Timing = require("Game/Timings/Timing")

---@class EffectTiming: Timing
---@field ename string Effect name.
---@field ilp boolean Ignore local player.
---@field flp boolean Force local player.
local EffectTiming = setmetatable({}, { __index = Timing })
EffectTiming.__index = EffectTiming

---Timing ID.
---@return string
function EffectTiming:id()
	return self.ename
end

---Equals check.
---@param other EffectTiming
---@return boolean
function EffectTiming:equals(other)
	if not Timing.equals(self, other) then
		return false
	end

	if self.ename ~= other.ename then
		return false
	end

	if self.ilp ~= other.ilp then
		return false
	end

	if self.flp ~= other.flp then
		return false
	end

	return true
end

---Load from partial values.
---@param values table
function EffectTiming:load(values)
	Timing.load(self, values)

	if typeof(values.ename) == "string" then
		self.ename = values.ename
	end

	if typeof(values.ilp) == "boolean" then
		self.ilp = values.ilp
	end

	if typeof(values.flp) == "boolean" then
		self.flp = values.flp
	end
end

---Clone timing.
---@return EffectTiming
function EffectTiming:clone()
	local clone = setmetatable(Timing.clone(self), EffectTiming)

	clone.ename = self.ename
	clone._rpd = self._rpd
	clone._rsd = self._rsd
	clone.rpue = self.rpue
	clone.ilp = self.ilp
	clone.flp = self.flp

	return clone
end

---Return a serializable table.
---@return EffectTiming
function EffectTiming:serialize()
	local serializable = Timing.serialize(self)

	serializable.ename = self.ename
	serializable.ilp = self.ilp
	serializable.flp = self.flp

	return serializable
end

---Create a new effect timing.
---@param values table?
---@return EffectTiming
function EffectTiming.new(values)
	local self = setmetatable(Timing.new(), EffectTiming)

	self.ename = ""
	self.ilp = false
	self.flp = false

	if values then
		self:load(values)
	end

	return self
end

-- Return EffectTiming module.
return EffectTiming

end)
__bundle_register("Game/Timings/AnimationTiming", function(require, _LOADED, __bundle_register, __bundle_modules)
---@module Game.Timings.Timing
local Timing = require("Game/Timings/Timing")

---@class AnimationTiming: Timing
---@field id string Animation ID.
---@field ha boolean Flag to see whether or not this timing can be cancelled by a hit.
---@field iae boolean Flag to see whether or not this timing should ignore animation end.
---@field phd boolean Past hitbox detection.
---@field pfh boolean Predict hitboxes facing.
---@field phds number History seconds for past hitbox detection.
---@field pfht number Extrapolation time for hitbox prediction.
---@field ieae boolean Flag to see whether or not this timing should ignore early animation end.
---@field mat number Max animation timeout in milliseconds.
---@field dp boolean Disable prediction.
---@field imb boolean Ignore megalodaunt block. Hidden option.
---@field ffh boolean Flag to see whether or not this timing should force facing hitbox to the user, no matter what. Hidden option.
local AnimationTiming = setmetatable({}, { __index = Timing })
AnimationTiming.__index = AnimationTiming

---Timing ID.
---@return string
function AnimationTiming:id()
	return self._id
end

---Equals check.
---@param other AnimationTiming
function AnimationTiming:equals(other)
	if not Timing.equals(self, other) then
		return false
	end

	if self.ha ~= other.ha then
		return false
	end

	if self.iae ~= other.iae then
		return false
	end

	if self.ieae ~= other.ieae then
		return false
	end

	if self.mat ~= other.mat then
		return false
	end

	if self.phd ~= other.phd then
		return false
	end

	if self.pfh ~= other.pfh then
		return false
	end

	if self.phds ~= other.phds then
		return false
	end

	if self.pfht ~= other.pfht then
		return false
	end

	if self.dp ~= other.dp then
		return false
	end

	if self.imb ~= other.imb then
		return false
	end

	return true
end

---Load from partial values.
---@param values table
function AnimationTiming:load(values)
	Timing.load(self, values)

	if typeof(values._id) == "string" then
		self._id = values._id
	end

	if typeof(values.ha) == "boolean" then
		self.ha = values.ha
	end

	if typeof(values.iae) == "boolean" then
		self.iae = values.iae
	end

	if typeof(values.ieae) == "boolean" then
		self.ieae = values.ieae
	end

	if typeof(values.mat) == "number" then
		self.mat = values.mat
	end

	if typeof(values.phd) == "boolean" then
		self.phd = values.phd
	end

	if typeof(values.pfh) == "boolean" then
		self.pfh = values.pfh
	end

	if typeof(values.phds) == "number" then
		self.phds = values.phds
	end

	if typeof(values.pfht) == "number" then
		self.pfht = values.pfht
	end

	if typeof(values.dp) == "boolean" then
		self.dp = values.dp
	end

	if typeof(values.imb) == "boolean" then
		self.imb = values.imb
	end
end

---Clone timing.
---@return AnimationTiming
function AnimationTiming:clone()
	local clone = setmetatable(Timing.clone(self), AnimationTiming)

	clone._id = self._id
	clone.ha = self.ha
	clone.iae = self.iae
	clone.ieae = self.ieae
	clone.mat = self.mat
	clone.phd = self.phd
	clone.pfh = self.pfh
	clone.phds = self.phds
	clone.pfht = self.pfht
	clone.dp = self.dp
	clone.imb = self.imb

	return clone
end

---Return a serializable table.
---@return AnimationTiming
function AnimationTiming:serialize()
	local serializable = Timing.serialize(self)

	serializable._id = self._id
	serializable.ha = self.ha
	serializable.iae = self.iae
	serializable.ieae = self.ieae
	serializable.mat = self.mat
	serializable.phd = self.phd
	serializable.pfh = self.pfh
	serializable.phds = self.phds
	serializable.pfht = self.pfht
	serializable.dp = self.dp
	serializable.imb = self.imb

	return serializable
end

---Create a new animation timing.
---@param values table?
---@return AnimationTiming
function AnimationTiming.new(values)
	local self = setmetatable(Timing.new(), AnimationTiming)

	self.dp = false
	self._id = ""
	self.ha = false
	self.iae = false
	self.ieae = false
	self.mat = 2000
	self.phd = false
	self.pfh = false
	self.phds = 0
	self.pfht = 0.15
	self.imb = false

	if values then
		self:load(values)
	end

	return self
end

-- Return AnimationTiming module.
return AnimationTiming

end)
__bundle_register("Game/Timings/TimingContainer", function(require, _LOADED, __bundle_register, __bundle_modules)
---@class TimingContainer
---@field timings table<string, Timing>
---@field module Timing
local TimingContainer = {}
TimingContainer.__index = TimingContainer

---Find a timing from name.
---@param name string
---@return Timing?
function TimingContainer:find(name)
	for _, timing in next, self.timings do
		if timing.name ~= name then
			continue
		end

		return timing
	end
end

---List all timings.
---@return Timing[]
function TimingContainer:list()
	local timings = {}

	for _, timing in next, self.timings do
		timings[#timings + 1] = timing
	end

	return timings
end

---Get names of all timings.
---@return string[]
function TimingContainer:names()
	local names = {}

	for _, timing in next, self.timings do
		names[#names + 1] = timing.name
	end

	table.sort(names)

	return names
end

---Remove a timing from the list.
---@param timing Timing
function TimingContainer:remove(timing)
	local id = timing:id()
	if not id then
		return
	end

	self.timings[id] = nil
end

---Equals check.
---@param other TimingContainer
---@return boolean
function TimingContainer:equals(other)
	if self:count() ~= other:count() then
		return false
	end

	for id, timing in next, self.timings do
		local otherTiming = other.timings[id]
		if not otherTiming then
			return false
		end

		if not timing:equals(otherTiming) then
			return false
		end
	end

	return true
end

---Clone timing container.
---@return TimingContainer
function TimingContainer:clone()
	local container = TimingContainer.new(self.module)

	for _, timing in next, self.timings do
		container:push(timing:clone())
	end

	return container
end

---Push a timing to the list.
---@param timing Timing
function TimingContainer:push(timing)
	local id = timing:id()
	if not id then
		return
	end

	---@note: Timing array keys must all be unique.
	if self.timings[id] then
		return error(string.format("Timing identifier '%s' already exists in container.", id))
	end

	---@note: Every timing must have unique names.
	if self:find(timing.name) then
		return error(string.format("Timing name '%s' already exists in container.", timing.name))
	end

	self.timings[id] = timing
end

---Clear all timings.
function TimingContainer:clear()
	self.timings = {}
end

---Get timing count.
---@return number
function TimingContainer:count()
	local count = 0

	for _ in next, self.timings do
		count = count + 1
	end

	return count
end

---Load from partial values.
---@param values table
function TimingContainer:load(values)
	for _, value in next, values do
		local timing = self.module.new(value)
		if not timing then
			continue
		end

		local id = timing:id()
		if not id then
			continue
		end

		---@note: Timing array keys must all be unique.
		if self.timings[id] then
			return error(string.format("Timing identifier '%s' already exists in container.", id))
		end

		---@note: Every timing must have unique names.
		if self:find(timing.name) then
			return error(string.format("Timing name '%s' already exists in container.", timing.name))
		end

		---@note: Why are the stored timing keys different from what's loaded?
		--- Internally, all timings are stored by their identifiers.
		--- This helps to quickly find a timing by its identifier. Example - an animation ID.
		--- Although, this does not mean each identifier must have a meaning. It can be random.

		self.timings[id] = timing
	end
end

---Return a serializable table.
---@return table
function TimingContainer:serialize()
	local out = {}

	for _, timing in next, self.timings do
		out[#out + 1] = timing:serialize()
	end

	return out
end

---Create new TimingContainer object.
---@param module Timing
---@return TimingContainer
function TimingContainer.new(module)
	local self = setmetatable({}, TimingContainer)
	self.timings = {}
	self.module = module
	return self
end

-- Return TimingContainer module.
return TimingContainer

end)
__bundle_register("Game/Timings/TimingContainerPair", function(require, _LOADED, __bundle_register, __bundle_modules)
---@class TimingContainerPair
---@note The configs are always prioritized over the internal timings.
---@field internal TimingContainer
---@field config TimingContainer
local TimingContainerPair = {}
TimingContainerPair.__index = TimingContainerPair

---Create new TimingContainerPair object.
---@param internal TimingContainer
---@param config TimingContainer
---@return TimingContainerPair
function TimingContainerPair.new(internal, config)
	local self = setmetatable({}, TimingContainerPair)
	self.internal = internal
	self.config = config
	return self
end

---Index timing container.
---@param key any?
---@return Timing?
function TimingContainerPair:index(key)
	key = PP_SCRAMBLE_STR(key)
	return self.config.timings[key] or self.internal.timings[key]
end

---Find timing from name.
---@param name string
---@return Timing?
function TimingContainerPair:find(name)
	return self.config:find(name) or self.internal:find(name)
end

---List all timings.
---@return Timing[]
function TimingContainerPair:list()
	local timings = {}

	for _, timing in next, self.config:list() do
		table.insert(timings, timing)
	end

	for _, timing in next, self.internal:list() do
		table.insert(timings, timing)
	end

	return timings
end

-- Return TimingContainerStack module.
return TimingContainerPair

end)
__bundle_register("Game/Timings/TimingSave", function(require, _LOADED, __bundle_register, __bundle_modules)
---@module Game.Timings.TimingContainer
local TimingContainer = require("Game/Timings/TimingContainer")

---@module Game.Timings.AnimationTiming
local AnimationTiming = require("Game/Timings/AnimationTiming")

---@module Game.Timings.EffectTiming
local EffectTiming = require("Game/Timings/EffectTiming")

---@module Game.Timings.PartTiming
local PartTiming = require("Game/Timings/PartTiming")

---@module Game.Timings.SoundTiming
local SoundTiming = require("Game/Timings/SoundTiming")

---@class TimingSave
---@field _data TimingContainer[]
---@field _removals table<string, string[]> For every container, a list of timing IDs that we need to remove from the internal data.
local TimingSave = {}
TimingSave.__index = TimingSave

---Timing save version constant.
---@note: Increment me when the data structure changes and we need to add backwards compatibility.
local TIMING_SAVE_VERSION = 1

---Get timing save.
---@return TimingContainer[]
function TimingSave:get()
	return self._data
end

---Clear timing containers.
function TimingSave:clear()
	for _, container in next, self._data do
		container:clear()
	end
end

---Load from partial values.
---@param values table
function TimingSave:load(values)
	local data = self._data

	if typeof(values.animation) == "table" then
		data.animation:load(values.animation)
	end

	if typeof(values.effect) == "table" then
		data.effect:load(values.effect)
	end

	if typeof(values.part) == "table" then
		data.part:load(values.part)
	end

	if typeof(values.sound) == "table" then
		data.sound:load(values.sound)
	end
end

---Clone timing save.
---@return TimingSave
function TimingSave:clone()
	local save = TimingSave.new()

	for idx, container in next, self._data do
		save._data[idx] = container:clone()
	end

	return save
end

---Equal timing saves.
---@param other TimingSave
---@return boolean
function TimingSave:equals(other)
	if not other or typeof(other) ~= "table" then
		return false
	end

	for idx, container in next, self._data do
		local otherContainer = other._data[idx]
		if not otherContainer then
			return false
		end

		if not container:equals(otherContainer) then
			return false
		end
	end

	return true
end

---Get timing save count.
---@return number
function TimingSave:count()
	local count = 0

	for _, container in next, self._data do
		count = count + container:count()
	end

	return count
end

---Return a serializable table.
---@return table
function TimingSave:serialize()
	local data = self._data

	return {
		version = TIMING_SAVE_VERSION,
		animation = data.animation:serialize(),
		effect = data.effect:serialize(),
		part = data.part:serialize(),
		sound = data.sound:serialize(),
	}
end

---Create new TimingSave object.
---@param values table?
---@return TimingSave
function TimingSave.new(values)
	local self = setmetatable({}, TimingSave)

	self._data = {
		animation = TimingContainer.new(AnimationTiming),
		effect = TimingContainer.new(EffectTiming),
		part = TimingContainer.new(PartTiming),
		sound = TimingContainer.new(SoundTiming),
	}

	if values then
		self:load(values)
	end

	return self
end

-- Return TimingSave module.
return TimingSave

end)
__bundle_register("Features/Combat/Objects/EffectDefender", function(require, _LOADED, __bundle_register, __bundle_modules)
---@module Features.Combat.Objects.Defender
local Defender = require("Features/Combat/Objects/Defender")

---@module Game.Timings.SaveManager
local SaveManager = require("Game/Timings/SaveManager")

---@module Features.Combat.Objects.RepeatInfo
local RepeatInfo = require("Features/Combat/Objects/RepeatInfo")

---@module Features.Combat.Objects.HitboxOptions
local HitboxOptions = require("Features/Combat/Objects/HitboxOptions")

---@module Utility.Configuration
local Configuration = require("Utility/Configuration")

---@module Utility.Logger
local Logger = require("Utility/Logger")

---@module Game.Latency
local Latency = require("Game/Latency")

---@class EffectDefender: Defender
---@field name string The name of the effect.
---@field data table The data of the effect.
local EffectDefender = setmetatable({}, { __index = Defender })
EffectDefender.__index = EffectDefender
EffectDefender.__type = "Effect"

-- Services.
local players = game:GetService("Players")

---Iteratively find effect owner from effect data.
---@param data table
---@return Model?
local findEffectOwner = LPH_NO_VIRTUALIZE(function(data)
	local live = workspace:FindFirstChild("Live")
	if not live then
		return
	end

	for _, value in next, data do
		if typeof(value) ~= "Instance" or value.Parent ~= live then
			continue
		end

		return value
	end
end)

---Check if we're in a valid state to proceed with the action.
---@param self EffectDefender
---@param options ValidationOptions
---@return boolean
EffectDefender.valid = LPH_NO_VIRTUALIZE(function(self, options)
	if not Defender.valid(self, options) then
		return false
	end

	local function internalNotifyFunction(timing, message)
		if not options.notify then
			return
		end

		return self:notify(timing, message)
	end

	local timing = options.timing
	local action = options.action

	local humanoidRootPart = self.owner:FindFirstChild("HumanoidRootPart")
	if not humanoidRootPart then
		return internalNotifyFunction(timing, "No humanoid root part found.")
	end

	local character = players.LocalPlayer.Character
	if not character then
		return internalNotifyFunction(timing, "No character found.")
	end

	if self.owner ~= players.LocalPlayer.Character then
		if not self:target(self.owner) then
			return internalNotifyFunction(timing, "Not a viable target.")
		end

		local hoptions = HitboxOptions.new(humanoidRootPart, timing)
		hoptions.spredict = false
		hoptions.action = action
		hoptions:ucache()

		if not self:hc(hoptions, timing.duih and RepeatInfo.new(timing) or nil) then
			return self:notify(timing, "Not in hitbox.")
		end
	end

	return true
end)

---Process effect.
---@param self EffectDefender
EffectDefender.process = LPH_NO_VIRTUALIZE(function(self)
	if not self.owner then
		return
	end

	if not Configuration.expectToggleValue("EnableAutoDefense") then
		return
	end

	---@type EffectTiming?
	local timing = self:initial(self.owner, SaveManager.es, self.owner.Name, self.name)
	if not timing then
		return
	end

	if timing.flp and self.owner ~= players.LocalPlayer.Character then
		return Logger.warn(
			"EffectDefender.process - Effect '%s' is not on local player (%s) is being ignored.",
			self.name,
			tostring(self.owner)
		)
	end

	if timing.ilp and self.owner == players.LocalPlayer.Character then
		return
	end

	---@note: Clean up previous tasks that are still waiting or suspended because they're in a different track.
	self:clean()

	-- Handle module.
	if timing.umoa then
		return self:module(timing)
	end

	---@note: Start processing the timing. Add the actions if we're not RPUE.
	if not timing.rpue then
		return self:actions(timing)
	end

	-- Start RPUE.
	local info = RepeatInfo.new(timing, Latency.rdelay(), self:uid(10))
	self:srpue(self.entity, timing, info)
end)

---Create new EffectDefender object.
---@param name string
---@param data table
---@param dao table
---@return EffectDefender
function EffectDefender.new(name, data, dao)
	local self = setmetatable(Defender.new(), EffectDefender)
	self.name = name
	self.data = data or {}
	self.owner = findEffectOwner(data)
	self:process()
	return self
end

-- Return EffectDefender module.
return EffectDefender

end)
__bundle_register("Features/Combat/Objects/HitboxOptions", function(require, _LOADED, __bundle_register, __bundle_modules)
---@class HitboxOptions
---@note: Options for the hitbox check.
---@field part BasePart? If this is specified and it exists, it will be used for the position.
---@field cframe CFrame? Else, the part's CFrame will be used.
---@field timing Timing|AnimationTiming|SoundTiming
---@field action Action?
---@field cache Vector3 Cached hitbox size.
---@field filter Instance[]
---@field spredict boolean If true, a check will run for predicted positions.
---@field ptime number? The predicted time in seconds for extrapolation.
---@field entity Model? The entity for extrapolation.
---@field phcolor Color3 The color for predicted hitboxes.
---@field pmcolor Color3 The color for predicted missed hitboxes.
---@field hcolor Color3 The color for hitboxes.
---@field mcolor Color3 The color for missed hitboxes.
---@field hmid number? Hitbox visualization ID for normal hitbox check.
---@field visualize boolean Whether to visualize the hitbox.
local HitboxOptions = {}
HitboxOptions.__index = HitboxOptions

-- Services.
local players = game:GetService("Players")

---Hit color.
---@return Color3
HitboxOptions.ghcolor = LPH_NO_VIRTUALIZE(function(self, result)
	return result and self.hcolor or self.mcolor
end)

---Predicted hit color.
---@return Color3
HitboxOptions.gphcolor = LPH_NO_VIRTUALIZE(function(self, result)
	return result and self.phcolor or self.pmcolor
end)

---Cloned hitbox options.
---@return HitboxOptions
HitboxOptions.clone = LPH_NO_VIRTUALIZE(function(self)
	local options = setmetatable({}, HitboxOptions)
	options.action = self.action
	options.spredict = self.spredict
	options.entity = self.entity
	options.ptime = self.ptime
	options.entity = self.entity
	options.phcolor = self.phcolor
	options.pmcolor = self.pmcolor
	options.hcolor = self.hcolor
	options.mcolor = self.mcolor
	options.hmid = self.hmid
	options.filter = self.filter
	options.part = self.part
	options.cframe = self.cframe
	options.timing = self.timing
	options.visualize = self.visualize
	return options
end)

---Update cache.
HitboxOptions.ucache = LPH_NO_VIRTUALIZE(function(self)
	if not self.timing then
		return error("HitboxOptions:update - no timing specified")
	end

	local hitbox = self.action and self.action.hitbox or self.timing.hitbox

	if self.timing.duih then
		hitbox = self.timing.hitbox
	end

	if not hitbox then
		self.cache = Vector3.new(0, 0, 0)
	else
		self.cache = Vector3.new(PP_SCRAMBLE_NUM(hitbox.X), PP_SCRAMBLE_NUM(hitbox.Y), PP_SCRAMBLE_NUM(hitbox.Z))
	end
end)

---Get the hitbox size.
---@return Vector3
HitboxOptions.hitbox = LPH_NO_VIRTUALIZE(function(self)
	if not self.cache then
		self:ucache()
	end

	return self.cache
end)

---Get extrapolated position.
---@return CFrame
HitboxOptions.extrapolate = LPH_NO_VIRTUALIZE(function(self)
	if not self.part then
		return error("HitboxOptions.extrapolate - unimplemented for CFrame")
	end

	if not self.ptime then
		return error("HitboxOptions.extrapolate - no predicted time specified")
	end

	-- Return the extrapolated position.
	return self.part.CFrame + (self.part.AssemblyLinearVelocity * self.ptime)
end)

---Get position.
---@return CFrame
HitboxOptions.pos = LPH_NO_VIRTUALIZE(function(self)
	if self.cframe then
		return self.cframe
	end

	if self.part then
		return self.part.CFrame
	end

	return error("HitboxOptions.pos - impossible condition")
end)

---Create new HitboxOptions object.
---@param target Instance|CFrame
---@param timing Timing|AnimationTiming|SoundTiming
---@param filter Instance[]?
---@return HitboxOptions
HitboxOptions.new = LPH_NO_VIRTUALIZE(function(target, timing, filter)
	local self = setmetatable({}, HitboxOptions)
	self.part = typeof(target) == "Instance" and target:IsA("BasePart") and target
	self.cframe = typeof(target) == "CFrame" and target
	self.timing = timing
	self.action = nil
	self.filter = filter or {}
	self.cache = Vector3.zero
	self.spredict = false
	self.hmid = nil
	self.entity = nil
	self.phcolor = Color3.new(1, 0, 1)
	self.pmcolor = Color3.new(0.349019, 0.345098, 0.345098)
	self.hcolor = Color3.new(0, 1, 0)
	self.mcolor = Color3.new(1, 0, 0)
	self.ptime = nil
	self.visualize = true

	if not self.part and not self.cframe or not self.timing then
		return error("HitboxOptions: No part or CFrame or timing specified.")
	end

	self:ucache()

	if filter then
		return self
	end

	local character = players.LocalPlayer.Character
	if not character then
		return self
	end

	self.filter = { character }

	return self
end)

-- Return HitboxOptions module.
return HitboxOptions

end)
__bundle_register("Features/Combat/Objects/RepeatInfo", function(require, _LOADED, __bundle_register, __bundle_modules)
---@note: Typed object that represents information. It's not really a true class but just needs to store the correct data.
---@class RepeatInfo
---@field track AnimationTrack?
---@field timing Timing
---@field start number
---@field index number
---@field irdelay number Initial receive delay.
---@field hmid number Hitbox visualization ID for repeat hitbox check.
local RepeatInfo = {}
RepeatInfo.__index = RepeatInfo

---Create new RepeatInfo object.
---@param timing Timing
---@param irdelay number
---@param hmid number
---@return RepeatInfo
RepeatInfo.new = LPH_NO_VIRTUALIZE(function(timing, irdelay, hmid)
	local self = setmetatable({}, RepeatInfo)
	self.track = nil
	self.timing = timing
	self.start = os.clock()
	self.index = 0
	self.irdelay = irdelay
	self.hmid = hmid
	return self
end)

-- Return RepeatInfo module.
return RepeatInfo

end)
__bundle_register("Features/Combat/Objects/Defender", function(require, _LOADED, __bundle_register, __bundle_modules)
---@module Utility.Logger
local Logger = require("Utility/Logger")

---@module Utility.Configuration
local Configuration = require("Utility/Configuration")

---@module Game.InputClient
local InputClient = require("Game/InputClient")

---@module Features.Combat.Objects.Task
local Task = require("Features/Combat/Objects/Task")

---@module Game.QueuedBlocking
local QueuedBlocking = require("Game/QueuedBlocking")

---@module Game.KeyHandling
local KeyHandling = require("Game/KeyHandling")

---@module Utility.Maid
local Maid = require("Utility/Maid")

---@module Game.Timings.ModuleManager
local ModuleManager = require("Game/Timings/ModuleManager")

---@module Utility.TaskSpawner
local TaskSpawner = require("Utility/TaskSpawner")

---@module Features.Combat.Targeting
local Targeting = require("Features/Combat/Targeting")

---@module Features.Combat.Objects.ValidationOptions
local ValidationOptions = require("Features/Combat/Objects/ValidationOptions")

---@module Features.Combat.EntityHistory
local EntityHistory = require("Features/Combat/EntityHistory")

---@module Features.Combat.Objects.HitboxOptions
local HitboxOptions = require("Features/Combat/Objects/HitboxOptions")

---@module Utility.OriginalStore
local OriginalStore = require("Utility/OriginalStore")

---@module Features.Combat.StateListener
local StateListener = require("Features/Combat/StateListener")

---@module Utility.Finder
local Finder = require("Utility/Finder")

---@module Game.Latency
local Latency = require("Game/Latency")

---@module GUI.Library
local Library = require("GUI/Library")

---@class Defender
---@field tasks Task[]
---@field tmaid Maid Cleaned up every clean cycle.
---@field rhook table<string, function> Hooked functions that we can restore on clean-up.
---@field markers table<string, boolean> Blocking markers for unknown length timings. If the entry exists and is true, then we're blocking.
---@field maid Maid
---@field hmaid Maid Maid for hitbox visualizations.
---@field uids number Unique ID counter for hitbox visualizations.
---@field afeinted boolean Whether if we have auto-feinted this defense cycle.
---@field ifeinted boolean Whether if we have initial auto-feinted this defense cycle.
local Defender = {}
Defender.__index = Defender
Defender.__type = "Defender"

-- Services.
local replicatedStorage = game:GetService("ReplicatedStorage")
local userInputService = game:GetService("UserInputService")
local players = game:GetService("Players")
local textChatService = game:GetService("TextChatService")
local debrisService = game:GetService("Debris")

-- Constants.
local MAX_VISUALIZATION_TIME = 5.0
local MAX_REPEAT_WAIT = 10.0
local PREDICTION_LENIENCY_MULTI = 10.0

---@module Game.Objects.DodgeOptions
local DodgeOptions = require("Game/Objects/DodgeOptions")

---Log a miss to the UI library with distance check.
---@param type string
---@param key string
---@param name string?
---@param distance number
---@param parent string? If provided, will be shown in the log.
---@return boolean
function Defender:miss(type, key, name, distance, parent)
	if not Configuration.expectToggleValue("ShowLoggerWindow") then
		return false
	end

	if
		distance < (Configuration.expectOptionValue("MinimumLoggerDistance") or 0)
		or distance > (Configuration.expectOptionValue("MaximumLoggerDistance") or 0)
	then
		return false
	end

	Library:AddMissEntry(type, key, name, distance, parent)

	return true
end

---Fetch distance.
---@param from Model? | BasePart?
---@return number?
Defender.distance = LPH_NO_VIRTUALIZE(function(_, from)
	if not from then
		return
	end

	local entRootPart = from

	if from:IsA("Model") then
		entRootPart = from:FindFirstChild("HumanoidRootPart")
	end

	if not entRootPart then
		return
	end

	local localCharacter = players.LocalPlayer.Character
	if not localCharacter then
		return
	end

	local localRootPart = localCharacter:FindFirstChild("HumanoidRootPart")
	if not localRootPart then
		return
	end

	return (entRootPart.Position - localRootPart.Position).Magnitude
end)

---Find target - hookable function.
---@param self Defender
---@param entity Model
---@return Target?
Defender.target = LPH_NO_VIRTUALIZE(function(self, entity)
	return Targeting.find(entity)
end)

---Get extrapolated seconds.
---@param self Defender
---@param timing AnimationTiming
---@return number
Defender.fsecs = LPH_NO_VIRTUALIZE(function(self, timing)
	local player = players:GetPlayerFromCharacter(self.entity)
	local sd = (player and player:GetAttribute("AveragePing") or 50.0) / 2000
	return (timing.pfht or 0.15) + (sd + Latency.rdelay())
end)

---Start repeat until parry end.
---@param self Defender
---@param ref Model|Part
---@param timing Timing
---@param info RepeatInfo
Defender.srpue = LPH_NO_VIRTUALIZE(function(self, ref, timing, info)
	if timing.umoa or timing.cbm then
		timing["_rpd"] = PP_SCRAMBLE_RE_NUM(timing["_rpd"])
		timing["_rsd"] = PP_SCRAMBLE_RE_NUM(timing["_rsd"])
		timing["imdd"] = PP_SCRAMBLE_RE_NUM(timing["imdd"])
		timing["imxd"] = PP_SCRAMBLE_RE_NUM(timing["imxd"])
	end

	local cache = {
		["name"] = PP_SCRAMBLE_STR(timing.name),
		["imdd"] = PP_SCRAMBLE_NUM(timing.imdd),
		["imxd"] = PP_SCRAMBLE_NUM(timing.imxd),
		["rsd"] = timing:rsd(),
		["rpd"] = timing:rpd(),
	}

	local target = self:target(ref)
	local part = target and target.root or CFrame.new()

	if ref:IsA("Part") then
		part = ref
	end

	local options = HitboxOptions.new(part, timing)
	options.spredict = not timing.duih
	options.ptime = self:fsecs(timing)
	options.entity = ref:IsA("Model") and target or nil
	options.hmid = info.hmid
	options:ucache()

	-- Start RPUE.
	self:mark(Task.new(string.format("RPUE_%s_%i", timing.name, 0), function()
		return cache["rsd"] - info.irdelay - Latency.sdelay()
	end, timing.punishable, timing.after, self.rpue, self, ref, timing, info, cache, options))

	-- Notify.
	if not LRM_UserNote or LRM_UserNote == "tester" then
		self:notify(
			timing,
			"Added RPUE '%s' (%.2fs, then every %.2fs) with ping '%.2f' (changing) subtracted.",
			cache["name"],
			cache["rsd"],
			cache["rpd"],
			Latency.rtt()
		)
	else
		self:notify(
			timing,
			"Added RPUE '%s' ([redacted], then every [redacted]) with ping '%.2f' (changing) subtracted.",
			cache["name"],
			Latency.rtt()
		)
	end
end)

---Repeat until parry end.
---@param self Defender
---@param ref Model|Part
---@param timing Timing
---@param info RepeatInfo
---@param cache table Cache table for RPUE to prevent unnecessary recalculations.
---@param options HitboxOptions
Defender.rpue = LPH_NO_VIRTUALIZE(function(self, ref, timing, info, cache, options)
	local distance = self:distance(ref)
	if not distance then
		return Logger.warn("Stopping RPUE '%s' because the distance is not valid.", cache.name)
	end

	if not self:rc(info) then
		return Logger.warn("Stopping RPUE '%s' because the repeat condition is not valid.", cache.name)
	end

	local target = ref:IsA("Model") and self:target(ref) or true
	local success = false
	local reasons = {}

	options.part = ref:IsA("Part") and ref or (target and target.root)
	options.cframe = not options.part and CFrame.new()

	if timing.duih and target then
		success = self:hc(options, info)
		reasons[#reasons + 1] = string.format("hitbox (%s)", tostring(options:hitbox()))
	end

	local within = (distance >= cache.imdd and distance <= cache.imxd)

	if timing then
		success = within
	end

	if not within then
		reasons[#reasons + 1] = string.format("distance range (%.2f < %.2f > %.2f)", cache.imdd, distance, cache.imxd)
	end

	info.index = info.index + 1

	self:mark(Task.new(string.format("RPUE_%s_%i", timing.name, info.index), function()
		return cache.rpd - info.irdelay - Latency.sdelay()
	end, timing.punishable, timing.after, self.rpue, self, ref, timing, info, cache, options))

	if not target then
		return Logger.warn("Skipping RPUE '%s' because the target is not valid.", cache.name)
	end

	if not success then
		return Logger.warn("Skipping RPUE '%s' (%s)", cache.name, #reasons > 1 and table.concat(reasons, ", ") or "N/A")
	end

	self:notify(timing, "Action type 'RPUE Parry' is being executed.")

	self:parry(timing, nil)
end)

---Check if we're in a valid state to proceed with action handling. Extend me.
---@param self Defender
---@param options ValidationOptions
---@return boolean
Defender.valid = LPH_NO_VIRTUALIZE(function(self, options)
	local integer = Random.new():NextNumber(1.0, 100.0)
	local rate = Configuration.expectOptionValue("FailureRate") or 0.0
	local timing = options.timing

	local function internalNotifyFunction(...)
		if not options.notify then
			return
		end

		return self:notify(...)
	end

	local overrideData = Library:GetOverrideData(PP_SCRAMBLE_STR(timing.name))

	if overrideData then
		rate = overrideData.fr
	end

	if (Configuration.expectToggleValue("AllowFailure") or overrideData) and integer <= rate then
		return internalNotifyFunction(timing, "(%i <= %i) Intentionally did not run.", integer, rate)
	end

	local selectedFilters = Configuration.expectOptionValue("AutoDefenseFilters") or {}

	if selectedFilters["Disable While Holding Block"] and StateListener.hblock() then
		return internalNotifyFunction(timing, "User is pressing down on a key binded to Block.")
	end

	local chatInputBarConfiguration = textChatService:FindFirstChildOfClass("ChatInputBarConfiguration")

	if
		selectedFilters["Disable When Textbox Focused"]
		and (userInputService:GetFocusedTextBox() or chatInputBarConfiguration.IsFocused)
	then
		return internalNotifyFunction(timing, "User is typing in a text box.")
	end

	if selectedFilters["Disable While Using Sightless Beam"] and StateListener.csb() then
		return internalNotifyFunction(timing, "User is using the 'Sightless Beam' move.")
	end

	if selectedFilters["Disable When Window Not Active"] and not iswindowactive() then
		return internalNotifyFunction(timing, "Window is not active.")
	end

	if selectedFilters["Disable During Chime Countdown"] and StateListener.ccd() then
		return internalNotifyFunction(timing, "Chime countdown is active.")
	end

	local effectReplicator = replicatedStorage:FindFirstChild("EffectReplicator")
	if not effectReplicator then
		return internalNotifyFunction(timing, "No effect replicator found.")
	end

	local effectReplicatorModule = require(effectReplicator)
	if not effectReplicatorModule then
		return internalNotifyFunction(timing, "No effect replicator module found.")
	end

	local actionType = options.action and options.action._type or "N/A"

	if
		not Configuration.expectToggleValue("BlatantRoll")
		or (actionType ~= PP_SCRAMBLE_STR("Dodge") and actionType ~= PP_SCRAMBLE_STR("Forced Full Dodge"))
	then
		if not self.afeinted and not options.sstun and StateListener.astun() then
			return internalNotifyFunction(timing, "User is in action stun.")
		end

		if effectReplicatorModule:FindEffect("Knocked") then
			return internalNotifyFunction(timing, "User is knocked.")
		end
	end

	if actionType == PP_SCRAMBLE_STR("Parry") then
		if effectReplicatorModule:FindEffect("AutoParry") and Configuration.expectToggleValue("UseAutoParryFrames") then
			return internalNotifyFunction(timing, "User has auto parry frames.")
		end
	end

	if timing.tag == "M1" and selectedFilters["Filter Out M1s"] then
		return internalNotifyFunction(timing, "Attacker is using a 'M1' attack.")
	end

	if timing.tag == "Mantra" and selectedFilters["Filter Out Mantras"] then
		return internalNotifyFunction(timing, "Attacker is using a 'Mantra' attack.")
	end

	if timing.tag == "Critical" and selectedFilters["Filter Out Criticals"] then
		return internalNotifyFunction(timing, "Attacker is using a 'Critical' attack.")
	end

	if timing.tag == "Undefined" and selectedFilters["Filter Out Undefined"] then
		return internalNotifyFunction(timing, "Attacker is using an 'Undefined' attack.")
	end

	return true
end)

---Check if any parts that are in our filter were hit.
---@note: Solara fallback.
local function checkParts(parts, filter)
	for _, part in next, parts do
		for _, fpart in next, filter do
			if part ~= fpart and not part:IsDescendantOf(fpart) then
				continue
			end

			return true
		end
	end

	return false
end

---Get a unique ID for hitboxes.
---@param spaces number Determines how many spaces that one UID can occupy.
---@return number
function Defender:uid(spaces)
	-- Increment.
	self.uids = self.uids + spaces

	-- Return.
	return self.uids
end

---Visualize a position and size.
---@param self Defender
---@param identifier number? If the identifier is nil, then we will auto-generate one for each visualization.
---@param cframe CFrame
---@param size Vector3
---@param color Color3
---@param shape Enum.PartType
Defender.visualize = LPH_NO_VIRTUALIZE(function(self, identifier, cframe, size, color, shape)
	local id = identifier or self:uid(10)
	local vpart = self.hmaid[id] or Instance.new("Part")

	pcall(function()
		vpart.Parent = workspace
	end)

	if vpart.Parent then
		vpart.Anchored = true
		vpart.CanCollide = false
		vpart.CanQuery = false
		vpart.CanTouch = false
		vpart.Material = Enum.Material.ForceField
		vpart.CastShadow = false
		vpart.Size = size
		vpart.CFrame = cframe
		vpart.Color = color
		vpart.Shape = shape
		vpart.Transparency = Configuration.expectToggleValue("EnableVisualizations") and 0.2 or 1.0
	end

	if self.hmaid[id] then
		return
	end

	self.hmaid[id] = vpart

	debrisService:AddItem(vpart, MAX_VISUALIZATION_TIME)
end)

---Run hitbox check. Returns wheter if the hitbox is being touched.
---@param self Defender
---@param cframe CFrame
---@param fd boolean
---@param soffset number
---@param size Vector3
---@param filter Instance[]
---@param shape Enum.PartType
---@return boolean?, CFrame?
Defender.hitbox = LPH_NO_VIRTUALIZE(function(self, cframe, fd, soffset, size, filter, shape)
	local shouldManualFilter = getexecutorname
		and (getexecutorname():match("Solara") or getexecutorname():match("Xeno"))

	local overlapParams = OverlapParams.new()
	overlapParams.FilterDescendantsInstances = shouldManualFilter and {} or filter
	overlapParams.FilterType = shouldManualFilter and Enum.RaycastFilterType.Exclude or Enum.RaycastFilterType.Include

	local character = players.LocalPlayer.Character
	if not character then
		return nil, nil
	end

	local root = character:FindFirstChild("HumanoidRootPart")
	if not root then
		return nil, nil
	end

	-- Used CFrame.
	local usedCFrame = cframe

	if fd then
		usedCFrame = usedCFrame * CFrame.new(0, 0, -(size.Z / 2))
	end

	if soffset and soffset ~= 0 then
		usedCFrame = usedCFrame * CFrame.new(0, 0, soffset)
	end

	-- Create simulation part.
	local simulationPart = Instance.new("Part")
	simulationPart.Size = size
	simulationPart.Material = Enum.Material.ForceField
	simulationPart.Shape = shape
	simulationPart.CFrame = usedCFrame

	if shape == Enum.PartType.Cylinder then
		simulationPart.CFrame = usedCFrame * CFrame.Angles(0, 0, math.rad(90))
	end

	-- Parts in bounds.
	local parts = workspace:GetPartsInPart(simulationPart, overlapParams)

	-- Return result.
	return shouldManualFilter and checkParts(parts, filter) or #parts > 0, usedCFrame
end)

---Check initial state.
---@param self Defender
---@param from Model? | BasePart?
---@param pair TimingContainerPair
---@param name string
---@param key string
---@return Timing?
Defender.initial = LPH_NO_VIRTUALIZE(function(self, from, pair, name, key)
	-- Find timing.
	local timing = pair:index(key)

	-- Fetch distance.
	local distance = self:distance(from)
	if not distance then
		return nil
	end

	-- Check for distance; if we have a timing.
	if timing then
		local md = PP_SCRAMBLE_NUM(timing.imdd)

		if md <= 0.01 then
			md = 0.0
		end

		if distance < md or distance > PP_SCRAMBLE_NUM(timing.imxd) then
			return nil
		end
	end

	-- Check for no timing. If so, let's log a miss.
	---@note: Ignore return value.
	if not timing then
		self:miss(self.__type, key, name, distance, from and tostring(from.Parent) or nil)
		return false
	end

	-- Return timing.
	return timing
end)

---Logger notify.
---@param self Defender
---@param timing Timing
---@param str string
Defender.notify = LPH_NO_VIRTUALIZE(function(self, timing, str, ...)
	if not Configuration.expectToggleValue("EnableNotifications") then
		return
	end

	Logger.qnotify("[%s] (%s) %s", PP_SCRAMBLE_STR(timing.name), self.__type, string.format(str, ...))
end)

---Repeat conditional.
---@param self Defender
---@param info RepeatInfo
---@return boolean
Defender.rc = LPH_NO_VIRTUALIZE(function(self, info)
	if os.clock() - info.start >= MAX_REPEAT_WAIT then
		return false
	end

	return true
end)

---Handle delay until in hitbox.
---@param self Defender
---@param options HitboxOptions
---@param info RepeatInfo
---@return boolean
Defender.duih = LPH_NO_VIRTUALIZE(function(self, options, info)
	local clone = options:clone()
	clone.hmid = info.hmid
	clone:ucache()

	while task.wait() do
		if not self:rc(info) then
			return false
		end

		if not self:hc(clone, nil) then
			continue
		end

		return true
	end
end)

---Handle hitbox check options.
---@param self Defender
---@param options HitboxOptions
---@param info RepeatInfo? Pass this in if you want to use the delay until in hitbox.
---@return boolean
Defender.hc = LPH_NO_VIRTUALIZE(function(self, options, info)
	local action = options.action
	local timing = options.timing

	-- Inner visualization function.
	local function innerVisualize(...)
		if not options.visualize then
			return
		end

		return self:visualize(...)
	end

	-- Run basic validation.
	local character = players.LocalPlayer.Character
	if not character then
		return false
	end

	local root = character:FindFirstChild("HumanoidRootPart")
	if not root then
		return false
	end

	if action and action.ihbc then
		return true
	end

	-- If we have info, then we want to delay until in hitbox.
	if info then
		return self:duih(options, info)
	end

	-- Fetch the data that we need.
	local hitbox = options:hitbox()
	local eposition = options.spredict and options:extrapolate() or nil
	local position = options:pos()
	local pt = timing.htype or Enum.PartType.Block

	-- Run hitbox check.
	local result, usedCFrame = self:hitbox(position, timing.fhb, timing.hso, hitbox, options.filter, pt)

	if usedCFrame then
		innerVisualize(options.hmid, usedCFrame, hitbox, options:ghcolor(result), pt)
		innerVisualize(options.hmid and options.hmid + 1 or nil, root.CFrame, root.Size, options:ghcolor(result), pt)
	end

	if not options.spredict or result then
		return result
	end

	-- Run prediction check.
	local closest = EntityHistory.pclosest(players.LocalPlayer, tick() - (Latency.rtt() * PREDICTION_LENIENCY_MULTI))
	if not closest then
		return false
	end

	local store = OriginalStore.new()

	-- Run check.
	store:run(root, "CFrame", closest, function()
		result, usedCFrame = self:hitbox(eposition, timing.fhb, timing.hso, hitbox, options.filter, pt)
	end)

	-- Visualize predicted hitbox.
	if usedCFrame then
		innerVisualize(options.hmid and options.hmid + 1 or nil, usedCFrame, hitbox, options:gphcolor(result), pt)
		innerVisualize(options.hmid and options.hmid + 1 or nil, closest, root.Size, options:gphcolor(result), pt)
	end

	-- Return result.
	return result
end)

---Handle action.
---@param self Defender
---@param timing Timing
---@param action Action
---@param started number
Defender.handle = LPH_NO_VIRTUALIZE(function(self, timing, action, started)
	local actionType = PP_SCRAMBLE_STR(action._type)

	if actionType == "End Block" then
		QueuedBlocking.stop("Defender_StartBlock")
	end

	-- Handle auto feint. We want to feint before the parry action gets sent out.
	-- We don't want to do this for any action that has:
	-- 1. Delay until in hitbox because we don't know the actual timing
	-- 2. A zero when time because it is instant
	-- 3. Is not an animation defender because it won't make sense to feint non-animation actions.
	if
		Configuration.expectToggleValue("AutoFeint")
		and not timing.duih
		and action._when > 0
		and self.__type == "Animation"
		and actionType ~= "End Block"
	then
		self:afeint(timing, action, started, false)
	end

	if actionType ~= "End Block" then
		if not self:valid(ValidationOptions.new(action, timing)) then
			return
		end
	end

	local redactedMap = {
		["Start Slide"] = "1",
		["End Slide"] = "2",
		["Teleport Up"] = "3",
		["Forced Full Dodge"] = "4",
		["Jump"] = "5",
		["Start Block"] = "6",
		["End Block"] = "7",
		["Parry"] = "8",
		["Dodge"] = "9",
		["Start Crouch"] = "10",
		["End Crouch"] = "11",
	}

	if LRM_UserNote then
		self:notify(timing, "Action type '%s' is being executed.", redactedMap[actionType] or actionType)
	else
		self:notify(timing, "Action type '%s' is being executed.", actionType)
	end

	local effectReplicator = replicatedStorage:FindFirstChild("EffectReplicator")
	if not effectReplicator then
		return
	end

	local effectReplicatorModule = require(effectReplicator)
	if not effectReplicatorModule then
		return
	end

	if actionType == "Start Block" then
		return QueuedBlocking.invoke(QueuedBlocking.BLOCK_TYPE_NORMAL, "Defender_StartBlock", 20.0)
	end

	local options = DodgeOptions.new()
	options.rollCancel = Configuration.expectToggleValue("RollCancel") and actionType ~= "Forced Full Dodge"
	options.rollCancelDelay = Configuration.expectOptionValue("RollCancelDelay") or 0.0
	options.direct = Configuration.expectToggleValue("BlatantRoll")

	local inIFrame = effectReplicatorModule:FindEffect("Immortal")
		or effectReplicatorModule:FindEffect("Dodge")
		or effectReplicatorModule:FindEffect("Ghost")

	if
		(actionType == "Dodge" or actionType == "Forced Full Dodge") and Configuration.expectToggleValue("ParryOnly")
	then
		actionType = "Parry"
		self:notify(timing, "Action 'Dodge' changed to 'Parry'")
	end

	if actionType == "Dodge" then
		if Configuration.expectToggleValue("UseIFrames") and inIFrame then
			return
		end

		return InputClient.dodge(options)
	end

	if actionType == "Forced Full Dodge" then
		return InputClient.dodge(options)
	end

	if actionType == "End Block" then
		return
	end

	if actionType == "Start Slide" then
		local serverSlide = KeyHandling.getRemote("ServerSlide")
		if not serverSlide then
			return
		end

		return serverSlide:FireServer(true)
	end

	if actionType == "End Slide" then
		local serverSlideStop = KeyHandling.getRemote("ServerSlideStop")
		if not serverSlideStop then
			return
		end

		return serverSlideStop:FireServer(false)
	end

	if actionType == "Start Crouch" then
		return InputClient.crouch(true)
	end

	if actionType == "End Crouch" then
		return InputClient.crouch(false)
	end

	if actionType == "Jump" then
		local humanController = InputClient.getHumanController()
		if not humanController then
			return
		end

		if effectReplicatorModule:HasAny("Swimming", "Jumped", "NoJump", "Landed") then
			return
		end

		if not humanController:Jump() then
			return
		end

		return InputClient.ejump()
	end

	if actionType == "Teleport Up" then
		local character = players.LocalPlayer.Character
		if not character then
			return
		end

		local humanoidRootPart = character:FindFirstChild("HumanoidRootPart")
		if not humanoidRootPart then
			return
		end

		if Finder.pnear(humanoidRootPart.Position, 500) then
			return self:notify(timing, "Action 'Teleport Up' blocked because there are players nearby.")
		end

		humanoidRootPart.CFrame = CFrame.new(humanoidRootPart.Position + Vector3.new(0, 75, 0))
	end

	self:parry(timing, action)
end)

---Handle parry.
---@param self Defender
---@param timing Timing
---@param action Action
Defender.parry = LPH_NO_VIRTUALIZE(function(self, timing, action)
	-- Options.
	local options = DodgeOptions.new()
	options.rollCancel = Configuration.expectToggleValue("RollCancel")
	options.rollCancelDelay = Configuration.expectOptionValue("RollCancelDelay") or 0.0
	options.direct = Configuration.expectToggleValue("BlatantRoll")

	-- Rate.
	local rate = (Configuration.expectOptionValue("DashInsteadOfParryRate") or 0.0)
	local overrideData = Library:GetOverrideData(PP_SCRAMBLE_STR(timing.name))
	if overrideData then
		rate = overrideData.dipr
	end

	-- Effect Replicator.
	local effectReplicator = replicatedStorage:FindFirstChild("EffectReplicator")
	local effectReplicatorModule = effectReplicator and require(effectReplicator)

	-- IFrame checks
	local inIFrame = effectReplicatorModule:FindEffect("Immortal")
		or effectReplicatorModule:FindEffect("DodgeFrame")
		or effectReplicatorModule:FindEffect("ParryFrame")
		or effectReplicatorModule:FindEffect("Ghost")

	-- Dash instead of parry.
	local dashReplacement = Random.new():NextNumber(1.0, 100.0) <= rate

	if action and PP_SCRAMBLE_STR(action._type) ~= "Parry" then
		dashReplacement = false
	end

	if not Configuration.expectToggleValue("AllowFailure") and not overrideData then
		dashReplacement = false
	end

	if timing.umoa or timing.actions:count() ~= 1 then
		dashReplacement = false
	end

	if Configuration.expectToggleValue("ParryOnly") then
		dashReplacement = false
	end

	local function internalNotify(...)
		if timing.rpue and timing.srpn then
			return
		end

		return self:notify(...)
	end

	if Configuration.expectToggleValue("UseIFrames") and inIFrame then
		return internalNotify(timing, "Action 'Parry' blocked because there are already existing IFrames.")
	end

	-- Parry if possible. Handles replacements.
	if StateListener.cparry() then
		-- Handle deflecting.
		if timing.nfdb or not StateListener.cdodge() or not dashReplacement then
			return QueuedBlocking.invoke(QueuedBlocking.BLOCK_TYPE_DEFLECT, "Defender_Deflect", nil)
		end

		-- Notify.
		internalNotify(timing, "Action type 'Parry' replaced to 'Dodge' type.")

		-- Dash replacement.
		return InputClient.dodge(options)
	end

	-- What fallbacks can we run?
	local canBlock = Configuration.expectToggleValue("DeflectBlockFallback")
		and not timing.nbfb
		and StateListener.cblock()

	local canVent = StateListener.cvent()
		and Configuration.expectToggleValue("VentFallback")
		and not timing.nvfb
		and not timing.rpue
		and self.__type ~= "Part"

	local canDodge = StateListener.cdodge()
		and Configuration.expectToggleValue("RollOnParryCooldown")
		and not timing.ndfb

	if canDodge then
		-- Dodge.
		InputClient.dodge(options)

		-- Notify.
		return internalNotify(timing, "Action type 'Parry' fallback to 'Dodge' type.")
	end

	if canVent then
		-- Vent.
		InputClient.vent()

		-- Notify.
		return internalNotify(timing, "Action type 'Parry' fallback to 'Vent' type.")
	end

	if canBlock then
		-- Block.
		QueuedBlocking.invoke(QueuedBlocking.BLOCK_TYPE_NORMAL, "Defender_BlockFallback", timing.bfht)

		-- Notify.
		return internalNotify(timing, "Action type 'Parry' fallback to 'Block' type.")
	end

	-- Cannot fallback.
	return internalNotify(timing, "Action 'Parry' blocked because no fallbacks are available.")
end)

---Check if we have input blocking tasks.
---@param self Defender
---@return boolean
Defender.blocking = LPH_NO_VIRTUALIZE(function(self)
	for _, marker in next, self.markers do
		if not marker then
			continue
		end

		return true
	end

	for _, task in next, self.tasks do
		if not task:blocking() then
			continue
		end

		return true
	end
end)

---Mark task.
---@param task Task
function Defender:mark(task)
	self.tasks[#self.tasks + 1] = task
end

---Clean up hooks.
function Defender:clhook()
	for key, old in next, self.rhook do
		if not self[key] then
			continue
		end

		self[key] = old
	end

	self.rhook = {}
end

---Clean up all tasks.
---@param self Defender
Defender.clean = LPH_NO_VIRTUALIZE(function(self)
	-- Clean-up tasks.
	for idx, task in next, self.tasks do
		if task.forced then
			continue
		end

		-- Cancel task.
		task:cancel()

		-- Clear in table.
		self.tasks[idx] = nil

		-- If we are cancelling a stop block or start block, then we want to end the block.
		if task.identifier ~= "End Block" and task.identifier ~= "Start Block" then
			continue
		end

		QueuedBlocking.stop("Defender_StartBlock")
	end

	-- Clean-up hooks.
	self:clhook()

	-- Clear temporary maid.
	self.tmaid:clean()

	-- Clear markers.
	self.markers = {}

	-- Clean up hitboxes.
	self.hmaid:clean()

	-- Reset auto feint.
	self.afeinted = false
end)

---Process module.
---@param self Defender
---@param timing Timing
---@varargs any
Defender.module = LPH_NO_VIRTUALIZE(function(self, timing, ...)
	-- Get loaded function.
	local lf = ModuleManager.modules[PP_SCRAMBLE_STR(timing.smod)]
	if not lf then
		return self:notify(timing, "No module '%s' found.", PP_SCRAMBLE_STR(timing.smod))
	end

	-- Create identifier.
	local identifier = string.format("Defender_RunModule_%s", PP_SCRAMBLE_STR(timing.smod))

	-- Notify.
	if not timing.smn then
		self:notify(timing, "Running module '%s' on timing.", PP_SCRAMBLE_STR(timing.smod))
	end

	-- Run module.
	self.tmaid:mark(TaskSpawner.spawn(identifier, lf, self, timing, ...))
end)

---Activate Prediction mantra instead of parrying.
---@param self Defender
---@param timing Timing
---@param action Action
Defender.prediction = LPH_NO_VIRTUALIZE(function(self, timing, action)
	-- Throw bypasses all counters.
	if PP_SCRAMBLE_STR(timing.smod) == "Throw" then
		return
	end

	-- Only use against players.
	if not players:GetPlayerFromCharacter(self.entity) then
		return
	end

	-- Windup delay.
	task.wait(0.1)

	local options = ValidationOptions.new(action, timing)
	options.skipFailureRate = true
	options.visualize = false
	if not self:valid(options) then
		return
	end

	-- Feint check.
	if self.__type == "Animation" and self.track and self:stopped(self.track, timing) then
		return
	end

	local localPlayer = players.LocalPlayer
	local character = localPlayer and localPlayer.Character
	local backpack = localPlayer and localPlayer:FindFirstChild("Backpack")
	local predictionMantra = backpack and backpack:FindFirstChild("Mantra:PredictionIntelligence{{Prediction}}")

	if not character then
		return
	end

	local effectReplicator = replicatedStorage:FindFirstChild("EffectReplicator")
	local effectReplicatorModule = effectReplicator and require(effectReplicator)

	if not effectReplicatorModule then
		return
	end

	-- IFrame check.
	local inIFrame = effectReplicatorModule:FindEffect("Immortal")
		or effectReplicatorModule:FindEffect("DodgeFrame")
		or effectReplicatorModule:FindEffect("ParryFrame")
		or effectReplicatorModule:FindEffect("Ghost")

	local isPlayer = self.entity and players:GetPlayerFromCharacter(self.entity)
	if Configuration.expectToggleValue("UseIFrames") and inIFrame and isPlayer then
		return
	end

	-- Hitbox check.
	if self.entity and self.__type == "Animation" then
		local root = self.entity:FindFirstChild("HumanoidRootPart")
		if not root then
			return
		end

		local hoptions = HitboxOptions.new(root, timing)
		hoptions.spredict = not timing.duih and not timing.dp
		hoptions.ptime = self:fsecs(timing)
		hoptions.action = action
		hoptions.entity = self.entity
		hoptions.visualize = false
		hoptions:ucache()

		if not self:hc(hoptions, nil) and not self:fpc(timing, hoptions) then
			return
		end
	end

	if not predictionMantra then
		return
	end

	local onCooldown = false
	for _, effect in next, effectReplicatorModule.Effects do
		if
			effect.Class == "ToolLockCD"
			and effect.index
			and effect.index.Value
			and tostring(effect.index.Value):find("PredictionIntelligence")
		then
			onCooldown = true
			break
		end
	end

	if onCooldown then
		return
	end

	local activateMantra = character:FindFirstChild("CharacterHandler")
		and character.CharacterHandler:FindFirstChild("Requests")
		and character.CharacterHandler.Requests:FindFirstChild("ActivateMantra")

	if not activateMantra then
		return
	end

	activateMantra:FireServer(predictionMantra)
	self:notify(timing, "Action 'Parry' replaced with 'Prediction' mantra.")
end)

---Activate Punishment mantra instead of parrying.
---@param self Defender
---@param timing Timing
---@param action Action
Defender.punishment = LPH_NO_VIRTUALIZE(function(self, timing, action)
	-- Throw bypasses all counters.
	if PP_SCRAMBLE_STR(timing.smod) == "Throw" then
		return
	end

	-- Only use against players.
	if not players:GetPlayerFromCharacter(self.entity) then
		return
	end

	-- Windup delay.
	task.wait(0.1)

	local options = ValidationOptions.new(action, timing)
	options.skipFailureRate = true
	options.visualize = false
	if not self:valid(options) then
		return
	end

	-- Feint check.
	if self.__type == "Animation" and self.track and self:stopped(self.track, timing) then
		return
	end

	local localPlayer = players.LocalPlayer
	local character = localPlayer and localPlayer.Character
	local backpack = localPlayer and localPlayer:FindFirstChild("Backpack")
	local punishmentMantra = backpack and backpack:FindFirstChild("Mantra:RevengeWeaponHeavy{{Punishment}}")

	if not character then
		return
	end

	local effectReplicator = replicatedStorage:FindFirstChild("EffectReplicator")
	local effectReplicatorModule = effectReplicator and require(effectReplicator)

	if not effectReplicatorModule then
		return
	end

	-- Defer to Prediction.
	if Configuration.expectToggleValue("UsePrediction") then
		local predictionMantra = backpack and backpack:FindFirstChild("Mantra:PredictionIntelligence{{Prediction}}")
		if predictionMantra then
			local predictionOnCooldown = false
			for _, effect in next, effectReplicatorModule.Effects do
				if
					effect.Class == "ToolLockCD"
					and effect.index
					and effect.index.Value
					and tostring(effect.index.Value):find("PredictionIntelligence")
				then
					predictionOnCooldown = true
					break
				end
			end

			if not predictionOnCooldown then
				return
			end
		end
	end

	-- Skip if already absorbing.
	if effectReplicatorModule:FindEffect("AbsorbCharge") then
		return
	end

	-- IFrame check.
	local inIFrame = effectReplicatorModule:FindEffect("Immortal")
		or effectReplicatorModule:FindEffect("DodgeFrame")
		or effectReplicatorModule:FindEffect("ParryFrame")
		or effectReplicatorModule:FindEffect("Ghost")

	local isPlayer = self.entity and players:GetPlayerFromCharacter(self.entity)
	if Configuration.expectToggleValue("UseIFrames") and inIFrame and isPlayer then
		return
	end

	-- Hitbox check.
	if self.entity and self.__type == "Animation" then
		local root = self.entity:FindFirstChild("HumanoidRootPart")
		if not root then
			return
		end

		local hoptions = HitboxOptions.new(root, timing)
		hoptions.spredict = not timing.duih and not timing.dp
		hoptions.ptime = self:fsecs(timing)
		hoptions.action = action
		hoptions.entity = self.entity
		hoptions.visualize = false
		hoptions:ucache()

		if not self:hc(hoptions, nil) and not self:fpc(timing, hoptions) then
			return
		end
	end

	if not punishmentMantra then
		return
	end

	local onCooldown = false
	for _, effect in next, effectReplicatorModule.Effects do
		if
			effect.Class == "ToolLockCD"
			and effect.index
			and effect.index.Value
			and tostring(effect.index.Value):find("RevengeWeaponHeavy")
		then
			onCooldown = true
			break
		end
	end

	if onCooldown then
		return
	end

	local activateMantra = character:FindFirstChild("CharacterHandler")
		and character.CharacterHandler:FindFirstChild("Requests")
		and character.CharacterHandler.Requests:FindFirstChild("ActivateMantra")

	if not activateMantra then
		return
	end

	activateMantra:FireServer(punishmentMantra)
	self:notify(timing, "Action 'Parry' replaced with 'Punishment' mantra.")
end)

---Handle auto feint.
---@param self Defender
---@param timing Timing
---@param action Action
---@param started number Timestamp of when the auto feint task started.
---@param initial boolean Whether this is the initial auto feint check.
Defender.afeint = LPH_NO_VIRTUALIZE(function(self, timing, action, started, initial)
	local function innerNotify(...)
		if initial then
			return
		end

		return self:notify(...)
	end

	local lfaction = StateListener.lAnimFaction
	if not lfaction then
		return innerNotify(timing, "Auto feint blocked because there is no local first action.")
	end

	local latimestamp = StateListener.lAnimTimestamp
	if not latimestamp then
		return innerNotify(timing, "Auto feint blocked because there is no last animation timestamp.")
	end

	if not StateListener.cfeint() then
		return innerNotify(timing, "Auto feint blocked because we are unable to feint.")
	end

	-- Our goal is to attempt to detect if this local timing will out-pace the animation timing that the enemey is doing.
	-- If it will out-pace it, then we don't want to feint as it will be useless, and not ideal.
	-- If not, then we did our goal, and prevented the user from getting hit.

	-- Time until our animation ends.
	local animTimeLeft = (lfaction:when() - (os.clock() - latimestamp)) + Latency.rtt()

	-- Time until the enemy's action hits us.
	local enemyTimeLeft = action:when() - (os.clock() - started)

	-- The local player will hit them before they do, so we don't want to feint.
	local autoFeintType = Configuration.expectOptionValue("AutoFeintType")

	if autoFeintType ~= "Aggressive" then
		if not timing.ha and enemyTimeLeft > animTimeLeft then
			return innerNotify(
				timing,
				"Auto feint blocked because enemy action (%.2fs, %.2fs) would not hit before local animation ends (%.2fs, %.2fs, %.2fs).",
				enemyTimeLeft,
				(os.clock() - started),
				animTimeLeft,
				lfaction:when(),
				(os.clock() - latimestamp)
			)
		end
	end

	local options = ValidationOptions.new(action, timing)
	options.sstun = true
	options.notify = false
	options.visualize = false

	if not self:valid(options) then
		return innerNotify(timing, "Auto feint failed because action is not valid.")
	end

	if not self.ifeinted then
		self:notify(timing, "Auto feint executed.")
	end

	if not initial then
		self.afeinted = true
	else
		self.ifeinted = true
	end

	InputClient.feint()
end)

---Add a action to the defender object.
---@param self Defender
---@param timing Timing
---@param action Action
Defender.action = LPH_NO_VIRTUALIZE(function(self, timing, action)
	if timing.umoa and self.__type == "Animation" then
		timing.et = action["_when"]
	end

	if timing.umoa or timing.cbm then
		action["_type"] = PP_SCRAMBLE_STR(action["_type"])
		action["name"] = PP_SCRAMBLE_STR(action["name"])
		action["_when"] = PP_SCRAMBLE_RE_NUM(action["_when"])
		action["hitbox"] = Vector3.new(
			PP_SCRAMBLE_RE_NUM(action["hitbox"].X),
			PP_SCRAMBLE_RE_NUM(action["hitbox"].Y),
			PP_SCRAMBLE_RE_NUM(action["hitbox"].Z)
		)
	end

	-- Get initial receive delay.
	local rdelay = Latency.rdelay()

	-- Add action.
	local atask = Task.new(PP_SCRAMBLE_STR(action._type), function()
		return action:when() - rdelay - Latency.sdelay()
	end, timing.punishable, timing.after, self.handle, self, timing, action, os.clock())

	if timing.forced then
		atask.forced = true
	end

	self:mark(atask)

	local actionType = PP_SCRAMBLE_STR(action._type)
	local isParryOrDodge = actionType == "Parry" or actionType == "Dodge"

	---@note: Schedule early Prediction task if enabled and action is Parry or Dodge.
	if Configuration.expectToggleValue("UsePrediction") and isParryOrDodge then
		self:mark(Task.new("Prediction", function()
			return action:when() - rdelay - Latency.sdelay() - 0.2
		end, timing.punishable, timing.after, self.prediction, self, timing, action, os.clock()))
	end

	---@note: Schedule early Punishment task if enabled and action is Parry or Dodge.
	if Configuration.expectToggleValue("UsePunishment") and isParryOrDodge then
		self:mark(Task.new("Punishment", function()
			return action:when() - rdelay - Latency.sdelay() - 0.2
		end, timing.punishable, timing.after, self.punishment, self, timing, action, os.clock()))
	end

	-- Add auto feint action.
	if
		Configuration.expectToggleValue("AutoFeint")
		and not timing.duih
		and action._when > 0
		and self.__type == "Animation"
		and action._type ~= PP_SCRAMBLE_STR("End Block")
	then
		self:mark(Task.new(PP_SCRAMBLE_STR(action._type), function()
			return (action:when() - rdelay - Latency.sdelay()) / 2
		end, timing.punishable, timing.after, self.afeint, self, timing, action, os.clock(), true))
	end

	-- Log.
	if not LRM_UserNote or LRM_UserNote == "tester" then
		self:notify(
			timing,
			"Added action '%s' (%.2fs) with ping '%.2f' (changing) subtracted.",
			PP_SCRAMBLE_STR(action.name),
			action:when(),
			Latency.rtt()
		)
	else
		self:notify(
			timing,
			"Added action '%s' ([redacted]) with ping '%.2f' (changing) subtracted.",
			PP_SCRAMBLE_STR(action.name),
			Latency.rtt()
		)
	end
end)

---Add actions from timing to defender object.
---@param self Defender
---@param timing Timing
Defender.actions = LPH_NO_VIRTUALIZE(function(self, timing)
	for _, action in next, timing.actions:get() do
		self:action(timing, action)
	end
end)

---Safely replace a function in the defender object.
---@param key string
---@param new function
---@return boolean, function
function Defender:hook(key, new)
	-- Check if we're already hooked.
	if self.rhook[key] then
		Logger.warn("Cannot hook '%s' because it is already hooked.", key)
		return false, nil
	end

	-- Get our assumed old / target function.
	local old = self[key]

	-- Check if function.
	if typeof(old) ~= "function" then
		Logger.warn("Cannot hook '%s' because it is not a function.", key)
		return false, nil
	end

	-- Create hook.
	self[key] = new

	-- Add to hook table with the old function so we can restore it on clean-up.
	self.rhook[key] = old

	-- Log.
	Logger.warn("Hooked '%s' with new function.", key)

	return true, old
end

---Detach defender object.
function Defender:detach()
	-- Clean self.
	self:clean()
	self.maid:clean()

	-- Clean up hitboxes.
	self.hmaid:clean()

	-- Set object nil.
	self = nil
end

---Create new Defender object.
---@return Defender
function Defender.new()
	local self = setmetatable({}, Defender)
	self.tasks = {}
	self.rhook = {}
	self.tmaid = Maid.new()
	self.maid = Maid.new()
	self.hmaid = Maid.new()
	self.uids = 0
	self.markers = {}
	self.lvisualization = os.clock()
	self.afeinted = false
	self.ifeinted = false
	return self
end

-- Return Defender module.
return Defender

end)
__bundle_register("Game/Objects/DodgeOptions", function(require, _LOADED, __bundle_register, __bundle_modules)
---@class DodgeOptions
---@field rollCancel boolean
---@field rollCancelDelay number
---@field direct boolean
---@field actionRolling boolean
local DodgeOptions = {}
DodgeOptions.__index = DodgeOptions

---Create new DodgeOptions object.
function DodgeOptions.new()
	local self = setmetatable({}, DodgeOptions)
	self.rollCancel = false
	self.rollCancelDelay = 0.0
	self.direct = false
	self.actionRolling = false
	return self
end

-- Return DodgeOptions module.
return DodgeOptions

end)
__bundle_register("Utility/OriginalStore", function(require, _LOADED, __bundle_register, __bundle_modules)
---@class OriginalStore
---@param data any
---@param index any
---@param value any
---@field stored boolean
local OriginalStore = {}
OriginalStore.__index = OriginalStore

---Get stored data value.
---@return any
OriginalStore.get = LPH_NO_VIRTUALIZE(function(self)
	if not self.stored then
		return nil
	end

	return self.value
end)

---Set something, run a callback, and then restore.
---@param data table|Instance
---@param index any
---@param value any
---@param callback fun(): any
OriginalStore.run = LPH_NO_VIRTUALIZE(function(self, data, index, value, callback)
	self:set(data, index, value)

	callback()

	self:restore()
end)

---Mark data value.
---@param data table|Instance
---@param index any
OriginalStore.mark = LPH_NO_VIRTUALIZE(function(self, data, index)
	if self.stored and self.data ~= data then
		self:restore()
	end

	if not self.stored then
		self.data = data
		self.index = index
		self.value = data[index]
		self.stored = true
	end
end)

---Set data value.
---@param data table|Instance
---@param index any
---@param value any
OriginalStore.set = LPH_NO_VIRTUALIZE(function(self, data, index, value)
	self:mark(data, index)

	data[index] = value
end)

---Restore data value.
OriginalStore.restore = LPH_NO_VIRTUALIZE(function(self)
	if not self.stored then
		return
	end

	pcall(function()
		self.data[self.index] = self.value
	end)

	self.stored = false
end)

---Detach OriginalStore object.
OriginalStore.detach = LPH_NO_VIRTUALIZE(function(self)
	self:restore()
	self.data = nil
	self.index = nil
	self.value = nil
	self.stored = false
end)

---Create new OriginalStore object.
---@return OriginalStore
OriginalStore.new = LPH_NO_VIRTUALIZE(function()
	local self = setmetatable({}, OriginalStore)
	self.data = nil
	self.index = nil
	self.value = nil
	self.stored = false
	return self
end)

-- Return OriginalStore module.
return OriginalStore

end)
__bundle_register("Features/Combat/Objects/ValidationOptions", function(require, _LOADED, __bundle_register, __bundle_modules)
---@class ValidationOptions
---@field sstun boolean Skip stun check.
---@field action Action The action being checked.
---@field timing Timing The timing of the action.
---@field notify boolean Whether to notify on failure.
---@field visualize boolean Whether to visualize the validation process.
local ValidationOptions = {}
ValidationOptions.__index = ValidationOptions

---Create a new ValidationOptions object.
---@param action Action
---@param timing Timing
ValidationOptions.new = LPH_NO_VIRTUALIZE(function(action, timing)
	local self = setmetatable({}, ValidationOptions)
	self.sstun = false
	self.action = action
	self.timing = timing
	self.notify = true
	self.visualize = true
	return self
end)

-- Return the module.
return ValidationOptions

end)
__bundle_register("Features/Combat/Targeting", function(require, _LOADED, __bundle_register, __bundle_modules)
-- Targeting module.
---@note: Glorified extended non-utility Entities file.
local Targeting = {}

---@module Utility.Configuration
local Configuration = require("Utility/Configuration")

---@module Game.PlayerScanning
local PlayerScanning = require("Game/PlayerScanning")

---@module Features.Combat.Objects.Target
local Target = require("Features/Combat/Objects/Target")

---@module Utility.Table
local Table = require("Utility/Table")

-- Services.
local players = game:GetService("Players")
local userInputService = game:GetService("UserInputService")

---Get a list of all viable targets.
---@return Target[]
Targeting.viable = LPH_NO_VIRTUALIZE(function()
	local live = workspace:FindFirstChild("Live")
	if not live then
		return {}
	end

	local localCharacter = players.LocalPlayer.Character
	if not localCharacter then
		return {}
	end

	local localRootPart = localCharacter and localCharacter:FindFirstChild("HumanoidRootPart")
	if not localRootPart then
		return {}
	end

	local currentCamera = workspace.CurrentCamera
	if not currentCamera then
		return {}
	end

	local targets = {}

	for _, entity in next, live:GetChildren() do
		if entity == localCharacter then
			continue
		end

		local playerFromCharacter = players:GetPlayerFromCharacter(entity)
		if not playerFromCharacter and Configuration.expectToggleValue("IgnoreMobs") then
			continue
		end

		if playerFromCharacter and Configuration.expectToggleValue("IgnorePlayers") then
			continue
		end

		local humanoid = entity:FindFirstChildWhichIsA("Humanoid")
		if not humanoid then
			continue
		end

		local rootPart = entity:FindFirstChild("HumanoidRootPart")
		if not rootPart then
			continue
		end

		if humanoid.Health <= 0 then
			continue
		end

		if
			playerFromCharacter
			and PlayerScanning.isAlly(playerFromCharacter)
			and Configuration.expectToggleValue("IgnoreAllies")
		then
			continue
		end

		local fieldOfViewToEntity =
			currentCamera.CFrame.LookVector:Dot((localRootPart.Position - rootPart.Position).Unit)

		local fieldOfViewLimit = Configuration.expectOptionValue("FOVLimit")

		if fieldOfViewLimit <= 0 or (fieldOfViewToEntity * -1) <= math.cos(math.rad(fieldOfViewLimit)) then
			continue
		end

		local currentDistance = (rootPart.Position - localRootPart.Position).Magnitude
		if currentDistance > Configuration.expectOptionValue("DistanceLimit") then
			continue
		end

		local mousePosition = userInputService:GetMouseLocation()
		local unitRay = workspace.CurrentCamera:ScreenPointToRay(mousePosition.X, mousePosition.Y)
		local distanceToCrosshair = unitRay:Distance(rootPart.Position)

		targets[#targets + 1] =
			Target.new(entity, humanoid, rootPart, distanceToCrosshair, fieldOfViewToEntity, currentDistance)
	end

	return targets
end)

---Get the best targets through sorting.
---@return Target[]
Targeting.best = LPH_NO_VIRTUALIZE(function()
	local targets = Targeting.viable()
	local sortType = Configuration.expectOptionValue("PlayerSelectionType")
	local sortFunction = nil

	if sortType == "Closest To Crosshair" then
		sortFunction = function(first, second)
			return first.dc < second.dc
		end
	end

	if sortType == "Closest In Distance" then
		sortFunction = function(first, second)
			return first.du < second.du
		end
	end

	if sortType == "Least Health" then
		sortFunction = function(first, second)
			return first.humanoid.Health < second.humanoid.Health
		end
	end

	table.sort(targets, sortFunction)

	return Table.slice(targets, 1, Configuration.expectOptionValue("MaxTargets"))
end)

---Find our model from a list of best targets.
---@param model Model
---@return Target?
Targeting.find = LPH_NO_VIRTUALIZE(function(model)
	for _, target in next, Targeting.best() do
		if target.character ~= model then
			continue
		end

		return target
	end
end)

-- Return Targeting module.
return Targeting

end)
__bundle_register("Features/Combat/Objects/Target", function(require, _LOADED, __bundle_register, __bundle_modules)
---@note: Typed object that represents a target. It's not really a true class but just needs to store the correct data.
---@class Target
---@field character Model
---@field humanoid Humanoid
---@field root BasePart
---@field dc number Distance to crosshair.
---@field fov number Field of view to target.
---@field du number Distance to us.
local Target = {}

---Create new Target object.
---@param character Model
---@param humanoid Humanoid
---@param root BasePart
---@param dc number
---@param fov number
---@param du number
---@return Target
Target.new = LPH_NO_VIRTUALIZE(function(character, humanoid, root, dc, fov, du)
	local self = setmetatable({}, Target)
	self.character = character
	self.humanoid = humanoid
	self.root = root
	self.dc = dc
	self.fov = fov
	self.du = du
	return self
end)

-- Return Target module.
return Target

end)
__bundle_register("Game/PlayerScanning", function(require, _LOADED, __bundle_register, __bundle_modules)
-- Player scanning is handled here.
local PlayerScanning = {
	scanQueue = {},
	scanDataCache = {},
	friendCache = {},
	waitingForLoad = {},
	readyList = {},
	scanning = false,
}

---@module Utility.CoreGuiManager
local CoreGuiManager = require("Utility/CoreGuiManager")

---@module Utility.Signal
local Signal = require("Utility/Signal")

---@module Utility.Maid
local Maid = require("Utility/Maid")

---@module Utility.Logger
local Logger = require("Utility/Logger")

---@module Utility.Configuration
local Configuration = require("Utility/Configuration")

-- Services.
local players = game:GetService("Players")
local httpService = game:GetService("HttpService")
local collectionService = game:GetService("CollectionService")
local runService = game:GetService("RunService")

-- Instances.
local moderatorSound = CoreGuiManager.imark(Instance.new("Sound"))

-- Maid.
local playerScanningMaid = Maid.new()

-- Timestamp.
local lastRateLimit = nil
local lastCheckedTimestamp = os.clock()
local lastPlayerScanTimestamp = os.clock()

-- Seen tools.
local seenTools = {}

---Fetch name.
local function fetchName(player)
	local spoofName = Configuration.expectToggleValue("InfoSpoofing")
		and Configuration.expectToggleValue("SpoofOtherPlayers")

	return spoofName and "[REDACTED]"
		or string.format("(%s) %s", player:GetAttribute("CharacterName") or "Unknown Character Name", player.Name)
end

---Partial look for string in list. Returns the string that got matched.
---@param list table<string, any>
---@param value string
---@return string?
local partialStringFind = LPH_NO_VIRTUALIZE(function(list, value)
	for _, str in next, list do
		if not value:match(str) then
			continue
		end

		return str
	end

	return nil
end)

---Fetch roblox data.
---@param url string
---@return boolean, string?
local function fetchRobloxData(url)
	if lastRateLimit and os.clock() - lastRateLimit <= 30 then
		return false, "On rate-limit cooldown."
	end

	local response = request({
		Url = url,
		Method = "GET",
		Headers = {
			["Content-Type"] = "application/json",
		},
	})

	if response.StatusCode == 429 then
		Logger.longNotify("Player scanning is being rate-limited and results will be delayed.")
		Logger.longNotify("Please stay in the server with caution.")

		lastRateLimit = os.clock()

		return false, "Rate-limited."
	end

	if not response then
		return error("Failed to fetch Roblox data.")
	end

	if not response.Success then
		return error(
			string.format("Failed to successfully fetch Roblox data with status code %i.", response.StatusCode)
		)
	end

	if not response.Body then
		return error("Failed to find Roblox data.")
	end

	return true, httpService:JSONDecode(response.Body)
end

---Check inventories for tools.
local function checkInventoriesForTools()
	for _, player in next, players:GetPlayers() do
		if not Configuration.expectToggleValue("NotifyItems") then
			continue
		end

		if player == players.LocalPlayer then
			continue
		end

		local backpack = player:FindFirstChild("Backpack")
		if not backpack then
			continue
		end

		local notifyItemsList = Options.NotifyItemsList and Options.NotifyItemsList.Values
		if not notifyItemsList then
			continue
		end

		-- Check if the player has any items that match the notify items list.
		for _, tool in next, backpack:GetChildren() do
			if seenTools[tool] then
				continue
			end

			local itemName = tool:GetAttribute("ItemName")
			if typeof(itemName) ~= "string" or itemName == "" then
				continue
			end

			local matchedString = partialStringFind(notifyItemsList, itemName)
			if not matchedString then
				continue
			end

			seenTools[tool] = matchedString

			Logger.longNotify("%s has item '%s' in their inventory.", fetchName(player), itemName)
		end

		-- If the matched string that filtered this item is no longer in the list, remove it.
		for tool, matched in next, seenTools do
			if table.find(notifyItemsList, matched) then
				continue
			end

			seenTools[tool] = nil
		end
	end

	lastCheckedTimestamp = os.clock()
end

---Run player scans.
local runPlayerScans = LPH_NO_VIRTUALIZE(function()
	local localPlayer = players.LocalPlayer
	if not localPlayer then
		return
	end

	for player, _ in next, PlayerScanning.scanQueue do
		if shared.Lycoris.dpscanning then
			continue
		end

		if not PlayerScanning.scanDataCache[player] then
			local handledSuccess, handledResult = nil, nil

			local unhandledSuccess, unhandledResult = pcall(function()
				handledSuccess, handledResult = PlayerScanning.getStaffRank(player)
			end)

			if not unhandledSuccess then
				Logger.warn(
					"Scan player %s ran into error '%s' while getting staff rank.",
					player.Name,
					unhandledResult
				)

				Logger.mnnotify("Failed to scan player %s for moderator status.", fetchName(player), unhandledResult)

				PlayerScanning.scanQueue[player] = nil

				continue
			end

			if not handledSuccess then
				continue
			end

			if Configuration.expectToggleValue("NotifyMod") and handledResult then
				Logger.mnnotify("%s is a staff member with the rank '%s' in group.", fetchName(player), handledResult)

				if Configuration.expectToggleValue("NotifyModSound") then
					moderatorSound.SoundId = "rbxassetid://6045346303"
					moderatorSound.PlaybackSpeed = 1
					moderatorSound.Volume = Configuration.expectToggleValue("NotifyModSoundVolume") or 10
					moderatorSound:Play()
				end
			end

			PlayerScanning.scanDataCache[player] = { staffRank = handledResult }
		end

		local backpack = player:FindFirstChild("Backpack")
		if not backpack then
			return
		end

		if not collectionService:HasTag(backpack, "Loaded") or #backpack:GetChildren() < 1 then
			if not PlayerScanning.waitingForLoad[player] then
				Logger.warn("Player scanning is waiting for %s to load in the game.", fetchName(player))
			end

			PlayerScanning.waitingForLoad[player] = true

			continue
		end

		if
			Configuration.expectToggleValue("NotifyVoidWalker")
			and backpack:FindFirstChild("Talent:Voidwalker Contract")
		then
			Logger.longNotify("%s has the Voidwalker Contract talent.", fetchName(player))
		end

		PlayerScanning.scanQueue[player] = nil

		PlayerScanning.friendCache[player] = localPlayer:GetFriendStatus(player) == Enum.FriendStatus.Friend

		Logger.warn("Player scanning finished scanning %s in queue.", fetchName(player))
	end
end)

---Are there moderators in the server?
---@return table
function PlayerScanning.hasModerators()
	for _, scanData in next, PlayerScanning.scanDataCache do
		if not scanData.staffRank then
			continue
		end

		return true
	end

	return false
end

---Is a player an ally?
---@param player Player
---@return boolean
function PlayerScanning.isAlly(player)
	---@note: bruh we can call ReputationSystem
	local localPlayerGuild = players.LocalPlayer:GetAttribute("Guild")
	local usernameList = Options["UsernameList"]

	if usernameList then
		local displayNameFound = player and table.find(usernameList.Values, player.DisplayName)
		local usernameFound = player and table.find(usernameList.Values, player.Name)

		if displayNameFound or usernameFound then
			return true
		end
	end

	return PlayerScanning.friendCache[player]
		or ((localPlayerGuild and #localPlayerGuild >= 1) and player:GetAttribute("Guild") == localPlayerGuild)
end

---Get staff rank - nil if they're not a staff.
---@param player Player
---@return string?
function PlayerScanning.getStaffRank(player)
	local responseSuccess, responseData =
		fetchRobloxData(("https://groups.roblox.com/v2/users/%i/groups/roles?includeLocked=true"):format(player.UserId))

	if not responseSuccess then
		return false, responseData
	end

	for _, groupData in next, responseData.data do
		if groupData.group.id ~= 5212858 then
			continue
		end

		if groupData.role.rank <= 0 then
			continue
		end

		return true, groupData.role.name
	end

	return true, nil
end

---Update player scanning.
---@note: Request will yield - so we need a debounce to prevent multiple scan loops.
---@note: We must defer the error back to the caller and reset the scanning debounce so errors will not break the scanning loop.
function PlayerScanning.update()
	if os.clock() - lastCheckedTimestamp >= 5.0 then
		checkInventoriesForTools()
	end

	if os.clock() - lastPlayerScanTimestamp <= 1.0 then
		return
	end

	lastPlayerScanTimestamp = os.clock()

	if PlayerScanning.scanning then
		return
	end

	PlayerScanning.scanning = true

	local success, result = pcall(runPlayerScans)

	PlayerScanning.scanning = false

	if success then
		return
	end

	return error(result)
end

---On friend status changed.
---@param player Player
---@param status Enum.FriendStatus
function PlayerScanning.friend(player, status)
	PlayerScanning.friendCache[player] = status == Enum.FriendStatus.Friend
end

---On player added.
---@param player Player
function PlayerScanning.onPlayerAdded(player)
	if player == players.LocalPlayer then
		return
	end

	PlayerScanning.scanQueue[player] = true
end

---On player removing.
---@param player Player
function PlayerScanning.onPlayerRemoving(player)
	PlayerScanning.scanQueue[player] = nil
	PlayerScanning.scanDataCache[player] = nil
	PlayerScanning.friendCache[player] = nil
	PlayerScanning.waitingForLoad[player] = nil
end

---Initialize PlayerScanning.
function PlayerScanning.init()
	-- Signals.
	local playerAddedSignal = Signal.new(players.PlayerAdded)
	local playerRemovingSignal = Signal.new(players.PlayerRemoving)
	local renderSteppedSignal = Signal.new(runService.RenderStepped)
	local friendStatusChanged = Signal.new(players.LocalPlayer.FriendStatusChanged)

	-- Connect events.
	playerScanningMaid:add(friendStatusChanged:connect("PlayerScanning_OnFriendStatusChanged", PlayerScanning.friend))
	playerScanningMaid:add(renderSteppedSignal:connect("PlayerScanning_Update", PlayerScanning.update))
	playerScanningMaid:add(playerAddedSignal:connect("PlayerScanning_OnPlayerAdded", PlayerScanning.onPlayerAdded))
	playerScanningMaid:add(
		playerRemovingSignal:connect("PlayerScanning_OnPlayerRemoving", PlayerScanning.onPlayerRemoving)
	)

	-- Run event(s) for existing players.
	for _, player in next, players:GetPlayers() do
		PlayerScanning.onPlayerAdded(player)
	end
end

---Detach PlayerScanning.
function PlayerScanning.detach()
	playerScanningMaid:clean()
end

-- Return PlayerScanning module.
return PlayerScanning

end)
__bundle_register("Features/Combat/Objects/Task", function(require, _LOADED, __bundle_register, __bundle_modules)
---@module Utility.TaskSpawner
local TaskSpawner = require("Utility/TaskSpawner")

---@module Utility.Configuration
local Configuration = require("Utility/Configuration")

---@class Task
---@field thread thread
---@field identifier string
---@field when number A timestamp when the task will be executed.
---@field punishable number A window in seconds where the task can be punished.
---@field after number A window in seconds where the task can be executed.
---@field delay function
local Task = {}
Task.__index = Task

---Check if task should block the input.
---@return boolean
Task.blocking = LPH_NO_VIRTUALIZE(function(self)
	if not (coroutine.status(self.thread) ~= "dead") then
		return false
	end

	-- We've exceeded the execution time. Block if we're within the after window.
	if os.clock() >= self:when() then
		return os.clock() <= self:when() + self.after
	end

	---@note: Allow us to do inputs up until a certain amount of time before the task happens.
	return os.clock() >= self:when() - self.punishable
end)

---Cancel task.
Task.cancel = LPH_NO_VIRTUALIZE(function(self)
	if coroutine.status(self.thread) ~= "suspended" then
		return
	end

	task.cancel(self.thread)
end)

---Get when approximately the task will be executed.
---@return number
Task.when = LPH_NO_VIRTUALIZE(function(self)
	return self.when + self.delay()
end)

---Create new Task object.
---@param identifier string
---@param delay function
---@param punishable number
---@param after number
---@param callback function
---@vararg any
---@return Task
Task.new = LPH_NO_VIRTUALIZE(function(identifier, delay, punishable, after, callback, ...)
	local self = setmetatable({}, Task)
	self.identifier = identifier
	self.delay = delay
	self.punishable = punishable
	self.after = after
	self.thread = TaskSpawner.delay("Action_" .. identifier, delay, callback, ...)
	self.forced = false

	if not self.punishable or self.punishable <= 0 then
		self.punishable = Configuration.expectOptionValue("DefaultPunishableWindow") or 0.7
	end

	if not self.after or self.after <= 0 then
		self.after = Configuration.expectOptionValue("DefaultAfterWindow") or 0.1
	end

	return self
end)

-- Return Task module.
return Task

end)
__bundle_register("Features/Combat/Objects/SoundDefender", function(require, _LOADED, __bundle_register, __bundle_modules)
---@module Features.Combat.Objects.Defender
local Defender = require("Features/Combat/Objects/Defender")

---@module Game.Timings.SaveManager
local SaveManager = require("Game/Timings/SaveManager")

---@module Utility.Signal
local Signal = require("Utility/Signal")

---@module Utility.Configuration
local Configuration = require("Utility/Configuration")

---@module Features.Combat.Objects.RepeatInfo
local RepeatInfo = require("Features/Combat/Objects/RepeatInfo")

---@module Features.Combat.Objects.HitboxOptions
local HitboxOptions = require("Features/Combat/Objects/HitboxOptions")

---@module Game.Latency
local Latency = require("Game/Latency")

---@class SoundDefender: Defender
---@field owner Model? The owner of the part.
---@field sound Sound The sound that we're defending.
---@field part BasePart A part that we can base the position off of.
local SoundDefender = setmetatable({}, { __index = Defender })
SoundDefender.__index = SoundDefender
SoundDefender.__type = "Sound"

-- Services.
local players = game:GetService("Players")

---Check if we're in a valid state to proceed with the action.
---@param self SoundDefender
---@param options ValidationOptions
---@return boolean
SoundDefender.valid = LPH_NO_VIRTUALIZE(function(self, options)
	if not Defender.valid(self, options) then
		return false
	end

	local function internalNotifyFunction(timing, message)
		if not options.notify then
			return
		end

		return self:notify(timing, message)
	end

	local timing = options.timing
	local action = options.action

	if self.owner and not self:target(self.owner) then
		if not timing.alp or not players.LocalPlayer.Character or self.owner ~= players.LocalPlayer.Character then
			return internalNotifyFunction(timing, "Not a viable target.")
		end
	end

	local character = players.LocalPlayer.Character
	if not character then
		return internalNotifyFunction(timing, "No character found.")
	end

	local hoptions = HitboxOptions.new(self.part, timing)
	hoptions.spredict = false
	hoptions.action = action
	hoptions:ucache()

	if not self:hc(hoptions, timing.duih and RepeatInfo.new(timing, Latency.rdelay(), self:uid(10)) or nil) then
		return internalNotifyFunction(timing, "Not in hitbox.")
	end

	return true
end)

---Repeat conditional.
---@param self SoundDefender
---@param _ RepeatInfo
---@return boolean
SoundDefender.rc = LPH_NO_VIRTUALIZE(function(self, _)
	if not self.sound.IsPlaying then
		return false
	end

	return true
end)

---Process sound playing.
---@param self SoundDefender
SoundDefender.process = LPH_NO_VIRTUALIZE(function(self)
	---@type SoundTiming?
	local timing = self:initial(
		self.owner or self.part,
		SaveManager.ss,
		self.owner and self.owner.Name or self.part.Name,
		tostring(self.sound.SoundId)
	)

	if not timing then
		return
	end

	if not Configuration.expectToggleValue("EnableAutoDefense") then
		return
	end

	if not timing.alp and (players.LocalPlayer.Character and self.owner == players.LocalPlayer.Character) then
		return
	end

	---@note: Clean up previous tasks that are still waiting or suspended because they're in a different track.
	self:clean()

	-- Use module if we need to.
	if timing.umoa then
		return self:module(timing)
	end

	---@note: Start processing the timing. Add the actions if we're not RPUE.
	if not timing.rpue then
		return self:actions(timing)
	end

	-- Start RPUE.
	local info = RepeatInfo.new(timing, Latency.rdelay(), self:uid(10))
	self:srpue(self.entity, timing, info)
end)

---Create new SoundDefender object.
---@param sound Sound
---@param part BasePart
---@return SoundDefender
function SoundDefender.new(sound, part)
	local self = setmetatable(Defender.new(), SoundDefender)
	local soundPlayed = Signal.new(sound.Played)

	self.sound = sound
	self.part = part
	self.owner = sound:FindFirstAncestorWhichIsA("Model")
	self.maid:mark(soundPlayed:connect(
		"SoundDefender_OnSoundPlayed",
		LPH_NO_VIRTUALIZE(function()
			self:process()
		end)
	))

	if sound.Playing then
		self:process()
	end

	return self
end

-- Return SoundDefender module.
return SoundDefender

end)
__bundle_register("Features/Combat/Objects/PartDefender", function(require, _LOADED, __bundle_register, __bundle_modules)
---@module Features.Combat.Objects.Defender
local Defender = require("Features/Combat/Objects/Defender")

---@module Game.Timings.SaveManager
local SaveManager = require("Game/Timings/SaveManager")

---@module Features.Combat.Objects.RepeatInfo
local RepeatInfo = require("Features/Combat/Objects/RepeatInfo")

---@module Features.Combat.Objects.HitboxOptions
local HitboxOptions = require("Features/Combat/Objects/HitboxOptions")

---@module Utility.Configuration
local Configuration = require("Utility/Configuration")

---@module Game.Latency
local Latency = require("Game/Latency")

---@class PartDefender: Defender
---@field part BasePart
---@field timing PartTiming
---@field touched boolean Determines whether if we touched the timing in the past.
---@field vuid string Visualizer UID.
local PartDefender = setmetatable({}, { __index = Defender })
PartDefender.__index = PartDefender
PartDefender.__type = "Part"

-- Services.
local players = game:GetService("Players")

---Get CFrame.
---@param self PartDefender
---@return CFrame
PartDefender.cframe = LPH_NO_VIRTUALIZE(function(self)
	return self.timing.uhc and self.part.CFrame or CFrame.new(self.part.Position)
end)

---Check if we're in a valid state to proceed with the action.
---@param self PartDefender
---@param options ValidationOptions
---@return boolean
PartDefender.valid = LPH_NO_VIRTUALIZE(function(self, options)
	if not Defender.valid(self, options) then
		return false
	end

	local function internalNotifyFunction(timing, message)
		if not options.notify then
			return
		end

		return self:notify(timing, message)
	end

	local timing = options.timing
	local action = options.action

	local character = players.LocalPlayer.Character
	if not character then
		return internalNotifyFunction(timing, "No character found.")
	end

	local hoptions = HitboxOptions.new(self.part, timing)
	hoptions.spredict = false
	hoptions.action = action
	hoptions:ucache()

	if not timing.duih or timing.umoa then
		if not self:hc(hoptions, timing.duih and RepeatInfo.new(timing, Latency.rdelay(), self.vuid) or nil) then
			return internalNotifyFunction(timing, "Not in hitbox.")
		end
	end

	return true
end)

---Update PartDefender object.
---@param self PartDefender
PartDefender.update = LPH_NO_VIRTUALIZE(function(self)
	-- Skip if we're not handling delay until in hitbox or we want to use modules.
	if not self.timing.duih or self.timing.umoa then
		return
	end

	-- Deny updates if we already have actions in the queue.
	if #self.tasks > 0 then
		return
	end

	local localPlayer = players.LocalPlayer
	if not localPlayer then
		return
	end

	local character = localPlayer.Character
	if not character then
		return
	end

	local hb = self.timing.hitbox

	hb = Vector3.new(PP_SCRAMBLE_NUM(hb.X), PP_SCRAMBLE_NUM(hb.Y), PP_SCRAMBLE_NUM(hb.Z))

	-- Get current hitbox state.
	---@note: If we're using PartDefender, why perserve rotation? It's likely wrong or gonna mess us up.
	local touching, cframe = self:hitbox(
		self:cframe(),
		self.timing.fhb,
		self.timing.hso,
		hb,
		{ character },
		self.timing.htype or Enum.PartType.Block
	)

	if cframe then
		self:visualize(
			self.vuid,
			cframe,
			hb,
			touching and Color3.fromHex("#DDF527") or Color3.fromHex("#2765F5"),
			self.timing.htype or Enum.PartType.Block
		)
	end

	-- Deny updates if we're not touching the part.
	if not touching then
		return
	end

	-- Deny updates if the we were touching the part last and we are touching it now.
	if self.touched and touching then
		return
	end

	-- Ok, set the new state.
	self.touched = touching

	-- Clean all previous tasks. Just to be safe. We already check if it's empty... so.
	self:clean()

	---@note: Start processing the timing. Add the actions if we're not RPUE.
	if not self.timing.rpue then
		return self:actions(self.timing)
	end

	-- Start RPUE.
	local info = RepeatInfo.new(self.timing, Latency.rdelay(), self:uid(10))
	self:srpue(self.entity, self.timing, info)
end)

---Create new PartDefender object.
---@param part BasePart
---@param timing PartTiming?
---@return PartDefender?
function PartDefender.new(part, timing)
	if not Configuration.expectToggleValue("EnableAutoDefense") then
		return nil
	end

	local okey = nil

	-- Hotfix for now; too lazy to do it the animation way.
	if part.Name:match("VengefulSlash") then
		okey = "VengefulSlashes"
	end

	local self = setmetatable(Defender.new(), PartDefender)
	self.part = part
	self.timing = timing or self:initial(part, SaveManager.ps, nil, okey or part.Name)
	self.touched = false
	self.vuid = self:uid(10)

	-- Handle no timing.
	if not self.timing then
		return nil
	end

	-- Handle module.
	if self.timing.umoa then
		self:module(self.timing)
	end

	-- Handle no hitbox delay.
	if self.timing.umoa or self.timing.duih then
		return self
	end

	local info = RepeatInfo.new(self.timing, Latency.rdelay(), self:uid(10))

	if self.timing.rpue then
		self:srpue(self.entity, self.timing, info)
	else
		self:actions(self.timing)
	end

	-- Return self.
	return self
end

-- Return PartDefender module.
return PartDefender

end)
__bundle_register("Features/Combat/Objects/AnimatorDefender", function(require, _LOADED, __bundle_register, __bundle_modules)
---@module Features.Combat.Objects.Defender
local Defender = require("Features/Combat/Objects/Defender")

---@module Utility.Signal
local Signal = require("Utility/Signal")

---@module Game.Timings.SaveManager
local SaveManager = require("Game/Timings/SaveManager")

---@module Utility.Logger
local Logger = require("Utility/Logger")

---@module Utility.Configuration
local Configuration = require("Utility/Configuration")

---@module Game.Timings.PlaybackData
local PlaybackData = require("Game/Timings/PlaybackData")

---@module Game.InputClient
local InputClient = require("Game/InputClient")

---@module Features.Combat.Objects.RepeatInfo
local RepeatInfo = require("Features/Combat/Objects/RepeatInfo")

---@module Game.QueuedBlocking
local QueuedBlocking = require("Game/QueuedBlocking")

---@module Features.Combat.Objects.HitboxOptions
local HitboxOptions = require("Features/Combat/Objects/HitboxOptions")

---@module Utility.OriginalStore
local OriginalStore = require("Utility/OriginalStore")

---@module Features.Combat.EntityHistory
local EntityHistory = require("Features/Combat/EntityHistory")

---@module Features.Combat.StateListener
local StateListener = require("Features/Combat/StateListener")

---@module Game.Latency
local Latency = require("Game/Latency")

---@module GUI.Library
local Library = require("GUI/Library")

---@class AnimatorDefender: Defender
---@field animator Animator
---@field offset number?
---@field entity Model
---@field keyframes Action[]
---@field timing AnimationTiming?
---@field pbdata table<AnimationTrack, PlaybackData> Playback data to be recorded.
---@field rpbdata table<string, PlaybackData> Recorded playback data. Optimization so we don't have to constantly reiterate over recorded data.
---@field manimations table<number, Animation>
---@field track AnimationTrack? Don't be confused. This is the **valid && last** animation track played.
---@field maid Maid This maid is cleaned up after every new animation track. Safe to use for on-animation-track setup.
---@field sct table<AnimationTrack, boolean> Tracks that need to have their speed changed.
---@field tsc table<AnimationTrack, number> Tracks that are saving their last speed.
local AnimatorDefender = setmetatable({}, { __index = Defender })
AnimatorDefender.__index = AnimatorDefender
AnimatorDefender.__type = "Animation"

-- Services.
local players = game:GetService("Players")
local replicatedStorage = game:GetService("ReplicatedStorage")

-- Constants.
local MAX_REPEAT_TIME = 5.0
local HISTORY_STEPS = 5.0
local PREDICT_FACING_DELTA = 3

---Is animation stopped? Made into a function for de-duplication.
---@param self AnimatorDefender
---@param track AnimationTrack
---@param timing AnimationTiming
---@param notify boolean? Whether to notify or not.
---@return boolean
AnimatorDefender.stopped = LPH_NO_VIRTUALIZE(function(self, track, timing, notify)
	local function internalNotifyFunction(...)
		if not notify then
			return
		end

		return self:notify(...)
	end

	local overrideData = Library:GetOverrideData(PP_SCRAMBLE_STR(timing.name))
	local rate = (Configuration.expectOptionValue("IgnoreAnimationEndRate") or 0.0)

	if overrideData then
		rate = overrideData.iaer
	end

	if
		(Configuration.expectToggleValue("AllowFailure") or overrideData)
		and not timing.rpue
		and Random.new():NextNumber(1.0, 100.0) <= rate
		and StateListener.cdodge()
	then
		return false, internalNotifyFunction(timing, "Intentionally ignoring animation end to simulate human error.")
	end

	if not timing.iae and not track.IsPlaying then
		return true, internalNotifyFunction(timing, "Animation stopped playing.")
	end

	if timing.iae and not timing.ieae and not track.IsPlaying and track.TimePosition < track.Length then
		return true, internalNotifyFunction(timing, "Animation stopped playing early.")
	end
end)

---Repeat conditional. Extra parameter 'track' added on.
---@param self AnimatorDefender
---@param info RepeatInfo
---@return boolean
AnimatorDefender.rc = LPH_NO_VIRTUALIZE(function(self, info)
	---@note: There are cases where we might not have a track. If it's not handled properly, it will throw an error.
	-- Perhaps, the animation can end and we're handling a different repeat conditional.
	if not info.track then
		return Logger.warn(
			"(%s) Did you forget to pass the track? Or perhaps you forgot to place a hook before using this function.",
			PP_SCRAMBLE_STR(info.timing.name)
		)
	end

	if self:stopped(info.track, info.timing) then
		return false
	end

	if info.timing.iae and os.clock() - info.start >= ((info.timing.mat / 1000) or MAX_REPEAT_TIME) then
		return self:notify(info.timing, "Max animation timeout exceeded.")
	end

	return true
end)

---Run predict facing hitbox check.
---@param self AnimatorDefender
---@param options HitboxOptions
---@return boolean
AnimatorDefender.pfh = LPH_NO_VIRTUALIZE(function(self, options)
	local root = self.entity:FindFirstChild("HumanoidRootPart")
	if not root then
		return false
	end

	local localRoot = players.LocalPlayer.Character and players.LocalPlayer.Character:FindFirstChild("HumanoidRootPart")
	if not localRoot then
		return false
	end

	if not options.timing.ffh then
		local yrate = EntityHistory.yrate(self.entity)
		if not yrate then
			return false
		end

		if math.abs(yrate) < PREDICT_FACING_DELTA then
			return
		end
	end

	local clone = options:clone()
	clone.hcolor = Color3.new(0, 1, 1)
	clone.mcolor = Color3.new(1, 1, 0)
	clone:ucache()

	local result = false
	local store = OriginalStore.new()

	store:run(root, "CFrame", CFrame.lookAt(root.Position, localRoot.Position), function()
		result = self:hc(clone, nil)
	end)

	return result
end)

---Run past hitbox check.
---@param timing Timing
---@param options HitboxOptions
---@return boolean
AnimatorDefender.phd = LPH_NO_VIRTUALIZE(function(self, timing, options)
	for _, cframe in next, EntityHistory.pstepped(self.entity, HISTORY_STEPS, timing.phds) or {} do
		local clone = options:clone()
		clone.cframe = cframe
		clone.hcolor = Color3.new(0.839215, 0.976470, 0.537254)
		clone.mcolor = Color3.new(0.564705, 0, 1)
		clone:ucache()

		if not self:hc(clone, nil) then
			continue
		end

		return true
	end
end)

---Run our facing extrapolation / interpolation.
AnimatorDefender.fpc = LPH_NO_VIRTUALIZE(function(self, timing, options)
	if timing.duih then
		return false
	end

	if (timing.ffh or timing.pfh) and self:pfh(options) then
		return true
	end

	if timing.phd and self:phd(timing, options) then
		return true
	end
end)

---Check if we're in a valid state to proceed with the action.
---@param self AnimatorDefender
---@param options ValidationOptions
---@return boolean
AnimatorDefender.valid = LPH_NO_VIRTUALIZE(function(self, options)
	if not Defender.valid(self, options) then
		return false
	end

	local timing = options.timing
	local action = options.action

	local function internalNotifyFunction(...)
		if not options.notify then
			return
		end

		return self:notify(...)
	end

	if not self.track then
		return internalNotifyFunction(timing, "No current track.")
	end

	if not self.entity then
		return internalNotifyFunction(timing, "No entity found.")
	end

	local target = self:target(self.entity)
	if not target then
		return internalNotifyFunction(timing, "Not a viable target.")
	end

	local root = self.entity:FindFirstChild("HumanoidRootPart")
	if not root then
		return internalNotifyFunction(timing, "No humanoid root part found.")
	end

	local character = players.LocalPlayer.Character
	if not character then
		return internalNotifyFunction(timing, "No character found.")
	end

	local targetInstance = self.entity:FindFirstChild("Target")

	if
		targetInstance
		and targetInstance.Value ~= character
		and Configuration.expectToggleValue("CheckTargetingValue")
	then
		return internalNotifyFunction(timing, "Not being targeted.")
	end

	local effectReplicator = replicatedStorage:FindFirstChild("EffectReplicator")
	if not effectReplicator then
		return internalNotifyFunction(timing, "No effect replicator found.")
	end

	local effectReplicatorModule = require(effectReplicator)
	if not effectReplicatorModule then
		return internalNotifyFunction(timing, "No effect replicator module found.")
	end

	if
		not timing.imb
		and root:FindFirstChild("MegalodauntBroken")
		and not players:GetPlayerFromCharacter(self.entity)
	then
		return internalNotifyFunction(timing, "Entity is block broken.")
	end

	if self:stopped(self.track, timing, options.notify) then
		return false
	end

	local hoptions = HitboxOptions.new(root, timing)
	hoptions.spredict = not timing.duih and not timing.dp
	hoptions.ptime = self:fsecs(timing)
	hoptions.action = action
	hoptions.entity = self.entity
	hoptions.visualize = options.visualize
	hoptions:ucache()

	local info = RepeatInfo.new(timing, Latency.rdelay(), self:uid(10))
	info.track = self.track

	local hc = self:hc(hoptions, timing.duih and info or nil)
	if hc then
		return true
	end

	local pc = self:fpc(timing, hoptions)
	if pc then
		return true
	end

	return self:notify(timing, "Not in hitbox.")
end)

---Update keyframe handling.
---@param self AnimatorDefender
AnimatorDefender.update = LPH_NO_VIRTUALIZE(function(self)
	for track, data in next, self.pbdata do
		-- Don't process tracks.
		if not Configuration.expectToggleValue("ShowAnimationVisualizer") then
			self.pbdata[track] = nil
			continue
		end

		-- Check if the track is playing.
		if not track.IsPlaying then
			-- Remove out of 'pbdata' and put it in to the recorded table.
			self.pbdata[track] = nil
			self.rpbdata[tostring(track.Animation.AnimationId)] = data

			-- Continue to next playback data.
			continue
		end

		-- Start tracking the animation's speed.
		data:astrack(track.Speed)
	end

	if not Configuration.expectToggleValue("AnimationSpeedChanger") then
		return
	end

	-- Animation speed changer.
	local min = Configuration.expectOptionValue("AnimationSpeedMinimum") or 1.0
	local max = Configuration.expectOptionValue("AnimationSpeedMaximum") or 1.3
	local rng = Random.new()

	for track, _ in next, self.sct do
		if not track.IsPlaying then
			self.sct[track] = nil
			self.tsc[track] = nil
			self.multiplier[track] = nil
			continue
		end

		if self.tsc[track] == tostring(track.Speed) then
			continue
		end

		local mode = rng:NextInteger(1, 2)
		local generated = nil

		if not self.multiplier[track] and not Configuration.expectToggleValue("SwitchBetweenSpeeds") then
			generated = rng:NextNumber(min, max)
		end

		if not self.multiplier[track] and Configuration.expectToggleValue("SwitchBetweenSpeeds") then
			generated = mode == 1 and min or max
		end

		if not self.multiplier[track] and generated then
			self.multiplier[track] = generated
		end

		local multiplier = self.multiplier[track]
		if not multiplier then
			continue
		end

		if multiplier == 1.0 then
			continue
		end

		local adjusted = track.Speed * multiplier

		track:AdjustSpeed(adjusted)

		self.tsc[track] = tostring(track.Speed)
	end
end)

---Virtualized processing checks.
---@param track AnimationTrack
---@return boolean
function AnimatorDefender:pvalidate(track)
	if Configuration.expectToggleValue("ValidateIncomingAnimations") then
		if track.Priority == Enum.AnimationPriority.Core then
			return false
		end

		local isComingFromPlayer = players:GetPlayerFromCharacter(self.entity)

		if isComingFromPlayer and track.WeightTarget <= 0.05 then
			return false
		end

		if isComingFromPlayer and self.manimations[track.Animation.AnimationId] ~= nil then
			Logger.warn(
				"(%s) Animation %s is being skipped from player %s because they're likely AP breaking.",
				self.manimations[track.Animation.AnimationId].Name,
				track.Animation.AnimationId,
				self.entity.Name
			)

			return false
		end

		local aid = tostring(track.Animation.AnimationId)

		-- Block abnormal animation speeds to prevent AP breaker spam.
		if track.Speed >= 1000 then
			Logger.warn("(%s) Blocked potential AP breaker from %s (speed: %.0fx)", aid, self.entity.Name, track.Speed)
			return
		end
	end

	return true
end

---Animation speed changer.
---@param self AnimatorDefender
---@param track AnimationTrack
AnimatorDefender.asc = LPH_NO_VIRTUALIZE(function(self, track)
	if not Configuration.expectToggleValue("AnimationSpeedChanger") then
		return
	end

	if
		Configuration.expectToggleValue("LimitToAPAnimations")
		and not SaveManager.as:index(tostring(track.Animation.AnimationId))
	then
		return
	end

	self.sct[track] = true
end)

---Process animation track.
---@todo: AP telemetry - aswell as tracking effects that are added with timestamps and current ping to that list.
---@param self AnimatorDefender
---@param track AnimationTrack
AnimatorDefender.process = LPH_NO_VIRTUALIZE(function(self, track)
	if players.LocalPlayer.Character and self.entity == players.LocalPlayer.Character then
		return self:asc(track)
	end

	if not self:pvalidate(track) then
		return
	end

	-- Animation ID.
	local aid = tostring(track.Animation.AnimationId)

	---@type AnimationTiming?
	local timing = self:initial(self.entity, SaveManager.as, self.entity.Name, aid)

	-- A bit of a hack, but it works.
	if timing ~= nil and Configuration.expectToggleValue("ShowAnimationVisualizer") then
		self.pbdata[track] = PlaybackData.new(self.entity)
	end

	if not timing then
		return
	end

	if not Configuration.expectToggleValue("EnableAutoDefense") then
		return
	end

	local humanoidRootPart = self.entity:FindFirstChild("HumanoidRootPart")
	if not humanoidRootPart then
		return
	end

	local effectReplicator = replicatedStorage:FindFirstChild("EffectReplicator")
	if not effectReplicator then
		return
	end

	local effectReplicatorModule = require(effectReplicator)
	if not effectReplicatorModule then
		return
	end

	if timing.tag == "Critical" then
		timing.nbfb = true
		timing.ha = true
	end

	---@note: Clean up previous tasks that are still waiting or suspended because they're in a different track.
	self:clean()

	-- Set current data.
	self.timing = timing
	self.track = track
	self.offset = Latency.rdelay()

	-- Use module over actions.
	if timing.umoa then
		return self:module(timing)
	end

	---@note: Start processing the timing. Add the actions if we're not RPUE.
	if not timing.rpue then
		return self:actions(timing)
	end

	-- Start RPUE.
	local info = RepeatInfo.new(timing, Latency.rdelay(), self:uid(10))
	info.track = track
	self:srpue(self.entity, timing, info)
end)

---Clean up the defender.
function AnimatorDefender:clean()
	-- Empty data.
	self.keyframes = {}

	-- Clean through base method.
	Defender.clean(self)
end

---Create new AnimatorDefender object.
---@param animator Animator
---@param manimations table<number, Animation>
---@return AnimatorDefender
function AnimatorDefender.new(animator, manimations)
	local entity = animator:FindFirstAncestorWhichIsA("Model")
	if not entity then
		return error(string.format("AnimatorDefender.new(%s) - no entity.", animator:GetFullName()))
	end

	local self = setmetatable(Defender.new(), AnimatorDefender)
	local animationPlayed = Signal.new(animator.AnimationPlayed)

	self.animator = animator
	self.manimations = manimations
	self.entity = entity

	self.track = nil
	self.timing = nil
	self.offset = nil

	self.keyframes = {}
	self.pbdata = {}
	self.rpbdata = {}
	self.sct = {}
	self.tsc = {}
	self.multiplier = {}

	self.maid:mark(animationPlayed:connect(
		"AnimatorDefender_OnAnimationPlayed",
		LPH_NO_VIRTUALIZE(function(track)
			self:process(track)
		end)
	))

	return self
end

-- Return AnimatorDefender module.
return AnimatorDefender

end)
__bundle_register("Game/Timings/PlaybackData", function(require, _LOADED, __bundle_register, __bundle_modules)
---@class PlaybackData
---@field base number Timestamp of when the object was created.
---@field ash table<number, number> Animation speed history. The key is the timestamp delta and the value is the speed at that point.
---@field entity Model Entity to playback.
local PlaybackData = {}
PlaybackData.__index = PlaybackData

---Get last exceeded speed difference from a timestamp delta.
---@param from number
---@return number?, number?
function PlaybackData:last(from)
	local latestExceededSpeed = nil
	local latestExceededDelta = nil

	for delta, speed in next, self.ash do
		if from <= delta then
			continue
		end

		if latestExceededDelta and delta <= latestExceededDelta then
			continue
		end

		latestExceededSpeed = speed
		latestExceededDelta = delta
	end

	return latestExceededSpeed, latestExceededDelta
end

---Track animation speed.
---@param speed number
function PlaybackData:astrack(speed)
	local delta = os.clock() - self.base

	if self:last(delta) == speed then
		return
	end

	self.ash[delta] = speed
end

---Create new PlaybackData object.
---@param entity Model
---@return PlaybackData
function PlaybackData.new(entity)
	local self = setmetatable({}, PlaybackData)
	self.base = os.clock()
	self.entity = entity

	---@note: Timestamp delta is how many seconds need to pass before being able to reach this speed.
	self.ash = {}

	return self
end

-- Return PlaybackData module.
return PlaybackData

end)
__bundle_register("Utility/ControlModule", function(require, _LOADED, __bundle_register, __bundle_modules)
return LPH_NO_VIRTUALIZE(function()
	-- This module is used for getting the proper input fly values - 1:1 with Aztup.
	local ControlModule = {
		forwardValue = 0,
		backwardValue = 0,
		leftValue = 0,
		rightValue = 0,
	}

	---@module Utility.Profiler
	local Profiler = require("Utility/Profiler")

	---@module Utility.Logger
	local Logger = require("Utility/Logger")

	---@module Utility.Maid
	local Maid = require("Utility/Maid")

	-- Maids.
	local controlMaid = Maid.new()

	-- Services.
	local ContextActionService = game:GetService("ContextActionService")

	---Bind action safely with maid, error, and profiler handling.
	---@param actionName string
	---@param callback function
	---@param createTouchButton boolean
	local function bindActionWrapper(actionName, callback, createTouchButton, ...)
		---Log bind action errors.
		---@param error string
		local function onBindActionWrapperError(error)
			Logger.trace("onBindActionWrapperError - (%s) - %s", actionName, error)
		end

		local actionWrapperCallback = callback
			and Profiler.wrap(string.format("ControlModule_BindActionWrapper_%s", actionName), function(...)
				local success, result = xpcall(callback, onBindActionWrapperError, ...)

				if not success then
					return nil
				end

				return result
			end)

		---@note: This is a hot-fix and should be handled properly in the future.
		controlMaid:add(function()
			ContextActionService:UnbindAction(actionName)
		end)

		ContextActionService:BindAction(actionName, actionWrapperCallback, createTouchButton, ...)
	end

	---Initialize control module.
	function ControlModule.init()
		bindActionWrapper("ControlModule_ForwardValue", function(_, inputState, _)
			ControlModule.forwardValue = (inputState == Enum.UserInputState.Begin) and -1 or 0
			return Enum.ContextActionResult.Pass
		end, false, Enum.KeyCode.W)

		bindActionWrapper("ControlModule_LeftValue", function(_, inputState, _)
			ControlModule.leftValue = (inputState == Enum.UserInputState.Begin) and -1 or 0
			return Enum.ContextActionResult.Pass
		end, false, Enum.KeyCode.A)

		bindActionWrapper("ControlModule_BackwardValue", function(_, inputState, _)
			ControlModule.backwardValue = (inputState == Enum.UserInputState.Begin) and 1 or 0
			return Enum.ContextActionResult.Pass
		end, false, Enum.KeyCode.S)

		bindActionWrapper("ControlModule_RightValue", function(_, inputState, _)
			ControlModule.rightValue = (inputState == Enum.UserInputState.Begin) and 1 or 0
			return Enum.ContextActionResult.Pass
		end, false, Enum.KeyCode.D)

		Logger.warn("ControlModule initialized.")
	end

	---Detach control module.
	function ControlModule.detach()
		controlMaid:clean()
		Logger.warn("ControlModule detached.")
	end

	---Get move vector.
	---@return Vector3
	function ControlModule.getMoveVector()
		return Vector3.new(
			ControlModule.leftValue + ControlModule.rightValue,
			0,
			ControlModule.forwardValue + ControlModule.backwardValue
		)
	end

	-- Return control module.
	return ControlModule
end)()

end)
__bundle_register("Features", function(require, _LOADED, __bundle_register, __bundle_modules)
-- Features related stuff is handled here.
local Features = {}

---@module Features.Automation.CharismaFarm
local CharismaFarm = require("Features/Automation/CharismaFarm")

---@module Features.Automation.InteligenceFarm
local IntelligenceFarm = require("Features/Automation/InteligenceFarm")

---@module Features.Game.Movement
local Movement = require("Features/Game/Movement")

---@module Features.Exploits.Exploits
local Exploits = require("Features/Exploits/Exploits")

---@module Features.Visuals.Visuals
local Visuals = require("Features/Visuals/Visuals")

---@module Features.Game.Removal
local Removal = require("Features/Game/Removal")

---@module Features.Game.Monitoring
local Monitoring = require("Features/Game/Monitoring")

---@module Features.Game.Spoofing
local Spoofing = require("Features/Game/Spoofing")

---@module Features.Game.OwnershipWatcher
local OwnershipWatcher = require("Features/Game/OwnershipWatcher")

---@module Utility.Logger
local Logger = require("Utility/Logger")

---@module Features.Combat.Defense
local Defense = require("Features/Combat/Defense")

---@module Features.Game.AnimationVisualizer
local AnimationVisualizer = require("Features/Game/AnimationVisualizer")

---@module Features.Automation.FishFarm
local FishFarm = require("Features/Automation/FishFarm")

---@module Features.Game.Teleport
local Teleport = require("Features/Game/Teleport")

---@module Features.Automation.AutoLoot
local AutoLoot = require("Features/Automation/AutoLoot")

---@module Game.AntiAFK
local AntiAFK = require("Game/AntiAFK")

---Initialize features.
---@note: Careful with features that have entire return LPH_NO_VIRTUALIZE(function() blocks. We assume that we don't care about what's placed in there.
function Features.init()
	Defense.init()
	Visuals.init()
	Movement.init()
	Monitoring.init()
	Removal.init()
	Exploits.init()
	Spoofing.init()
	OwnershipWatcher.init()
	CharismaFarm.init()
	IntelligenceFarm.init()
	FishFarm.init()
	Teleport.init()
	AutoLoot.init()
	AntiAFK.init()

	-- Only initialize if we're a builder.
	if not armorshield or armorshield.current_role == "builder" then
		AnimationVisualizer.init()
	end

	Logger.warn("Features initialized.")
end

---Detach features.
function Features.detach()
	-- Only detach if we're a builder.
	if not armorshield or armorshield.current_role == "builder" then
		AnimationVisualizer.detach()
	end

	Teleport.detach()
	AntiAFK.detach()
	FishFarm.detach()
	Defense.detach()
	CharismaFarm.detach()
	IntelligenceFarm.detach()
	Spoofing.detach()
	OwnershipWatcher.detach()
	Movement.detach()
	Removal.detach()
	Monitoring.detach()
	Exploits.detach()
	Visuals.detach()
	AutoLoot.detach()
	Logger.warn("Features detached.")
end

-- Return Features module.
return Features

end)
__bundle_register("Features/Game/Teleport", function(require, _LOADED, __bundle_register, __bundle_modules)
-- Teleport module.
---@note: Teleports in Deepwoken do not work the same. They lag you back, obviously. This is a utility module to handle repeatedly teleporting for a specific purpose.
local Teleport = { destination = nil, gdp = nil }

---@module Utility.Maid
local Maid = require("Utility/Maid")

---@module Utility.Signal
local Signal = require("Utility/Signal")

---@module Utility.TaskSpawner
local TaskSpawner = require("Utility/TaskSpawner")

---@module Utility.Configuration
local Configuration = require("Utility/Configuration")

-- Services.
local replicatedStorage = game:GetService("ReplicatedStorage")
local runService = game:GetService("RunService")
local players = game:GetService("Players")

-- Maids.
local tmaid = Maid.new()

---On player GUI descendant added.
---@param child Instance
local function onPlayerGuiDescendantAdded(child)
	if not child:IsA("TextLabel") then
		return
	end

	local coords = string.split(child.Text, ", ")
	local x, y, z = tonumber(coords[1]), tonumber(coords[2]), tonumber(coords[3])
	if not x or not y or not z then
		return
	end

	local position = Vector3.new(x, y, z)

	if (position - Vector3.new(-20000, 20000, -20000)).Magnitude <= 20 and Teleport.destination == "Voidheart" then
		return Teleport.stop()
	end

	if (position - Vector3.new(1596.1, 555.7, 2849.9)).Magnitude <= 20 and Teleport.destination == "LowerErisia" then
		return Teleport.stop()
	end

	if Teleport.gdp and (position - Teleport.gdp).Magnitude <= 20 and Teleport.destination == "GuildDoor" then
		return Teleport.stop()
	end
end

---Get guild doors from partial or exact name.
---@note: First instance is the entrance door. The second instance is the exit door.
---@param name string
---@return Instance?, Instance?
local function getGuildDoors(name)
	for _, instance in next, workspace:GetChildren() do
		if not instance.Name:match("GuildDoor") then
			continue
		end

		local guildName = instance:GetAttribute("GuildName")
		if not guildName then
			continue
		end

		if not guildName:lower():match(name:lower()) then
			continue
		end

		return instance, workspace:FindFirstChild(string.gsub(instance.Name, "GuildDoor", "GuildExitDoor"))
	end

	return nil
end

---Loop for teleport module.
local function onTeleportLoop()
	local dest = Teleport.destination
	if not dest then
		return
	end

	local localPlayer = players.LocalPlayer
	local character = localPlayer.Character
	if not character then
		return
	end

	if dest == "EasternLuminant" then
		tmaid:add(
			TaskSpawner.spawn(
				"Teleport_EasternLuminantStream",
				players.LocalPlayer.RequestStreamAroundAsync,
				players.LocalPlayer,
				Vector3.new(-2632.86084, 628.632935, -6707.99805),
				0.1
			)
		)

		local realmTeleporter = workspace:FindFirstChild("RealmTeleporter")
		if not realmTeleporter then
			return
		end

		character:PivotTo(realmTeleporter.CFrame)
	end

	if dest == "EtreanLuminant" then
		tmaid:add(
			TaskSpawner.spawn(
				"Teleport_EtreanLuminantStream",
				players.LocalPlayer.RequestStreamAroundAsync,
				players.LocalPlayer,
				Vector3.new(-514.263, 665.174316, -4772.3208),
				0.1
			)
		)

		local realmTeleporter = workspace:FindFirstChild("RealmTeleporter")
		if not realmTeleporter then
			return
		end

		character:PivotTo(realmTeleporter.CFrame)
	end

	if dest == "Depths" then
		tmaid:add(
			TaskSpawner.spawn(
				"Teleport_DepthsStream",
				players.LocalPlayer.RequestStreamAroundAsync,
				players.LocalPlayer,
				Vector3.new(39911.3672, 39980.9375, 39708.3203),
				0.1
			)
		)

		local modOffice = workspace:FindFirstChild("ModOffice")
		local officePit = modOffice and modOffice:FindFirstChild("OfficePit")
		if not officePit then
			return
		end

		character:PivotTo(officePit.CFrame)
	end

	if dest == "Voidheart" then
		tmaid:add(
			TaskSpawner.spawn(
				"Teleport_VoidheartStream",
				players.LocalPlayer.RequestStreamAroundAsync,
				players.LocalPlayer,
				Vector3.new(-20000.0, 19713.9609, -20000.0),
				0.1
			)
		)

		local voidheart = workspace:FindFirstChild("Voidheart")
		local voidheartVoidWarp = voidheart and voidheart:FindFirstChild("VoidheartVoidWarp")
		if not voidheartVoidWarp then
			return
		end

		character:PivotTo(CFrame.new(-20000.0, 19713.9609, -20000.0))
	end

	if dest == "TrialOfOne" then
		tmaid:add(
			TaskSpawner.spawn(
				"Teleport_TrialStream",
				players.LocalPlayer.RequestStreamAroundAsync,
				players.LocalPlayer,
				Vector3.new(-959.787659, 146.996887, -6659.63037),
				0.1
			)
		)

		local oneEntrance = workspace:FindFirstChild("OneEntrance")
		if not oneEntrance then
			return
		end

		local effectReplicator = replicatedStorage:FindFirstChild("EffectReplicator")
		if not effectReplicator then
			return
		end

		local effectReplicatorModule = require(effectReplicator)
		if not effectReplicatorModule then
			return
		end

		if effectReplicatorModule:FindEffect("Knocked") then
			return Teleport.stop()
		end

		character:PivotTo(oneEntrance.CFrame)
	end

	if dest == "GuildDoor" then
		local guildName = Configuration.expectOptionValue("GuildDoorName")
		if not guildName or #guildName <= 0 then
			return
		end

		local entranceDoor, exitDoor = getGuildDoors(guildName)
		if not entranceDoor or not exitDoor then
			return
		end

		local guildBaseCFrame = entranceDoor:GetAttribute("TargetCFrame")
		if not guildBaseCFrame then
			return
		end

		local guildDoorCFrame = exitDoor:GetAttribute("TargetCFrame")
		if not guildDoorCFrame then
			return
		end

		Teleport.gdp = guildDoorCFrame.Position

		-- Stream in the guild base.
		tmaid:add(
			TaskSpawner.spawn(
				"Teleport_GuildBaseStream",
				players.LocalPlayer.RequestStreamAroundAsync,
				players.LocalPlayer,
				guildBaseCFrame.Position,
				0.1
			)
		)

		-- Teleport over their bounds to trigger a forced game teleport.
		character:PivotTo(CFrame.new(guildBaseCFrame.Position - Vector3.new(0, 150, 0)))
	end
end

---Start teleport module.
---@param destination string
function Teleport.start(destination)
	if not destination then
		return error("Destination must be provided for teleporting.")
	end

	Teleport.destination = destination
end

---Stop teleport module.
function Teleport.stop()
	Teleport.destination = nil
end

---Initialize Teleport module.
function Teleport.init()
	local localPlayer = players.LocalPlayer
	local playerGui = localPlayer:WaitForChild("PlayerGui")
	local descendantAddedSignal = Signal.new(playerGui.DescendantAdded)
	tmaid:mark(descendantAddedSignal:connect("Teleport_PlayerGui_DescendantAdded", onPlayerGuiDescendantAdded))

	local renderStepped = Signal.new(runService.RenderStepped)
	tmaid:mark(renderStepped:connect("Teleport_RenderStepped", onTeleportLoop))
end

---Detach Teleport module.
function Teleport.detach()
	tmaid:clean()
end

-- Return Teleport module.
return Teleport

end)
__bundle_register("Features/Automation/FishFarm", function(require, _LOADED, __bundle_register, __bundle_modules)
-- Fish farming.
local FishFarm = {}

---@module Game.AntiAFK
local AntiAFK = require("Game/AntiAFK")

---@module Utility.Maid
local Maid = require("Utility/Maid")

---@module Utility.Signal
local Signal = require("Utility/Signal")

---@module Utility.Logger
local Logger = require("Utility/Logger")

---@module Utility.Configuration
local Configuration = require("Utility/Configuration")

-- Services.
local players = game:GetService("Players")
local runService = game:GetService("RunService")

-- Signals.
local renderStepped = Signal.new(runService.RenderStepped)

-- Maids.
local fishFarmMaid = Maid.new()

-- Timestamp.
local fishFarmTimestamp = os.clock()

-- State.
local wasActivated = false

---Update fish farm.
local function updateFishFarm()
	if os.clock() - fishFarmTimestamp < 0.1 then
		return
	end

	fishFarmTimestamp = os.clock()

	AntiAFK.stop("FishFarm")

	if not Configuration.expectToggleValue("AutoFish") then
		return
	end

	AntiAFK.start("FishFarm")

	local localPlayer = players.LocalPlayer
	local localPlayerCharacter = localPlayer.Character
	if not localPlayerCharacter then
		return
	end

	local humanoid = localPlayerCharacter:FindFirstChild("Humanoid")
	if not humanoid then
		return
	end

	local backpack = localPlayer:FindFirstChild("Backpack")
	if not backpack then
		return
	end

	local characterRod = localPlayerCharacter:FindFirstChild("Fishing Rod")
	local backpackRod = backpack:FindFirstChild("Fishing Rod")

	if not characterRod then
		return backpackRod and humanoid:EquipTool(backpackRod)
	end

	local handle = characterRod:FindFirstChild("Handle")
	local rod = handle and handle:FindFirstChild("Rod")
	local bobby = rod and rod:FindFirstChild("bobby")
	if not bobby then
		return
	end

	local addBait = characterRod:FindFirstChild("AddBait")
	if not addBait then
		return
	end

	---@todo: add fish meat lol
	local baitTable = {
		"Plumfruit",
		"Pomar",
		"Gobletto",
		"Squid",
		"Dentifilo",
		"Seaweed Bundle",
		"Urchin",
		"Browncap",
		"Chum",
		"Calabash",
		"Pufferfish",
		"Redd",
	}

	for _, baitName in next, baitTable do
		local bait = backpack:FindFirstChild(baitName)
		if not bait then
			continue
		end

		if bobby:FindFirstChild("bait") then
			break
		end

		return addBait:FireServer(bait)
	end

	local hook = bobby:FindFirstChild("hook")
	if not hook then
		return
	end

	if hook.Transparency ~= 1.0 then
		wasActivated = not wasActivated
		return wasActivated and characterRod:Deactivate() or characterRod:Activate()
	end

	local inputUpdate = characterRod:FindFirstChild("InputUpdate")
	if not inputUpdate then
		return
	end

	local playerGui = localPlayer:FindFirstChild("PlayerGui")
	if not playerGui then
		return
	end

	local fishingGui = playerGui:FindFirstChild("FishingGui")
	if not fishingGui or not fishingGui.Enabled then
		return
	end

	local mainFrame = fishingGui:FindFirstChild("MainFrame")
	if not mainFrame then
		return
	end

	local holdA = mainFrame:FindFirstChild("HoldA")
	local holdS = mainFrame:FindFirstChild("HoldS")
	local holdD = mainFrame:FindFirstChild("HoldD")
	if not holdA or not holdS or not holdD then
		return
	end

	inputUpdate:FireServer({
		a = holdA.Visible,
		s = holdS.Visible,
		d = holdD.Visible,
	})
end

---Fish farming.
function FishFarm.init()
	-- Attach the fish farm.
	fishFarmMaid:add(renderStepped:connect("FishFarm_RenderStepped", updateFishFarm))

	-- Log.
	Logger.warn("Fish Farm initialized.")
end

---Detach the fish farm.
function FishFarm.detach()
	-- Clean the maid.
	fishFarmMaid:clean()

	-- Log.
	Logger.warn("Fish Farm detached.")
end

-- Return FishFarm module.
return FishFarm

end)
__bundle_register("Features/Game/AnimationVisualizer", function(require, _LOADED, __bundle_register, __bundle_modules)
return LPH_NO_VIRTUALIZE(function()
	-- Animation visualizer module.
	---@note: This code is UI code. It is ugly on purpose and lazily made.
	local AnimationVisualizer = {}

	---@module Features.Combat.Defense
	local Defense = require("Features/Combat/Defense")

	---@module Utility.Signal
	local Signal = require("Utility/Signal")

	---@module Utility.Maid
	local Maid = require("Utility/Maid")

	---@module GUI.Library
	local Library = require("GUI/Library")

	---@module Utility.CoreGuiManager
	local CoreGuiManager = require("Utility/CoreGuiManager")

	-- Visualizer maid.
	local visualizerMaid = Maid.new()

	-- Services.
	local runService = game:GetService("RunService")
	local userInputService = game:GetService("UserInputService")
	local players = game:GetService("Players")

	local screenGui = CoreGuiManager.imark(Instance.new("ScreenGui"))
	screenGui.Name = "ScreenGui"
	screenGui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
	screenGui.Enabled = false

	local outer = Instance.new("Frame")
	outer.Name = "Outer"
	outer.BackgroundColor3 = Color3.new(1, 1, 1)
	outer.Position = UDim2.new(0.27, 0, 0.216, 0)
	outer.BorderColor3 = Color3.new()
	outer.Size = UDim2.new(0, 260, 0, 301.75)
	outer.ZIndex = 100
	outer.Parent = screenGui

	local inner = Instance.new("Frame")
	inner.Name = "Inner"
	inner.BackgroundColor3 = Library.MainColor
	inner.BorderMode = Enum.BorderMode.Inset
	inner.BorderColor3 = Library.OutlineColor
	inner.Size = UDim2.new(1, 0, 1, 0)
	inner.Parent = outer

	local animationVisualizer = Instance.new("TextLabel")
	animationVisualizer.Name = "AnimationVisualizer"
	animationVisualizer.FontFace = Font.new("rbxasset://fonts/families/RobotoMono.json")
	animationVisualizer.TextColor3 = Library.AccentColor
	animationVisualizer.Text = "Animation Visualizer"
	animationVisualizer.BackgroundColor3 = Color3.new()
	animationVisualizer.BorderSizePixel = 0
	animationVisualizer.BackgroundTransparency = 1
	animationVisualizer.Position = UDim2.new(0, 5, 0, 5)
	animationVisualizer.TextXAlignment = Enum.TextXAlignment.Left
	animationVisualizer.BorderColor3 = Color3.new()
	animationVisualizer.TextSize = 17
	animationVisualizer.Size = UDim2.new(1, 0, 0, 20)
	animationVisualizer.Parent = inner

	local sliderOuter = Instance.new("Frame")
	sliderOuter.Name = "SliderOuter"
	sliderOuter.BackgroundColor3 = Color3.new(1, 1, 1)
	sliderOuter.Position = UDim2.new(0.323, -78, 0.835, 24)
	sliderOuter.BorderColor3 = Color3.new()
	sliderOuter.BorderSizePixel = 0
	sliderOuter.Size = UDim2.new(0, 247, 0, 15)
	sliderOuter.Parent = inner

	local sliderText = Instance.new("TextLabel")
	sliderText.Name = "SliderText"
	sliderText.FontFace = Font.new("rbxasset://fonts/families/RobotoMono.json")
	sliderText.TextColor3 = Library.FontColor
	sliderText.Text = "0.000 / ? (?ms)"
	sliderText.BackgroundTransparency = 1
	sliderText.BackgroundColor3 = Color3.new(1, 1, 1)
	sliderText.BorderSizePixel = 0
	sliderText.BorderColor3 = Color3.new()
	sliderText.TextSize = 12
	sliderText.ZIndex = 12
	sliderText.Size = UDim2.new(1, 0, 1, 0)
	sliderText.Parent = sliderOuter

	local sliderFill = Instance.new("Frame")
	sliderFill.Name = "SliderFill"
	sliderFill.BorderMode = Enum.BorderMode.Inset
	sliderFill.BorderColor3 = Library.AccentColorDark
	sliderFill.BackgroundColor3 = Library.AccentColor
	sliderFill.Size = UDim2.new(0, 1, 1, 0)
	sliderFill.ZIndex = 10
	sliderFill.Parent = sliderOuter

	local hideBorderRight = Instance.new("Frame")
	hideBorderRight.Name = "HideBorderRight"
	hideBorderRight.BackgroundColor3 = Library.AccentColor
	hideBorderRight.Position = UDim2.new(1, 0, 0, 0)
	hideBorderRight.BorderColor3 = Color3.new()
	hideBorderRight.BorderSizePixel = 0
	hideBorderRight.Size = UDim2.new(0, 1, 1, 0)
	hideBorderRight.Parent = sliderFill
	hideBorderRight.Visible = false

	local sliderInner = Instance.new("Frame")
	sliderInner.Name = "SliderInner"
	sliderInner.BorderColor3 = Color3.new()
	sliderInner.BackgroundColor3 = Library.MainColor
	sliderInner.Size = UDim2.new(1, 0, 1, 0)
	sliderInner.Parent = sliderOuter

	local frameBackwards = Instance.new("TextButton")
	frameBackwards.Name = "FrameBackwards"
	frameBackwards.FontFace = Font.new("rbxasset://fonts/families/SourceSansPro.json")
	frameBackwards.TextColor3 = Color3.new()
	frameBackwards.Text = ""
	frameBackwards.Position = UDim2.new(0.323, -78, 0.835, -2)
	frameBackwards.BackgroundColor3 = Library.MainColor
	frameBackwards.BorderColor3 = Color3.new()
	frameBackwards.TextSize = 14
	frameBackwards.Size = UDim2.new(0, 70, 0, 20)
	frameBackwards.Parent = inner

	local icon = Instance.new("ImageLabel")
	icon.Name = "Icon"
	icon.ScaleType = Enum.ScaleType.Crop
	icon.BorderColor3 = Color3.new()
	icon.BackgroundColor3 = Library.FontColor
	icon.Image = "rbxassetid://10734961526"
	icon.BackgroundTransparency = 1
	icon.Position = UDim2.new(0.5, -8, 0.5, -8)
	icon.SizeConstraint = Enum.SizeConstraint.RelativeXX
	icon.BorderSizePixel = 0
	icon.Size = UDim2.new(0, 16, 0, 16)
	icon.Parent = frameBackwards

	local playStop = Instance.new("TextButton")
	playStop.Name = "PlayStop"
	playStop.FontFace = Font.new("rbxasset://fonts/families/SourceSansPro.json")
	playStop.TextColor3 = Color3.new()
	playStop.BorderColor3 = Color3.new()
	playStop.Text = ""
	playStop.Position = UDim2.new(0.323, 0, 0.835, -2)
	playStop.BackgroundColor3 = Library.MainColor
	playStop.TextSize = 14
	playStop.Size = UDim2.new(0, 91, 0, 20)
	playStop.Parent = inner

	local iconTwo = Instance.new("ImageLabel")
	iconTwo.Name = "Icon"
	iconTwo.BorderColor3 = Color3.new()
	iconTwo.BackgroundColor3 = Library.FontColor
	iconTwo.Image = "rbxassetid://10734919336"
	iconTwo.BackgroundTransparency = 1
	iconTwo.Position = UDim2.new(0.5, -8, 0.5, -8)
	iconTwo.SizeConstraint = Enum.SizeConstraint.RelativeXX
	iconTwo.BorderSizePixel = 0
	iconTwo.Size = UDim2.new(0, 16, 0, 16)
	iconTwo.Parent = playStop

	local viewportFrame = Instance.new("ViewportFrame")
	viewportFrame.Name = "ViewportFrame"
	viewportFrame.Visible = false
	viewportFrame.BorderMode = Enum.BorderMode.Inset
	viewportFrame.LightColor = Color3.new(0.549, 0.525, 0.435)
	viewportFrame.Ambient = Color3.new(0.318, 0.318, 0.318)
	viewportFrame.Position = UDim2.new(0, 4, 0, 26)
	viewportFrame.BackgroundColor3 = Library.MainColor
	viewportFrame.BorderColor3 = Color3.new()
	viewportFrame.Size = UDim2.new(1, -8, 0, 195)
	viewportFrame.Parent = inner

	local worldModel = Instance.new("WorldModel", viewportFrame)

	local camera = Instance.new("Camera", viewportFrame)
	camera.CameraType = Enum.CameraType.Scriptable
	camera.FieldOfView = 70

	local speedText = Instance.new("TextLabel")
	speedText.Name = "SpeedText"
	speedText.FontFace = Font.new("rbxasset://fonts/families/RobotoMono.json")
	speedText.TextColor3 = Library.FontColor
	speedText.Text = "Speed (???)"
	speedText.BackgroundTransparency = 1
	speedText.BackgroundColor3 = Color3.new(1, 1, 1)
	speedText.BorderSizePixel = 0
	speedText.BorderColor3 = Color3.new()
	speedText.TextSize = 12
	speedText.Size = UDim2.new(0, 82, 0, 20)
	speedText.ZIndex = 19
	speedText.Parent = viewportFrame

	local noViewportFrame = Instance.new("Frame")
	noViewportFrame.Name = "NoViewportFrame"
	noViewportFrame.BackgroundColor3 = Library.MainColor
	noViewportFrame.Position = UDim2.new(0, 4, 0, 26)
	noViewportFrame.BorderColor3 = Color3.new()
	noViewportFrame.BorderMode = Enum.BorderMode.Inset
	noViewportFrame.Size = UDim2.new(1, -8, 0, 195)
	noViewportFrame.Parent = inner

	local textLabel = Instance.new("TextLabel")
	textLabel.Name = "TextLabel"
	textLabel.FontFace = Font.new("rbxasset://fonts/families/RobotoMono.json")
	textLabel.TextColor3 = Library.FontColor
	textLabel.BorderColor3 = Color3.new()
	textLabel.Text = "Unknown Error"
	textLabel.BackgroundColor3 = Color3.new(1, 1, 1)
	textLabel.BorderSizePixel = 0
	textLabel.BackgroundTransparency = 1
	textLabel.Position = UDim2.new(0.0968, 0, 0.369, 0)
	textLabel.TextWrapped = true
	textLabel.TextSize = 14
	textLabel.Size = UDim2.new(0, 200, 0, 50)
	textLabel.Parent = noViewportFrame

	local color = Instance.new("Frame")
	color.Name = "Color"
	color.BackgroundColor3 = Library.AccentColor
	color.BorderColor3 = Color3.new()
	color.BorderSizePixel = 0
	color.Size = UDim2.new(1, 0, 0, 2)
	color.Parent = inner

	local frameForwards = Instance.new("TextButton")
	frameForwards.Name = "FrameForwards"
	frameForwards.FontFace = Font.new("rbxasset://fonts/families/SourceSansPro.json")
	frameForwards.TextColor3 = Color3.new()
	frameForwards.Text = ""
	frameForwards.Position = UDim2.new(0.323, 99, 0.835, -2)
	frameForwards.BackgroundColor3 = Library.MainColor
	frameForwards.BorderColor3 = Color3.new()
	frameForwards.TextSize = 14
	frameForwards.Size = UDim2.new(0, 69, 0, 20)
	frameForwards.Parent = inner

	local iconThree = Instance.new("ImageLabel")
	iconThree.Name = "Icon"
	iconThree.ScaleType = Enum.ScaleType.Crop
	iconThree.BorderColor3 = Color3.new()
	iconThree.BackgroundColor3 = Library.FontColor
	iconThree.Image = "rbxassetid://10734961809"
	iconThree.BackgroundTransparency = 1
	iconThree.Position = UDim2.new(0.5, -8, 0.5, -8)
	iconThree.SizeConstraint = Enum.SizeConstraint.RelativeXX
	iconThree.BorderSizePixel = 0
	iconThree.Size = UDim2.new(0, 16, 0, 16)
	iconThree.Parent = frameForwards

	local animationTextbox = Instance.new("TextBox")
	animationTextbox.Name = "AnimationTextbox"
	animationTextbox.CursorPosition = -1
	animationTextbox.TextColor3 = Library.FontColor
	animationTextbox.Text = "rbxassetid://0"
	animationTextbox.BackgroundColor3 = Library.MainColor
	animationTextbox.Position = UDim2.new(0.323, -78, 0.835, -24)
	animationTextbox.BorderColor3 = Color3.new()
	animationTextbox.FontFace = Font.new("rbxasset://fonts/families/RobotoMono.json")
	animationTextbox.TextSize = 14
	animationTextbox.Size = UDim2.new(0, 246, 0, 15)
	animationTextbox.Parent = inner

	-- Current data for playback loop.
	local currentPlaybackData = nil
	local currentTrack = nil
	local isPaused = false
	local timeElapsed = 0.0

	---Map slider value.
	---@param value number
	---@param min number
	---@param max number
	---@param minSize number
	---@param maxSize number
	local function mapSliderValue(value, min, max, minSize, maxSize)
		return (1 - ((value - min) / (max - min))) * minSize + ((value - min) / (max - min)) * maxSize
	end

	---On Animation ID focus lost.
	---@param enter boolean
	---@param _ InputObject
	local function onIdFocusLost(enter, _)
		if not enter then
			return
		end

		-- Empty out previous data.
		currentTrack = nil
		currentPlaybackData = nil

		---@type PlaybackData
		local playbackData = Defense.agpd(animationTextbox.Text)
		if not playbackData then
			return AnimationVisualizer.message("No Playback Data Found")
		end

		-- Remove all previously loaded models.
		for _, descendant in next, viewportFrame:GetDescendants() do
			if descendant.ClassName ~= "Model" then
				continue
			end

			descendant:Destroy()
		end

		-- Load the model & center it.
		local entity = playbackData.entity:Clone()
		entity.Parent = worldModel
		entity:PivotTo(CFrame.new(0, 0, 0))

		-- Fetch the primary part. If it does not exist, then the entity has been unloaded.
		if not entity.PrimaryPart then
			return AnimationVisualizer.message("No Primary Part Found")
		end

		-- Setup camera.
		local _, bbs = entity:GetBoundingBox()
		camera.CFrame =
			CFrame.lookAt(entity.PrimaryPart.Position - Vector3.new(0, 0, bbs.Magnitude), entity.PrimaryPart.Position)

		-- Fetch animator.
		local animator = entity:FindFirstChildWhichIsA("Animator", true)
		if not animator then
			return AnimationVisualizer.message("No Animator Found")
		end

		-- Stop previous animations.
		for _, track in next, animator:GetPlayingAnimationTracks() do
			track:Stop()
		end

		-- Create animation.
		local animation = Instance.new("Animation")
		animation.AnimationId = animationTextbox.Text

		-- Store current data for playback.
		currentPlaybackData = playbackData
		currentTrack = animator:LoadAnimation(animation)

		-- Play animation and keep it at zero speed.
		currentTrack:Play(0.0, 100, 0.0)
		currentTrack.Priority = Enum.AnimationPriority.Action
		currentTrack.Looped = true
		visualizerMaid:mark(currentTrack.DidLoop:Connect(function()
			timeElapsed = 0.0
		end))

		-- Reset time elapsed.
		timeElapsed = 0.0

		-- Show frames.
		viewportFrame.Visible = true
		noViewportFrame.Visible = false
	end

	---Get time elapsed from time position.
	---@param timePosition number
	---@param animationLength number
	---@return number?
	local function getTimeElapsedFromTp(timePosition, animationLength)
		if not currentPlaybackData then
			return nil
		end

		if timePosition <= 0 then
			return 0.0
		end

		-- Numerical integration to find elapsed time.
		local currentPos = 0
		local elapsed = 0
		local dt = 0.01
		local iterations = 0

		while currentPos < timePosition do
			local speed = currentPlaybackData:last(elapsed) or 1
			local stepSize = speed * dt

			iterations = iterations + 1

			---@note: We can calculate how many iterations this should likely take based on the length (e.g 4 seconds) of the animation.
			--- Since we have a delta time of 0.01s, that means we can multiply the length by 100 to get our iteration amount.
			--- Then, we should multiply that number by 10 to act as a buffer. At minimum, we'll allow for 1000 iterations.
			if iterations >= math.max(((animationLength * 100) * 10), 1000) then
				break
			end

			-- If adding the full step would exceed the target position, calculate partial step and break.
			if currentPos + stepSize > timePosition then
				local remainingTime = (timePosition - currentPos) / speed
				elapsed = elapsed + remainingTime
				break
			end

			currentPos = currentPos + stepSize
			elapsed = elapsed + dt
		end

		-- Return the elapsed time.
		return elapsed
	end

	---On playback loop.
	---@param delta number
	local function onPlaybackLoop(delta)
		if not screenGui.Enabled then
			return
		end

		iconTwo.Image = isPaused and "rbxassetid://10734923549" or "rbxassetid://10734919336"

		-- Run slider calculations.
		local mhs = sliderOuter.AbsoluteSize.X
		local hs = currentTrack and mapSliderValue(currentTrack.TimePosition, 0.0, currentTrack.Length, 0, mhs) or 0.0

		-- Update slider text.
		sliderText.Text = (currentTrack and currentPlaybackData)
				and string.format(
					"%.3f/%.3f (%ims)",
					currentTrack.TimePosition,
					currentTrack.Length,
					math.round((getTimeElapsedFromTp(currentTrack.TimePosition, currentTrack.Length) or 0.0) * 1000)
				)
			or "0.000 / ??? (???ms)"

		-- Update size.
		sliderFill.Visible = not (hs == 0)
		sliderFill.Size = UDim2.new(0, math.max(math.ceil(hs), 1), 1, 0)
		hideBorderRight.Visible = not (hs == mhs or hs == 0)

		-- Update speed amount.
		speedText.Text = currentTrack and string.format("Speed (%.2f)", currentTrack.Speed) or "Speed (???)"

		if currentTrack and isPaused then
			speedText.Text = string.format(
				"Speed (%.2f)",
				currentPlaybackData:last(getTimeElapsedFromTp(currentTrack.TimePosition, currentTrack.Length) or 0.0)
					or 0.0
			)
		end

		if not currentTrack or not currentPlaybackData then
			return
		end

		if isPaused then
			return currentTrack:AdjustSpeed(0.0)
		end

		timeElapsed = timeElapsed + delta

		currentTrack:AdjustSpeed(currentPlaybackData:last(timeElapsed) or 0.0)
	end

	---Toggle play stop function.
	local function togglePlayStop()
		if not currentTrack then
			return
		end

		if not currentTrack.IsPlaying then
			return
		end

		isPaused = not isPaused
	end

	---Go backwards one frame.
	local function onFrameBackwards()
		if not currentTrack then
			return
		end

		currentTrack.TimePosition = math.max(currentTrack.TimePosition - 0.01, 0)
	end

	---Go forwards one frame.
	local function onFrameForwards()
		if not currentTrack then
			return
		end

		currentTrack.TimePosition = math.min(currentTrack.TimePosition + 0.01, currentTrack.Length)
	end

	---On slider input began.
	---@param input InputObject
	---@param gameProcessed boolean
	local function onSliderInputBegan(input, gameProcessed)
		if gameProcessed then
			return
		end

		if input.UserInputType ~= Enum.UserInputType.MouseButton1 then
			return
		end

		while screenGui.Enabled and userInputService:IsMouseButtonPressed(Enum.UserInputType.MouseButton1) do
			if not currentTrack then
				return
			end

			-- Pause track.
			isPaused = true

			-- Calculate new time position.
			local mouse = players.LocalPlayer:GetMouse()
			local sliderOuterSize = sliderOuter.AbsoluteSize.X
			local mouseX = math.clamp(mouse.X - sliderOuter.AbsolutePosition.X, 0, sliderOuterSize)
			local newTimePosition = mapSliderValue(mouseX, 0, sliderOuterSize, 0, currentTrack.Length)

			-- Update time position.
			currentTrack.TimePosition = newTimePosition

			-- Wait.
			runService.PreRender:Wait()
		end

		timeElapsed = getTimeElapsedFromTp(currentTrack.TimePosition, currentTrack.Length) or 0.0
	end

	---Outer input began.
	---@param input InputObject
	---@param gameProcessed boolean
	local function outerFrameInputBegan(input, gameProcessed)
		if gameProcessed then
			return
		end

		if input.KeyCode == Enum.KeyCode.Space then
			return togglePlayStop()
		end

		if input.KeyCode == Enum.KeyCode.Right then
			return onFrameForwards()
		end

		if input.KeyCode == Enum.KeyCode.Left then
			return onFrameBackwards()
		end
	end

	---Set the visibility of the AnimationVisualizer.
	---@param state boolean
	function AnimationVisualizer.visible(state)
		screenGui.Enabled = state
	end

	---Show a message.
	---@param message string
	function AnimationVisualizer.message(message)
		viewportFrame.Visible = false
		noViewportFrame.Visible = true
		textLabel.Text = message
	end

	---Initialize AnimationVisualizer module.
	function AnimationVisualizer.init()
		-- Initialize GUI.
		screenGui.Name = "AnimationVisualizer"
		screenGui.Enabled = false
		screenGui.DisplayOrder = 1

		-- Make draggable.
		Library:MakeDraggable(outer)

		-- Setup colors.
		Library:AddToRegistry(color, {
			BackgroundColor3 = "AccentColor",
		}, true)

		Library:AddToRegistry(animationVisualizer, {
			TextColor3 = "AccentColor",
		}, true)

		Library:AddToRegistry(hideBorderRight, {
			BackgroundColor3 = "AccentColor",
		}, true)

		Library:AddToRegistry(sliderFill, {
			BackgroundColor3 = "AccentColor",
		}, true)

		Library:AddToRegistry(inner, {
			BackgroundColor3 = "MainColor",
			BorderColor3 = "OutlineColor",
		}, true)

		Library:AddToRegistry(playStop, {
			BackgroundColor3 = "MainColor",
			BorderColor3 = "Black",
		}, true)

		Library:AddToRegistry(animationTextbox, {
			BackgroundColor3 = "MainColor",
			BorderColor3 = "Black",
			TextColor3 = "FontColor",
		}, true)

		Library:AddToRegistry(icon, {
			ImageColor3 = "FontColor",
		}, true)

		Library:AddToRegistry(iconTwo, {
			ImageColor3 = "FontColor",
		}, true)

		Library:AddToRegistry(iconThree, {
			ImageColor3 = "FontColor",
		}, true)

		Library:AddToRegistry(textLabel, {
			TextColor3 = "FontColor",
		}, true)

		Library:AddToRegistry(speedText, {
			TextColor3 = "FontColor",
		}, true)

		Library:AddToRegistry(noViewportFrame, {
			BackgroundColor3 = "MainColor",
			BorderColor3 = "Black",
		}, true)

		Library:AddToRegistry(frameBackwards, {
			BackgroundColor3 = "MainColor",
			BorderColor3 = "Black",
		}, true)

		Library:AddToRegistry(frameForwards, {
			BackgroundColor3 = "MainColor",
			BorderColor3 = "Black",
		}, true)

		Library:AddToRegistry(viewportFrame, {
			BackgroundColor3 = "MainColor",
			BorderColor3 = "Black",
		}, true)

		Library:AddToRegistry(sliderOuter, {
			BorderColor3 = "Black",
		}, true)

		Library:AddToRegistry(sliderInner, {
			BackgroundColor3 = "MainColor",
			BorderColor3 = "Black",
		}, true)

		Library:AddToRegistry(sliderFill, {
			BackgroundColor3 = "AccentColor",
			BorderColor3 = "AccentColorDark",
		}, true)

		Library:AddToRegistry(hideBorderRight, {
			BackgroundColor3 = "AccentColor",
		}, true)

		Library:AddToRegistry(sliderText, {
			TextColor3 = "FontColor",
		}, true)

		-- Setup camera.
		viewportFrame.CurrentCamera = camera

		-- Setup intro scene.
		AnimationVisualizer.message("Waiting For Animation ID")

		-- Setup signals.
		local idFocusLost = Signal.new(animationTextbox.FocusLost)
		local preRender = Signal.new(runService.PreRender)
		local playStopClicked = Signal.new(playStop.MouseButton1Click)
		local outerInputBegan = Signal.new(outer.InputBegan)
		local frameBackwardsClick = Signal.new(frameBackwards.MouseButton1Click)
		local frameForwardsClick = Signal.new(frameForwards.MouseButton1Click)
		local sliderInputBegan = Signal.new(sliderOuter.InputBegan)

		visualizerMaid:add(sliderInputBegan:connect("AnimationVisualizer_SliderInputBegan", onSliderInputBegan))
		visualizerMaid:add(frameForwardsClick:connect("AnimationVisualizer_FrameForwardsClick", onFrameForwards))
		visualizerMaid:add(frameBackwardsClick:connect("AnimationVisualizer_FrameBackwardsClick", onFrameBackwards))
		visualizerMaid:add(outerInputBegan:connect("AnimationVisualizer_OuterInputBegan", outerFrameInputBegan))
		visualizerMaid:add(playStopClicked:connect("AnimationVisualizer_PlayStopClicked", togglePlayStop))
		visualizerMaid:add(preRender:connect("AnimationVisualizer_PlaybackLoop", onPlaybackLoop))
		visualizerMaid:add(idFocusLost:connect("AnimationVisualizer_IdFocusLost", onIdFocusLost))

		-- Add outer frame to library.
		Library.AnimationVisualizerFrame = outer
	end

	---Detach AnimationVisualizer module.
	function AnimationVisualizer.detach()
		visualizerMaid:clean()
	end

	-- Return AnimationVisualizer module.
	return AnimationVisualizer
end)()

end)
__bundle_register("Features/Game/OwnershipWatcher", function(require, _LOADED, __bundle_register, __bundle_modules)
-- Ownership data.
local clientPart = Instance.new("Part", workspace)
local clientSuccess, clientPeerId = pcall(function()
	return gethiddenproperty(clientPart, "NetworkOwnerV3")
end)

clientPart:Destroy()

---Check for network ownership.
---@param part BasePart
---@return boolean
local function hasNetworkOwnership(part)
	local exploitFallback = isnetworkowner or function(...)
		return false
	end

	if getexecutorname():match("AWP") then
		return exploitFallback(part)
	end

	if getexecutorname():match("Volcano") then
		return exploitFallback(part)
	end

	if not clientSuccess then
		return exploitFallback(part)
	end

	local partSuccess, partPeerId = pcall(function()
		return gethiddenproperty(part, "NetworkOwnerV3")
	end)

	if not partSuccess then
		return exploitFallback(part)
	end

	return partPeerId == clientPeerId
end

return LPH_NO_VIRTUALIZE(function()
	-- Ownership watcher module.
	local OwnershipWatcher = { modelsToScan = {}, parts = {} }

	-- Services
	local runService = game:GetService("RunService")

	---@module Utility.Maid
	local Maid = require("Utility/Maid")

	---@module Utility.Configuration
	local Configuration = require("Utility/Configuration")

	---@module Utility.Signal
	local Signal = require("Utility/Signal")

	---@module Utility.InstanceWrapper
	local InstanceWrapper = require("Utility/InstanceWrapper")

	---@module Utility.Logger
	local Logger = require("Utility/Logger")

	---@module Features.Automation.EchoFarm
	local EchoFarm = require("Features/Automation/EchoFarm")

	-- Signals.
	local renderStepped = Signal.new(runService.RenderStepped)

	-- Maids.
	local ownershipMaid = Maid.new()

	---Clean up parts. Every model to scan has a maid linked to it.
	local function cleanParts()
		for _, maid in next, OwnershipWatcher.modelsToScan do
			maid:clean()
		end
	end

	---Add live characters to ownership watcher.
	---@param character Model
	local function onLiveAdded(character)
		if not character:IsA("Model") then
			return
		end

		if OwnershipWatcher.modelsToScan[character] then
			return
		end

		OwnershipWatcher.modelsToScan[character] = Maid.new()
	end

	---Remove live characters from ownership watcher.
	---@param character Model
	local function onLiveRemoved(character)
		if not OwnershipWatcher.modelsToScan[character] then
			return
		end

		OwnershipWatcher.modelsToScan[character]:clean()
		OwnershipWatcher.modelsToScan[character] = nil
	end

	---Update ownership.
	local function updateOwnership()
		---@optimization: Stop updating when we don't need it.
		if
			not Configuration.expectToggleValue("ShowOwnership")
			and not Configuration.expectToggleValue("VoidMobs")
			and not EchoFarm.voiding
		then
			return cleanParts()
		end

		-- Create an update table.
		local updateTable = {}

		-- Add models.
		for model, maid in next, OwnershipWatcher.modelsToScan do
			local humanoidRootPart = model:FindFirstChild("HumanoidRootPart")
			if not humanoidRootPart then
				continue
			end

			-- Check if owner.
			local isNetworkOwner = hasNetworkOwnership(humanoidRootPart)

			-- Visualization.
			local netVisual = InstanceWrapper.create(maid, "NetworkVisual", "Part", model)
			netVisual.Size = Vector3.new(10, 10, 10)
			netVisual.Transparency = Configuration.expectToggleValue("ShowOwnership") and 0.8 or 1.0
			netVisual.Color = isNetworkOwner and Color3.fromRGB(0, 255, 0) or Color3.fromRGB(255, 0, 0)
			netVisual.CFrame = humanoidRootPart.CFrame
			netVisual.Anchored = true
			netVisual.CanCollide = false

			-- Part data.
			local data = OwnershipWatcher.parts[humanoidRootPart]
				or {
					owned = isNetworkOwner,
					model = model,
				}

			-- Update part data.
			data.owned = isNetworkOwner
			data.model = model

			-- Set in global part list.
			OwnershipWatcher.parts[humanoidRootPart] = data

			-- Set in map.
			updateTable[humanoidRootPart] = data
		end

		-- Override global part list with the new update table.
		---@note: This will get rid of any parts that were not updated (e.g no longer existing root part or not in model list) upon cycle.
		---@todo: Fix me - this is a bit of a hack.
		OwnershipWatcher.parts = updateTable
	end

	---Get table of watched parts along with a mapping to extra data.
	---@return table<BasePart, table>
	function OwnershipWatcher.get()
		return OwnershipWatcher.parts
	end

	---Iniitalize OwnershipWatcher module.
	function OwnershipWatcher.init()
		local live = workspace:WaitForChild("Live")
		local liveChildAdded = Signal.new(live.ChildAdded)
		local liveChildRemoved = Signal.new(live.ChildRemoved)

		ownershipMaid:add(liveChildAdded:connect("OwnershipWatcher_OnLiveChildAdded", onLiveAdded))
		ownershipMaid:add(liveChildRemoved:connect("OwnershipWatcher_OnLiveChildRemoved", onLiveRemoved))
		ownershipMaid:add(renderStepped:connect("OwnershipWatcher_RenderStepped", updateOwnership))

		for _, entity in next, live:GetChildren() do
			onLiveAdded(entity)
		end

		Logger.warn("OwnershipWatcher initialized.")
	end

	---Detach OwnershipWatcher module.
	function OwnershipWatcher.detach()
		-- Clean up ownership maids.
		ownershipMaid:clean()

		-- Clean up parts.
		cleanParts()

		-- Log.
		Logger.warn("OwnershipWatcher detached.")
	end

	-- Return OwnershipWatcher module.
	return OwnershipWatcher
end)()

end)
__bundle_register("Utility/InstanceWrapper", function(require, _LOADED, __bundle_register, __bundle_modules)
-- Instance wrapper module - used for continously updating functions that require instances.
local InstanceWrapper = {}

-- Services.
local collectionService = game:GetService("CollectionService")

---@module Utility.Signal
local Signal = require("Utility/Signal")

---Cache an instance, clean the instance up through a maid, and automatically uncache on deletion.
---@param instanceMaid Maid
---@param identifier any
---@param inst Instance
---@return Instance
InstanceWrapper.mark = LPH_NO_VIRTUALIZE(function(instanceMaid, identifier, inst)
	local maidInstance = instanceMaid[identifier]
	if maidInstance then
		return maidInstance
	end

	local onAncestorChange = Signal.new(inst.AncestryChanged)

	if inst:IsA("BodyVelocity") then
		collectionService:AddTag(inst, "AllowedBM")
	end

	instanceMaid[identifier] = inst
	instanceMaid:add(onAncestorChange:connect("Instance_OnAncestorChange", function(_)
		if inst:IsDescendantOf(game) then
			return
		end

		instanceMaid:removeTask(identifier)
	end))

	return inst
end)

---Create & cache an instance, clean the instance up through a maid, and automatically uncache on deletion.
---@param instanceMaid Maid
---@param identifier any
---@param type string
---@param parent Instance?
---@return Instance
InstanceWrapper.create = LPH_NO_VIRTUALIZE(function(instanceMaid, identifier, type, parent)
	local maidInstance = instanceMaid[identifier]
	if maidInstance then
		return maidInstance
	end

	local newInstance = Instance.new(type, parent)
	local onAncestorChange = Signal.new(newInstance.AncestryChanged)

	if newInstance:IsA("BodyVelocity") then
		collectionService:AddTag(newInstance, "AllowedBM")
	end

	instanceMaid[identifier] = newInstance
	instanceMaid:add(onAncestorChange:connect("Instance_OnAncestorChange", function(_)
		if newInstance:IsDescendantOf(game) then
			return
		end

		instanceMaid:removeTask(identifier)
	end))

	return newInstance
end)

-- Return InstanceWrapper module
return InstanceWrapper

end)
__bundle_register("Features/Game/Spoofing", function(require, _LOADED, __bundle_register, __bundle_modules)
return LPH_NO_VIRTUALIZE(function()
	---@module Utility.Maid
	local Maid = require("Utility/Maid")

	---@module Utility.Signal
	local Signal = require("Utility/Signal")

	---@module Utility.Configuration
	local Configuration = require("Utility/Configuration")

	---@module Utility.Logger
	local Logger = require("Utility/Logger")

	---@module Utility.OriginalStoreManager
	local OriginalStoreManager = require("Utility/OriginalStoreManager")

	-- Spoofing module.
	---@note: Replace (e.g Konga Clutch Ring Spoofer) with Talent Spoofer & Instance Spoofer in the future.
	local Spoofing = { force = false }

	-- Services.
	local runService = game:GetService("RunService")
	local starterGui = game:GetService("StarterGui")
	local players = game:GetService("Players")
	local collectionService = game:GetService("CollectionService")
	local replicatedStorage = game:GetService("ReplicatedStorage")

	-- Signals.
	local renderStepped = Signal.new(runService.RenderStepped)

	-- Maid.
	local spoofingMaid = Maid.new()

	-- Original store managers.
	local infoSpoofMap = spoofingMaid:mark(OriginalStoreManager.new())

	-- Konga's clutch ring instance.
	local fakeKongaClutchRing = Instance.new("Folder")
	fakeKongaClutchRing.Name = "Ring:Konga's Clutch Ring"

	-- Freestyler's band instance.
	local fakeFreestylerBand = Instance.new("Folder")
	fakeFreestylerBand.Name = "Ring:Freestyler's Band"

	-- Timestamp.
	local lastTimestampRun = os.clock()

	-- Variables.
	local originalTags = nil

	-- Constants.
	local EXPECTED_EMOTE_CHILDREN = 20 + 1
	local EMOTE_SPOOFER_TAGS = {
		"EmotePack1",
		"EmotePack2",
		"MetalBadge",
	}

	---Update emote spoofer.
	local function updateEmoteSpoofer()
		local localPlayer = players.LocalPlayer
		if not localPlayer then
			return
		end

		local playerGui = localPlayer.PlayerGui
		if not playerGui then
			return
		end

		local gestureGui = playerGui:FindFirstChild("GestureGui")
		if not gestureGui then
			return
		end

		local mainFrame = gestureGui:FindFirstChild("MainFrame")
		local gestureScroll = mainFrame and mainFrame:FindFirstChild("GestureScroll")
		if not gestureScroll then
			return
		end

		local starterGestureGui = starterGui:FindFirstChild("GestureGui")
		if not starterGestureGui then
			return
		end

		if not originalTags then
			originalTags = localPlayer:GetTags()
		end

		for _, tag in next, EMOTE_SPOOFER_TAGS do
			if originalTags[tag] then
				continue
			end

			collectionService:AddTag(localPlayer, tag)
		end

		if #gestureScroll:GetChildren() >= EXPECTED_EMOTE_CHILDREN then
			return
		end

		gestureGui:Destroy()

		local newGestureGui = starterGestureGui:Clone()
		newGestureGui.Parent = playerGui
	end

	---Reset emote spoofer.
	local function resetEmoteSpoofer()
		if not originalTags then
			return
		end

		local localPlayer = players.LocalPlayer
		if not localPlayer then
			return
		end

		for _, tag in next, EMOTE_SPOOFER_TAGS do
			if not originalTags[tag] then
				continue
			end

			collectionService:RemoveTag(localPlayer, tag)
		end
	end

	---Update freestyler band spoof.
	local function updateFreestylerBandSpoof(character)
		local localPlayer = players.LocalPlayer
		if not localPlayer then
			return
		end

		local backpack = localPlayer:FindFirstChild("Backpack")
		if not backpack then
			return
		end

		local ssvPassives = character:GetAttribute("ssv_Passives")
		local passiveList = ssvPassives and ssvPassives:split(";") or {}

		if table.find(passiveList, "Freestyler's Band") then
			return
		end

		passiveList[#passiveList + 1] = "Freestyler's Band"
		character:SetAttribute("ssv_Passives", table.concat(passiveList, ";"))
		fakeFreestylerBand.Parent = backpack
	end

	---Update konga clutch ring spoof.
	local function updateKongaClutchRingSpoof(character)
		local localPlayer = players.LocalPlayer
		if not localPlayer then
			return
		end

		local backpack = localPlayer:FindFirstChild("Backpack")
		if not backpack then
			return
		end

		local ssvPassives = character:GetAttribute("ssv_Passives")
		local passiveList = ssvPassives and ssvPassives:split(";") or {}

		if table.find(passiveList, "Konga's Clutch Ring") then
			return
		end

		passiveList[#passiveList + 1] = "Konga's Clutch Ring"
		character:SetAttribute("ssv_Passives", table.concat(passiveList, ";"))
		fakeKongaClutchRing.Parent = backpack
	end

	---Reset freestyler band spoof.
	local function resetFreestylerBandSpoof(character)
		local ssvPassives = character:GetAttribute("ssv_Passives")
		local passiveList = ssvPassives and ssvPassives:split(";") or {}

		for idx, passive in next, passiveList do
			if passive ~= "Freestyler's Band" then
				continue
			end

			table.remove(passiveList, idx)
			break
		end

		character:SetAttribute("ssv_Passives", table.concat(passiveList, ";"))
		fakeFreestylerBand.Parent = nil
	end

	---Reset konga clutch ring spoof.
	local function resetKongaClutchRingSpoof(character)
		local ssvPassives = character:GetAttribute("ssv_Passives")
		local passiveList = ssvPassives and ssvPassives:split(";") or {}

		for idx, passive in next, passiveList do
			if passive ~= "Konga's Clutch Ring" then
				continue
			end

			table.remove(passiveList, idx)
			break
		end

		character:SetAttribute("ssv_Passives", table.concat(passiveList, ";"))
		fakeKongaClutchRing.Parent = nil
	end

	---On Player GUI descendant added.
	---@param instance Instance
	local function onPgDescendantAdded(instance)
		if
			instance.Name ~= "DeathID"
			and instance.Name ~= "KillerPlayer"
			and instance.Name ~= "KillerCharacter"
			and instance.Name ~= "Timestamp"
		then
			return
		end

		if not instance:IsA("TextLabel") and not instance:IsA("TextBox") then
			return
		end

		instance.Visible = not (
			Configuration.expectToggleValue("InfoSpoofing")
			and Configuration.expectToggleValue("HideDeathInformation")
		)
	end

	---Update death information spoof.
	local function updateDeathInformationSpoof()
		local localPlayer = players.LocalPlayer
		local playerGui = localPlayer:FindFirstChild("PlayerGui")
		if not playerGui then
			return
		end

		local killGui = playerGui:FindFirstChild("KillGui")
		if not killGui then
			return
		end

		local splash = killGui:FindFirstChild("Splash")
		if not splash then
			return
		end

		for _, descendant in next, splash:GetDescendants() do
			onPgDescendantAdded(descendant)
		end
	end

	---Update spoofing.
	local function updateSpoofing()
		if os.clock() - lastTimestampRun <= 2.0 then
			return
		end

		lastTimestampRun = os.clock()

		if Configuration.expectToggleValue("EmoteSpoofer") then
			updateEmoteSpoofer()
		else
			resetEmoteSpoofer()
		end

		if not Configuration.expectToggleValue("InfoSpoofing") then
			infoSpoofMap:restore()
		end

		updateDeathInformationSpoof()

		local player = players.LocalPlayer
		if not player then
			return
		end

		local character = player.Character
		if not character then
			return
		end

		if Configuration.expectToggleValue("FreestylersBandSpoof") then
			updateFreestylerBandSpoof(character)
		else
			resetFreestylerBandSpoof(character)
		end

		if Configuration.expectToggleValue("KongaClutchRingSpoof") then
			updateKongaClutchRingSpoof(character)
		else
			resetKongaClutchRingSpoof(character)
		end
	end

	---Spoof game version.
	---@param value string
	function Spoofing.sgv(value)
		if not Configuration.expectToggleValue("InfoSpoofing") then
			return
		end

		local player = players.LocalPlayer
		if not player then
			return
		end

		local playerGui = player:FindFirstChild("PlayerGui")
		if not playerGui then
			return
		end

		local topBarGui = playerGui:FindFirstChild("TopbarGui")
		local container = topBarGui and topBarGui:FindFirstChild("Container")
		local infoFrame = container and container:FindFirstChild("InfoFrame")
		local gameInfo = infoFrame and infoFrame:FindFirstChild("GameInfo")
		if not gameInfo then
			return
		end

		local gameVersionLabel = gameInfo:FindFirstChild("GameVersion")
		if not gameVersionLabel then
			return
		end

		infoSpoofMap:add(gameVersionLabel, "Text", value)
	end

	---Spoof date string.
	---@param value string
	function Spoofing.sds(value)
		if not Configuration.expectToggleValue("InfoSpoofing") then
			return
		end

		local player = players.LocalPlayer
		if not player then
			return
		end

		local playerGui = player:FindFirstChild("PlayerGui")
		if not playerGui then
			return
		end

		local topBarGui = playerGui:FindFirstChild("TopbarGui")
		local container = topBarGui and topBarGui:FindFirstChild("Container")
		local infoFrame = container and container:FindFirstChild("InfoFrame")
		local worldInfoFrame = infoFrame and infoFrame:FindFirstChild("WorldInfo")
		if not worldInfoFrame then
			return
		end

		local dateLabel = worldInfoFrame:FindFirstChild("Date")
		if not dateLabel then
			return
		end

		infoSpoofMap:add(dateLabel, "Text", value)
	end

	---Spoof slot string.
	---@param value string
	function Spoofing.sss(value)
		if not Configuration.expectToggleValue("InfoSpoofing") then
			return
		end

		local player = players.LocalPlayer
		if not player then
			return
		end

		local playerGui = player:FindFirstChild("PlayerGui")
		if not playerGui then
			return
		end

		local topBarGui = playerGui:FindFirstChild("TopbarGui")
		local container = topBarGui and topBarGui:FindFirstChild("Container")
		local infoFrame = container and container:FindFirstChild("InfoFrame")
		local characterInfo = infoFrame and infoFrame:FindFirstChild("CharacterInfo")
		if not characterInfo then
			return
		end

		local slotLabel = characterInfo:FindFirstChild("Slot")
		if not slotLabel then
			return
		end

		infoSpoofMap:add(slotLabel, "Text", value)
	end

	---Fire attribute changed signal.
	---@param instance Instance
	---@param attribute string
	function Spoofing.facs(instance, attribute)
		local original = instance:GetAttribute(attribute)
		instance:SetAttribute(attribute, "SPOOFING_RICS")
		instance:SetAttribute(attribute, original)
	end

	---Fire changed signal for value.
	---@param instance ValueBase
	function Spoofing.fvcs(instance)
		local original = instance.Value
		instance.Value = "SPOOFING_RICS"
		instance.Value = original
	end

	---Refresh changed signals for information.
	---@note: Attempts to trigger them w/o using 'firesignal' or 'getconnections' because they crash.
	function Spoofing.rics()
		for _, player in next, players:GetPlayers() do
			Spoofing.facs(player, "Guild")
			Spoofing.facs(player, "FirstName")
			Spoofing.facs(player, "LastName")

			local character = player.Character
			if not character then
				continue
			end

			Spoofing.facs(character, "GuildRich")

			local humanoid = character:FindFirstChild("Humanoid")
			if not humanoid then
				continue
			end

			Spoofing.facs(humanoid, "CharacterName")
		end

		local serverRegion = replicatedStorage:FindFirstChild("SERVER_REGION")
		local serverName = replicatedStorage:FindFirstChild("SERVER_NAME")
		local serverAge = replicatedStorage:FindFirstChild("SERVER_AGE")

		if not serverRegion or not serverName or not serverAge then
			return
		end

		Spoofing.fvcs(serverRegion)
		Spoofing.fvcs(serverName)

		-- This function actually caches the last text size and takes the biggest one, so we need to have a pretty small text.
		local original = serverAge.Value
		serverAge.Value = "L"
		serverAge.Value = original
	end

	---Initialize spoofing.
	function Spoofing.init()
		-- Get player data.
		local localPlayer = players.LocalPlayer
		local playerGui = localPlayer:WaitForChild("PlayerGui")
		local pgDescendantAdded = Signal.new(playerGui.DescendantAdded)

		-- Attach.
		spoofingMaid:add(renderStepped:connect("Spoofing_OnRenderStepped", updateSpoofing))
		spoofingMaid:add(pgDescendantAdded:connect("Spoofing_OnPGDescendantAdded", onPgDescendantAdded))

		-- Log.
		Logger.warn("Spoofing initialized.")
	end

	---Detach spoofing.
	function Spoofing.detach()
		-- Tell hooks that we need to clean up instead of spoofing - regardless of what user set.
		Spoofing.force = true

		-- Clean up maid.
		spoofingMaid:clean()

		-- Clean up spoofed data.
		Spoofing.rics()

		-- Clean up instances & other spoofing.
		fakeFreestylerBand.Parent = nil
		fakeKongaClutchRing.Parent = nil
		resetEmoteSpoofer()

		-- Log detach.
		Logger.warn("Spoofing detached.")
	end

	-- Return Spoofing module.
	return Spoofing
end)()

end)
__bundle_register("Utility/OriginalStoreManager", function(require, _LOADED, __bundle_register, __bundle_modules)
---@module Utility.OriginalStore
local OriginalStore = require("Utility/OriginalStore")

---@class OriginalStoreManager
---@param inner OriginalStore[]
local OriginalStoreManager = {}
OriginalStoreManager.__index = OriginalStoreManager

---Forget data value.
---@param data table|Instance
OriginalStoreManager.forget = LPH_NO_VIRTUALIZE(function(self, data)
	self.inner[data] = nil
end)

---Mark data value.
---@param data table|Instance
---@param index any
OriginalStoreManager.mark = LPH_NO_VIRTUALIZE(function(self, data, index)
	local object = self.inner[data] or OriginalStore.new()

	object:mark(data, index)

	self.inner[data] = object
end)

---Add data value.
---@param data table|Instance
---@param index any
---@param value any
OriginalStoreManager.add = LPH_NO_VIRTUALIZE(function(self, data, index, value)
	local object = self.inner[data] or OriginalStore.new()

	object:set(data, index, value)

	self.inner[data] = object
end)

---Get data values.
---@return OriginalStore[]
OriginalStoreManager.data = LPH_NO_VIRTUALIZE(function(self)
	return self.inner
end)

---Get data value.
---@param data table|Instance
---@return OriginalStore
OriginalStoreManager.get = LPH_NO_VIRTUALIZE(function(self, data)
	return self.inner[data]
end)

---Restore data values.
OriginalStoreManager.restore = LPH_NO_VIRTUALIZE(function(self)
	for _, store in next, self.inner do
		store:restore()
	end
end)

---Detach OriginalStoreManager object.
OriginalStoreManager.detach = LPH_NO_VIRTUALIZE(function(self)
	for _, store in next, self.inner do
		store:detach()
	end

	self.inner = {}
end)

---Create new OriginalStoreManager object.
---@return OriginalStoreManager
OriginalStoreManager.new = LPH_NO_VIRTUALIZE(function()
	local self = setmetatable({}, OriginalStoreManager)
	self.inner = {}
	return self
end)

-- Return OriginalStoreManager module.
return OriginalStoreManager

end)
__bundle_register("Features/Game/Monitoring", function(require, _LOADED, __bundle_register, __bundle_modules)
return LPH_NO_VIRTUALIZE(function()
	---@module Utility.Maid
	local Maid = require("Utility/Maid")

	---@module Utility.Signal
	local Signal = require("Utility/Signal")

	---@module Utility.Configuration
	local Configuration = require("Utility/Configuration")

	---@module Utility.OriginalStore
	local OriginalStore = require("Utility/OriginalStore")

	---@module Utility.OriginalStoreManager
	local OriginalStoreManager = require("Utility/OriginalStoreManager")

	---@module Utility.CoreGuiManager
	local CoreGuiManager = require("Utility/CoreGuiManager")

	---@module Utility.TaskSpawner
	local TaskSpawner = require("Utility/TaskSpawner")

	---@module Utility.JSON
	local JSON = require("Utility/JSON")

	---@module Utility.Logger
	local Logger = require("Utility/Logger")

	---@module Utility.Finder
	local Finder = require("Utility/Finder")

	---@module Game.LeaderboardClient
	local LeaderboardClient = require("Game/LeaderboardClient")

	-- Monitoring module.
	local Monitoring = { subject = nil, seen = {} }

	-- Services.
	local runService = game:GetService("RunService")
	local players = game:GetService("Players")

	-- Signals.
	local renderStepped = Signal.new(runService.RenderStepped)

	-- Maids.
	local monitoringMaid = Maid.new()
	local spectateMaid = Maid.new()
	local buildStealMaid = Maid.new()
	local plwMaid = Maid.new()

	-- Instances.
	local beepSound = CoreGuiManager.imark(Instance.new("Sound"))

	-- Update limiting.
	local lastUpdateTime = os.clock()

	-- Original stores.
	local cameraSubject = spectateMaid:mark(OriginalStore.new())

	-- Original store managers.
	local showHiddenMap = spectateMaid:mark(OriginalStoreManager.new())

	---Fetch name.
	local function fetchName(player)
		local spoofName = Configuration.expectToggleValue("InfoSpoofing")
			and Configuration.expectToggleValue("SpoofOtherPlayers")

		return spoofName and "[REDACTED]"
			or string.format("(%s) %s", player:GetAttribute("CharacterName") or "Unknown Character Name", player.Name)
	end

	---On whitelisting input began.
	---@param player Player
	---@param input InputObject
	local function onWhitelistingInputBegan(player, input)
		if input.KeyCode ~= Enum.KeyCode.L then
			return
		end

		local usernameList = Options["UsernameList"]
		if not usernameList then
			return
		end

		local whitelisted = usernameList.Values
		if not whitelisted then
			return
		end

		local whitelistIndex = table.find(whitelisted, player.Name)

		if whitelistIndex then
			whitelisted[whitelistIndex] = nil

			Logger.notify("Removed player '%s' from the whitelist.", fetchName(player))
		else
			whitelisted[#whitelisted + 1] = player.Name

			Logger.notify("Added player '%s' to the whitelist.", fetchName(player))
		end

		usernameList:SetValues(whitelisted)
		usernameList:SetValue({})
		usernameList:Display()
	end

	---On spectate input began.
	---@param player Player
	---@param input InputObject
	local function onSpectateInputBegan(player, input)
		if input.UserInputType ~= Enum.UserInputType.MouseButton1 then
			return
		end

		-- Fetch name for player.
		local usedName = fetchName(player)

		-- Get data.
		local localPlayer = players.LocalPlayer
		if not localPlayer then
			return Logger.notify("Failed to spectate '%s' because the local player does not exist.", usedName)
		end

		local character = player.Character
		if not character then
			return Logger.notify("Failed to spectate '%s' because their character does not exist.", usedName)
		end

		local mapPosition = character:GetAttribute("MapPos")
		local humanoidRootPart = character:FindFirstChild("HumanoidRootPart")

		-- Request a stream if we're able to and we know that they're not loaded in.
		if mapPosition and not humanoidRootPart then
			spectateMaid:add(
				TaskSpawner.spawn(
					"Monitoring_RequestStreamMapPos",
					players.LocalPlayer.RequestStreamAroundAsync,
					players.LocalPlayer,
					mapPosition,
					0.1
				)
			)

			return Logger.notify("Requesting stream for unloaded character '%s' - try again later.", usedName)
		end

		-- Fail because they're *truly* not loaded in.
		if not humanoidRootPart then
			return Logger.notify("Failed to spectate '%s' because they are not loaded in.", usedName)
		end

		local shouldUpdateSubject = Monitoring.subject ~= humanoidRootPart and players.LocalPlayer ~= player

		Monitoring.subject = shouldUpdateSubject and humanoidRootPart or nil

		if shouldUpdateSubject then
			Logger.notify("Started spectating player %s.", usedName)
		else
			Logger.notify("Reset spectating camera subject.")
		end
	end

	---On build steal player.
	---@param player Player
	local function onBuildStealPlayer(player)
		local character = player.Character
		if not character then
			return Logger.notify(
				"Failed to steal build from '%s' because their character does not exist.",
				fetchName(player)
			)
		end

		local backpack = player:FindFirstChild("Backpack")
		if not backpack then
			return Logger.notify(
				"Failed to steal build from '%s' because their backpack does not exist.",
				fetchName(player)
			)
		end

		local humanoid = character:FindFirstChildOfClass("Humanoid")
		if not humanoid then
			return Logger.notify(
				"Failed to steal build from '%s' because their humanoid does not exist.",
				fetchName(player)
			)
		end

		-- Prepare data.
		local data = {
			version = 3,
			stats = {
				buildName = string.format("(%i) (%s) Stolen Build", os.time(), player.Name),
				buildDescription = "(.gg/lyc) Build stolen using Linoria V2's Build Stealer feature. Pre-shrine must be solved for. Stuff can be missing or bugged. Finally, check notes.",
				buildAuthor = ".gg/lyc",
				power = character:GetAttribute("Level"),
				pointsUntilNextPower = 67,
				points = 67,
				pointSpent = 67,
				traitPoints = 0,
				traits = {
					Vitality = character:GetAttribute("Trait_Health"),
					Erudition = character:GetAttribute("Trait_Ether"),
					Songchant = character:GetAttribute("Trait_MantraDamage"),
					Proficiency = character:GetAttribute("Trait_WeaponDamage"),
				},
				meta = {
					Race = "None",
					Oath = "None",
					Murmur = "None",
					Bell = "None",
					Origin = "Castaway",
					Outfit = "None",
				},
			},
			attributes = {
				weapon = {
					["Heavy Wep."] = character:GetAttribute("Stat_WeaponHeavy"),
					["Medium Wep."] = character:GetAttribute("Stat_WeaponMedium"),
					["Light Wep."] = character:GetAttribute("Stat_WeaponLight"),
				},
				base = {
					Strength = character:GetAttribute("Stat_Strength"),
					Fortitude = character:GetAttribute("Stat_Fortitude"),
					Agility = character:GetAttribute("Stat_Agility"),
					Intelligence = character:GetAttribute("Stat_Intelligence"),
					Willpower = character:GetAttribute("Stat_Willpower"),
					Charisma = character:GetAttribute("Stat_Charisma"),
				},
				attunement = {
					Flamecharm = character:GetAttribute("Stat_ElementFire"),
					Frostdraw = character:GetAttribute("Stat_ElementIce"),
					Thundercall = character:GetAttribute("Stat_ElementLightning"),
					Galebreathe = character:GetAttribute("Stat_ElementWind"),
					Shadowcast = character:GetAttribute("Stat_ElementShadow"),
					Ironsing = character:GetAttribute("Stat_ElementMetal"),
					Bloodrend = character:GetAttribute("Stat_ElementBlood"),
				},
			},
			content = {
				mantraModifications = {},
				notes = "",
			},
			meta = {
				tags = {},
				isPrivate = true,
			},
			talents = {},
			mantras = {},
			weapons = "",
			enchant = "",
			motif = "",
			preShrine = {
				base = {
					Strength = 100,
					Fortitude = 100,
					Agility = 100,
					Intelligence = 100,
					Willpower = 100,
					Charisma = 100,
				},
				weapon = {
					["Heavy Wep."] = 100,
					["Medium Wep."] = 100,
					["Light Wep."] = 100,
				},
				attunement = {
					Flamecharm = 100,
					Frostdraw = 100,
					Thundercall = 100,
					Galebreathe = 100,
					Shadowcast = 100,
					Ironsing = 100,
					Bloodrend = 100,
				},
			},
			postShrine = nil,
			favoritedTalents = {},
		}

		data.postShrine = data.attributes

		local stats = data.stats
		local meta = data.stats.meta
		local boonIdx = 1
		local flawIdx = 1
		local notes = {}

		-- Fix data.
		for _, instance in next, backpack:GetChildren() do
			local filtered = string.gsub(instance.Name, "Talent:", "")

			if filtered:match("Murmur") then
				meta.Murmur = filtered:gsub("Murmur: ", "")
			end

			if filtered:match("Oath") then
				meta.Oath = filtered:gsub("Oath: ", "")
			end

			if filtered:match("Resonance") then
				meta.Bell = filtered:gsub("Resonance:", "")
			end

			if filtered:match("Boon") then
				stats["boon" .. boonIdx] = filtered:gsub("Boon:", "")
				boonIdx = boonIdx + 1
			end

			if filtered:match("Flaw") then
				stats["flaw" .. flawIdx] = filtered:gsub("Flaw:", "")
				flawIdx = flawIdx + 1
			end

			if filtered:match("Mantra") and instance:GetAttribute("DisplayName") then
				notes[#notes + 1] = (filtered:match("RecalledMantra") and "[RECALLED MANTRA]" or "[USED MANTRA]")
					.. " "
					.. (instance:GetAttribute("RichStats") or "NO RICH STATS?")
					.. "\n"

				if filtered:match("RecalledMantra") then
					continue
				end

				data.mantras[#data.mantras + 1] = instance:GetAttribute("DisplayName")
				data.content.mantraModifications[instance:GetAttribute("DisplayName")] = {}
			end

			if instance.Name == "Weapon" then
				notes[#notes + 1] = "[USED WEAPON] " .. (instance:GetAttribute("RichStats") or filtered)
			end

			if instance.Name:match("Talent") then
				data.talents[#data.talents + 1] = filtered
			end
		end

		for _, instance in next, character:GetChildren() do
			if instance.Name == "Ring" then
				notes[#notes + 1] = string.format("[EQUIPPED RING] %s\n", instance:GetAttribute("DisplayName"))
					.. (instance:GetAttribute("RichStats") or instance.Name)
			end

			if instance.Name == "Shirt" then
				notes[#notes + 1] = "[EQUIPPED SHIRT ID] " .. instance.ShirtTemplate
			end

			if instance.Name == "Pants" then
				notes[#notes + 1] = "[EQUIPPED PANTS ID] " .. instance.PantsTemplate
			end

			if
				instance.Name:match("Equipment")
				and instance:GetAttribute("RichStats")
				and instance:GetAttribute("DisplayName")
			then
				notes[#notes + 1] = string.format(
					"[EQUIPPED EQUIPMENT] [%s] %s\n",
					instance.Name,
					instance:GetAttribute("DisplayName")
				) .. instance:GetAttribute("RichStats")
			end
		end

		notes[#notes + 1] = string.format("[HEALTH] %.2f/%.2f", humanoid.Health, humanoid.MaxHealth)

		data.content.notes = table.concat(notes, "\n\n")

		-- Create builder link.
		local response = request({
			Url = "https://deepwoken.co/api/proxy",
			Method = "POST",
			Headers = {
				["Content-Type"] = "application/json",
			},
			Body = JSON.encode({
				options = {
					body = JSON.encode(data),
					method = "POST",
					credentials = "include",
				},
				url = "https://api.deepwoken.co/build",
			}),
		})

		if not response then
			return Logger.notify("Failed to steal build from '%s' due to no response.", fetchName(player))
		end

		if not response.Success then
			return Logger.notify(
				"(Status %i) Failed to steal build from '%s' due to build creation failure.",
				response.StatusCode,
				fetchName(player)
			)
		end

		if not response.Body then
			return Logger.notify("Failed to steal build from '%s' due to no response body.", fetchName(player))
		end

		local decoded = JSON.decode(response.Body)

		if not decoded or not decoded.id then
			return Logger.notify(
				"(Status %i) Failed to steal build from '%s' due to invalid response body.",
				response.StatusCode,
				fetchName(player)
			)
		end

		-- Set clipboard.
		setclipboard(string.format("https://deepwoken.co/builder?id=%s", decoded.id))

		-- Notify.
		Logger.notify("Stole build from '%s' and copied the builder link to your clipboard.", fetchName(player))
	end

	---Update build stealing.
	local function updateBuildStealing()
		local leaderboardMap, refreshLeaderboard = LeaderboardClient.gld(), LeaderboardClient.glrf()
		if not leaderboardMap or not refreshLeaderboard then
			return cameraSubject:restore()
		end

		-- Refresh leaderboard state.
		refreshLeaderboard()

		-- Update leaderboard based on state.
		for player, frame in next, leaderboardMap do
			local inputBegan = Signal.new(frame.InputBegan)
			local label = string.format("Monitoring_InputBegan_Steal_%s", player.Name)

			if buildStealMaid[frame] then
				continue
			end

			buildStealMaid[frame] = inputBegan:connect(label, function(input)
				if input.KeyCode ~= Enum.KeyCode.P then
					return
				end

				onBuildStealPlayer(player)
			end)
		end
	end

	---Update player list whitelisting.
	local function updatePlayerListWhitelisting()
		local leaderboardMap, refreshLeaderboard = LeaderboardClient.gld(), LeaderboardClient.glrf()
		if not leaderboardMap or not refreshLeaderboard then
			return cameraSubject:restore()
		end

		-- Refresh leaderboard state.
		refreshLeaderboard()

		-- Update leaderboard based on state.
		for player, frame in next, leaderboardMap do
			local inputBegan = Signal.new(frame.InputBegan)
			local label = string.format("Monitoring_InputBegan_PLW_%s", player.Name)

			if plwMaid[frame] then
				continue
			end

			plwMaid[frame] = inputBegan:connect(label, function(input)
				onWhitelistingInputBegan(player, input)
			end)
		end
	end

	---Update spectating.
	local function updateSpectating()
		local leaderboardMap, refreshLeaderboard = LeaderboardClient.gld(), LeaderboardClient.glrf()
		if not leaderboardMap or not refreshLeaderboard then
			return cameraSubject:restore()
		end

		-- Refresh leaderboard state.
		refreshLeaderboard()

		-- Update leaderboard based on state.
		for player, frame in next, leaderboardMap do
			local inputBegan = Signal.new(frame.InputBegan)
			local label = string.format("Monitoring_InputBegan%s", player.Name)

			if Configuration.expectToggleValue("ShowHiddenPlayers") then
				showHiddenMap:add(frame, "Visible", true)
			end

			if spectateMaid[frame] then
				continue
			end

			spectateMaid[frame] = inputBegan:connect(label, function(input)
				onSpectateInputBegan(player, input)
			end)
		end
	end

	---Update player proximity.
	local function updatePlayerProximity()
		local proximityRange = Configuration.expectOptionValue("PlayerProximityRange") or 350
		local playersInRange = Finder.gpir(proximityRange)
		if not playersInRange then
			return
		end

		local localPlayer = players.LocalPlayer
		if not localPlayer then
			return
		end

		local backpack = localPlayer:FindFirstChild("Backpack")
		if not backpack then
			return
		end

		-- Handle monitoring.
		for player, _ in next, Monitoring.seen do
			local isInPlayerRange = table.find(playersInRange, player)
			if isInPlayerRange then
				continue
			end

			local removeNotification = Monitoring.seen[player]

			removeNotification()

			Monitoring.seen[player] = nil
		end

		for _, player in next, playersInRange do
			if Monitoring.seen[player] ~= nil then
				continue
			end

			if
				Configuration.expectToggleValue("PlayerProximityVW")
				and not backpack:FindFirstChild("Talent:Voidwalker Contract")
			then
				continue
			end

			Monitoring.seen[player] =
				Logger.mnnotify("%s entered your proximity radius of %i studs.", fetchName(player), proximityRange)

			if Configuration.expectToggleValue("PlayerProximityBeep") then
				beepSound.SoundId = "rbxassetid://100849623977896"
				beepSound.PlaybackSpeed = 1
				beepSound.Volume = Configuration.expectOptionValue("PlayerProximityBeepVolume") or 0.1
				beepSound:Play()
			end
		end
	end

	---Update subject montioring.
	local function updateSubjectMonitoring()
		-- Set camera subject.
		cameraSubject:set(workspace.CurrentCamera, "CameraSubject", Monitoring.subject)

		if Monitoring.subject ~= nil then
			players.LocalPlayer:AddTag("ForcedSubject")
		else
			players.LocalPlayer:RemoveTag("ForcedSubject")
		end

		-- Request stream.
		spectateMaid:add(
			TaskSpawner.spawn(
				"Monitoring_RequestStreamSpectate",
				players.LocalPlayer.RequestStreamAroundAsync,
				players.LocalPlayer,
				Monitoring.subject.Position,
				0.1
			)
		)
	end

	---Update monitoring.
	local function updateMonitoring()
		if Monitoring.subject then
			updateSubjectMonitoring()
		else
			cameraSubject:restore()
		end

		if os.clock() - lastUpdateTime <= 2.0 then
			return
		end

		lastUpdateTime = os.clock()

		if Configuration.expectToggleValue("PlayerListWhitelisting") then
			updatePlayerListWhitelisting()
		else
			plwMaid:clean()
		end

		if Configuration.expectToggleValue("BuildStealer") then
			updateBuildStealing()
		else
			buildStealMaid:clean()
		end

		if Configuration.expectToggleValue("PlayerSpectating") then
			updateSpectating()
		else
			spectateMaid:clean()
		end

		if Configuration.expectToggleValue("PlayerProximity") then
			updatePlayerProximity()
		end
	end

	---Initialize monitoring.
	function Monitoring.init()
		-- Attach.
		monitoringMaid:add(renderStepped:connect("Monitoring_OnRenderStepped", updateMonitoring))

		-- Log.
		Logger.warn("Monitoring initialized.")
	end

	---Detach spectating.
	function Monitoring.detach()
		-- Clean.
		monitoringMaid:clean()
		buildStealMaid:clean()
		spectateMaid:clean()
		plwMaid:clean()
		showHiddenMap:restore()

		-- Get leaderboard data.
		local refreshLeaderboard = LeaderboardClient.glrf()

		-- Refresh leaderboard.
		if refreshLeaderboard then
			refreshLeaderboard()
		end

		-- Log.
		Logger.warn("Monitoring detached.")
	end

	-- Return Monitoring module.
	return Monitoring
end)()

end)
__bundle_register("Game/LeaderboardClient", function(require, _LOADED, __bundle_register, __bundle_modules)
-- LeaderboardClient module.
local LeaderboardClient = { calling = false }

-- Services.
local players = game:GetService("Players")

-- Caching.
local cachedUpvaluesTable = nil
local cachedUpvaluesFunction = nil
local lastDataCacheTime = os.clock()
local lastFunctionCacheTime = os.clock()

---Filter function.
---@param func function?
---@return boolean
local function filterFunction(func)
	if not func or not islclosure(func) then
		return false
	end

	local info = debug.getinfo(func)
	if info.name ~= nil and info.name ~= "" then
		return false
	end

	local constants = debug.getconstants(func)
	if #constants ~= 1 or constants[1] ~= "Destroy" then
		return false
	end

	local upvalues = debug.getupvalues(func)
	if not upvalues then
		return false
	end

	return true
end

---Get leaderboard refresh function.
---@return function?
function LeaderboardClient.glrf()
	if cachedUpvaluesFunction and os.clock() - lastFunctionCacheTime <= 2.0 then
		return cachedUpvaluesFunction
	end

	for _, con in next, getconnections(players.PlayerRemoving) do
		local func = con.Function
		if not filterFunction(func) then
			continue
		end

		local upvalues = debug.getupvalues(func)
		if not upvalues then
			continue
		end

		-- Fetch function.
		local upvaluesFunction = upvalues[2]

		-- Cache.
		cachedUpvaluesFunction = upvaluesFunction
		lastFunctionCacheTime = os.clock()

		-- Return function.
		return function()
			-- Never allow a call when we already have an open one.
			if LeaderboardClient.calling then
				return
			end

			-- Mark that we're calling...
			LeaderboardClient.calling = true

			-- Call the function.
			upvaluesFunction()

			-- Close calling!
			LeaderboardClient.calling = false
		end
	end

	return nil
end

---Get leaderboard data.
---@return table?
function LeaderboardClient.gld()
	if cachedUpvaluesTable and os.clock() - lastDataCacheTime <= 2.0 then
		return cachedUpvaluesTable
	end

	for _, con in next, getconnections(players.PlayerRemoving) do
		local func = con.Function
		if not filterFunction(func) then
			continue
		end

		local upvalues = debug.getupvalues(func)
		if not upvalues then
			continue
		end

		-- Fetch data.
		local upvaluesTable = upvalues[1]

		-- Cache.
		cachedUpvaluesTable = upvaluesTable
		lastDataCacheTime = os.clock()

		-- Return data.
		return upvaluesTable
	end

	return nil
end

-- Return LeaderboardClient module.
return LeaderboardClient

end)
__bundle_register("Features/Game/Removal", function(require, _LOADED, __bundle_register, __bundle_modules)
return LPH_NO_VIRTUALIZE(function()
	-- Removal related stuff is handled here.
	local Removal = {}

	---@module Utility.Maid
	local Maid = require("Utility/Maid")

	---@module Utility.Signal
	local Signal = require("Utility/Signal")

	---@module Game.KeyHandling
	local KeyHandling = require("Game/KeyHandling")

	---@module Utility.Configuration
	local Configuration = require("Utility/Configuration")

	---@module Utility.OriginalStoreManager
	local OriginalStoreManager = require("Utility/OriginalStoreManager")

	---@module Utility.OriginalStore
	local OriginalStore = require("Utility/OriginalStore")

	---@module Utility.Logger
	local Logger = require("Utility/Logger")

	-- Services.
	local runService = game:GetService("RunService")
	local players = game:GetService("Players")
	local replicatedStorage = game:GetService("ReplicatedStorage")
	local lighting = game:GetService("Lighting")
	local debris = game:GetService("Debris")

	-- Maids.
	local removalMaid = Maid.new()

	-- Acid water.
	local originalAcidRemote = nil
	local placeholderRemote = Instance.new("RemoteEvent")
	placeholderRemote.Name = "AcidRemote"

	-- Original stores.
	local noShadows = removalMaid:mark(OriginalStore.new())
	local noBlur = removalMaid:mark(OriginalStore.new())

	-- Original store managers.
	local echoModifiersMap = removalMaid:mark(OriginalStoreManager.new())
	local noFogMap = removalMaid:mark(OriginalStoreManager.new())
	local killBricksMap = removalMaid:mark(OriginalStoreManager.new())
	local damageBricksMap = removalMaid:mark(OriginalStoreManager.new())
	local lightBarrierMap = removalMaid:mark(OriginalStoreManager.new())
	local yunShulBarrierMap = removalMaid:mark(OriginalStoreManager.new())
	local yunShulResonanceDoorMap = removalMaid:mark(OriginalStoreManager.new())
	local hiveGateMap = removalMaid:mark(OriginalStoreManager.new())

	-- Signals.
	local renderStepped = Signal.new(runService.RenderStepped)
	local workspaceDescendantAdded = Signal.new(workspace.DescendantAdded)
	local workspaceDescendantRemoving = Signal.new(workspace.DescendantRemoving)

	-- Originals.
	local originalBlindseerState = false

	-- Last update.
	local lastUpdate = os.clock()
	local lastWindEffectTimestamp = os.clock()

	---Update no echo modifiers.
	---@param localPlayer Player
	local function updateNoEchoModifiers(localPlayer)
		local backpack = localPlayer:FindFirstChild("Backpack")
		if not backpack then
			return
		end

		for _, instance in pairs(backpack:GetChildren()) do
			if not instance.Name:match("EchoMod") then
				continue
			end

			echoModifiersMap:add(instance, "Parent", nil)
		end
	end

	---Update no hive gate.
	local function updateNoHiveGate()
		for _, store in next, hiveGateMap:data() do
			local data = store.data
			if not data then
				continue
			end

			store:set(store.data, "Parent", nil)
		end
	end

	---Update no kill bricks.
	local function updateNoKillBricks()
		for _, store in next, killBricksMap:data() do
			local data = store.data
			if not data then
				continue
			end

			store:set(store.data, "CFrame", CFrame.new(math.huge, math.huge, math.huge))
		end
	end

	---Update no light barrier.
	local function updateNoLightBarrier()
		for _, store in next, lightBarrierMap:data() do
			local data = store.data
			if not data then
				continue
			end

			store:set(store.data, "CFrame", CFrame.new(math.huge, math.huge, math.huge))
		end
	end

	---Update no fog.
	local function updateNoFog()
		if lighting.FogStart == 9e9 and lighting.FogEnd == 9e9 then
			return
		end

		noFogMap:add(lighting, "FogStart", 9e9)
		noFogMap:add(lighting, "FogEnd", 9e9)

		local atmosphere = lighting:FindFirstChildOfClass("Atmosphere")
		if not atmosphere then
			return
		end

		if atmosphere.Density == 0 then
			return
		end

		noFogMap:add(atmosphere, "Density", 0)
	end

	---Update no blind.
	local function updateNoBlind()
		local localPlayer = players.LocalPlayer
		local character = localPlayer.Character
		if not character then
			return
		end

		local characterHashes = replicatedStorage:FindFirstChild("CharacterHashes")
		local characterHashesModule = characterHashes and require(characterHashes)
		local characterHashData = characterHashesModule and characterHashesModule.GetDynamic(character)
		if not characterHashData then
			return
		end

		originalBlindseerState = characterHashData["Oath: Blindseer"]

		characterHashData["Oath: Blindseer"] = true
	end

	---Reset no blind.
	local function resetNoBlind()
		local localPlayer = players.LocalPlayer
		local character = localPlayer.Character
		if not character then
			return
		end

		local characterHashes = replicatedStorage:FindFirstChild("CharacterHashes")
		local characterHashesModule = characterHashes and require(characterHashes)
		local characterHashData = characterHashesModule and characterHashesModule.GetDynamic(character)
		if not characterHashData then
			return
		end

		characterHashData["Oath: Blindseer"] = originalBlindseerState
	end

	---Update no blur.
	local function updateNoBlur()
		local genericBlur = lighting:FindFirstChild("GenericBlur")
		if not genericBlur then
			return
		end

		local underwaterBlur = lighting:FindFirstChild("UnderwaterBlur")
		if not underwaterBlur then
			return
		end

		noBlur:set(genericBlur, "Size", 0.0)
		noBlur:set(underwaterBlur, "Size", 0.0)
	end

	---Update no yun shul barrier.
	local function updateNoYunShulBarrier()
		for _, store in next, yunShulBarrierMap:data() do
			local data = store.data
			if not data then
				continue
			end

			store:set(store.data, "CFrame", CFrame.new(math.huge, math.huge, math.huge))
		end

		for _, store in next, yunShulResonanceDoorMap:data() do
			local data = store.data
			if not data then
				continue
			end

			store:set(store.data, "Parent", nil)
		end
	end

	---Update no acid water.
	local function updateNoAcidWater()
		if originalAcidRemote then
			return
		end

		local requests = replicatedStorage:FindFirstChild("Requests")
		if not requests then
			return
		end

		local acidRemote = requests:FindFirstChild("AcidRemote")
		if not acidRemote then
			return
		end

		originalAcidRemote = acidRemote
		originalAcidRemote.Name = "AcidRemote_Original"
		placeholderRemote.Parent = requests
	end

	---Restore no acid water.
	local function restoreNoAcidWater()
		if not originalAcidRemote then
			return
		end

		originalAcidRemote.Name = "AcidRemote"
		placeholderRemote.Parent = nil
	end
	
	---Update no damage bricks.
	local function updateNoDamageBricks()
		for _, store in next, damageBricksMap:data() do
			local data = store.data
			if not data then
				continue
			end

			store:set(store.data, "Parent", nil)
		end
	end

	-- Restore no damage bricks.
	local function restoreNoDamageBricks()
		damageBricksMap:restore()
		for _,v in next, game:GetService("CollectionService"):GetTagged("DamageBrick") do
			v:Destroy()
		end
	end

	---Update removal.
	local function updateRemoval()
		if os.clock() - lastUpdate <= 3.0 then
			return
		end

		lastUpdate = os.clock()

		local localPlayer = players.LocalPlayer
		if not localPlayer then
			return
		end

		if Configuration.expectToggleValue("NoFog") then
			updateNoFog()
		else
			noFogMap:restore()
		end

		if Configuration.expectToggleValue("NoEchoModifiers") then
			updateNoEchoModifiers(localPlayer)
		else
			echoModifiersMap:restore()
		end

		if Configuration.expectToggleValue("NoKillBricks") then
			updateNoKillBricks()
		else
			killBricksMap:restore()
		end
		
		if Configuration.expectToggleValue("NoDamageBricks") then
			updateNoDamageBricks()
		else
			restoreNoDamageBricks()
		end

		if Configuration.expectToggleValue("NoHiveGate") then
			updateNoHiveGate()
		else
			hiveGateMap:restore()
		end

		if Configuration.expectToggleValue("NoCastleLightBarrier") then
			updateNoLightBarrier()
		else
			lightBarrierMap:restore()
		end

		if Configuration.expectToggleValue("NoYunShulBarrier") then
			updateNoYunShulBarrier()
		else
			yunShulBarrierMap:restore()
			yunShulResonanceDoorMap:restore()
		end

		if Configuration.expectToggleValue("NoBlind") then
			updateNoBlind()
		else
			resetNoBlind()
		end

		if Configuration.expectToggleValue("NoBlur") then
			updateNoBlur()
		else
			noBlur:restore()
		end

		if Configuration.expectToggleValue("NoAcidWater") then
			updateNoAcidWater()
		else
			restoreNoAcidWater()
		end

		if Configuration.expectToggleValue("NoShadows") then
			noShadows:set(lighting, "GlobalShadows", false)
		else
			noShadows:restore()
		end
	end

	---Hide effect by unlinking it from being found.
	---@param effect table
	local function hideEffect(effect)
		local effectReplicator = replicatedStorage:FindFirstChild("EffectReplicator")
		if not effectReplicator then
			return
		end

		local effectReplicatorModule = require(effectReplicator)
		if not effectReplicatorModule then
			return
		end

		if not effect.ID then
			return
		end

		effectReplicatorModule.Effects[effect.ID] = nil
	end

	---Update removal effects.
	---@param effect table
	local function updateRemovalEffects(effect)
		local stunEffects = { "Stun", "Action", "MobileAction" }

		if Configuration.expectToggleValue("NoStun") and table.find(stunEffects, effect.Class) then
			hideEffect(effect)
		end

		if
			(effect.Class == "BeingWinded" or effect.Class == "StrongWind")
			and Configuration.expectToggleValue("NoWind")
		then
			lastWindEffectTimestamp = os.clock()
			return hideEffect(effect)
		end

		if Configuration.expectToggleValue("NoWind") and os.clock() - lastWindEffectTimestamp <= 30.0 then
			if
				effect.Class == "Speed"
				or effect.Class == "NoJump"
				or effect.Class == "NoStun"
				or effect.Class == "NoSprint"
				or effect.Class == "NoRoll"
			then
				return hideEffect(effect)
			end
		end

		if
			(effect.Class == "NoJump" or effect.Class == "NoJumpAlt")
			and Configuration.expectToggleValue("AlwaysAllowJump")
		then
			return hideEffect(effect)
		end

		if
			effect.Class == "SpeedOverride"
			and effect.Value < 14
			and Configuration.expectToggleValue("NoSpeedDebuff")
		then
			return hideEffect(effect)
		end

		if effect.Class == "Speed" and effect.Value < 0 and Configuration.expectToggleValue("NoSpeedDebuff") then
			rawset(effect, "Value", 0)
		end

		if effect.Class == "Burning" and Configuration.expectToggleValue("AutoExtinguishFire") then
			local serverSlide = KeyHandling.getRemote("ServerSlide")
			local serverSlideStop = KeyHandling.getRemote("ServerSlideStop")

			if not serverSlide or not serverSlideStop then
				return Logger.warn("ServerSlide or ServerSlideStop not found.")
			end

			serverSlide:FireServer(true)
			serverSlideStop:FireServer()
		end
	end

	---On workspace descendant added.
	---@param descendant Instance
	local function onWorkspaceDescendantAdded(descendant)
		if descendant:IsA("Model") and descendant.Name == "ResonanceDoor" then
			yunShulResonanceDoorMap:mark(descendant, "Parent")
		end

		if descendant:IsA("Model") and descendant.Name == "HiveGate" then
			hiveGateMap:mark(descendant, "Parent")
		end

		if descendant.Name == "WindPusher" and Configuration.expectToggleValue("NoWind") then
			debris:AddItem(descendant, 0.01)
		end

		if not descendant:IsA("BasePart") then
			return
		end

		if descendant.Name == "LifeField" then
			lightBarrierMap:mark(descendant, "CFrame")
		end

		local killInstance = descendant.Name == "KillBrick" or descendant.Name == "KillPlane"
		local killChasm = descendant.Name:match("Chasm")
		local superWall = descendant.Name == "SuperWall"
		local damagePart = descendant.Name == "Lava" and descendant:FindFirstChild("Hazardous") and not descendant:HasTag("DamageBrick")

		if killInstance or killChasm or superWall then
			killBricksMap:mark(descendant, "CFrame")
		end

		if descendant.Name == "DeepPassage_Yun" then
			yunShulBarrierMap:mark(descendant, "CFrame")
		end

		if damagePart then
			damageBricksMap:mark(descendant, "Parent")
		end
	end

	---On workspace descendant removing.
	---@param descendant Instance
	local function onWorkspaceDescendantRemoving(descendant)
		killBricksMap:forget(descendant)
		lightBarrierMap:forget(descendant)
	end

	---Initalize removal.
	function Removal.init()
		---@note: Not type of RBXScriptSignal - but it works.
		local effectReplicator = replicatedStorage:WaitForChild("EffectReplicator")
		local effectReplicatorModule = require(effectReplicator)
		local effectAddedSignal = Signal.new(effectReplicatorModule.EffectAdded)

		removalMaid:add(
			workspaceDescendantAdded:connect("Removal_WorkspaceDescendantAdded", onWorkspaceDescendantAdded)
		)
		removalMaid:add(
			workspaceDescendantRemoving:connect("Removal_WorkspaceDescendantRemoving", onWorkspaceDescendantRemoving)
		)

		removalMaid:add(renderStepped:connect("Removal_RenderStepped", updateRemoval))
		removalMaid:add(effectAddedSignal:connect("Removal_EffectAdded", updateRemovalEffects))

		for _, descendant in pairs(workspace:GetDescendants()) do
			onWorkspaceDescendantAdded(descendant)
		end

		for _, effect in next, effectReplicatorModule.Effects do
			updateRemovalEffects(effect)
		end

		-- Log.
		Logger.warn("Removal initialized.")
	end

	---Detach removal.
	function Removal.detach()
		-- Clean.
		removalMaid:clean()

		-- Restore.
		resetNoBlind()
		restoreNoAcidWater()

		-- Log.
		Logger.warn("Removal detached.")
	end

	-- Return Removal module.
	return Removal
end)()

end)
__bundle_register("Features/Visuals/Visuals", function(require, _LOADED, __bundle_register, __bundle_modules)
---@module Utility.Maid
local Maid = require("Utility/Maid")

---@module Utility.Signal
local Signal = require("Utility/Signal")

---@module Features.Visuals.Objects.ModelESP
local ModelESP = require("Features/Visuals/Objects/ModelESP")

---@module Features.Visuals.Objects.PartESP
local PartESP = require("Features/Visuals/Objects/PartESP")

---@module Features.Visuals.Objects.MobESP
local MobESP = require("Features/Visuals/Objects/MobESP")

---@module Features.Visuals.Objects.PlayerESP
local PlayerESP = require("Features/Visuals/Objects/PlayerESP")

---@module Utility.TaskSpawner
local TaskSpawner = require("Utility/TaskSpawner")

---@module Features.Visuals.Objects.FilteredESP
local FilteredESP = require("Features/Visuals/Objects/FilteredESP")

---@module Features.Visuals.Group
local Group = require("Features/Visuals/Group")

---@module Utility.Profiler
local Profiler = require("Utility/Profiler")

---@module Utility.Configuration
local Configuration = require("Utility/Configuration")

---@module Utility.OriginalStoreManager
local OriginalStoreManager = require("Utility/OriginalStoreManager")

---@module Features.Visuals.Objects.ChestESP
local ChestESP = require("Features/Visuals/Objects/ChestESP")

---@module Utility.InstanceWrapper
local InstanceWrapper = require("Utility/InstanceWrapper")

---@module Utility.Table
local Table = require("Utility/Table")

---@module Utility.Logger
local Logger = require("Utility/Logger")

---@module Features.Visuals.Objects.ObeliskESP
local ObeliskESP = require("Features/Visuals/Objects/ObeliskESP")

---@module Features.Visuals.Objects.BoneAltarESP
local BoneAltarESP = require("Features/Visuals/Objects/BoneAltarESP")

---@module Features.Combat.StateListener
local StateListener = require("Features/Combat/StateListener")

-- Visuals module.
local Visuals = { bdata = nil, drinfo = nil }

-- Last visuals update.
local lastVisualsUpdate = os.clock()
local lastHoveringUpdate = os.clock()
local lastESPUpdate = os.clock()

-- Services.
local runService = game:GetService("RunService")
local players = game:GetService("Players")
local replicatedStorage = game:GetService("ReplicatedStorage")
local textChatService = game:GetService("TextChatService")
local userInputService = game:GetService("UserInputService")
local guiService = game:GetService("GuiService")

-- Signals.
local renderStepped = Signal.new(runService.RenderStepped)

-- Maids.
local visualsMaid = Maid.new()
local builderAssistanceMaid = Maid.new()

-- Card frames.
local cardFrames = {}

-- Map.
local labelMap = {}
local hoveringMap = {}

-- Terrain attachments.
local attachments = {}

-- Groups.
local groups = {}

-- Original stores.
local fieldOfView = nil

-- Original store managers.
local showRobloxChatMap = visualsMaid:mark(OriginalStoreManager.new())
local noAnimatedSeaMap = visualsMaid:mark(OriginalStoreManager.new())
local noPersistentMap = visualsMaid:mark(OriginalStoreManager.new())
local buildAssistanceMap = visualsMaid:mark(OriginalStoreManager.new())
local jobBoardMap = visualsMaid:mark(OriginalStoreManager.new())

---Update chain of perfection tracker.
local updateChainOfPerfectionTracker = LPH_NO_VIRTUALIZE(function()
	local localPlayer = players.LocalPlayer
	if not localPlayer then
		return
	end

	local playerGui = localPlayer.PlayerGui
	if not playerGui then
		return
	end

	local currencyGui = playerGui:FindFirstChild("CurrencyGui")
	if not currencyGui then
		return
	end

	local currencyFrame = currencyGui:FindFirstChild("CurrencyFrame")
	if not currencyFrame then
		return
	end

	local crownsTextLabel = currencyFrame:FindFirstChild("Crowns")
	if not crownsTextLabel then
		return
	end

	-- Setup.
	local stackTextLabel = InstanceWrapper.mark(visualsMaid, "StackTextLabel", crownsTextLabel:Clone())
	stackTextLabel.Name = "ChainStacks"
	stackTextLabel.Parent = currencyFrame
	stackTextLabel.Visible = true

	-- Amount.
	local amountLabel = stackTextLabel:FindFirstChild("Amount")
	if not amountLabel then
		return
	end

	amountLabel.Text = tostring(StateListener.chainStacks or 0)
	amountLabel.TextColor3 = Color3.new(255, 255, 255)

	-- Icon.
	local icon = stackTextLabel:FindFirstChild("Icon")
	if not icon then
		return
	end

	icon.Image = "rbxassetid://92751444684393"
	icon.ImageColor3 = Color3.new(255, 255, 255)
	icon.ImageRectOffset = Vector2.new(0, 0)
	icon.ImageRectSize = Vector2.new(0, 0)

	-- Lore.
	stackTextLabel:SetAttribute("Tip_Title", "Chain Stacks")
	stackTextLabel:SetAttribute(
		"Tip_Desc",
		"This shows how many 'Chain of Perfection' stacks you currently have. This number is a prediction."
	)
end)

---Update sanity tracker.
local updateSanityTracker = LPH_NO_VIRTUALIZE(function()
	local localPlayer = players.LocalPlayer
	if not localPlayer then
		return
	end

	local playerGui = localPlayer.PlayerGui
	if not playerGui then
		return
	end

	local currencyGui = playerGui:FindFirstChild("CurrencyGui")
	if not currencyGui then
		return
	end

	local currencyFrame = currencyGui:FindFirstChild("CurrencyFrame")
	if not currencyFrame then
		return
	end

	local crownsTextLabel = currencyFrame:FindFirstChild("Crowns")
	if not crownsTextLabel then
		return
	end

	-- Character.
	local character = localPlayer.Character
	if not character then
		return
	end

	local sanity = character:FindFirstChild("Sanity")
	if not sanity then
		return
	end

	-- Setup.
	local sanityTextLabel = InstanceWrapper.mark(visualsMaid, "SanityTextLabel", crownsTextLabel:Clone())
	sanityTextLabel.Name = "Sanity"
	sanityTextLabel.Parent = currencyFrame
	sanityTextLabel.Visible = true

	local mainColor = Color3.fromRGB(0, 191, 255)

	if sanity.Value <= sanity.MaxValue * 0.70 then
		mainColor = Color3.fromRGB(255, 239, 94)
	end

	if sanity.Value <= sanity.MaxValue * 0.50 then
		mainColor = Color3.fromRGB(255, 216, 110)
	end

	if sanity.Value <= sanity.MaxValue * 0.40 then
		mainColor = Color3.fromRGB(255, 111, 0)
	end

	if sanity.Value <= sanity.MaxValue * 0.10 then
		mainColor = Color3.fromRGB(255, 0, 0)
	end

	if sanity.Value <= 0.0 then
		mainColor = Color3.fromRGB(114, 114, 114)
	end

	-- Amount.
	local amountLabel = sanityTextLabel:FindFirstChild("Amount")
	if not amountLabel then
		return
	end

	local formatString = ((sanity.Value / sanity.MaxValue) * 100) <= 1.0 and "%.2f" or "%i"
	amountLabel.Text = string.format(formatString, (sanity.Value / sanity.MaxValue) * 100) .. "%"
	amountLabel.TextColor3 = mainColor

	-- Icon.
	local icon = sanityTextLabel:FindFirstChild("Icon")
	if not icon then
		return
	end

	icon.Image = "http://www.roblox.com/asset/?id=16865012250"
	icon.ImageColor3 = mainColor
	icon.ImageRectOffset = Vector2.new(0, 0)
	icon.ImageRectSize = Vector2.new(0, 0)

	-- Lore.
	sanityTextLabel:SetAttribute("Tip_Title", "Sanity")
	sanityTextLabel:SetAttribute(
		"Tip_Desc",
		"The Flicker is a creeping affliction, awarded by the abyss for prolonged exposure to its horrors or a perverse talent for understanding its maddening secrets. This erosion of the mind holds a terrifying value in the afflicted's perception, granting a twisted understanding of the unseen, marking them as touched by powers beyond mortal comprehension."
	)
end)

---On Player GUI descendant added.
---@param descendant Instance
local onPlayerGuiDescendantAdded = LPH_NO_VIRTUALIZE(function(descendant)
	if descendant.Name ~= "CardFrame" then
		return
	end

	cardFrames[descendant] = true
end)

---On Player GUI descendant removed.
---@param descendant Instance
local onPlayerGuiDescendantRemoving = LPH_NO_VIRTUALIZE(function(descendant)
	if not cardFrames[descendant] then
		return
	end

	cardFrames[descendant] = nil
end)

---Update card frames.
local updateCardFrames = LPH_NO_VIRTUALIZE(function()
	for frame in next, cardFrames do
		local title = frame:FindFirstChild("Title")
		if not title then
			continue
		end

		local border = frame:FindFirstChild("Border")
		if not border then
			continue
		end

		local drinfo = Visuals.drinfo
		if not drinfo then
			continue
		end

		---@type BuilderData
		local bdata = Visuals.bdata
		if not bdata then
			continue
		end

		local trimmedName = string.gsub(title.Text, "^%s*(.-)%s*$", "%1")
		local cardInData = table.find(bdata.talents, trimmedName) or table.find(bdata.mantras, trimmedName)

		buildAssistanceMap:add(border, "ImageColor3", cardInData and Color3.new(0, 255, 0) or Color3.new(255, 0, 0))

		if
			cardInData
			and bdata.ddata:possible(trimmedName, bdata.pre)
			and not bdata.ddata:possible(trimmedName, bdata.post)
		then
			buildAssistanceMap:add(border, "ImageColor3", Color3.new(255, 0, 255))
		end

		if cardInData then
			continue
		end

		local mappingMatch = {
			["Vitality"] = { expectedValue = bdata.traits["Vitality"], value = drinfo["TraitHealth"] },
			["Erudition"] = { expectedValue = bdata.traits["Erudition"], value = drinfo["TraitEther"] },
			["Proficiency"] = { expectedValue = bdata.traits["Proficiency"], value = drinfo["TraitWeaponDamage"] },
			["Songchant"] = { expectedValue = bdata.traits["Songchant"], value = drinfo["TraitMantraDamage"] },
		}

		for idx, data in next, mappingMatch do
			if not title.Text:match(idx) then
				continue
			end

			buildAssistanceMap:add(
				border,
				"ImageColor3",
				data.expectedValue ~= data.value and Color3.new(0, 255, 0) or Color3.new(255, 0, 0)
			)
		end
	end
end)

---Update power background.
---@param jframe Frame
local updatePowerBackground = LPH_NO_VIRTUALIZE(function(jframe)
	local panels = jframe and jframe:FindFirstChild("Panels")
	local infoFrame = panels and panels:FindFirstChild("InfoFrame")
	local sheets = infoFrame and infoFrame:FindFirstChild("Sheets")
	local power = sheets and sheets:FindFirstChild("Power")
	local background = power and power:FindFirstChild("Background")
	if not background then
		return
	end

	local drinfo = Visuals.drinfo
	if not drinfo then
		return
	end

	---@type BuilderData
	local bdata = Visuals.bdata
	if not bdata then
		return
	end

	---@note: We do not care if there is no pre-shrine state at all.
	if not bdata:dshrine() then
		return
	end

	local color = Color3.fromRGB(245, 137, 5)
	local pstate = bdata:ipre(drinfo)

	if pstate == 0 then
		color = Color3.fromRGB(97, 4, 113)
	end

	if pstate == 1 then
		color = Color3.fromRGB(37, 129, 236)
	end

	buildAssistanceMap:add(background, "BackgroundColor3", color)
end)

---Update attribute frame.
---@param jframe Frame
local updateAttributeFrame = LPH_NO_VIRTUALIZE(function(jframe)
	local panels = jframe:FindFirstChild("Panels")
	local attributeFrame = panels and panels:FindFirstChild("AttributeFrame")
	local sheets = attributeFrame and attributeFrame:FindFirstChild("Sheets")
	if not sheets then
		return
	end

	local drinfo = Visuals.drinfo
	if not drinfo then
		return
	end

	---@type BuilderData
	local bdata = Visuals.bdata
	if not bdata then
		return
	end

	local attributes = bdata:attributes(drinfo)
	local mapping = {
		["Agility"] = attributes.base["Agility"],
		["Strength"] = attributes.base["Strength"],
		["Fortitude"] = attributes.base["Fortitude"],
		["Intelligence"] = attributes.base["Intelligence"],
		["Willpower"] = attributes.base["Willpower"],
		["Charisma"] = attributes.base["Charisma"],
		["ElementBlood"] = attributes.attunement["Bloodrend"],
		["ElementFire"] = attributes.attunement["Flamecharm"],
		["ElementIce"] = attributes.attunement["Frostdraw"],
		["ElementLightning"] = attributes.attunement["Thundercall"],
		["ElementWind"] = attributes.attunement["Galebreathe"],
		["ElementShadow"] = attributes.attunement["Shadowcast"],
		["ElementMetal"] = attributes.attunement["Ironsing"],
		["WeaponHeavy"] = attributes.weapon["Heavy Wep."],
		["WeaponMedium"] = attributes.weapon["Medium Wep."],
		["WeaponLight"] = attributes.weapon["Light Wep."],
	}

	for _, instance in next, sheets:GetDescendants() do
		if not instance:IsA("TextButton") then
			continue
		end

		local expectedValue = mapping[instance.Name]
		if not expectedValue then
			continue
		end

		local background = instance:FindFirstChild("Background")
		if not background then
			continue
		end

		local valueLabel = instance:FindFirstChild("Value")
		if not valueLabel then
			continue
		end

		local statInvested = tonumber(drinfo["Stat" .. instance.Name])
		if not statInvested then
			continue
		end

		local value = (bdata:ipre(drinfo) == 0 and statInvested <= 0) and statInvested or tonumber(valueLabel.Text)
		if not value then
			continue
		end

		local abbrevLabel = instance:FindFirstChild("Abbrev")
		if not abbrevLabel then
			continue
		end

		local color = expectedValue ~= value and Color3.fromRGB(9, 136, 0) or Color3.fromRGB(127, 0, 2)

		if value > expectedValue then
			color = Color3.fromRGB(128, 128, 128)
		end

		buildAssistanceMap:add(background, "BackgroundColor3", color)

		buildAssistanceMap:add(abbrevLabel, "Text", string.format("GET (%i)", expectedValue))
	end
end)

---Update traits.
---@param jframe Frame
local updateTraits = LPH_NO_VIRTUALIZE(function(jframe)
	local panels = jframe:FindFirstChild("Panels")
	local infoFrame = panels and panels:FindFirstChild("InfoFrame")
	local sheets = infoFrame and infoFrame:FindFirstChild("Sheets")
	local traitSheet = sheets and sheets:FindFirstChild("TraitSheet")
	local container = traitSheet and traitSheet:FindFirstChild("Container")
	if not container then
		return
	end

	local drinfo = Visuals.drinfo
	if not drinfo then
		return
	end

	---@type BuilderData
	local bdata = Visuals.bdata
	if not bdata then
		return
	end

	local mapping = {
		["Ether"] = bdata.traits["Erudition"],
		["Health"] = bdata.traits["Vitality"],
		["WeaponDamage"] = bdata.traits["Proficiency"],
		["MantraDamage"] = bdata.traits["Songchant"],
	}

	for _, instance in next, sheets:GetDescendants() do
		if not instance:IsA("Frame") then
			continue
		end

		local expectedValue = mapping[instance.Name]
		if not expectedValue then
			continue
		end

		local background = instance:FindFirstChild("Background")
		if not background then
			continue
		end

		local valueLabel = instance:FindFirstChild("Value")
		if not valueLabel then
			continue
		end

		local value = tonumber(valueLabel.Text)
		if not value then
			continue
		end

		local color = expectedValue ~= value and Color3.fromRGB(9, 136, 0) or Color3.fromRGB(127, 0, 2)

		if value > expectedValue then
			color = Color3.fromRGB(128, 128, 128)
		end

		buildAssistanceMap:add(background, "BackgroundColor3", color)
	end
end)

---Strip weapon tags like [HVY], [LHT], [MED], [FTD], [BLD] for display.
local function stripTags(str)
	return str:gsub("%s*%[.-%]$", "")
end

---Update talent sheet.
---@param rframe Frame
local updateTalentSheet = LPH_NO_VIRTUALIZE(function(rframe)
	local talentSheet = rframe:FindFirstChild("TalentSheet")
	local container = talentSheet and talentSheet:FindFirstChild("Container")
	local talentScroll = container and container:FindFirstChild("TalentScroll")
	if not talentScroll then
		return
	end

	local drinfo = Visuals.drinfo
	if not drinfo then
		return
	end

	---@type BuilderData
	local bdata = Visuals.bdata
	if not bdata then
		return
	end

	local divider = talentScroll:FindFirstChild("8ZQuestDivider")
	if not divider then
		return
	end

	-- Find a frame template with title child (new ui structure).
	local talentFrameTemplate = nil
	for _, child in next, talentScroll:GetChildren() do
		if child:IsA("Frame") and not child.Name:match("Divider$") and child:FindFirstChild("Title") then
			talentFrameTemplate = child
			break
		end
	end

	if not talentFrameTemplate then
		return
	end

	-- Disable UIVanity script while modifying GUI.
	local playerGui = players.LocalPlayer:FindFirstChild("PlayerGui")
	local uiVanity = playerGui and playerGui:FindFirstChild("UIVanity")
	local wasEnabled = uiVanity and uiVanity.Enabled

	if uiVanity then
		uiVanity.Enabled = false
	end

	-- Clean maid to re-setup.
	builderAssistanceMaid:clean()

	-- Create state.
	labelMap = {}

	-- First step: color everything inside and remove everything that is in the builder list already.
	local filteredTalents = table.clone(bdata.talents)

	for _, instance in next, talentScroll:GetDescendants() do
		if not instance:IsA("TextLabel") then
			continue
		end

		if instance.Name ~= "Title" then
			continue
		end

		local instanceText = instance.Text

		local idx = Table.find(filteredTalents, function(value, _)
			local valueClean = stripTags(value)
			return instanceText == valueClean or instanceText == value
		end)

		if not idx then
			continue
		end

		buildAssistanceMap:add(instance, "TextColor3", Color3.fromRGB(9, 255, 0))

		filteredTalents[idx] = nil
	end

	-- Pre second step: create a nice looking separator.
	local tseparator = InstanceWrapper.mark(builderAssistanceMaid, "tdivider", divider:Clone())
	tseparator.Name = "LMissingTalentDivider"
	tseparator.LayoutOrder = 9990
	tseparator.Parent = talentScroll

	-- Second step: add every filtered talent as red (or purple if pre-shrine).
	local talentOrder = 9991
	for _, talent in next, filteredTalents do
		local data = bdata.ddata:get(talent)
		if not data then
			continue
		end

		local cleanTalent = stripTags(talent)

		local newFrame = InstanceWrapper.mark(builderAssistanceMaid, talent, talentFrameTemplate:Clone())
		local pshlocked = (bdata.ddata:possible(talent, bdata.pre) and not bdata.ddata:possible(talent, bdata.post))
		newFrame.Name = "M" .. cleanTalent
		newFrame.LayoutOrder = talentOrder
		talentOrder = talentOrder + 1

		local icon = newFrame:FindFirstChild("Icon")
		if icon then
			icon:Destroy()
		end

		local title = newFrame:FindFirstChild("Title")
		if title then
			title.Name = "M" .. cleanTalent
			title.Text = cleanTalent
			title.TextColor3 = pshlocked and Color3.fromRGB(255, 4, 255) or Color3.fromRGB(255, 0, 2)
			title.TextTransparency = 0.4
		end

		newFrame.Parent = talentScroll

		labelMap["M" .. cleanTalent] = data
	end

	-- Pre third step: create a nice looking separator.
	local mseparator = InstanceWrapper.mark(builderAssistanceMaid, "mdivider", divider:Clone())
	mseparator.Name = "XMissingMantraDivider"
	mseparator.LayoutOrder = 9995
	mseparator.Parent = talentScroll

	-- Third step: add every mantra as red (or purple if pre-shrine).
	local mantraOrder = 9996
	for _, mantra in next, bdata.mantras do
		local data = bdata.ddata:get(mantra)
		if not data then
			continue
		end

		local cleanMantra = stripTags(mantra)

		local idx = Table.find(players.LocalPlayer.Backpack:GetChildren(), function(value, _)
			local displayName = value:GetAttribute("DisplayName")
			if not displayName then
				return false
			end
			local cleanDisplayName = stripTags(displayName)
			return cleanDisplayName == cleanMantra or displayName == cleanMantra
		end)

		local newFrame = InstanceWrapper.mark(builderAssistanceMaid, mantra, talentFrameTemplate:Clone())
		local pshlocked = (bdata.ddata:possible(mantra, bdata.pre) and not bdata.ddata:possible(mantra, bdata.post))
		newFrame.Name = "Z" .. cleanMantra
		newFrame.LayoutOrder = mantraOrder
		mantraOrder = mantraOrder + 1

		local icon = newFrame:FindFirstChild("Icon")
		if icon then
			icon:Destroy()
		end

		local title = newFrame:FindFirstChild("Title")
		if title then
			title.Name = "Z" .. cleanMantra
			title.Text = cleanMantra
			title.TextColor3 = pshlocked and Color3.fromRGB(255, 4, 255) or Color3.fromRGB(255, 0, 2)
			title.TextTransparency = 0.4

			if idx then
				title.TextColor3 = Color3.fromRGB(9, 255, 0)
			end
		end

		newFrame.Parent = talentScroll

		labelMap["Z" .. cleanMantra] = data
	end

	-- Re-enable UIVanity script.
	if uiVanity and wasEnabled then
		uiVanity.Enabled = true
	end
end)

---Update card hovering.
local updateCardHovering = LPH_NO_VIRTUALIZE(function()
	if os.clock() - lastHoveringUpdate <= 0.05 then
		return
	end

	lastHoveringUpdate = os.clock()

	local localPlayer = players.LocalPlayer
	local playerGui = localPlayer and localPlayer:FindFirstChild("PlayerGui")
	local backpackGui = playerGui and playerGui:FindFirstChild("BackpackGui")
	if not backpackGui then
		return
	end

	local rightFrame = backpackGui and backpackGui:FindFirstChild("RightFrame")
	if not rightFrame then
		return
	end

	local talentSheet = rightFrame and rightFrame:FindFirstChild("TalentSheet")
	local container = talentSheet and talentSheet:FindFirstChild("Container")
	local talentScroll = container and container:FindFirstChild("TalentScroll")
	if not talentScroll then
		return
	end

	local talentDisplay = talentSheet and talentSheet:FindFirstChild("TalentDisplay")
	local cardFrame = talentDisplay and talentDisplay:FindFirstChild("CardFrame")
	if not cardFrame then
		return
	end

	local icon = cardFrame:FindFirstChild("Icon")
	local stats = cardFrame:FindFirstChild("Stats")
	local title = cardFrame:FindFirstChild("Title")

	local details = cardFrame:FindFirstChild("Details")
	local desc = details and details:FindFirstChild("Desc")
	local class = details and details:FindFirstChild("Class")

	if not icon or not stats or not class or not desc or not title then
		return
	end

	local mousePosition = userInputService:GetMouseLocation() - guiService:GetGuiInset()
	if not mousePosition then
		return
	end

	local guiObjects = playerGui:GetGuiObjectsAtPosition(mousePosition.X, mousePosition.Y)

	-- Build hovering set.
	local currentlyHovering = {}
	for _, object in next, guiObjects do
		if object:IsA("TextLabel") and labelMap[object.Name] then
			currentlyHovering[object.Name] = object
		end

		-- Check Frame > Title pattern.
		if object:IsA("Frame") then
			local titleLabel = object:FindFirstChild("Title")
			if titleLabel and titleLabel:IsA("TextLabel") and labelMap[titleLabel.Name] then
				currentlyHovering[titleLabel.Name] = titleLabel
			end
		end
	end

	-- Remove unhovered objects.
	for name, storedObject in next, hoveringMap do
		if currentlyHovering[name] then
			continue
		end

		-- Reset transparency.
		if storedObject and typeof(storedObject) == "Instance" and storedObject:IsA("TextLabel") then
			storedObject.TextTransparency = 0.4
		end

		hoveringMap[name] = nil
	end

	local firstHoveringData = nil
	local hoveringOverTalent = false

	-- Check talent sheet hover.
	for _, object in next, guiObjects do
		if not hoveringOverTalent and object:IsDescendantOf(talentSheet) then
			hoveringOverTalent = true
		end
	end

	-- Update hovered objects.
	for name, targetLabel in next, currentlyHovering do
		local data = labelMap[name]
		if not data then
			continue
		end

		-- Set transparency.
		targetLabel.TextTransparency = 0.1

		-- Store reference.
		hoveringMap[name] = targetLabel

		-- Set data.
		firstHoveringData = firstHoveringData or data
	end

	talentDisplay.Visible = hoveringOverTalent
	stats.Text = ""

	if not firstHoveringData then
		return
	end

	desc.Text = firstHoveringData.desc or "N/A"
	title.Text = firstHoveringData.name or "N/A"
	class.Text = firstHoveringData.category or "???"
	icon.ImageRectOffset = Vector2.new(0, 0)
	icon.Image = "rbxassetid://94097748688985"

	local colorTable = {
		["rare"] = Color3.fromRGB(145, 94, 95),
		["common"] = Color3.fromRGB(98, 97, 90),
		["advanced"] = Color3.fromRGB(58, 117, 129),
		["whisper"] = Color3.fromRGB(143, 110, 145),
		["mystery"] = Color3.fromRGB(145, 158, 172),
		["oath"] = Color3.fromRGB(25, 44, 62),
		["faction"] = Color3.fromRGB(52, 83, 41),
		["quest"] = Color3.fromRGB(153, 125, 47),
		["resonance"] = Color3.fromRGB(63, 78, 129),
		["corrupted resonance"] = Color3.fromRGB(117, 48, 81),
		["drowned resonance"] = Color3.fromRGB(198, 199, 255),
		["legendary resonance"] = Color3.fromRGB(222, 209, 191),
		["artifact"] = Color3.fromRGB(114, 77, 222),
	}

	local backgroundColor = colorTable[string.lower(firstHoveringData.rarity or "N/A")]
	if backgroundColor then
		cardFrame.BackgroundColor3 = backgroundColor
	end

	local reqData = firstHoveringData.reqs
	local reqTags = {}
	local tagMap = {
		["Strength"] = "STR",
		["Fortitude"] = "FTD",
		["Agility"] = "AGI",
		["Intelligence"] = "INT",
		["Willpower"] = "WIL",
		["Charisma"] = "CHA",
		["Mind"] = "MIND",
		["Body"] = "BODY",
		["Heavy Wep."] = "WEP",
		["Medium Wep."] = "WEP",
		["Light Wep."] = "WEP",
		["Flamecharm"] = "FLM",
		["Frostdraw"] = "FRST",
		["Thundercall"] = "THUN",
		["Galebreathe"] = "GALE",
		["Shadowcast"] = "SDW",
		["Ironsing"] = "IRON",
		["Bloodrend"] = "BLD",
	}

	local function checkAttributes(attributes)
		for idx, requirement in next, attributes do
			local tag = tagMap[idx]
			if not tag then
				continue
			end

			if requirement == 0 then
				continue
			end

			reqTags[#reqTags + 1] = string.format("%s %s", requirement, tag)
		end
	end

	if reqData.power ~= "0" then
		reqTags[#reqTags + 1] = string.format("PWR %s", reqData.power)
	end

	checkAttributes(reqData.base)
	checkAttributes(reqData.weapon)
	checkAttributes(reqData.attunement)

	stats.Text = table.concat(reqTags, ", ")
end)

---Update train.
---@param jframe Frame
local updateTrain = LPH_NO_VIRTUALIZE(function(jframe)
	local panels = jframe:FindFirstChild("Panels")
	local attributeFrame = panels and panels:FindFirstChild("AttributeFrame")
	local sheets = attributeFrame and attributeFrame:FindFirstChild("Sheets")
	if not sheets then
		return
	end

	local drinfo = Visuals.drinfo
	if not drinfo then
		return
	end

	---@type BuilderData
	local bdata = Visuals.bdata
	if not bdata then
		return
	end

	local attributes = bdata:attributes(drinfo)
	local mapping = {
		["Agility"] = attributes.base["Agility"],
		["Strength"] = attributes.base["Strength"],
		["Fortitude"] = attributes.base["Fortitude"],
		["Intelligence"] = attributes.base["Intelligence"],
		["Willpower"] = attributes.base["Willpower"],
		["Charisma"] = attributes.base["Charisma"],
		["ElementBlood"] = attributes.attunement["Bloodrend"],
		["ElementFire"] = attributes.attunement["Flamecharm"],
		["ElementIce"] = attributes.attunement["Frostdraw"],
		["ElementLightning"] = attributes.attunement["Thundercall"],
		["ElementWind"] = attributes.attunement["Galebreathe"],
		["ElementShadow"] = attributes.attunement["Shadowcast"],
		["ElementMetal"] = attributes.attunement["Ironsing"],
		["WeaponHeavy"] = attributes.weapon["Heavy Wep."],
		["WeaponMedium"] = attributes.weapon["Medium Wep."],
		["WeaponLight"] = attributes.weapon["Light Wep."],
	}

	for _, instance in next, sheets:GetDescendants() do
		if not instance:IsA("TextButton") then
			continue
		end

		local expectedValue = mapping[instance.Name]
		if not expectedValue then
			continue
		end

		local train = instance:FindFirstChild("Train")
		if not train then
			continue
		end

		if not train.Visible then
			continue
		end

		local valueLabel = instance:FindFirstChild("Value")
		if not valueLabel then
			continue
		end

		local statInvested = tonumber(drinfo["Stat" .. instance.Name])
		if not statInvested then
			continue
		end

		local value = (bdata:ipre(drinfo) == 0 and statInvested <= 0) and statInvested or tonumber(valueLabel.Text)
		if not value then
			continue
		end

		local color = expectedValue ~= value and Color3.fromRGB(9, 136, 0) or Color3.fromRGB(127, 0, 2)

		if value > expectedValue then
			color = Color3.fromRGB(128, 128, 128)
		end

		buildAssistanceMap:add(train, "ImageColor3", color)
	end
end)

---Update build assistance.
local updateBuildAssistance = LPH_NO_VIRTUALIZE(function()
	updateCardFrames()

	local localPlayer = players.LocalPlayer
	local playerGui = localPlayer and localPlayer:FindFirstChild("PlayerGui")
	local backpackGui = playerGui and playerGui:FindFirstChild("BackpackGui")
	if not backpackGui then
		return
	end

	local rightFrame = backpackGui and backpackGui:FindFirstChild("RightFrame")
	if not rightFrame then
		return
	end

	local bpJournalFrame = rightFrame and rightFrame:FindFirstChild("JournalFrame")
	if not bpJournalFrame then
		return
	end

	updateAttributeFrame(bpJournalFrame)
	updateTraits(bpJournalFrame)
	updatePowerBackground(bpJournalFrame)
	updateTalentSheet(rightFrame)
	updateTrain(bpJournalFrame)
end)

---Update no persistence.
local updateNoPersistence = LPH_NO_VIRTUALIZE(function()
	local localPlayer = players.LocalPlayer
	if not localPlayer then
		return
	end

	for _, group in next, groups do
		for _, object in next, group:data() do
			if object.__type == "PlayerESP" and object.character and object.character:IsA("Model") then
				noPersistentMap:add(object.character, "ModelStreamingMode", Enum.ModelStreamingMode.Default)
			end

			if object.__type == "ModelESP" and object.model then
				noPersistentMap:add(object.model, "ModelStreamingMode", Enum.ModelStreamingMode.Default)
			end
		end
	end
end)

---Update show roblox chat.
local updateShowRobloxChat = LPH_NO_VIRTUALIZE(function()
	local localPlayer = players.LocalPlayer
	if not localPlayer then
		return
	end

	local playerGui = localPlayer.PlayerGui
	if not playerGui then
		return
	end

	local chatWindowConfiguration = textChatService:FindFirstChild("ChatWindowConfiguration")
	if not chatWindowConfiguration then
		return
	end

	showRobloxChatMap:add(chatWindowConfiguration, "Enabled", true)

	---@note: Probably set a proper restore for this?
	--- But, in Deepwoken, users cannot realisitically access the Roblox chat anyway.
	textChatService.OnIncomingMessage = function(message)
		local source = message.TextSource
		if not source then
			return
		end

		local player = players:GetPlayerByUserId(source.UserId)
		if not player then
			return
		end

		if Configuration.expectToggleValue("InfoSpoofing") then
			message.PrefixText = "[REDACTED]"
			return
		end

		message.PrefixText = string.gsub(message.PrefixText, player.DisplayName, player.Name)
		message.PrefixText =
			string.format("(%s) %s", player:GetAttribute("CharacterName") or "Unknown Character Name", player.Name)
	end
end)

---Update no animated sea.
local updateNoAnimatedSea = LPH_NO_VIRTUALIZE(function()
	local localPlayer = players.LocalPlayer
	local playerScripts = localPlayer and localPlayer:FindFirstChild("PlayerScripts")
	if not playerScripts then
		return
	end

	local seaClient = playerScripts:FindFirstChild("SeaClient")
	if not seaClient then
		return
	end

	noAnimatedSeaMap:add(seaClient, "Enabled", false)

	for _, descendant in next, seaClient:GetDescendants() do
		if not descendant:IsA("LocalScript") then
			continue
		end

		noAnimatedSeaMap:add(descendant, "Enabled", false)
	end
end)

---Update terrain attachments.
local updateTerrainAttachments = LPH_NO_VIRTUALIZE(function()
	for _, attachment in next, attachments do
		local jtg = attachment:FindFirstChild("JobTrackerGui")
		if not jtg then
			continue
		end

		jobBoardMap:add(jtg, "MaxDistance", Configuration.idOptionValue("JobBoard", "MaxDistance") or 1e9)
	end
end)

---Update ESP.
local updateESP = LPH_NO_VIRTUALIZE(function()
	if os.clock() - lastESPUpdate <= (1 / (Configuration.expectOptionValue("ESPRefreshRate") or 30)) then
		return
	end

	lastESPUpdate = os.clock()

	for _, group in next, groups do
		group:update()
	end
end)

---Update visuals.
local updateVisuals = LPH_NO_VIRTUALIZE(function()
	updateESP()

	if Configuration.expectToggleValue("BuildAssistance") then
		updateCardHovering()
	end

	if os.clock() - lastVisualsUpdate <= 2.5 then
		return
	end

	lastVisualsUpdate = os.clock()

	if Configuration.idToggleValue("JobBoard", "Enable") then
		updateTerrainAttachments()
	else
		jobBoardMap:restore()
	end

	if Configuration.expectToggleValue("ChainOfPerfectionTracker") then
		updateChainOfPerfectionTracker()
	else
		visualsMaid["StackTextLabel"] = nil
	end

	if Configuration.expectToggleValue("SanityTracker") then
		updateSanityTracker()
	else
		visualsMaid["SanityTextLabel"] = nil
	end

	if Configuration.expectToggleValue("BuildAssistance") then
		updateBuildAssistance()
	else
		buildAssistanceMap:restore()
		builderAssistanceMaid:clean()
	end

	if Configuration.expectToggleValue("NoPersisentESP") then
		updateNoPersistence()
	else
		noPersistentMap:restore()
	end

	if Configuration.expectToggleValue("NoAnimatedSea") then
		updateNoAnimatedSea()
	else
		noAnimatedSeaMap:restore()
	end

	if Configuration.expectToggleValue("ModifyFieldOfView") then
		-- Save original.
		fieldOfView = fieldOfView or players.LocalPlayer:GetAttribute("FieldOfView")

		-- Set modified.
		players.LocalPlayer:SetAttribute("FieldOfView", Configuration.expectOptionValue("FieldOfView"))
	elseif fieldOfView then
		-- Set original.
		players.LocalPlayer:SetAttribute("FieldOfView", fieldOfView)

		-- Clear.
		fieldOfView = nil
	end

	if Configuration.expectToggleValue("ShowRobloxChat") then
		updateShowRobloxChat()
	else
		showRobloxChatMap:restore()
	end
end)

---Emplace object.
---@param instance Instance
---@param object ModelESP|PartESP
local emplaceObject = LPH_NO_VIRTUALIZE(function(instance, object)
	local group = groups[object.identifier] or Group.new(object.identifier)

	group:insert(instance, object)

	groups[object.identifier] = group
end)

---On Live ChildAdded.
---@param child Instance
local onLiveChildrenAdded = LPH_NO_VIRTUALIZE(function(child)
	if players:GetPlayerFromCharacter(child) then
		return
	end

	-- Safeguard to not get players on the Mob ESP.
	if players:FindFirstChild(child.Name) then
		return
	end

	return emplaceObject(
		child,
		FilteredESP.new(MobESP.new("Mob", child, child:GetAttribute("MOB_rich_name") or child.Name))
	)
end)

---On NPCs ChildAdded.
---@param child Instance
local onNPCsChildAdded = LPH_NO_VIRTUALIZE(function(child)
	if child.Name == "WindrunnerOrb" and child:IsA("BasePart") then
		return emplaceObject(child, PartESP.new("WindrunnerOrb", child, "Windrunner Orb"))
	end

	return emplaceObject(child, ModelESP.new("NPC", child, child.Name))
end)

---On Ingredients ChildAdded.
---@param child Instance
local onIngredientsChildAdded = LPH_NO_VIRTUALIZE(function(child)
	return emplaceObject(child, FilteredESP.new(PartESP.new("Ingredient", child, child.Name)))
end)

---On Thrown ChildAdded.
---@param child Instance
local onThrownChildAdded = LPH_NO_VIRTUALIZE(function(child)
	local name = child.Name

	if name == "MinistryCacheIndicator" then
		return emplaceObject(child, PartESP.new("MinistryCacheIndicator", child, "Ministry Cache Indicator"))
	end

	if name == "BigArtifact" and child:IsA("Model") then
		return emplaceObject(child, ModelESP.new("Artifact", child, "Artifact"))
	end

	if name == "BellMeteor" then
		return emplaceObject(child, ModelESP.new("BellMeteor", child, "Bell Meteor"))
	end

	if name == "ExplodeCrate" then
		return emplaceObject(child, PartESP.new("ExplosiveBarrel", child, "Explosive Barrel"))
	end

	if name == "BagDrop" then
		return emplaceObject(child, PartESP.new("BagDrop", child, "Bag"))
	end

	if name == "EventFeatherRef" then
		return emplaceObject(child, PartESP.new("OwlFeathers", child, "Owl Feathers"))
	end

	if name == "BoneSpear" then
		return emplaceObject(child, PartESP.new("BoneSpear", child, "Bone Spear"))
	end

	visualsMaid:mark(TaskSpawner.spawn("Visuals_ChestCheck", function()
		if child.Name == "Chest" and child:GetAttribute("LootName") ~= nil then
			return emplaceObject(child, ChestESP.new("Chest", child, "Chest"))
		end

		if not child:IsA("Model") and not child:IsA("Part") then
			return
		end

		if child:WaitForChild("LootUpdated", 0.1) then
			return emplaceObject(child, ChestESP.new("Chest", child, "Chest"))
		end
	end))
end)

---On Shop ChildAdded.
---@param child Instance
local onShopChildAdded = LPH_NO_VIRTUALIZE(function(child)
	local name = child.Name

	if not child:FindFirstChild("Cost") then
		return
	end

	if child:IsA("Model") then
		return emplaceObject(child, ModelESP.new("ShopESP", child, name))
	end

	return emplaceObject(child, PartESP.new("ShopESP", child, name))
end)

---Create listener.
---@param instance Instance
---@param identifier string
---@param addedCallback function
---@param removingCallback function
---@param childFlag boolean
local createListener = LPH_NO_VIRTUALIZE(function(instance, identifier, addedCallback, removingCallback, childFlag)
	local type = childFlag and "Child" or "Descendant"
	local added = Signal.new(childFlag and instance.ChildAdded or instance.DescendantAdded)
	local removed = Signal.new(childFlag and instance.ChildRemoved or instance.DescendantRemoving)

	visualsMaid:add(added:connect(string.format("Visuals_%sOn%sAdded", identifier, type), addedCallback))
	visualsMaid:add(removed:connect(string.format("Visuals_%sOn%sRemoved", identifier, type), removingCallback))

	Profiler.run(string.format("Visuals_%sAddInitial", identifier), function()
		for _, child in next, (childFlag and instance:GetChildren() or instance:GetDescendants()) do
			addedCallback(child)
		end
	end)
end)

-- Forward declaration.
local onWorkspaceChildAdded = nil

---On instance removing.
---@param inst Instance
local onInstanceRemoving = LPH_NO_VIRTUALIZE(function(inst)
	for _, group in next, groups do
		local object = group:remove(inst)
		if not object then
			continue
		end

		object:detach()
	end
end)

---On Avatar Room DescendantAdded.
---@param descendant Instance
local onAvatarRoomDescendantAdded = LPH_NO_VIRTUALIZE(function(descendant)
	if descendant.Name ~= "Altar" then
		return
	end

	return emplaceObject(descendant, BoneAltarESP.new("BoneAltar", descendant, "Bone Altar"))
end)

---On Workspace ChildAdded.
---@param child Instance
onWorkspaceChildAdded = LPH_NO_VIRTUALIZE(function(child)
	local name = child.Name

	if name == "Layer2Floor2" then
		return createListener(child, "Layer2Floor2", onWorkspaceChildAdded, onInstanceRemoving, true)
	end

	if name == "TrueAvatarBossRoom" then
		return createListener(child, "TrueAvatarBossRoom", onAvatarRoomDescendantAdded, onInstanceRemoving, false)
	end

	if name == "BellKeys" then
		for _, descendant in next, child:GetDescendants() do
			if not descendant:IsA("BasePart") then
				continue
			end

			if descendant.Name ~= "BellKey" then
				continue
			end

			return emplaceObject(descendant, PartESP.new("BellKey", descendant, "Bell Key"))
		end
	end

	if name == "JobBoard" then
		return emplaceObject(child, ModelESP.new("JobBoard", child, "Job Board"))
	end

	if name == "BigArtifact" and child:IsA("Model") then
		return emplaceObject(child, ModelESP.new("Artifact", child, "Artifact"))
	end

	if name == "WindrunnerOrb" and child:IsA("BasePart") then
		return emplaceObject(child, PartESP.new("WindrunnerOrb", child, "Windrunner Orb"))
	end

	if name == "DepthsWhirlpool" then
		return emplaceObject(child, ModelESP.new("Whirlpool", child, "Whirlpool"))
	end

	if name == "Sack" then
		return emplaceObject(child, PartESP.new("BagDrop", child, "Sack"))
	end

	if name == "MinistryCacheIndicator" then
		return emplaceObject(child, PartESP.new("MinistryCacheIndicator", child, "Ministry Cache Indicator"))
	end

	if name:match("GuildDoor") then
		local doorName = child:GetAttribute("GuildName") or "Unidentified Guild Door"
		return emplaceObject(child, PartESP.new("GuildDoor", child, doorName))
	end

	if name == "GuildBanner" then
		return emplaceObject(child, ModelESP.new("GuildBanner", child, "Guild Banner"))
	end

	if name == "Obelisk" then
		return emplaceObject(child, ObeliskESP.new("Obelisk", child, "Obelisk"))
	end

	if name:match("ArmorBrick") then
		local billboardGui = child:FindFirstChild("BillboardGui")
		local armorBrickLabel = billboardGui and billboardGui:FindFirstChild("TextLabel")
		local armorBrickName = armorBrickLabel and armorBrickLabel.Text

		if not armorBrickLabel then
			armorBrickName = "Unknown Armor Brick"
		end

		return emplaceObject(child, PartESP.new("ArmorBrick", child, armorBrickName))
	end

	if name == "RareObelisk" then
		return emplaceObject(child, ModelESP.new("RareObelisk", child, "Rare Obelisk"))
	end

	if name == "HealBrick" then
		return emplaceObject(child, PartESP.new("HealBrick", child, "Heal Brick"))
	end

	if name == "MantraObelisk" then
		return emplaceObject(child, ModelESP.new("MantraObelisk", child, "Mantra Obelisk"))
	end

	if name:match("Boundary") then
		return emplaceObject(child, PartESP.new("VOIBoundaryESP", child, child.Name))
	end

	if child:GetAttribute("Rarity") and child:IsA("MeshPart") then
		return emplaceObject(child, PartESP.new("VOIWeaponESP", child, child.Name))
	end

	visualsMaid:mark(TaskSpawner.spawn("Visuals_BRWeaponCheck", function()
		if child:IsA("MeshPart") and child:WaitForChild("InteractPrompt", 0.1) and not name:match("Barrel") then
			return emplaceObject(child, PartESP.new("BRWeapon", child, name))
		end
	end))
end)

---On terrain added.
local onTerrainChildAdded = LPH_NO_VIRTUALIZE(function(child)
	if child.Name ~= "Attachment" and not child:IsA("Attachment") then
		return
	end

	attachments[#attachments + 1] = child
end)

---On player added.
---@param player Player
local onPlayerAdded = LPH_NO_VIRTUALIZE(function(player)
	if player == players.LocalPlayer then
		return
	end

	local characterAdded = Signal.new(player.CharacterAdded)
	local characterRemoving = Signal.new(player.CharacterRemoving)
	local playerDestroying = Signal.new(player.Destroying)

	local characterAddedId = nil
	local characterRemovingId = nil
	local playerDestroyingId = nil

	characterAddedId = visualsMaid:add(characterAdded:connect("Visuals_OnCharacterAdded", function(character)
		emplaceObject(player, PlayerESP.new("Player", player, character))
	end))

	characterRemovingId = visualsMaid:add(characterRemoving:connect("Visuals_OnCharacterRemoving", function()
		onInstanceRemoving(player)
	end))

	playerDestroyingId = visualsMaid:add(playerDestroying:connect("Visuals_OnPlayerDestroying", function()
		visualsMaid[characterAddedId] = nil
		visualsMaid[characterRemovingId] = nil
		visualsMaid[playerDestroyingId] = nil
	end))

	local character = player.Character
	if not character then
		return
	end

	emplaceObject(player, PlayerESP.new("Player", player, character))
end)

---Initialize Visuals.
function Visuals.init()
	local live = workspace:WaitForChild("Live")
	local npcs = workspace:WaitForChild("NPCs")
	local ingredients = workspace:WaitForChild("Ingredients")
	local thrown = workspace:WaitForChild("Thrown")
	local terrain = workspace:WaitForChild("Terrain")
	local shops = workspace:WaitForChild("Shops")

	createListener(terrain, "Terrain", onTerrainChildAdded, onInstanceRemoving, true)
	createListener(workspace, "Workspace", onWorkspaceChildAdded, onInstanceRemoving, true)
	createListener(thrown, "Thrown", onThrownChildAdded, onInstanceRemoving, true)
	createListener(live, "Live", onLiveChildrenAdded, onInstanceRemoving, true)
	createListener(npcs, "NPCs", onNPCsChildAdded, onInstanceRemoving, true)
	createListener(ingredients, "Ingredients", onIngredientsChildAdded, onInstanceRemoving, true)
	createListener(players, "Players", onPlayerAdded, onInstanceRemoving, true)
	createListener(shops, "Shops", onShopChildAdded, onInstanceRemoving, true)

	---@note: We only need to get this once.
	for _, descendant in next, replicatedStorage:WaitForChild("MarkerWorkspace"):GetDescendants() do
		if descendant.Name ~= "AreaMarker" then
			continue
		end

		local areaMarkerName = descendant.Parent.Name or "Unidentified Area Marker"
		emplaceObject(descendant, FilteredESP.new(PartESP.new("AreaMarker", descendant, areaMarkerName)))
	end

	local localPlayer = players.LocalPlayer
	local playerGui = localPlayer:WaitForChild("PlayerGui")
	local playerGuiDescendantAdded = Signal.new(playerGui.DescendantAdded)
	local playerGuiDescendantRemoving = Signal.new(playerGui.DescendantRemoving)

	-- Wait for UIVanity and fix its initialization.
	visualsMaid:mark(TaskSpawner.spawn("Visuals_UIVanityWait", function()
		local uiVanity = playerGui:WaitForChild("UIVanity", 10)

		-- Disable and re-enable UIVanity to fix initialization issues.
		if uiVanity then
			uiVanity.Enabled = false
			task.wait()
			uiVanity.Enabled = true
		end

		-- Now safe to connect signals and process GUI.
		visualsMaid:add(playerGuiDescendantAdded:connect("Visuals_OnPlayerGuiDescendantAdded", onPlayerGuiDescendantAdded))
		visualsMaid:add(
			playerGuiDescendantRemoving:connect("Visuals_OnPlayerGuiDescendantRemoving", onPlayerGuiDescendantRemoving)
		)
		visualsMaid:add(renderStepped:connect("Visuals_RenderStepped", updateVisuals))

		for _, descendant in next, playerGui:GetDescendants() do
			onPlayerGuiDescendantAdded(descendant)
		end
	end))

	local info = replicatedStorage:WaitForChild("Info")
	local dataReplication = info:WaitForChild("DataReplication")
	local dataReplicationModule = require(dataReplication)

	-- GetData() can fail on hot reload.
	local success, drinfo = pcall(function()
		return dataReplicationModule.GetData()
	end)

	Visuals.drinfo = success and drinfo or nil

	Logger.warn("Visuals initialized.")
end

-- Detach Visuals.
function Visuals.detach()
	for _, group in next, groups do
		group:detach()
	end

	visualsMaid:clean()
	builderAssistanceMaid:clean()

	Logger.warn("Visuals detached.")
end

-- Return Visuals module.
return Visuals

end)
__bundle_register("Features/Visuals/Objects/BoneAltarESP", function(require, _LOADED, __bundle_register, __bundle_modules)
---@module Features.Visuals.Objects.ModelESP
local ModelESP = require("Features/Visuals/Objects/ModelESP")

---@module Utility.Configuration
local Configuration = require("Utility/Configuration")

---@class BoneAltarESP: ModelESP
local BoneAltarESP = setmetatable({}, { __index = ModelESP })
BoneAltarESP.__index = BoneAltarESP
BoneAltarESP.__type = "BoneAltarESP"

---Update BoneAltarESP.
---@param self BoneAltarESP
BoneAltarESP.update = LPH_NO_VIRTUALIZE(function(self)
	local model = self.model

	local boneSpear = model:FindFirstChild("BoneSpear")

	if Configuration.idToggleValue(self.identifier, "HideIfBoneInside") and boneSpear then
		return self:visible(false)
	end

	ModelESP.update(self, {})
end)

---Create new BoneAltarESP object.
---@param identifier string
---@param model Model
---@param label string
function BoneAltarESP.new(identifier, model, label)
	return setmetatable(ModelESP.new(identifier, model, label), BoneAltarESP)
end

-- Return BoneAltarESP module.
return BoneAltarESP

end)
__bundle_register("Features/Visuals/Objects/ModelESP", function(require, _LOADED, __bundle_register, __bundle_modules)
---@module Features.Visuals.Objects.InstanceESP
local InstanceESP = require("Features/Visuals/Objects/InstanceESP")

---@module Utility.Configuration
local Configuration = require("Utility/Configuration")

---@class ModelESP: InstanceESP
---@field model Model
local ModelESP = setmetatable({}, { __index = InstanceESP })
ModelESP.__index = ModelESP
ModelESP.__type = "ModelESP"

---Update ModelESP.
---@param self ModelESP
---@param tags string[]
ModelESP.update = LPH_NO_VIRTUALIZE(function(self, tags)
	local model = self.model

	if not model.Parent then
		return self:visible(false)
	end

	InstanceESP.update(self, model:GetPivot().Position, tags or {})
end)

---Create new ModelESP object.
---@param identifier string
---@param model Model
---@param label string
function ModelESP.new(identifier, model, label)
	if not model:IsA("Model") then
		return error(string.format("ModelESP expected model on %s creation.", identifier))
	end

	local self = setmetatable(InstanceESP.new(model, identifier, label), ModelESP)
	self.model = model

	if not Configuration.expectOptionValue("NoPersisentESP") then
		self.model.ModelStreamingMode = Enum.ModelStreamingMode.Persistent
	end

	return self
end

-- Return ModelESP module.
return ModelESP

end)
__bundle_register("Features/Visuals/Objects/InstanceESP", function(require, _LOADED, __bundle_register, __bundle_modules)
---@module Utility.Configuration
local Configuration = require("Utility/Configuration")

---@module Utility.Maid
local Maid = require("Utility/Maid")

---@class InstanceESP
---@field identifier string
---@field maid Maid
---@field label string
---@field text TextLabel
---@field billboard BillboardGui
---@field instance Instance
local InstanceESP = {}
InstanceESP.__index = InstanceESP
InstanceESP.__type = "InstanceESP"

-- Services.
local playersService = game:GetService("Players")

-- Formats.
local ESP_DISTANCE_FORMAT = "%s [%i]"

---Set visibility.
---@param visible boolean
function InstanceESP:visible(visible)
	self.billboard.Enabled = visible
end

---Detach InstanceESP.
function InstanceESP:detach()
	self.maid:clean()
end

---Build text.
---@param self InstanceESP
---@param label string
---@param tags string[]
---@return string
InstanceESP.build = LPH_NO_VIRTUALIZE(function(self, label, tags)
	if #tags <= 0 then
		return label
	end

	local lines = {}
	local start = true

	for _, tag in next, tags do
		local line = lines[#lines] or label

		if not start and #line > Configuration.expectOptionValue("ESPSplitLineLength") then
			lines[#lines + 1] = tag
			continue
		end

		line = line .. " " .. tag

		lines[start and 1 or #lines] = line

		start = false
	end

	return table.concat(lines, "\n")
end)

---Update InstanceESP.
---@param self InstanceESP
---@param position Vector3
---@param tags string[]
InstanceESP.update = LPH_NO_VIRTUALIZE(function(self, position, tags)
	local label = self.label
	local identifier = self.identifier

	if not Configuration.idToggleValue(identifier, "Enable") then
		return self:visible(false)
	end

	local localPlayer = playersService.LocalPlayer
	local localCharacter = localPlayer and localPlayer.Character

	if not localCharacter then
		return self:visible(false)
	end

	local localRoot = localCharacter:FindFirstChild("HumanoidRootPart")
	if not localRoot then
		return self:visible(false)
	end

	local distance = (localRoot.Position - position).Magnitude

	if distance > Configuration.idOptionValue(identifier, "MaxDistance") then
		return self:visible(false)
	end

	if Configuration.idToggleValue(identifier, "ShowDistance") then
		label = ESP_DISTANCE_FORMAT:format(label, distance)
	end

	-- Set visible.
	self:visible(true)

	-- Update text.
	local text = self.text
	text.Text = self:build(label, tags)
	text.TextColor3 = Configuration.idOptionValue(identifier, "Color")
	text.TextSize = Configuration.expectOptionValue("FontSize")
	text.Font = Enum.Font[Configuration.expectOptionValue("Font")] or Enum.Font.Code
end)

---Setup InstanceESP.
function InstanceESP:setup()
	local billboardGui = Instance.new("BillboardGui")
	billboardGui.AlwaysOnTop = true
	billboardGui.Size = UDim2.new(1e5, 0, 1e5, 0)
	billboardGui.Enabled = false
	billboardGui.Adornee = self.instance
	billboardGui.Parent = workspace
	billboardGui.AutoLocalize = false

	local textLabel = Instance.new("TextLabel")
	textLabel.BackgroundTransparency = 1.0
	textLabel.Size = UDim2.new(1, 0, 1, 0)
	textLabel.TextStrokeTransparency = 0.0
	textLabel.Parent = billboardGui
	textLabel.AutoLocalize = false

	self.billboard = self.maid:mark(billboardGui)
	self.text = self.maid:mark(textLabel)
end

---Create new InstanceESP object.
---@param instance Instance
---@param identifier string
---@param label string
function InstanceESP.new(instance, identifier, label)
	local self = setmetatable({}, InstanceESP)
	self.label = label
	self.instance = instance
	self.identifier = identifier
	self.maid = Maid.new()
	self:setup()
	return self
end

-- Return InstanceESP module.
return InstanceESP

end)
__bundle_register("Features/Visuals/Objects/ObeliskESP", function(require, _LOADED, __bundle_register, __bundle_modules)
---@module Features.Visuals.Objects.ModelESP
local ModelESP = require("Features/Visuals/Objects/ModelESP")

---@module Utility.Configuration
local Configuration = require("Utility/Configuration")

---@class ObeliskESP: ModelESP
local ObeliskESP = setmetatable({}, { __index = ModelESP })
ObeliskESP.__index = ObeliskESP
ObeliskESP.__type = "ObeliskESP"

---Update ObeliskESP.
---@param self ObeliskESP
ObeliskESP.update = LPH_NO_VIRTUALIZE(function(self)
	local model = self.model

	local bpart = model:FindFirstChild("BuzzPart")
	if not bpart then
		return self:visible(false)
	end

	local interactPrompt = bpart:FindFirstChildOfClass("ProximityPrompt")

	if Configuration.idToggleValue(self.identifier, "HideIfTurnedOn") and not interactPrompt then
		return self:visible(false)
	end

	ModelESP.update(self, {})
end)

---Create new ObeliskESP object.
---@param identifier string
---@param model Model
---@param label string
function ObeliskESP.new(identifier, model, label)
	return setmetatable(ModelESP.new(identifier, model, label), ObeliskESP)
end

-- Return ObeliskESP module.
return ObeliskESP

end)
__bundle_register("Features/Visuals/Objects/ChestESP", function(require, _LOADED, __bundle_register, __bundle_modules)
---@module Features.Visuals.Objects.ModelESP
local ModelESP = require("Features/Visuals/Objects/ModelESP")

---@module Features.Visuals.Objects.PartESP
local PartESP = require("Features/Visuals/Objects/PartESP")

---@module Utility.Configuration
local Configuration = require("Utility/Configuration")

---@class ChestESP: ModelESP
local ChestESP = setmetatable({}, { __index = ModelESP })
ChestESP.__index = ChestESP
ChestESP.__type = "ChestESP"

---Update ChestESP.
---@param self ChestESP
ChestESP.update = LPH_NO_VIRTUALIZE(function(self)
	local inst = self.part or self.model

	if Configuration.idToggleValue(self.identifier, "HideIfOpened") and not inst:HasTag("ClosedChest") then
		return self:visible(false)
	end

	if self.part then
		PartESP.update(self, {})
	else
		ModelESP.update(self, {})
	end
end)

---Create new ChestESP object.
---@param identifier string
---@param inst Instance
---@param label string
function ChestESP.new(identifier, inst, label)
	return setmetatable(
		inst:IsA("Model") and ModelESP.new(identifier, inst, label) or PartESP.new(identifier, inst, label),
		ChestESP
	)
end

-- Return ChestESP module.
return ChestESP

end)
__bundle_register("Features/Visuals/Objects/PartESP", function(require, _LOADED, __bundle_register, __bundle_modules)
---@module Features.Visuals.Objects.InstanceESP
local InstanceESP = require("Features/Visuals/Objects/InstanceESP")

---@class PartESP: InstanceESP
---@field part Part
local PartESP = setmetatable({}, { __index = InstanceESP })
PartESP.__index = PartESP
PartESP.__type = "PartESP"

---Update PartESP.
---@param self PartESP
---@param tags string[]
PartESP.update = LPH_NO_VIRTUALIZE(function(self, tags)
	local part = self.part

	if not part.Parent then
		return self:visible(false)
	end

	InstanceESP.update(self, part.Position, tags or {})
end)

---Create new PartESP object.
---@param identifier string
---@param part Part
---@param label string
function PartESP.new(identifier, part, label)
	if not part:IsA("BasePart") then
		return error(string.format("PartESP expected part on %s creation.", identifier))
	end

	local self = setmetatable(InstanceESP.new(part, identifier, label), PartESP)
	self.part = part
	return self
end

-- Return PartESP module.
return PartESP

end)
__bundle_register("Features/Visuals/Group", function(require, _LOADED, __bundle_register, __bundle_modules)
---@module Utility.ReferencedMap
local ReferencedMap = require("Utility/ReferencedMap")

---@module Utility.Profiler
local Profiler = require("Utility/Profiler")

---@module Utility.Logger
local Logger = require("Utility/Logger")

---@module Utility.Configuration
local Configuration = require("Utility/Configuration")

---@class Group: ReferencedMap
---@field part number
---@field icount number
---@field updated boolean
---@field identifier string
local Group = setmetatable({}, ReferencedMap)
Group.__index = Group

---Update ESP object.
---@param self Group
---@param object ModelESP|PartESP|FilteredESP
Group.object = LPH_NO_VIRTUALIZE(function(self, object)
	self.count = self.count + 1

	if not self.warned and self.count >= 500 then
		-- Notify user.
		Logger.longNotify("(%s) Too many objects will cause your elements to stop updating.", object.identifier)

		-- Set warning.
		self.warned = true
	end

	---@note: If we're updating too many objects, it will cause Roblox to hide UI elements and kick us from the game.
	if self.count >= 500 then
		return
	end

	Profiler.run(string.format("ESP_Update_%s", object.identifier), object.update, object)
end)

---Update group.
---@param self Group
Group.update = LPH_NO_VIRTUALIZE(function(self)
	local map = self:data()

	if not Configuration.idToggleValue(self.identifier, "Enable") then
		return self:hide()
	end

	if Configuration.expectToggleValue("ESPSplitUpdates") then
		local totalElements = #map
		local totalFrames = Configuration.expectOptionValue("ESPSplitFrames")

		local objectsPerPart = math.ceil(totalElements / totalFrames)
		local currentPart = self.part

		local startIdx = (currentPart - 1) * objectsPerPart + 1
		local endIdx = math.min(currentPart * objectsPerPart, totalElements)

		for idx = startIdx, endIdx do
			self:object(map[idx])
		end

		self.part = self.part + 1

		if self.part > totalFrames then
			self.count = 0
			self.part = 1
		end
	else
		for _, object in next, map do
			self:object(object)
		end

		self.part = 1
		self.count = 0
	end

	self.updated = true
end)

---Hide group.
---@param self Group
Group.hide = LPH_NO_VIRTUALIZE(function(self)
	if not self.updated then
		return
	end

	for _, object in next, self:data() do
		object:visible(false)
	end

	self.updated = false
end)

---Detach group.
---@param self Group
Group.detach = LPH_NO_VIRTUALIZE(function(self)
	for _, object in next, self:data() do
		object:detach()
	end
end)

---Create new Group object.
---@param identifier string
---@return Group
function Group.new(identifier)
	local self = setmetatable(ReferencedMap.new(), Group)
	self.part = 1
	self.count = 0
	self.warned = false
	self.updated = true
	self.identifier = identifier
	return self
end

-- Return Group module.
return Group

end)
__bundle_register("Utility/ReferencedMap", function(require, _LOADED, __bundle_register, __bundle_modules)
return LPH_NO_VIRTUALIZE(function()
	---@class ReferencedMap
	---@field _map table
	---@field _references table
	local ReferencedMap = {}
	ReferencedMap.__index = ReferencedMap

	---Insert a value into the map.
	---@param ref any
	---@param element any
	function ReferencedMap:insert(ref, element)
		local key = #self._map + 1
		self._map[key] = element
		self._references[ref] = element
	end

	---Return and remove a element from the map.
	---@param ref any
	---@return any?
	function ReferencedMap:remove(ref)
		local element = self._references[ref]
		if not element then
			return nil
		end

		self._references[ref] = nil

		local position = table.find(self._map, element)
		if not position then
			return nil
		end

		table.remove(self._map, position)

		return element
	end

	---Size of the map.
	---@return number
	function ReferencedMap:size()
		return #self._map
	end

	---Return the map data.
	---@return table
	function ReferencedMap:data()
		return self._map
	end

	---Create new ReferencedMap object.
	---@return ReferencedMap
	function ReferencedMap.new()
		local self = setmetatable({}, ReferencedMap)
		self._map = {}
		self._references = {}
		return self
	end

	-- Return ReferencedMap module.
	return ReferencedMap
end)()

end)
__bundle_register("Features/Visuals/Objects/FilteredESP", function(require, _LOADED, __bundle_register, __bundle_modules)
---@module Utility.Configuration
local Configuration = require("Utility/Configuration")

---@class FilteredESP
---@note: This is a wrapper object.
---@field object ModelESP|PartESP
---@field identifier string
---@field delayTimestamp number?
local FilteredESP = {}
FilteredESP.__index = FilteredESP
FilteredESP.__type = "FilteredESP"

---Partial look for string in list.
local partialStringFind = LPH_NO_VIRTUALIZE(function(list, value)
	for _, str in next, list do
		if not value:lower():match(str:lower()) then
			continue
		end

		return true
	end

	return false
end)

---Set visible.
---@param visible boolean
function FilteredESP:visible(visible)
	self.object:visible(visible)
end

---Detach FilteredESP.
function FilteredESP:detach()
	self.object:detach()
end

---Update FilteredESP.
---@param self FilteredESP
FilteredESP.update = LPH_NO_VIRTUALIZE(function(self)
	local object = self.object
	local identifier = self.identifier
	local label = object.label

	if Configuration.idToggleValue(identifier, "FilterObjects") then
		local filterLabelList = Configuration.idOptionValues(identifier, "FilterLabelList")
		local filterLabelListType = Configuration.idOptionValue(identifier, "FilterLabelListType")
		local filterLabelListIndex = partialStringFind(filterLabelList, label)

		if filterLabelListType == "Hide Labels Out Of List" and not filterLabelListIndex then
			return self:visible(false)
		end

		if filterLabelListType == "Hide Labels In List" and filterLabelListIndex then
			return self:visible(false)
		end
	end

	object:update()

	self.delayTimestamp = object.delayTimestamp
end)

---Create new FilteredESP object.
---@param object ModelESP|PartESP
function FilteredESP.new(object)
	local self = setmetatable({}, FilteredESP)
	self.object = object
	self.identifier = object.identifier
	self.delayTimestamp = object.delayTimestamp
	return self
end

-- Return FilteredESP module.
return FilteredESP

end)
__bundle_register("Features/Visuals/Objects/PlayerESP", function(require, _LOADED, __bundle_register, __bundle_modules)
---@module Features.Visuals.Objects.EntityESP
local EntityESP = require("Features/Visuals/Objects/EntityESP")

---@module Utility.Configuration
local Configuration = require("Utility/Configuration")

---@module Game.PlayerScanning
local PlayerScanning = require("Game/PlayerScanning")

---@class PlayerESP: EntityESP
local PlayerESP = setmetatable({}, { __index = EntityESP })
PlayerESP.__index = PlayerESP
PlayerESP.__type = "PlayerESP"

-- Services.
local players = game:GetService("Players")

-- Formats.
local ESP_HEALTH = "[%i/%i]"
local ESP_POWER = "[Power %i]"
local ESP_DANGER_TIME = "[%s]"

---Check if a player has an oath.
---@return boolean
local hasOath = LPH_NO_VIRTUALIZE(function(player)
	local backpack = player:FindFirstChildOfClass("Backpack")
	if not backpack then
		return false
	end

	for _, instance in next, backpack:GetChildren() do
		if not instance.Name:match("Oath") then
			continue
		end

		return true
	end

	return false
end)

---Update PlayerESP.
---@param self PlayerESP
PlayerESP.update = LPH_NO_VIRTUALIZE(function(self)
	local localPlayer = players.LocalPlayer
	local localCharacter = localPlayer.Character

	local localHumanoid = localCharacter and localCharacter:FindFirstChildOfClass("Humanoid")
	local localRoot = localCharacter and localCharacter:FindFirstChild("HumanoidRootPart")

	if not localRoot then
		return self:visible(false)
	end

	if not localHumanoid then
		return self:visible(false)
	end

	local entity = self.entity
	local player = self.player
	local identifier = self.identifier

	local humanoid = entity:FindFirstChildOfClass("Humanoid")
	if not humanoid then
		return self:visible(false)
	end

	local root = entity:FindFirstChild("HumanoidRootPart")
	if not root then
		return self:visible(false)
	end

	if
		PlayerScanning.isAlly(player)
		and Configuration.idToggleValue(identifier, "HideIfAlly")
		and Configuration.idToggleValue(identifier, "MarkAllies")
	then
		return self:visible(false)
	end

	-- Update text.
	local state = "NEUTRAL"
	local delta = localHumanoid.Health - humanoid.Health
	local color = Color3.new(1, 1, 1)

	if delta < 0 then
		state = "UNDER"
	end

	if delta < -50 then
		color = Color3.new(1, 0, 0)
	end

	if delta > 0 then
		state = "OVER"
	end

	if delta > 50 then
		color = Color3.new(0, 1, 0)
	end

	local fcontainer = self.fcontainer
	local flabel = fcontainer and fcontainer:FindFirstChildOfClass("TextLabel")
	local distance = (localRoot.Position - root.Position).Magnitude

	if fcontainer and flabel then
		-- Update flag text.
		self:utext(fcontainer, string.format("%s\n%iHP", state, math.ceil(delta)))

		-- Text size.
		flabel.Position = UDim2.new(0, 2, 0, flabel.TextSize + 2)
		flabel.TextColor3 = color

		-- Visibility?
		fcontainer.Visible = Configuration.idToggleValue(identifier, "ShowHealthComparison") and distance <= 150
	end

	-- Bar mapping.
	local mapping = {
		["ArmorBar"] = { container = self.abar, vstore = self.entity:FindFirstChild("Armor") },
		["PostureBar"] = { container = self.pbar, vstore = self.entity:FindFirstChild("BreakMeter") },
		["BloodBar"] = { container = self.bbar, vstore = self.entity:FindFirstChild("Blood") },
		["TempoBar"] = { container = self.tbar, vstore = self.entity:FindFirstChild("Tempo") },
		["SanityBar"] = { container = self.sbar, vstore = self.entity:FindFirstChild("Sanity") },
	}

	for idx, data in next, mapping do
		local container = data.container
		if not container then
			continue
		end

		-- Visibility?
		container.Visible = Configuration.idToggleValue(identifier, idx)

		-- Modify size.
		self.mbs(container, false, data.vstore and data.vstore.Value / data.vstore.MaxValue or 0.0)

		local bar = self.gb(container)
		if not bar then
			continue
		end

		-- Bar color.
		bar.BackgroundColor3 = Configuration.idOptionValue(identifier, idx .. "Color") or Color3.new(0.0, 0.0, 0.0)
	end

	local level = entity:GetAttribute("Level") or -1
	local playerNameType = Configuration.idOptionValue(identifier, "PlayerNameType")
	local playerName = "Unknown Player"

	if playerNameType == "Character Name" then
		playerName = player:GetAttribute("CharacterName")
	elseif playerNameType == "Roblox Display Name" then
		playerName = player.DisplayName
	elseif playerNameType == "Roblox Username" then
		playerName = player.Name
	end

	if Configuration.expectToggleValue("InfoSpoofing") and Configuration.expectToggleValue("SpoofOtherPlayers") then
		playerName = "Linoria V2 On Top"
	end

	self.label = playerName

	local tags = { ESP_HEALTH:format(humanoid.Health or -1, humanoid.MaxHealth or -1), ESP_POWER:format(level) }

	local dangerTime = humanoid:GetAttribute("DangerExpiration")
	local dangerTimeLeft = dangerTime and math.ceil(dangerTime - workspace:GetServerTimeNow())

	if Configuration.idToggleValue(identifier, "ShowDangerTime") and dangerTimeLeft and dangerTimeLeft >= 0 then
		tags[#tags + 1] = ESP_DANGER_TIME:format(
			dangerTimeLeft >= 60 and os.date("%Mm %Ss", dangerTimeLeft) or os.date("%Ss", dangerTimeLeft)
		)
	end

	EntityESP.update(self, tags)

	local label = self.ncontainer:FindFirstChildOfClass("TextLabel")
	if not label then
		return
	end

	local backpack = player:FindFirstChildOfClass("Backpack")
	if not backpack then
		return
	end

	if Configuration.idToggleValue(identifier, "MarkSackUsers") and entity:FindFirstChild("Sack") then
		label.TextColor3 = Configuration.idOptionValue(identifier, "SackColor")
	end

	if Configuration.idToggleValue(identifier, "MarkOathUsers") and hasOath(player) then
		label.TextColor3 = Configuration.idOptionValue(identifier, "OathColor")
	end

	if Configuration.idToggleValue(identifier, "MarkAllies") and PlayerScanning.isAlly(player) then
		label.TextColor3 = Configuration.idOptionValue(identifier, "AllyColor")
	end

	local dlabel = self.dcontainer:FindFirstChildOfClass("TextLabel")
	if dlabel then
		dlabel.TextColor3 = label.TextColor3
	end
end)

---Add extra elements.
PlayerESP.extra = LPH_NO_VIRTUALIZE(function(self)
	self.abar = self:add("ArmorBar", "left", 6, function(container)
		self:cgb(container, false, true, Color3.new(1, 1, 1))
	end)

	self.pbar = self:add("PostureBar", "bottom", 3, function(container)
		self:cgb(container, false, false, Color3.new(1, 1, 1))
	end)

	self.bbar = self:add("BloodBar", "bottom", 3, function(container)
		self:cgb(container, false, false, Color3.new(1, 1, 1))
	end)

	self.tbar = self:add("TempoBar", "bottom", 3, function(container)
		self:cgb(container, false, false, Color3.new(1, 1, 1))
	end)

	self.sbar = self:add("SanityBar", "bottom", 3, function(container)
		self:cgb(container, false, false, Color3.new(1, 1, 1))
	end)

	self.fcontainer = self:add("Flags", "right", 16, function(container)
		local TextLabel = Instance.new("TextLabel")
		TextLabel.Parent = container
		TextLabel.Text = "NEUTRAL\n0HP"
		TextLabel.Size = UDim2.new(0, 400, 1, 0)
		TextLabel.AnchorPoint = Vector2.new(0.0, 0.5)
		TextLabel.Position = UDim2.new(0, 2, 0, 8 + 2)
		TextLabel.BackgroundTransparency = 1.0
		TextLabel.TextStrokeColor3 = Color3.new(0.0, 0.0, 0.0)
		TextLabel.TextStrokeTransparency = 0.0
		TextLabel.TextColor3 = Color3.new(1.0, 1.0, 1.0)
		TextLabel.TextSize = 8
		TextLabel.TextXAlignment = Enum.TextXAlignment.Left
		TextLabel.TextWrapped = false
		TextLabel.Font = Enum.Font.Code
	end)
end)

---Create new PlayerESP object.
---@param identifier string
---@param player Player
---@param character Model
function PlayerESP.new(identifier, player, character)
	local self = setmetatable(EntityESP.new(character, identifier, "Unknown Player"), PlayerESP)
	self.player = player
	self.identifier = identifier

	if character and character:IsA("Model") and not Configuration.expectOptionValue("NoPersisentESP") then
		character.ModelStreamingMode = Enum.ModelStreamingMode.Persistent
	end

	self:setup()
	self:build()
	self:update()

	return self
end

-- Return PlayerESP module.
return PlayerESP

end)
__bundle_register("Features/Visuals/Objects/EntityESP", function(require, _LOADED, __bundle_register, __bundle_modules)
---@module Utility.Configuration
local Configuration = require("Utility/Configuration")

---@module Utility.Maid
local Maid = require("Utility/Maid")

---@module Utility.Signal
local Signal = require("Utility/Signal")

---@module Utility.TaskSpawner
local TaskSpawner = require("Utility/TaskSpawner")

---@class EntityESP
local EntityESP = {}
EntityESP.__index = EntityESP
EntityESP.__type = "EntityESP"

-- Services.
local playersService = game:GetService("Players")
local replicatedStorage = game:GetService("ReplicatedStorage")
local tweenService = game:GetService("TweenService")

-- Constants.
local ELEMENT_PADDING = 1
local BILLBOARD_MIN_WIDTH = 10
local BILLBOARD_MIN_HEIGHT = 10

---Give an inside outline to a frame.
---@param frame Frame
---@param strokeColor Color3
---@param insideOffset number
EntityESP.gio = LPH_NO_VIRTUALIZE(function(frame, strokeColor, insideOffset)
	local sizeOffset = -insideOffset * 2
	local strokeContainer = Instance.new("Frame")
	strokeContainer.Name = "Outline_" .. tostring(insideOffset)
	strokeContainer.Parent = frame
	strokeContainer.Size = UDim2.new(1, sizeOffset, 1, sizeOffset)
	strokeContainer.Position = UDim2.new(0, insideOffset, 0, insideOffset)
	strokeContainer.BackgroundTransparency = 1

	local outlineStroke = Instance.new("UIStroke")
	outlineStroke.Color = strokeColor
	outlineStroke.Thickness = 1
	outlineStroke.BorderStrokePosition = Enum.BorderStrokePosition.Inner
	outlineStroke.Parent = strokeContainer

	return strokeContainer
end)

---Update text.
---@param self EntityESP
---@param container Frame
---@param text string
EntityESP.utext = LPH_NO_VIRTUALIZE(function(self, container, text)
	local textLabel = container:FindFirstChildOfClass("TextLabel")
	if not textLabel then
		return
	end

	textLabel.Text = text
	textLabel.TextSize = Configuration.expectOptionValue("FontSize") or 13
	textLabel.Font = Enum.Font[Configuration.expectOptionValue("Font") or "Code"] or Enum.Font.Code
	textLabel.TextColor3 = Configuration.idOptionValue(self.identifier, "Color") or Color3.new(1, 1, 1)
end)

---Get bar in container.
EntityESP.gb = LPH_NO_VIRTUALIZE(function(container)
	local background = container:FindFirstChild("Background")
	if not background then
		return nil
	end

	local barArea = background:FindFirstChild("BarArea")
	if not barArea then
		return nil
	end

	local bar = barArea:FindFirstChild("Bar")
	if not bar then
		return nil
	end

	return bar
end)

---Modify bar size.
---@param container Frame
---@param vertical boolean
---@param percentage number
EntityESP.mbs = LPH_NO_VIRTUALIZE(function(container, vertical, percentage)
	local background = container:FindFirstChild("Background")
	if not background then
		return
	end

	local barArea = background:FindFirstChild("BarArea")
	if not barArea then
		return
	end

	local bar = barArea:FindFirstChild("Bar")
	if not bar then
		return
	end

	percentage = math.clamp(percentage, 0.0, 1.0)

	if vertical then
		bar.Size = UDim2.new(1, 0, percentage, 0)
	else
		bar.Size = UDim2.new(percentage, 0, 1, 0)
	end
end)

---Create a generic bar.
---@param container Frame
---@param vertical boolean
---@param seperators boolean
---@param color Color3
EntityESP.cgb = LPH_NO_VIRTUALIZE(function(self, container, seperators, vertical, color)
	local background = Instance.new("Frame")
	background.Name = "Background"
	background.Parent = container

	if vertical then
		background.Size = UDim2.new(1, -1, -1, 0)
		background.Position = UDim2.new(1, -1, 1, 0)
		background.AnchorPoint = Vector2.new(1.0, 0.0)
	else
		background.Size = UDim2.new(1, 0, 1, 0)
		background.Position = UDim2.new(0, 0, 0, 0)
		background.AnchorPoint = Vector2.new(0, 0)
	end

	background.BackgroundColor3 = Color3.new(0.0862745, 0.105882, 0.219608)
	background.BorderSizePixel = 0

	self.gio(background, Color3.new(0, 0, 0), 0)

	local barArea = Instance.new("Frame")
	barArea.Name = "BarArea"
	barArea.Parent = background
	barArea.BackgroundTransparency = 1
	barArea.Position = UDim2.new(0, 1, 0, 1)
	barArea.Size = UDim2.new(1, -2, 1, -2)
	barArea.ZIndex = 1

	-- separators only for vertical bars (to match original visual)
	if seperators then
		for Idx = 1, 4 do
			local Separator = Instance.new("Frame")
			Separator.Name = "Separator"
			Separator.Parent = barArea
			Separator.BackgroundColor3 = Color3.new(0, 0, 0)
			Separator.BorderSizePixel = 0
			Separator.Position = UDim2.new(0, 0, Idx / 5, 0)
			Separator.Size = UDim2.new(1, 0, 0, 1)
			Separator.ZIndex = 3
		end
	end

	local bar = Instance.new("Frame")
	bar.Name = "Bar"
	bar.Parent = barArea
	bar.BorderSizePixel = 0
	bar.ZIndex = 2

	if vertical then
		bar.AnchorPoint = Vector2.new(0, 1)
		bar.Position = UDim2.new(0, 0, 1, 0)
		bar.Size = UDim2.new(1, 0, 0.0, 0)
	else
		bar.Position = UDim2.new(0, 0, 0, 0)
		bar.Size = UDim2.new(0.0, 0, 1, 0)
	end

	bar.BackgroundColor3 = color
end)

---Set visibility.
---@param visible boolean
EntityESP.visible = LPH_NO_VIRTUALIZE(function(self, visible)
	self.billboard.Enabled = visible
end)

---Detach InstanceESP.
EntityESP.detach = LPH_NO_VIRTUALIZE(function(self)
	self.maid:clean()
end)

---Update seperators.
---@param self EntityESP
---@param distance number
EntityESP.useperators = LPH_NO_VIRTUALIZE(function(self, distance)
	local bar = self.gb(self.hbar)
	if not bar then
		return
	end

	local seperators = bar.Parent:GetChildren()

	for _, sep in next, seperators do
		if not sep:IsA("Frame") then
			continue
		end

		if sep.Name ~= "Separator" then
			continue
		end

		sep.Visible = distance <= 300
	end
end)

---Build text.
---@param self EntityESP
---@param label string
---@param tags string[]
---@return string, number
EntityESP.btext = LPH_NO_VIRTUALIZE(function(self, label, tags)
	if #tags <= 0 then
		return label
	end

	local lines = {}
	local start = true

	for _, tag in next, tags do
		local line = lines[#lines] or label

		if not start and #line > Configuration.expectOptionValue("ESPSplitLineLength") then
			lines[#lines + 1] = tag
			continue
		end

		line = line .. " " .. tag

		lines[start and 1 or #lines] = line

		start = false
	end

	return table.concat(lines, "\n"), #lines
end)

---On health changed.
---@param self PlayerESP
EntityESP.hchanged = LPH_NO_VIRTUALIZE(function(self)
	if not self.lhealth then
		return
	end

	if self.billboard.Enabled == false then
		return
	end

	if not Configuration.idToggleValue(self.identifier, "ShowHealthChanges") then
		return
	end

	local character = self.entity
	if not character or not character:IsA("Model") then
		return
	end

	local humanoid = character:FindFirstChildOfClass("Humanoid")
	if not humanoid then
		return
	end

	local root = character:FindFirstChild("HumanoidRootPart")
	if not root then
		return
	end

	local debris = replicatedStorage:FindFirstChild("Debris")
	if not debris then
		return
	end

	local newHealth = humanoid.Health
	local differenceColor = Color3.fromRGB(255, 0, 0)
	local differenceAmount = newHealth - self.lhealth

	if differenceAmount >= 0 then
		differenceColor = Color3.fromRGB(0, 255, 0)
	end

	self.lhealth = newHealth

	if differenceAmount >= -0.5 and differenceAmount <= 0.5 then
		return
	end

	local clientEffectModules = replicatedStorage:FindFirstChild("ClientEffectModules")
	local replication = clientEffectModules and clientEffectModules:FindFirstChild("Replication")
	local replicationModule = replication and replication:FindFirstChild("Replication")
	if not replicationModule then
		return
	end

	local damageSplash = replicationModule:FindFirstChild("DamageSplash")
	if not damageSplash then
		return
	end

	local thrown = workspace:FindFirstChild("Thrown")
	if not thrown then
		return
	end

	local initialOffset = Vector3.new(math.random() * 2 - 1, math.random() * 2 - 1, math.random() * 2 - 1) * 2
	local clonedSplash = damageSplash:Clone()
	clonedSplash.Adornee = root
	clonedSplash.Size = UDim2.new(2.5, 0, 0.5, 0)
	clonedSplash.Parent = thrown
	clonedSplash.TextLabel.Text = string.format("%.02f", differenceAmount)
	clonedSplash.StudsOffsetWorldSpace = initialOffset

	if differenceColor then
		clonedSplash.TextLabel.TextColor3 = differenceColor
	end

	local textLabel = clonedSplash and clonedSplash:FindFirstChild("TextLabel")
	if not textLabel then
		return
	end

	local uiStroke = textLabel:FindFirstChild("UIStroke")
	if not uiStroke then
		return
	end

	uiStroke.Transparency = 1.0

	tweenService
		:Create(clonedSplash, TweenInfo.new(0.5, Enum.EasingStyle.Back), {
			Size = UDim2.new(5, 0, 1),
		})
		:Play()

	tweenService
		:Create(clonedSplash, TweenInfo.new(5, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
			StudsOffsetWorldSpace = initialOffset + Vector3.new(0, 10, 0),
		})
		:Play()

	self.maid:mark(TaskSpawner.delay("PlayerESP_RemoveDamageSplash", function()
		return 3.0
	end, function()
		tweenService
			:Create(textLabel, TweenInfo.new(2), {
				TextTransparency = 1,
			})
			:Play()
	end))

	debris:Fire(clonedSplash, 5)
end)

---Update InstanceESP.
---@param self InstanceESP
---@param tags string[]
EntityESP.update = LPH_NO_VIRTUALIZE(function(self, tags)
	local identifier = self.identifier

	-- Perform basic validation.
	local localPlayer = playersService.LocalPlayer
	local localCharacter = localPlayer and localPlayer.Character
	local localRoot = localCharacter and localCharacter:FindFirstChild("HumanoidRootPart")

	local entityHumanoid = self.entity and self.entity:FindFirstChildOfClass("Humanoid")
	local entityRoot = self.entity and self.entity:FindFirstChild("HumanoidRootPart")
	local position = entityRoot and entityRoot.Position

	if not Configuration.idToggleValue(identifier, "Enable") then
		return self:visible(false)
	end

	if not entityHumanoid then
		return self:visible(false)
	end

	if not localRoot then
		return self:visible(false)
	end

	if not position then
		return self:visible(false)
	end

	local distance = (localRoot.Position - position).Magnitude

	if distance > Configuration.idOptionValue(identifier, "MaxDistance") then
		return self:visible(false)
	end

	---@todo: This was a lazy way to connect to the signal.
	if not self.maid["PlayerESP_OnHealthChanged"] and not self.lhealth then
		-- Create signal wrapper.
		local onHealthChanged = Signal.new(entityHumanoid.HealthChanged)

		-- Store last health.
		self.lhealth = entityHumanoid.Health

		-- Connect to health changed signal.
		self.maid["PlayerESP_OnHealthChanged"] = onHealthChanged:connect("PlayerESP_OnHealthChanged", function()
			self:hchanged()
		end)
	end

	-- Update Adornee.
	self.billboard.Adornee = entityRoot

	-- Update element visibility.
	local bbstroke = self.bbstroke
	local wbstroke = self.wbstroke
	local dcontainer = self.dcontainer
	local ncontainer = self.ncontainer
	local hbar = self.hbar

	bbstroke.Visible = Configuration.idToggleValue(identifier, "BoundingBox")
	wbstroke.Visible = Configuration.idToggleValue(identifier, "BoundingBox")
	dcontainer.Visible = Configuration.idToggleValue(identifier, "ShowDistance")
	hbar.Visible = Configuration.idToggleValue(identifier, "HealthBar")

	-- Update element information.
	local fontSize = Configuration.expectOptionValue("FontSize") or 13
	local text, lines = self:btext(self.label, tags)
	self:utext(ncontainer, text)

	local name = self:find("Name")
	if name then
		name.space = (lines * fontSize) + (ELEMENT_PADDING * 2)
	end

	local delement = self:find("Distance")
	if delement then
		delement.space = fontSize + (ELEMENT_PADDING * 2)
	end

	if dcontainer then
		self:utext(dcontainer, string.format("%im", math.floor(distance)))
	end

	-- Get bar.
	local bar = self.gb(hbar)

	if hbar and bar then
		-- Percentage.
		local percent = entityHumanoid.Health / entityHumanoid.MaxHealth
		local fullColor = Configuration.idOptionValue(identifier, "FullColor")
		local emptyColor = Configuration.idOptionValue(identifier, "EmptyColor")

		-- Update sizing.
		self.mbs(hbar, true, percent)

		-- Update color.
		bar.BackgroundColor3 = emptyColor:Lerp(fullColor, math.clamp(percent, 0.0, 1.0))

		-- Update seperators.
		self:useperators(distance)
	end

	-- Build layout.
	self:build()

	-- Set visible.
	self:visible(true)
end)

---Build EntityESP layout.
EntityESP.build = LPH_NO_VIRTUALIZE(function(self)
	-- Calculate total thickness added to each side.
	local sideOffsets = { top = 0, bottom = 0, left = 0, right = 0 }

	for side, elementList in next, self.elements do
		local offsetElementCount = 0

		-- Add up space for each element on this side.
		for _, item in next, elementList do
			if not item.container.Visible then
				continue
			end

			sideOffsets[side] = sideOffsets[side] + item.space + ELEMENT_PADDING
			offsetElementCount = offsetElementCount + 1
		end

		-- Remove trailing padding if we offset any elements.
		if offsetElementCount > 0 then
			sideOffsets[side] = sideOffsets[side] - ELEMENT_PADDING
		end
	end

	-- Determine the "max" padding needed to keep things symmetrical.
	local maxHorizontalPadding = math.max(sideOffsets.left, sideOffsets.right)
	local maxVerticalPadding = math.max(sideOffsets.top, sideOffsets.bottom)

	-- Scale the BillboardGUI accordingly.
	local extentsSize = self.entity:GetExtentsSize()

	-- Invalidate cached size if the size has changed significantly.
	if self.lextents and math.abs(self.lextents.Magnitude - extentsSize.Magnitude) >= 10.0 then
		self.sextents = nil
	end

	self.lextents = extentsSize

	if not self.sextents then
		local fmodel = self.entity:Clone()

		for _, inst in next, fmodel:GetDescendants() do
			if not inst.Parent then
				continue
			end

			if inst:IsA("BasePart") and not inst.Parent:IsA("BasePart") then
				continue
			end

			if not inst:FindFirstChildWhichIsA("Weld") and not inst:FindFirstChildWhichIsA("Motor6D") then
				continue
			end

			inst:Destroy()
		end

		self.sextents = fmodel:GetExtentsSize()
	end

	self.billboard.Size = UDim2.new(
		self.sextents.X + 1.5,
		maxHorizontalPadding * 2 + BILLBOARD_MIN_WIDTH,
		self.sextents.Y + 1.5,
		maxVerticalPadding * 2 + BILLBOARD_MIN_HEIGHT
	)

	-- Position the bounding box in the exact center of our symmetrical GUI.
	self.bbox.Position = UDim2.new(0, maxHorizontalPadding, 0, maxVerticalPadding)
	self.bbox.Size = UDim2.new(1, -(maxHorizontalPadding * 2), 1, -(maxVerticalPadding * 2))

	-- 1. Stacking upwards from the box (top elements).
	local currentTopOffset = 0

	for _, element in next, self.elements.top do
		if not element.container.Visible then
			continue
		end

		element.container.Parent = self.canvas
		element.container.AnchorPoint = Vector2.new(0, 1)
		element.container.Position = UDim2.new(0, maxHorizontalPadding, 0, maxVerticalPadding - currentTopOffset)
		element.container.Size = UDim2.new(1, -(maxHorizontalPadding * 2), 0, element.space)
		currentTopOffset = currentTopOffset + element.space + ELEMENT_PADDING

		if element.created then
			continue
		end

		if not element.create then
			continue
		end

		element.create(element.container)
		element.created = true
	end

	-- 2. Stacking downwards from the box (bottom elements).
	local currentBottomOffset = 0

	for _, element in next, self.elements.bottom do
		if not element.container.Visible then
			continue
		end

		element.container.Parent = self.bbox
		element.container.AnchorPoint = Vector2.new(0, 0)
		element.container.Position = UDim2.new(0, 0, 1, currentBottomOffset)
		element.container.Size = UDim2.new(1, 0, 0, element.space)
		currentBottomOffset = currentBottomOffset + element.space + ELEMENT_PADDING

		if element.created then
			continue
		end

		if not element.create then
			continue
		end

		element.create(element.container)
		element.created = true
	end

	-- 3. Stacking to the left from the box (left elements).
	local currentLeftOffset = 0

	for _, element in next, self.elements.left do
		if not element.container.Visible then
			continue
		end

		element.container.Parent = self.canvas
		element.container.AnchorPoint = Vector2.new(1, 0)
		element.container.Position = UDim2.new(0, maxHorizontalPadding - currentLeftOffset, 0, maxVerticalPadding)
		element.container.Size = UDim2.new(0, element.space, 1, -(maxVerticalPadding * 2))
		currentLeftOffset = currentLeftOffset + element.space + ELEMENT_PADDING

		if element.created then
			continue
		end

		if not element.create then
			continue
		end

		element.create(element.container)
		element.created = true
	end

	-- 4. Stacking to the right from the box (right elements).
	local currentRightOffset = 0

	for _, element in next, self.elements.right do
		if not element.container.Visible then
			continue
		end

		element.container.Parent = self.bbox
		element.container.AnchorPoint = Vector2.new(0, 0)
		element.container.Position = UDim2.new(1, currentRightOffset, 0, 0)
		element.container.Size = UDim2.new(0, element.space, 1, 0)
		currentRightOffset = currentRightOffset + element.space + ELEMENT_PADDING

		if element.created then
			continue
		end

		if not element.create then
			continue
		end

		element.create(element.container)
		element.created = true
	end
end)

---Find an element with a given name.
---@param name string
EntityESP.find = LPH_NO_VIRTUALIZE(function(self, name)
	for _, list in next, self.elements do
		for _, element in next, list do
			if element.name ~= name then
				continue
			end

			return element
		end
	end

	return nil
end)

---Add new element(s) to EntityESP.
---@param name string
---@param side string "Top" | "Bottom" | "Left" | "Right"
---@param space number
---@param create function
EntityESP.add = LPH_NO_VIRTUALIZE(function(self, name, side, space, create)
	local container = Instance.new("Frame")
	container.Name = string.format("%s_Container_%s", side, name)
	container.BackgroundTransparency = 1

	table.insert(self.elements[side], {
		name = name,
		container = container,
		space = space,
		create = create,
		created = false,
	})

	return container
end)

---Add extra elements. Override me.
EntityESP.extra = LPH_NO_VIRTUALIZE(function(_) end)

---Setup EntityESP.
EntityESP.setup = LPH_NO_VIRTUALIZE(function(self)
	local root = self.entity:FindFirstChild("HumanoidRootPart")

	local billboardGui = Instance.new("BillboardGui")
	billboardGui.AlwaysOnTop = true
	billboardGui.Enabled = false
	billboardGui.Adornee = root or self.entity
	billboardGui.Parent = workspace
	billboardGui.ClipsDescendants = false
	billboardGui.AutoLocalize = false

	local canvas = Instance.new("Frame")
	canvas.Name = "Canvas"
	canvas.BackgroundTransparency = 1
	canvas.Size = UDim2.new(1, 0, 1, 0)
	canvas.Position = UDim2.new(0, 0, 0, 0)
	canvas.Parent = billboardGui

	local espBoundingBox = Instance.new("Frame")
	espBoundingBox.Name = "ESPBoundingBox"
	espBoundingBox.Parent = canvas
	espBoundingBox.BackgroundTransparency = 1
	espBoundingBox.Size = UDim2.new(1, 0, 1, 0)
	espBoundingBox.Position = UDim2.new(0, 0, 0, 0)

	-- Box outlines. We cannot set visible to the frame directly, we must hide these two if we don't want bounding boxes.
	self.bbstroke = self.gio(espBoundingBox, Color3.new(0, 0, 0), 0)
	self.wbstroke = self.gio(espBoundingBox, Color3.new(1, 1, 1), 1)

	-- Setup main instances.
	self.billboard = self.maid:mark(billboardGui)
	self.canvas = self.maid:mark(canvas)
	self.bbox = self.maid:mark(espBoundingBox)

	-- Add elements.
	self.hbar = self:add("HealthBar", "left", 6, function(container)
		self:cgb(container, true, true, Color3.new(1.0, 1.0, 1.0))
	end)

	self:extra()

	self.dcontainer = self:add("Distance", "bottom", 16, function(container)
		local textLabel = Instance.new("TextLabel")
		textLabel.Parent = container
		textLabel.Text = "0m"
		textLabel.Size = UDim2.new(0, 400, 1, 0)
		textLabel.AnchorPoint = Vector2.new(0.5, 0)
		textLabel.Position = UDim2.new(0.5, 0, 0, 0)
		textLabel.BackgroundTransparency = 1.0
		textLabel.TextStrokeColor3 = Color3.new(0.0, 0.0, 0.0)
		textLabel.TextStrokeTransparency = 0.0
		textLabel.TextColor3 = Color3.new(1.0, 1.0, 1.0)
		textLabel.TextSize = 13
		textLabel.TextWrapped = false
		textLabel.Font = Enum.Font.Code
	end)

	self.ncontainer = self:add("Name", "top", 16, function(container)
		local textLabel = Instance.new("TextLabel")
		textLabel.Parent = container
		textLabel.Text = "N/A"
		textLabel.Size = UDim2.new(0, 400, 1, 0)
		textLabel.AnchorPoint = Vector2.new(0.5, 0)
		textLabel.Position = UDim2.new(0.5, 0, 0, 0)
		textLabel.BackgroundTransparency = 1.0
		textLabel.TextStrokeColor3 = Color3.new(0.0, 0.0, 0.0)
		textLabel.TextStrokeTransparency = 0.0
		textLabel.TextColor3 = Color3.new(0.0117647, 1, 1)
		textLabel.TextSize = 13
		textLabel.TextWrapped = false
		textLabel.Font = Enum.Font.Code
	end)
end)

---Create new EntityESP object. Caller is responsible for setup and update.
---@param entity Model
---@param identifier string
---@param label string
function EntityESP.new(entity, identifier, label)
	local self = setmetatable({}, EntityESP)
	self.label = label
	self.entity = entity
	self.identifier = identifier
	self.maid = Maid.new()
	self.elements = {
		top = {},
		bottom = {},
		left = {},
		right = {},
	}

	return self
end

-- Return EntityESP module.
return EntityESP

end)
__bundle_register("Features/Visuals/Objects/MobESP", function(require, _LOADED, __bundle_register, __bundle_modules)
---@module Features.Visuals.Objects.EntityESP
local EntityESP = require("Features/Visuals/Objects/EntityESP")

---@class MobESP: EntityESP
local MobESP = setmetatable({}, { __index = EntityESP })
MobESP.__index = MobESP
MobESP.__type = "MobESP"

-- Formats.
local ESP_HEALTH = "[%i/%i]"

---Update MobESP.
---@param self MobESP
MobESP.update = LPH_NO_VIRTUALIZE(function(self)
	local humanoid = self.entity:FindFirstChildOfClass("Humanoid")
	if not humanoid then
		return self:visible(false)
	end

	EntityESP.update(self, { ESP_HEALTH:format(humanoid.Health, humanoid.MaxHealth) })
end)

---Create new MobESP object.
---@param identifier string
---@param model Model
---@param label string
function MobESP.new(identifier, model, label)
	local self = setmetatable(EntityESP.new(model, identifier, label), MobESP)
	self:setup()
	self:build()
	self:update()
	return self
end

-- Return MobESP module.
return MobESP

end)
__bundle_register("Features/Exploits/Exploits", function(require, _LOADED, __bundle_register, __bundle_modules)
---@module Utility.Maid
local Maid = require("Utility/Maid")

---@module Utility.InstanceWrapper
local InstanceWrapper = require("Utility/InstanceWrapper")

-- Void maid.
local voidMaid = Maid.new()

---Void part.
---@param model Model
---@param part Part
local function voidPart(model, part)
	---@note: Push the part down constantly in an attempt to get it to fall through the void.
	---This also has the positive note of making the part not sleep - retaining it.
	if not part:FindFirstChild("BodyVelocity") then
		local partConstantVelocity = InstanceWrapper.create(voidMaid, part, "BodyVelocity", part)
		partConstantVelocity.MaxForce = Vector3.new(1 / 0, 1 / 0, 1 / 0)
		partConstantVelocity.Velocity = Vector3.new(100, -100000, 0)
		partConstantVelocity.P = 1 / 0
	end

	---@note: Remove part controllers.
	local velocityController = part:FindFirstChild("ControlVel")
		or part:FindFirstChild("SafetyBV")
		or part:FindFirstChild("SwimBV")
		or part:FindFirstChild("Holder")

	if velocityController and velocityController:IsA("BodyMover") then
		velocityController:Destroy()
	end

	-- Set part properties.
	part.AssemblyLinearVelocity = Vector3.new(1000, -10000, 0)
	part.Position = Vector3.new(part.Position.X, -4000, part.Position.Z)
	part.CanCollide = false

	-- Stop part from sleeping.
	sethiddenproperty(part, "NetworkIsSleeping", false)
end

return LPH_NO_VIRTUALIZE(function()
	-- Exploits related stuff is handled here.
	local Exploits = { forceVoid = false, ownershipTimestamp = 0, ownershipItem = nil, currentRootPart = nil }

	---@module Utility.Signal
	local Signal = require("Utility/Signal")

	---@module Utility.Configuration
	local Configuration = require("Utility/Configuration")

	---@module Utility.OriginalStore
	local OriginalStore = require("Utility/OriginalStore")

	---@module Features.Game.OwnershipWatcher
	local OwnershipWatcher = require("Features/Game/OwnershipWatcher")

	---@module Utility.Logger
	local Logger = require("Utility/Logger")

	---@module Features.Automation.EchoFarm
	local EchoFarm = require("Features/Automation/EchoFarm")

	-- Services.
	local runService = game:GetService("RunService")
	local players = game:GetService("Players")
	local physicsService = game:GetService("PhysicsService")
	local replicatedStorage = game:GetService("ReplicatedStorage")

	-- Collision group name using our unique table.
	local collisionGroupName = tostring(Exploits)

	-- Maids.
	local exploitsMaid = Maid.new()
	local pathfindBreakerMaid = Maid.new()

	-- Original stores.
	local allowSleep = voidMaid:mark(OriginalStore.new())

	-- Signals.
	local heartbeat = Signal.new(runService.Heartbeat)
	local preRender = Signal.new(runService.PreRender)

	-- Last velocity before breaker modification.
	local lastVelocity = nil

	-- Last Vector
	local lastVector = 1

	---Clean up void mobs.
	local function cleanVoidMobs()
		voidMaid:clean()
		allowSleep:restore()
	end

	---Update void mobs.
	local function updateVoidMobs()
		local localPlayer = players.LocalPlayer

		-- Set simulation radius.
		if setsimulationradius then
			setsimulationradius(math.huge, math.huge)
		else
			sethiddenproperty(localPlayer, "MaxSimulationRadius", 9e9)
			sethiddenproperty(localPlayer, "SimulationRadius", 9e9)
		end

		-- Set allow sleep.
		allowSleep:set(settings().Physics, "AllowSleep", false)

		---@type BasePart
		for part, data in next, OwnershipWatcher.parts do
			local model = data.model
			if not model then
				continue
			end

			-- Check for ownership. If we don't have it, then we need to reset what we changed during void.
			if not data.owned then
				continue
			end

			---@todo: Filtering out parts (CheckPartConnections, missing checks, etc)
			local localCharacter = localPlayer and localPlayer.Character
			if not localCharacter then
				continue
			end

			if model == localCharacter then
				continue
			end

			if model.Parent ~= workspace.Live then
				continue
			end

			---@note: Set the part to not collide.
			for _, instance in pairs(model:GetChildren()) do
				if instance:IsA("BasePart") then
					instance.CanCollide = false
				end

				local bone = instance:FindFirstChild("Bone")
				if not bone or not bone:IsA("BasePart") then
					continue
				end

				bone.CanCollide = false
			end

			voidPart(model, part)
		end
	end

	---Get knocked ownership item.
	local function getKnockedOwnershipItem()
		local localPlayer = players.LocalPlayer
		if not localPlayer then
			return
		end

		local backpack = localPlayer:FindFirstChild("Backpack")
		if not backpack then
			return
		end

		local selected = nil

		for _, item in pairs(backpack:GetChildren()) do
			if item.Name:match("Talent") then
				continue
			end

			if not item:IsA("Tool") then
				continue
			end

			if not item:FindFirstChildOfClass("BasePart") then
				continue
			end

			selected = item
		end

		if not selected then
			selected = localPlayer.Character and localPlayer.Character:FindFirstChild("Weapon")
			selected = selected or backpack:FindFirstChild("Weapon")
		end

		return selected
	end

	---Update move while knocked.
	local function updateMoveWhileKnocked()
		local effectReplicator = replicatedStorage:FindFirstChild("EffectReplicator")
		local effectReplicatorModule = require(effectReplicator)

		if not effectReplicatorModule:FindEffect("Knocked") then
			return
		end

		local localPlayer = players.LocalPlayer
		if not localPlayer then
			return
		end

		local character = localPlayer.Character
		if not character then
			return
		end

		local rootPart = character:FindFirstChild("HumanoidRootPart")
		if not rootPart then
			return
		end

		local humanoid = character:FindFirstChild("Humanoid")
		if not humanoid then
			return
		end

		local backpack = localPlayer:FindFirstChild("Backpack")
		if not backpack then
			return
		end

		local ownershipItem = Exploits.ownershipItem or getKnockedOwnershipItem()
		if not ownershipItem then
			return
		end

		if not Exploits.ownershipItem or not Exploits.ownershipItem:IsDescendantOf(game) then
			Exploits.ownershipItem = ownershipItem
		end

		if tick() - Exploits.ownershipTimestamp <= 0.15 then
			return
		end

		local leftHand = character:FindFirstChild("LeftHand")
		local rightHand = character:FindFirstChild("RightHand")
		local hasHandWeapon = false

		if leftHand and leftHand:FindFirstChild("HandWeapon") then
			hasHandWeapon = true
		end

		if rightHand and rightHand:FindFirstChild("HandWeapon") then
			hasHandWeapon = true
		end

		local characterHandler = character:FindFirstChild("CharacterHandler")
		local requests = characterHandler and characterHandler:FindFirstChild("Requests")
		local equipWeapon = requests and requests:FindFirstChild("EquipWeapon")

		if ownershipItem.Name == "Weapon" and hasHandWeapon then
			return equipWeapon and equipWeapon:FireServer(false)
		end

		if ownershipItem.Name == "Weapon" and not hasHandWeapon then
			return equipWeapon and equipWeapon:FireServer(true)
		end

		if ownershipItem.Parent == character then
			return humanoid:UnequipTools()
		end

		if ownershipItem.Parent == backpack then
			humanoid:EquipTool(ownershipItem)
		end

		Exploits.ownershipTimestamp = tick()
	end

	---Update pathfind breaker heartbeat.
	local function updatePathfindBreakerHeartbeat()
		local character = players.LocalPlayer.Character
		if not character then
			return
		end

		local humanoidRootPart = character:FindFirstChild("HumanoidRootPart")
		if not humanoidRootPart then
			return
		end

		lastVelocity = humanoidRootPart.AssemblyLinearVelocity

		if Configuration.expectToggleValue("AggressiveMode") then
			humanoidRootPart.AssemblyLinearVelocity = Vector3.new(0, -1e5, 0)
		else
			humanoidRootPart.AssemblyLinearVelocity = Vector3.new(0, -9e9, 0)
		end

		if not Configuration.expectToggleValue("PathfindBreakerHighlight") then
			return pathfindBreakerMaid:clean()
		end

		local highlight = InstanceWrapper.create(pathfindBreakerMaid, "PathfindBreakerHighlight", "Highlight")
		highlight.FillColor = Configuration.expectOptionValue("PathfindBreakerHighlightColor")
		highlight.OutlineColor = Configuration.expectOptionValue("PathfindBreakerHighlightOutlineColor")

		if humanoidRootPart.Parent then
			highlight.Parent = humanoidRootPart.Parent
		end
	end

	---Update exploits.
	local function updateExploits()
		local localPlayer = players.LocalPlayer
		if not localPlayer then
			return
		end

		if EchoFarm.voiding or Configuration.expectToggleValue("VoidMobs") then
			updateVoidMobs()
		else
			cleanVoidMobs()
		end

		if Configuration.expectToggleValue("MoveWhileKnocked") then
			updateMoveWhileKnocked()
		end

		if Configuration.expectToggleValue("PathfindBreaker") then
			updatePathfindBreakerHeartbeat()
		else
			lastVelocity = nil
			pathfindBreakerMaid:clean()
		end
	end

	---Update pathfind breaker.
	local function updatePathfindBreakerRender()
		if not lastVelocity then
			return
		end

		local character = players.LocalPlayer and players.LocalPlayer.Character
		if not character then
			return
		end

		local humanoidRootPart = character:FindFirstChild("HumanoidRootPart")
		if not humanoidRootPart then
			return
		end

		humanoidRootPart.AssemblyLinearVelocity = lastVelocity
	end

	---Initalize exploits.
	function Exploits.init()
		exploitsMaid:add(heartbeat:connect("Exploits_Heartbeat", updateExploits))
		exploitsMaid:add(preRender:connect("Exploits_PreRender", updatePathfindBreakerRender))

		---@note: Wrapped in a PCall to prevent errors.
		pcall(function()
			physicsService:RegisterCollisionGroup(collisionGroupName)
			physicsService:CollisionGroupSetCollidable(collisionGroupName, collisionGroupName, false)
			physicsService:CollisionGroupSetCollidable(collisionGroupName, "Default", false)
			physicsService:CollisionGroupSetCollidable(collisionGroupName, "Player", false)
			physicsService:CollisionGroupSetCollidable(collisionGroupName, "WalkThrough", false)
		end)

		-- Log.
		Logger.warn("Exploits initialized.")
	end

	---Detach voidMobs.
	function Exploits.detach()
		-- Clean.
		exploitsMaid:clean()
		voidMaid:clean()
		pathfindBreakerMaid:clean()

		-- Log.
		Logger.warn("Exploits detached.")
	end

	-- Return Exploits module.
	return Exploits
end)()

end)
__bundle_register("Features/Game/Movement", function(require, _LOADED, __bundle_register, __bundle_modules)
---@module Utility.Configuration
local Configuration = require("Utility/Configuration")

---@module Utility.OriginalStoreManager
local OriginalStoreManager = require("Utility/OriginalStoreManager")

---@module Utility.Maid
local Maid = require("Utility/Maid")

-- Maids.
local movementMaid = Maid.new()

-- Services.
local players = game:GetService("Players")
local replicatedStorage = game:GetService("ReplicatedStorage")

return LPH_NO_VIRTUALIZE(function()
	-- Movement related stuff is handled here.
	local Movement = {}

	---@module Utility.Signal
	local Signal = require("Utility/Signal")

	---@module Utility.InstanceWrapper
	local InstanceWrapper = require("Utility/InstanceWrapper")

	---@module Utility.OriginalStore
	local OriginalStore = require("Utility/OriginalStore")

	---@module Utility.ControlModule
	local ControlModule = require("Utility/ControlModule")

	---@module Utility.Finder
	local Finder = require("Utility/Finder")

	---@module Features.Game.Tweening
	local Tweening = require("Features/Game/Tweening")

	---@module Utility.Logger
	local Logger = require("Utility/Logger")

	-- Services.
	local runService = game:GetService("RunService")
	local userInputService = game:GetService("UserInputService")

	-- Original stores.
	local agilitySpoofer = movementMaid:mark(OriginalStore.new())

	-- Original store managers.
	local noClipMap = movementMaid:mark(OriginalStoreManager.new())

	-- Signals.
	local preSimulation = Signal.new(runService.PreSimulation)
	local heartbeat = Signal.new(runService.Heartbeat)

	-- Instances.
	local cachedTarget = nil

	---Update noclip.
	---@param character Model
	---@param rootPart BasePart
	local function updateNoClip(character, rootPart)
		local effectReplicator = replicatedStorage:FindFirstChild("EffectReplicator")
		if not effectReplicator then
			return
		end

		local controllerManager = character:FindFirstChild("ControllerManager")
		if not controllerManager then
			return
		end

		local airController = controllerManager:FindFirstChild("AirController")
		if not airController then
			return
		end

		local groundController = controllerManager:FindFirstChild("GroundController")
		if not groundController then
			return
		end

		if Configuration.expectToggleValue("Fly") then
			controllerManager.ActiveController = airController
		else
			controllerManager.ActiveController = groundController
		end

		local effectReplicatorModule = require(effectReplicator)
		local knockedRestore = effectReplicatorModule:FindEffect("Knocked")
			and Configuration.expectToggleValue("NoClipCollisionsKnocked")

		if Tweening.active then
			knockedRestore = false
		end

		for _, instance in pairs(character:GetChildren()) do
			if not instance:IsA("BasePart") then
				continue
			end

			noClipMap:add(instance, "CanCollide", knockedRestore and noClipMap:get(instance):get() or false)

			local bone = instance:FindFirstChild("Bone")
			if not bone then
				continue
			end

			local success, result = pcall(function()
				return bone.CanCollide ~= nil
			end)

			if not success or not result then
				continue
			end

			noClipMap:add(bone, "CanCollide", knockedRestore and noClipMap:get(bone):get() or false)
		end
	end

	---Update speed hack.
	---@param rootPart BasePart
	---@param humanoid Humanoid
	local function updateSpeedHack(rootPart, humanoid)
		if Configuration.expectToggleValue("Fly") then
			return
		end

		rootPart.AssemblyLinearVelocity = rootPart.AssemblyLinearVelocity * Vector3.new(0, 1, 0)

		local moveDirection = humanoid.MoveDirection
		if moveDirection.Magnitude <= 0.001 then
			return
		end

		rootPart.AssemblyLinearVelocity = rootPart.AssemblyLinearVelocity
			+ moveDirection.Unit * Configuration.expectOptionValue("SpeedhackSpeed")
	end

	---Update CFrame speed hack.
	---@param rootPart BasePart
	---@param humanoid Humanoid
	---@param deltaTime number
	local function updateCFrameSpeed(rootPart, humanoid, deltaTime)
		if Configuration.expectToggleValue("Fly") then
			return
		end

		local moveDirection = humanoid.MoveDirection
		if not moveDirection or moveDirection.Magnitude <= 0.001 then
			return
		end

		local speed = Configuration.expectOptionValue("CFrameSpeedMultiplier")
		rootPart.CFrame = rootPart.CFrame + moveDirection * (speed * deltaTime)
	end

	---Update infinite jump.
	---@param rootPart BasePart
	local function updateInfiniteJump(rootPart)
		if Configuration.expectToggleValue("Fly") then
			return
		end

		if not userInputService:IsKeyDown(Enum.KeyCode.Space) then
			return
		end

		rootPart.AssemblyLinearVelocity = rootPart.AssemblyLinearVelocity * Vector3.new(1, 0, 1)
		rootPart.AssemblyLinearVelocity = rootPart.AssemblyLinearVelocity
			+ Vector3.new(0, Configuration.expectOptionValue("InfiniteJumpBoost"), 0)
	end

	---Update fly hack.
	---@param rootPart BasePart
	---@param humanoid Humanoid
	local function updateFlyHack(rootPart, humanoid)
		local camera = workspace.CurrentCamera
		if not camera then
			return
		end

		-- Heliodar fly fix.
		if rootPart:FindFirstChild("HelioFlight") then
			rootPart.HelioFlight:Destroy()
		end

		local flyBodyVelocity = InstanceWrapper.create(movementMaid, "flyBodyVelocity", "BodyVelocity", rootPart)
		flyBodyVelocity.MaxForce = Vector3.new(9e9, 9e9, 9e9)

		local flyVelocity = camera.CFrame:VectorToWorldSpace(
			ControlModule.getMoveVector() * Configuration.expectOptionValue("FlySpeed")
		)

		if userInputService:IsKeyDown(Enum.KeyCode.Space) then
			flyVelocity = flyVelocity + Vector3.new(0, Configuration.expectOptionValue("FlyUpSpeed"), 0)
		end

		flyBodyVelocity.Velocity = flyVelocity
	end

	---Update max momentum spoofer.
	local function updateMaxMomentumSpoofer()
		local effectReplicator = replicatedStorage:FindFirstChild("EffectReplicator")
		local effectReplicatorModule = effectReplicator and require(effectReplicator)
		if not effectReplicatorModule then
			return
		end

		local forcedMomentumEffect = effectReplicatorModule:FindEffect("ForceMomentum")
		if not forcedMomentumEffect then
			return effectReplicatorModule:CreateEffect("ForceMomentum")
		end

		if forcedMomentumEffect.Value ~= 10 then
			forcedMomentumEffect.Value = 10
		end

		forcedMomentumEffect.Disabled = not Configuration.expectToggleValue("MaxMomentumSpoof")
	end

	---Update agility spoofer.
	---@param character Model
	local function updateAgilitySpoofer(character)
		local agility = character:FindFirstChild("PassiveAgility")
		if not agility then
			return
		end

		---@note: For every 10 investment points, there are two real agility points.
		-- With 40 investment points, we can have 16 real agility points.
		-- However, with 30 investment points, we can only have 14 real agility points.
		-- This means that the starting value must be 8 and we must increase by 2 for every point we have.
		local agilitySpoofValue = 8 + (Options.AgilitySpoof.Value / 10) * 2

		if Toggles.BoostAgilityDirectly.Value then
			agilitySpoofValue = Options.AgilitySpoof.Value
		end

		agilitySpoofer:set(agility, "Value", agilitySpoofValue)
	end

	---Update tween to back.
	local function updateTweenToBack()
		local validTargets = Finder.geir(300, Configuration.expectToggleValue("AttachIgnorePlayers"))
		if not validTargets then
			return true
		end

		local attachTarget = Configuration.expectToggleValue("StickyAttach") and cachedTarget or validTargets[1]
		if not attachTarget then
			return true
		end

		if not attachTarget.Parent then
			return false
		end

		local attachTargetHrp = attachTarget:FindFirstChild("HumanoidRootPart")
		if not attachTargetHrp then
			return false
		end

		local attachTargetHumanoid = attachTarget:FindFirstChild("Humanoid")
		if not attachTargetHumanoid then
			return false
		end

		if attachTargetHumanoid.Health <= 0 then
			return false
		end

		cachedTarget = cachedTarget or attachTarget

		local offsetCFrame = CFrame.new(
			0.0,
			Configuration.expectOptionValue("HeightOffset"),
			Configuration.expectOptionValue("BackOffset")
		)

		local targetPosition = (attachTargetHrp.CFrame * offsetCFrame).Position
		local goalCFrame = CFrame.lookAt(targetPosition, attachTargetHrp.Position)

		Tweening.goal("TweenToBack", goalCFrame, false)

		return true
	end

	---Update movement.
	---@param dt number
	local function updateMovement(dt)
		local localPlayer = players.LocalPlayer
		local character = localPlayer.Character
		if not character then
			return
		end

		local rootPart = character:FindFirstChild("HumanoidRootPart")
		if not rootPart then
			return
		end

		local humanoid = character:FindFirstChild("Humanoid")
		if not humanoid then
			return
		end

		if not Configuration.expectToggleValue("TweenToBack") or not updateTweenToBack() then
			cachedTarget = nil
		end

		if Configuration.expectToggleValue("AgilitySpoof") then
			updateAgilitySpoofer(character)
		else
			agilitySpoofer:restore()
		end

		if Configuration.expectToggleValue("MaxMomentumSpoof") then
			updateMaxMomentumSpoofer()
		end

		if Tweening.active or Configuration.expectToggleValue("NoClip") then
			updateNoClip(character, rootPart)
		else
			noClipMap:restore()
		end

		if Tweening.active then
			return
		end

		if Configuration.expectToggleValue("Fly") then
			updateFlyHack(rootPart, humanoid)
		else
			movementMaid["flyBodyVelocity"] = nil
		end

		if Configuration.expectToggleValue("Speedhack") then
			updateSpeedHack(rootPart, humanoid)
		end

		-- CFrame Speed is standalone and can be used independently of Speedhack.
		if Configuration.expectToggleValue("CFrameSpeed") then
			updateCFrameSpeed(rootPart, humanoid, dt)
		end

		if Configuration.expectToggleValue("InfiniteJump") then
			updateInfiniteJump(rootPart)
		end
	end

	---Initialize movement.
	function Movement.init()
		-- Attach.
		movementMaid:add(preSimulation:connect("Movement_PreSimulation", updateMovement))
		movementMaid:add(heartbeat:connect("Movement_Heartbeat", Tweening.update))

		-- Log.
		Logger.warn("Movement initialized.")
	end

	---Detach movement.
	function Movement.detach()
		-- Clean.
		movementMaid:clean()

		-- Log.
		Logger.warn("Movement detached.")
	end

	-- Return Movement module.
	return Movement
end)()

end)
__bundle_register("Features/Automation/InteligenceFarm", function(require, _LOADED, __bundle_register, __bundle_modules)
-- Inteligence farming.
local InteligenceFarm = {}

---@module Utility.Maid
local Maid = require("Utility/Maid")

---@module Utility.Signal
local Signal = require("Utility/Signal")

---@module Utility.Attributes
local Attributes = require("Utility/Attributes")

---@module Utility.Logger
local Logger = require("Utility/Logger")

-- Services.
local players = game:GetService("Players")
local runService = game:GetService("RunService")

-- Signals.
local renderStepped = Signal.new(runService.RenderStepped)

-- Maids.
local autoIntelligenceMaid = Maid.new()

---Update inteligence.
local function updateInteligence()
	local inteligenceFarm = Toggles["AutoIntelligence"]
	if not inteligenceFarm or not inteligenceFarm.Value then
		return
	end

	local inteligenceFarmCap = Options["IntelligenceCap"]
	if not inteligenceFarmCap then
		return
	end

	local localPlayer = players.LocalPlayer
	local localPlayerCharacter = localPlayer.Character
	if not localPlayerCharacter then
		return
	end

	if not Attributes.isNotAtCap(localPlayerCharacter, "Stat_Intelligence", inteligenceFarmCap.Value) then
		Logger.longNotify("Intelligence AutoFarm is automatically stopping.")
		return inteligenceFarm:SetValue(false)
	end

	local humanoid = localPlayerCharacter:FindFirstChild("Humanoid")
	if not humanoid then
		return
	end

	local backpack = localPlayer:FindFirstChild("Backpack")
	if not backpack then
		return
	end

	local characterBook = localPlayerCharacter:FindFirstChild("Math Textbook")
	local backpackBook = backpack:FindFirstChild("Math Textbook")

	if not characterBook and backpackBook then
		return humanoid:EquipTool(backpackBook)
	end

	local choicePrompt = localPlayer.PlayerGui:FindFirstChild("ChoicePrompt")
	if not choicePrompt then
		return characterBook and characterBook:Activate()
	end

	local choiceRemote = choicePrompt:FindFirstChild("Choice")
	if not choiceRemote then
		return
	end

	local choiceFrame = choicePrompt:FindFirstChild("ChoiceFrame")
	if not choiceFrame then
		return
	end

	local descSheet = choiceFrame:FindFirstChild("DescSheet")
	local description = descSheet and descSheet:FindFirstChild("Desc")
	if not description then
		return
	end

	local options = choiceFrame:FindFirstChild("Options")
	if not options then
		return
	end

	-- Fetch possible answers.
	local answers = {}

	for _, instance in next, options:GetChildren() do
		if not instance:IsA("TextButton") then
			continue
		end

		local number = tonumber(instance.Name)
		if not number then
			continue
		end

		table.insert(answers, number)
	end

	-- Parse description of junk.
	local descriptionText = tostring(description.Text)
	local parsedDescription = descriptionText:gsub("What is", ""):gsub(" ", ""):gsub("?", ""):gsub("by", "")

	-- Get the current operation.
	local operation = nil

	if parsedDescription:match("divided") then
		operation = "divided"
	end

	if parsedDescription:match("times") then
		operation = "times"
	end

	if parsedDescription:match("plus") then
		operation = "plus"
	end

	if parsedDescription:match("minus") then
		operation = "minus"
	end

	if not operation then
		return
	end

	-- Parse numbers.
	local parsedNumbers = parsedDescription:split(operation)
	local firstNumber = tonumber(parsedNumbers[1] or "")
	local secondNumber = tonumber(parsedNumbers[2] or "")
	if not firstNumber or not secondNumber then
		return
	end

	-- Calculate the answer.
	local answer = nil

	if operation == "divided" then
		answer = firstNumber / secondNumber
	end

	if operation == "times" then
		answer = firstNumber * secondNumber
	end

	if operation == "plus" then
		answer = firstNumber + secondNumber
	end

	if operation == "minus" then
		answer = firstNumber - secondNumber
	end

	-- Find the closest of the possible answers to the real one.
	local closestAnswer = nil
	local closestDifference = nil

	for _, possible in next, answers do
		local delta = math.abs(answer - possible)

		if closestDifference and delta > closestDifference then
			continue
		end

		closestAnswer = possible
		closestDifference = delta
	end

	if not closestAnswer then
		return
	end

	-- Fire with the closest answer as a string.
	choiceRemote:FireServer(tostring(closestAnswer))
end

---Intelligence farming.
function InteligenceFarm.init()
	-- Attach the inteligence farm.
	autoIntelligenceMaid:add(renderStepped:connect("AttributeFarmIntelligence_OnPreRender", updateInteligence))

	-- Log.
	Logger.warn("Inteligence Farm initialized.")
end

---Detach the inteligence farm.
function InteligenceFarm.detach()
	-- Clean the maid.
	autoIntelligenceMaid:clean()

	-- Log.
	Logger.warn("Inteligence Farm detached.")
end

-- Return InteligenceFarm module
return InteligenceFarm

end)
__bundle_register("Utility/Attributes", function(require, _LOADED, __bundle_register, __bundle_modules)
return LPH_NO_VIRTUALIZE(function()
	-- Attributes module for handling attribute related functions.
	local Attributes = {}

	---Is the user not at the specified stat cap yet?
	---@param playerCharacter Model
	---@param attribute string
	---@param cap string
	---@return boolean
	function Attributes.isNotAtCap(playerCharacter, attribute, cap)
		local useDefault = cap == ""
		local maxStat = useDefault and 100 or tonumber(cap)
		local statCap = maxStat == 0 and 100 or maxStat

		local currentStat = tonumber(playerCharacter:GetAttribute(attribute) or 0)
		if not currentStat or currentStat >= statCap then
			return false
		end

		return true
	end

	-- Return AttributeFarm module
	return Attributes
end)()

end)
__bundle_register("Features/Automation/CharismaFarm", function(require, _LOADED, __bundle_register, __bundle_modules)
-- Charisma farming.
local CharismaFarm = {}

---@module Utility.Maid
local Maid = require("Utility/Maid")

---@module Utility.Signal
local Signal = require("Utility/Signal")

---@module Utility.Attributes
local Attributes = require("Utility/Attributes")

---@module Utility.Logger
local Logger = require("Utility/Logger")

-- Services.
local players = game:GetService("Players")
local runService = game:GetService("RunService")

-- Signals.
local renderStepped = Signal.new(runService.RenderStepped)

-- Maids.
local autoCharismaMaid = Maid.new()

---Update charisma.
local function updateCharisma()
	local charismaFarm = Toggles["AutoCharisma"]
	if not charismaFarm or not charismaFarm.Value then
		return
	end

	local charismaFarmCap = Options["CharismaCap"]
	if not charismaFarmCap then
		return
	end

	local localPlayer = players.LocalPlayer
	local localPlayerCharacter = localPlayer.Character
	if not localPlayerCharacter then
		return
	end

	if not Attributes.isNotAtCap(localPlayerCharacter, "Stat_Charisma", charismaFarmCap.Value) then
		Logger.longNotify("Charisma AutoFarm is automatically stopping.")
		return charismaFarm:SetValue(false)
	end

	local humanoid = localPlayerCharacter:FindFirstChild("Humanoid")
	if not humanoid then
		return
	end

	local backpack = localPlayer:FindFirstChild("Backpack")
	if not backpack then
		return
	end

	local characterBook = localPlayerCharacter:FindFirstChild("How to Make Friends")
	local backpackBook = backpack:FindFirstChild("How to Make Friends")

	if not characterBook and backpackBook then
		return humanoid:EquipTool(backpackBook)
	end

	local choicePrompt = localPlayer.PlayerGui:FindFirstChild("ChoicePrompt")
	if not choicePrompt then
		return characterBook and characterBook:Activate()
	end

	local choiceFrame = choicePrompt:FindFirstChild("ChoiceFrame")
	if not choiceFrame then
		return
	end

	local chatChoice = choicePrompt:FindFirstChild("ChatChoice")
	if not chatChoice then
		return
	end

	local description = choiceFrame:FindFirstChild("Desc")
	if not description then
		return
	end

	local text = description.Text:split("\n")
	local charismaLine = text[2]:sub(2, -2)

	chatChoice:InvokeServer(charismaLine)
end

---Charisma farming.
function CharismaFarm.init()
	-- Attach.
	autoCharismaMaid:add(renderStepped:connect("AttributeFarmCharisma_OnPreRender", updateCharisma))

	-- Log.
	Logger.warn("Charisma Farm initialized.")
end

---Detach the charisma farm.
function CharismaFarm.detach()
	-- Clean.
	autoCharismaMaid:clean()

	-- Log.
	Logger.warn("Charisma Farm detached.")
end

-- Return CharismaFarm module
return CharismaFarm

end)
__bundle_register("Menu", function(require, _LOADED, __bundle_register, __bundle_modules)
-- Menu module.
local Menu = {}

---@module GUI.ThemeManager
local ThemeManager = require("GUI/ThemeManager")

---@module GUI.SaveManager
local SaveManager = require("GUI/SaveManager")

---@module GUI.Library
local Library = require("GUI/Library")

---@module Menu.CombatTab
local CombatTab = require("Menu/CombatTab")

---@module Menu.GameTab
local GameTab = require("Menu/GameTab")

---@module Menu.AutomationTab
local AutomationTab = require("Menu/AutomationTab")

---@module Menu.BuilderTab
local BuilderTab = require("Menu/BuilderTab")

---@module Menu.VisualsTab
local VisualsTab = require("Menu/VisualsTab")

---@module Menu.ExploitTab
local ExploitTab = require("Menu/ExploitTab")

---@module Menu.LycorisTab
local LycorisTab = require("Menu/LycorisTab")

---@module Utility.Logger
local Logger = require("Utility/Logger")

---@module Utility.Maid
local Maid = require("Utility/Maid")

---@module Utility.Signal
local Signal = require("Utility/Signal")

---@module Utility.Configuration
local Configuration = require("Utility/Configuration")

-- Services.
local runService = game:GetService("RunService")
local stats = game:GetService("Stats")
local players = game:GetService("Players")
local userInputService = game:GetService("UserInputService")

-- Signals.
local renderStepped = Signal.new(runService.RenderStepped)

-- Maids.
local menuMaid = Maid.new()

-- Constants.
local MENU_TITLE = "Linoria V2 | Deepwoken"

if LRM_UserNote then
	MENU_TITLE = string.format(
		"(Commit %s) Linoria V2 | Deepwoken First Release",
		string.sub("6c10af8d79e3dc253ba6db7f343613361c37e378", 1, 6)
	)
end

---Initialize menu.
function Menu.init()
	-- Create window.
	local window = Library:CreateWindow({
		Title = MENU_TITLE,
		Center = true,
		AutoShow = not shared.Lycoris.silent,
		TabPadding = 8,
		MenuFadeTime = 0.0,
	})

	-- Configure ThemeManager.
	ThemeManager:SetLibrary(Library)
	ThemeManager:SetFolder("Lycoris-Rewrite-Themes")

	-- Configure SaveManager.
	SaveManager:SetLibrary(Library)
	SaveManager:IgnoreThemeSettings()
	SaveManager:SetFolder("Lycoris-Rewrite-Configs")
	SaveManager:SetIgnoreIndexes({
		"Fly",
		"NoClip",
		"Speedhack",
		"InfiniteJump",
		"TweenToObjective",
		"TweenToBack",
	})

	-- Initialize all tabs. Don't initialize them if we have the 'exploit_tester' role.
	CombatTab.init(window)
	BuilderTab.init(window)
	GameTab.init(window)
	VisualsTab.init(window)
	AutomationTab.init(window)
	ExploitTab.init(window)
	LycorisTab.init(window)

	-- Last update.
	local lastUpdate = os.clock()

	-- Update watermark.
	menuMaid:add(renderStepped:connect(
		"Menu_WatermarkUpdate",
		LPH_NO_VIRTUALIZE(function()
			if os.clock() - lastUpdate <= 0.5 then
				return
			end

			lastUpdate = os.clock()

			-- Get stats.
			local networkStats = stats:FindFirstChild("Network")
			local workspaceStats = stats:FindFirstChild("Workspace")
			local performanceStats = stats:FindFirstChild("PerformanceStats")
			local serverStats = networkStats and networkStats:FindFirstChild("ServerStatsItem") or nil

			-- Get data.
			local pingData = serverStats and serverStats:FindFirstChild("Data Ping") or nil
			local heartbeatData = workspaceStats and workspaceStats:FindFirstChild("Heartbeat") or nil
			local cpuData = performanceStats and performanceStats:FindFirstChild("CPU") or nil
			local gpuData = performanceStats and performanceStats:FindFirstChild("GPU") or nil

			-- Set values.
			local ping = pingData and pingData:GetValue() or 0.0
			local fps = heartbeatData and heartbeatData:GetValue() or 0.0
			local cpu = cpuData and cpuData:GetValue() or 0.0
			local gpu = gpuData and gpuData:GetValue() or 0.0

			-- Character data.
			local mouse = players.LocalPlayer and players.LocalPlayer:GetMouse()
			local character = players.LocalPlayer and players.LocalPlayer.Character
			local humanoidRootPart = character and character:FindFirstChild("HumanoidRootPart")
			local position = humanoidRootPart and humanoidRootPart.Position
			local positionFormat = position and string.format("(%.2f, %.2f, %.2f)", position.X, position.Y, position.Z)
				or "N/A"

			-- String.
			local str = string.format("%s | %.2fms | %.1f/s | %.1fms | %.1fms", MENU_TITLE, ping, fps, cpu, gpu)

			if Configuration.expectToggleValue("ShowDebugInformation") then
				str = str .. string.format(" | %s", positionFormat)
				str = str .. string.format(" | %s", mouse and mouse.Target and mouse.Target:GetFullName() or "N/A")
			end

			-- Set watermark.
			Library:SetWatermark(str)
		end)
	))

	local inputBegan = Signal.new(userInputService.InputBegan)

	inputBegan:connect("Menu_InputBegan", function(input, gameProcessed)
		if gameProcessed then
			return
		end

		if not Configuration.expectToggleValue("ShowDebugInformation") then
			return
		end

		if input.KeyCode == Enum.KeyCode.F8 then
			local mouse = players.LocalPlayer and players.LocalPlayer:GetMouse()
			local target = mouse and mouse.Target
			if not target then
				return
			end

			target.Name = tostring(math.random(100000, 1000000))

			return Logger.mnnotify("The target has been renamed to '%s' as a marker.", target.Name)
		end

		if input.KeyCode == Enum.KeyCode.Equals and Library.Recording then
			local Character = players.LocalPlayer and players.LocalPlayer.Character
			local HumanoidRootPart = Character and Character:FindFirstChild("HumanoidRootPart")
			local Position = HumanoidRootPart and HumanoidRootPart.Position
			local PositionFormat = Position
					and string.format("CFrame.new(%.2f, %.2f, %.2f)", Position.X, Position.Y, Position.Z)
				or "N/A"

			Library.PositionList[#Library.PositionList + 1] = PositionFormat
		end
	end)

	-- Configure Library.
	Library.ToggleKeybind = Options.MenuKeybind

	-- Load auto-load config.
	SaveManager:LoadAutoloadConfig()

	-- Log menu initialization.
	Logger.warn("Menu initialized.")
end

---Detach menu.
function Menu.detach()
	menuMaid:clean()

	BuilderTab.detach()

	Library:Unload()

	Logger.warn("Menu detached.")
end

-- Return Menu module.
return Menu

end)
__bundle_register("Menu/LycorisTab", function(require, _LOADED, __bundle_register, __bundle_modules)
-- LycorisTab module.
local LycorisTab = {}

---@module GUI.ThemeManager
local ThemeManager = require("GUI/ThemeManager")

---@module GUI.SaveManager
local SaveManager = require("GUI/SaveManager")

---@module GUI.Library
local Library = require("GUI/Library")

---@module Utility.Logger
local Logger = require("Utility/Logger")

---Initialize Cheat Settings section.
---@param groupbox table
function LycorisTab.initCheatSettingsSection(groupbox)
	groupbox:AddButton("Toggle Silent Mode", function()
		if not isfile or not delfile or not writefile then
			return
		end

		shared.Lycoris.silent = not shared.Lycoris.silent

		if not shared.Lycoris.silent then
			Logger.notify("Silent mode was disabled.")
		end

		if isfile("smarker.txt") then
			delfile("smarker.txt")
		else
			writefile(
				"smarker.txt",
				"Hello, if you're reading this, that means you have Lycoris-Rewrite (Deepwoken) silent mode turned on. Deleting this file will turn it off."
			)
		end
	end)

	groupbox:AddButton("Toggle Player Scanning", function()
		if not isfile or not delfile or not writefile then
			return
		end

		shared.Lycoris.dpscanning = not shared.Lycoris.dpscanning

		if shared.Lycoris.dpscanning then
			Logger.notify("Player scanning was disabled.")
		else
			Logger.notify("Player scanning was enabled.")
		end

		if isfile("dpscanning.txt") then
			delfile("dpscanning.txt")
		else
			writefile(
				"dpscanning.txt",
				"Hello, if you're reading this, that means you have Lycoris-Rewrite (Deepwoken) player scanning turned off. Deleting this file will turn it on."
			)
		end
	end)

	groupbox:AddButton("Toggle Bloxstrap RPC", function()
		if not isfile or not delfile or not writefile then
			return
		end

		shared.Lycoris.norpc = not shared.Lycoris.norpc

		if not shared.Lycoris.norpc then
			Logger.notify("Bloxstrap RPC was enabled.")
		else
			Logger.notify("Bloxstrap RPC was disabled.")
		end

		if isfile("norpc.txt") then
			delfile("norpc.txt")
		else
			writefile(
				"norpc.txt",
				"Hello, if you're reading this, that means you have Lycoris-Rewrite (Deepwoken) Bloxstrap RPC turned off. Deleting this file will turn it on."
			)
		end
	end)

	groupbox:AddButton("Unload Cheat", function()
		shared.Lycoris.detach()
	end)
end

---Initialize UI Settings section.
---@param groupbox table
function LycorisTab.initUISettingsSection(groupbox)
	groupbox:AddSlider("NotificationScale", {
		Text = "Notification Scale",
		Min = 50,
		Max = 300,
		Default = 100,
		Rounding = 0,
		Suffix = "%",
	})

	groupbox:AddSlider("QuickNotificationSpeed", {
		Text = "Quick Notification Speed",
		Min = 0.1,
		Max = 2.0,
		Default = 0.5,
		Rounding = 2,
		Suffix = "s",
	})

	local menuBindLabel = groupbox:AddLabel("Menu Bind")

	menuBindLabel:AddKeyPicker("MenuKeybind", { Default = "LeftAlt", NoUI = true, Text = "Menu Keybind" })

	local keybindFrameLabel = groupbox:AddLabel("Keybind List Bind")

	keybindFrameLabel:AddKeyPicker("KeybindList", {
		Default = "N/A",
		Mode = "Off",
		NoUI = true,
		Text = "Keybind List",
		Callback = function(Value)
			Library.KeybindFrame.Visible = Value
		end,
	})

	local watermarkFrameLabel = groupbox:AddLabel("Watermark Bind")

	watermarkFrameLabel:AddKeyPicker("Watermark", {
		Default = "N/A",
		Mode = "Off",
		NoUI = true,
		Text = "Watermark",
		Callback = function(Value)
			Library:SetWatermarkVisibility(Value)
		end,
	})
end

---Initialize tab.
function LycorisTab.init(window)
	-- Create tab.
	local tab = window:AddTab("Settings") -- dont change the name, it's more confusing if its named that way

	-- Initialize sections.
	LycorisTab.initCheatSettingsSection(tab:AddLeftGroupbox("Cheat Settings"))
	LycorisTab.initUISettingsSection(tab:AddRightGroupbox("UI Settings"))

	-- Configure SaveManager & ThemeManager.
	ThemeManager:ApplyToTab(tab)
	SaveManager:BuildConfigSection(tab)
end

-- Return LycorisTab module.
return LycorisTab

end)
__bundle_register("GUI/SaveManager", function(require, _LOADED, __bundle_register, __bundle_modules)
return LPH_NO_VIRTUALIZE(function()
	local httpService = game:GetService("HttpService")

	---Export UDim2 to a serializable table.
	---@param udim2 UDim2
	---@return table
	local function uDIm2Export(udim2)
		return {
			xScale = udim2.X.Scale,
			xOffset = udim2.X.Offset,
			yScale = udim2.Y.Scale,
			yOffset = udim2.Y.Offset,
		}
	end

	---Import UDim2 from a serializable table.
	---@param serialized table
	---@return UDim2
	local function uDim2Import(serialized)
		return UDim2.new(serialized.xScale, serialized.xOffset, serialized.yScale, serialized.yOffset)
	end

	local SaveManager = {}
	do
		SaveManager.Folder = "Lycoris-Rewrite-Configs"
		SaveManager.Ignore = {}
		SaveManager.Parser = {
			Toggle = {
				Save = function(idx, object)
					return { type = "Toggle", idx = idx, value = object.Value }
				end,
				Load = function(idx, data)
					if Toggles[idx] then
						Toggles[idx]:SetValue(data.value)
					end
				end,
			},
			Slider = {
				Save = function(idx, object)
					return { type = "Slider", idx = idx, value = tostring(object.Value) }
				end,
				Load = function(idx, data)
					if Options[idx] then
						Options[idx]:SetValue(data.value)
					end
				end,
			},
			Dropdown = {
				Save = function(idx, object)
					return {
						type = "Dropdown",
						idx = idx,
						value = object.Value,
						values = object.SaveValues and object.Values or nil,
						mutli = object.Multi,
					}
				end,
				Load = function(idx, data)
					if Options[idx] then
						Options[idx]:SetValue(data.value)

						if not data.values then
							return
						end

						Options[idx]:SetValues(data.values)
					end
				end,
			},
			ColorPicker = {
				Save = function(idx, object)
					return {
						type = "ColorPicker",
						idx = idx,
						hue = object.Hue,
						sat = object.Sat,
						vib = object.Vib,
						transparency = object.Transparency,
						rainbow = object.Rainbow,
					}
				end,
				Load = function(idx, data)
					if Options[idx] then
						Options[idx].Rainbow = data.rainbow
						Options[idx]:SetValue({ data.hue, data.sat, data.vib }, data.transparency)
						Options[idx]:Display()
					end
				end,
			},
			KeyPicker = {
				Save = function(idx, object)
					return { type = "KeyPicker", idx = idx, mode = object.Mode, key = object.Value }
				end,
				Load = function(idx, data)
					if Options[idx] then
						Options[idx]:SetValue({ data.key, data.mode })
					end
				end,
			},

			Input = {
				Save = function(idx, object)
					return { type = "Input", idx = idx, text = object.Value }
				end,
				Load = function(idx, data)
					if Options[idx] and type(data.text) == "string" then
						Options[idx]:SetValue(data.text)
					end
				end,
			},
		}

		function SaveManager:SetIgnoreIndexes(list)
			for _, key in next, list do
				self.Ignore[key] = true
			end
		end

		function SaveManager:SetFolder(folder)
			self.Folder = folder
			self:BuildFolderTree()
		end

		function SaveManager:Save(name)
			if not name then
				return false, "no config file is selected"
			end

			local fullPath = self.Folder .. "/" .. name .. ".json"

			local data = {
				objects = {},
				keybindFramePosition = uDIm2Export(self.Library.KeybindFrame.Position),
				watermarkFramePosition = uDIm2Export(self.Library.Watermark.Position),
				infoLoggerFramePosition = uDIm2Export(self.Library.InfoLoggerFrame.Position),
				infoLoggerBlacklistHistory = self.Library.InfoLoggerData.KeyBlacklistHistory,
				infoLoggerBlacklist = self.Library.InfoLoggerData.KeyBlacklistList,
				infoLoggerCycle = self.Library.InfoLoggerData.InfoLoggerCycle,
				animationVisualizerFramePosition = uDIm2Export(self.Library.AnimationVisualizerFrame.Position),
				overrideData = self.Library.OverrideData,
			}

			for idx, toggle in next, Toggles do
				if self.Ignore[idx] then
					continue
				end

				table.insert(data.objects, self.Parser[toggle.Type].Save(idx, toggle))
			end

			for idx, option in next, Options do
				if not self.Parser[option.Type] then
					continue
				end
				if self.Ignore[idx] then
					continue
				end

				table.insert(data.objects, self.Parser[option.Type].Save(idx, option))
			end

			local success, encoded = pcall(httpService.JSONEncode, httpService, data)
			if not success then
				return false, "failed to encode data"
			end

			writefile(fullPath, encoded)
			return true
		end

		function SaveManager:Load(name)
			if not name then
				return false, "no config file is selected"
			end

			local file = self.Folder .. "/" .. name .. ".json"
			if not isfile(file) then
				return false, "invalid file"
			end

			local success, decoded = pcall(httpService.JSONDecode, httpService, readfile(file))
			if not success then
				return false, "decode error"
			end

			if decoded.keybindFramePosition then
				self.Library.KeybindFrame.Position = uDim2Import(decoded.keybindFramePosition)
			end

			if decoded.watermarkFramePosition then
				self.Library.Watermark.Position = uDim2Import(decoded.watermarkFramePosition)
			end

			if decoded.infoLoggerFramePosition then
				self.Library.InfoLoggerFrame.Position = uDim2Import(decoded.infoLoggerFramePosition)
			end

			if decoded.infoLoggerBlacklistHistory then
				self.Library.InfoLoggerData.KeyBlacklistHistory = decoded.infoLoggerBlacklistHistory
			end

			if decoded.animationVisualizerFramePosition then
				self.Library.AnimationVisualizerFrame.Position = uDim2Import(decoded.animationVisualizerFramePosition)
			end

			local timingList = Options["TimingOverrideList"]

			if decoded.overrideData and timingList then
				self.Library.OverrideData = decoded.overrideData

				local values = {}

				for rname, _ in next, decoded.overrideData do
					values[#values + 1] = rname
				end

				timingList:SetValues(values)
			end

			for _, option in next, decoded.objects do
				if self.Parser[option.type] then
					task.spawn(function()
						self.Parser[option.type].Load(option.idx, option)
					end) -- task.spawn() so the config loading wont get stuck.
				end
			end

			if decoded.infoLoggerBlacklist then
				self.Library.InfoLoggerData.KeyBlacklistList = decoded.infoLoggerBlacklist
				self.Library:RefreshInfoLogger()
				if Options and Options.BlacklistedKeys then
					Options.BlacklistedKeys:SetValues(self.Library:KeyBlacklists())
				end
			end

			if decoded.infoLoggerCycle then
				self.Library.InfoLoggerData.InfoLoggerCycle = decoded.infoLoggerCycle
				self.Library:RefreshInfoLogger()
				if Options and Options.BlacklistedKeys then
					Options.BlacklistedKeys:SetValues(self.Library:KeyBlacklists())
				end
			end

			return true
		end

		function SaveManager:IgnoreThemeSettings()
			self:SetIgnoreIndexes({
				"BackgroundColor",
				"MainColor",
				"AccentColor",
				"OutlineColor",
				"FontColor", -- themes
				"ThemeManager_ThemeList",
				"ThemeManager_CustomThemeList",
				"ThemeManager_CustomThemeName", -- themes
			})
		end

		function SaveManager:BuildFolderTree()
			local paths = {
				self.Folder,
			}

			for i = 1, #paths do
				local str = paths[i]
				if not isfolder(str) then
					makefolder(str)
				end
			end
		end

		function SaveManager:RefreshConfigList()
			local list = listfiles(self.Folder)

			local out = {}
			for i = 1, #list do
				local file = list[i]
				if file:sub(-5) == ".json" then
					-- i hate this but it has to be done ...

					local pos = file:find(".json", 1, true)
					local start = pos

					local char = file:sub(pos, pos)
					while char ~= "/" and char ~= "\\" and char ~= "" do
						pos = pos - 1
						char = file:sub(pos, pos)
					end

					if char == "/" or char == "\\" then
						table.insert(out, file:sub(pos + 1, start - 1))
					end
				end
			end

			return out
		end

		function SaveManager:SetLibrary(library)
			self.Library = library
		end

		function SaveManager:LoadAutoloadConfig()
			if isfile(self.Folder .. "/autoload.txt") then
				local name = readfile(self.Folder .. "/autoload.txt")

				local success, err = self:Load(name)
				if not success then
					return self.Library:Notify("Failed to load autoload config: " .. err)
				end

				self.Library:Notify(string.format("Auto loaded config %q", name))
			end
		end

		function SaveManager:BuildConfigSection(tab)
			assert(self.Library, "Must set SaveManager.Library")

			local section = tab:AddRightGroupbox("Config Manager")

			section:AddInput("SaveManager_ConfigName", { Text = "Config name" })
			section:AddDropdown(
				"SaveManager_ConfigList",
				{ Text = "Config list", Values = self:RefreshConfigList(), AllowNull = true }
			)

			section:AddDivider()

			section
				:AddButton("Create config", function()
					local name = Options.SaveManager_ConfigName.Value

					if name:gsub(" ", "") == "" then
						return self.Library:Notify("Invalid config name (empty)", 2)
					end

					local success, err = self:Save(name)
					if not success then
						return self.Library:Notify("Failed to save config: " .. err)
					end

					self.Library:Notify(string.format("Created config %q", name))

					Options.SaveManager_ConfigList:SetValues(self:RefreshConfigList())
					Options.SaveManager_ConfigList:SetValue(nil)
				end)
				:AddButton("Load config", function()
					local name = Options.SaveManager_ConfigList.Value

					local success, err = self:Load(name)
					if not success then
						return self.Library:Notify("Failed to load config: " .. err)
					end

					self.Library:Notify(string.format("Loaded config %q", name))
				end)

			section:AddButton("Overwrite config", function()
				local name = Options.SaveManager_ConfigList.Value

				local success, err = self:Save(name)
				if not success then
					return self.Library:Notify("Failed to overwrite config: " .. err)
				end

				self.Library:Notify(string.format("Overwrote config %q", name))
			end)

			section:AddButton("Refresh list", function()
				Options.SaveManager_ConfigList:SetValues(self:RefreshConfigList())
				Options.SaveManager_ConfigList:SetValue(nil)
			end)

			section:AddButton("Set as autoload", function()
				local name = Options.SaveManager_ConfigList.Value
				writefile(self.Folder .. "/autoload.txt", name)
				SaveManager.AutoloadLabel:SetText("Current autoload config: " .. name)
				self.Library:Notify(string.format("Set %q to auto load", name))
			end)

			SaveManager.AutoloadLabel = section:AddLabel("Current autoload config: none", true)

			if isfile(self.Folder .. "/autoload.txt") then
				local name = readfile(self.Folder .. "/autoload.txt")
				SaveManager.AutoloadLabel:SetText("Current autoload config: " .. name)
			end

			SaveManager:SetIgnoreIndexes({ "SaveManager_ConfigList", "SaveManager_ConfigName" })
		end

		SaveManager:BuildFolderTree()
	end

	return SaveManager
end)()

end)
__bundle_register("GUI/ThemeManager", function(require, _LOADED, __bundle_register, __bundle_modules)
return LPH_NO_VIRTUALIZE(function()
	local httpService = game:GetService("HttpService")
	local ThemeManager = {}
	do
		ThemeManager.Folder = "Lycoris-Rewrite-Themes"
		ThemeManager.Library = nil
		ThemeManager.BuiltInThemes = {
			["Default"] = {
				1,
				httpService:JSONDecode(
					'{"FontColor":"ffffff","MainColor":"1c1c1c","AccentColor":"0055ff","BackgroundColor":"141414","OutlineColor":"323232"}'
				),
			},
			["BBot"] = {
				2,
				httpService:JSONDecode(
					'{"FontColor":"ffffff","MainColor":"1e1e1e","AccentColor":"7e48a3","BackgroundColor":"232323","OutlineColor":"141414"}'
				),
			},
			["Fatality"] = {
				3,
				httpService:JSONDecode(
					'{"FontColor":"ffffff","MainColor":"1e1842","AccentColor":"c50754","BackgroundColor":"191335","OutlineColor":"3c355d"}'
				),
			},
			["Jester"] = {
				4,
				httpService:JSONDecode(
					'{"FontColor":"ffffff","MainColor":"242424","AccentColor":"db4467","BackgroundColor":"1c1c1c","OutlineColor":"373737"}'
				),
			},
			["Mint"] = {
				5,
				httpService:JSONDecode(
					'{"FontColor":"ffffff","MainColor":"242424","AccentColor":"3db488","BackgroundColor":"1c1c1c","OutlineColor":"373737"}'
				),
			},
			["Tokyo Night"] = {
				6,
				httpService:JSONDecode(
					'{"FontColor":"ffffff","MainColor":"191925","AccentColor":"6759b3","BackgroundColor":"16161f","OutlineColor":"323232"}'
				),
			},
			["Ubuntu"] = {
				7,
				httpService:JSONDecode(
					'{"FontColor":"ffffff","MainColor":"3e3e3e","AccentColor":"e2581e","BackgroundColor":"323232","OutlineColor":"191919"}'
				),
			},
			["Quartz"] = {
				8,
				httpService:JSONDecode(
					'{"FontColor":"ffffff","MainColor":"232330","AccentColor":"426e87","BackgroundColor":"1d1b26","OutlineColor":"27232f"}'
				),
			},
		}

		function ThemeManager:ApplyTheme(theme)
			local customThemeData = self:GetCustomTheme(theme)
			local data = customThemeData or self.BuiltInThemes[theme]

			if not data then
				return
			end

			for idx, themeData in next, customThemeData or data[2] do
				if type(themeData) == "string" then
					self.Library[idx] = Color3.fromHex(themeData)

					if Options[idx] then
						Options[idx]:SetValueRGB(Color3.fromHex(themeData))
					end
				else
					self.Library[idx] = Color3.fromHSV(themeData.hue, themeData.sat, themeData.vib)

					if Options[idx] then
						Options[idx].Rainbow = themeData.rainbow
						Options[idx]:SetValue({ themeData.hue, themeData.sat, themeData.vib }, themeData.transparency)
						Options[idx]:Display()
					end
				end
			end

			self:ThemeUpdate()
		end

		function ThemeManager:ThemeUpdate()
			-- This allows us to force apply themes without loading the themes tab :)
			local options = { "FontColor", "MainColor", "AccentColor", "BackgroundColor", "OutlineColor" }
			for i, field in next, options do
				if Options and Options[field] then
					self.Library[field] = Options[field].Value
				end
			end

			self.Library.AccentColorDark = self.Library:GetDarkerColor(self.Library.AccentColor)
			self.Library:UpdateColorsUsingRegistry()
		end

		function ThemeManager:LoadDefault()
			local theme = "Default"
			local content = isfile(self.Folder .. "/default.txt") and readfile(self.Folder .. "/default.txt")

			local isDefault = true
			if content then
				if self.BuiltInThemes[content] then
					theme = content
				elseif self:GetCustomTheme(content) then
					theme = content
					isDefault = false
				end
			elseif self.BuiltInThemes[self.DefaultTheme] then
				theme = self.DefaultTheme
			end

			if isDefault then
				Options.ThemeManager_ThemeList:SetValue(theme)
			else
				self:ApplyTheme(theme)
			end
		end

		function ThemeManager:SaveDefault(theme)
			writefile(self.Folder .. "/default.txt", theme)
		end

		function ThemeManager:CreateThemeManager(groupbox)
			groupbox
				:AddLabel("Background color")
				:AddColorPicker("BackgroundColor", { Default = self.Library.BackgroundColor })
			groupbox:AddLabel("Main color"):AddColorPicker("MainColor", { Default = self.Library.MainColor })
			groupbox:AddLabel("Accent color"):AddColorPicker("AccentColor", { Default = self.Library.AccentColor })
			groupbox:AddLabel("Outline color"):AddColorPicker("OutlineColor", { Default = self.Library.OutlineColor })
			groupbox:AddLabel("Font color"):AddColorPicker("FontColor", { Default = self.Library.FontColor })

			local ThemesArray = {}
			for Name, Theme in next, self.BuiltInThemes do
				table.insert(ThemesArray, Name)
			end

			table.sort(ThemesArray, function(a, b)
				return self.BuiltInThemes[a][1] < self.BuiltInThemes[b][1]
			end)

			groupbox:AddDivider()
			groupbox:AddDropdown("ThemeManager_ThemeList", { Text = "Theme list", Values = ThemesArray, Default = 1 })

			groupbox:AddButton("Set as default", function()
				self:SaveDefault(Options.ThemeManager_ThemeList.Value)
				self.Library:Notify(string.format("Set default theme to %q", Options.ThemeManager_ThemeList.Value))
			end)

			Options.ThemeManager_ThemeList:OnChanged(function()
				self:ApplyTheme(Options.ThemeManager_ThemeList.Value)
			end)

			groupbox:AddDivider()
			groupbox:AddInput("ThemeManager_CustomThemeName", { Text = "Custom theme name" })
			groupbox:AddDropdown(
				"ThemeManager_CustomThemeList",
				{ Text = "Custom themes", Values = self:ReloadCustomThemes(), AllowNull = true, Default = 1 }
			)
			groupbox:AddDivider()

			groupbox
				:AddButton("Save theme", function()
					self:SaveCustomTheme(Options.ThemeManager_CustomThemeName.Value)

					Options.ThemeManager_CustomThemeList:SetValues(self:ReloadCustomThemes())
					Options.ThemeManager_CustomThemeList:SetValue(nil)
				end)
				:AddButton("Load theme", function()
					self:ApplyTheme(Options.ThemeManager_CustomThemeList.Value)
				end)

			groupbox:AddButton("Refresh list", function()
				Options.ThemeManager_CustomThemeList:SetValues(self:ReloadCustomThemes())
				Options.ThemeManager_CustomThemeList:SetValue(nil)
			end)

			groupbox:AddButton("Set as default", function()
				if
					Options.ThemeManager_CustomThemeList.Value ~= nil
					and Options.ThemeManager_CustomThemeList.Value ~= ""
				then
					self:SaveDefault(Options.ThemeManager_CustomThemeList.Value)
					self.Library:Notify(
						string.format("Set default theme to %q", Options.ThemeManager_CustomThemeList.Value)
					)
				end
			end)

			ThemeManager:LoadDefault()

			local function UpdateTheme()
				self:ThemeUpdate()
			end

			Options.BackgroundColor:OnChanged(UpdateTheme)
			Options.MainColor:OnChanged(UpdateTheme)
			Options.AccentColor:OnChanged(UpdateTheme)
			Options.OutlineColor:OnChanged(UpdateTheme)
			Options.FontColor:OnChanged(UpdateTheme)
		end

		function ThemeManager:GetCustomTheme(file)
			local path = self.Folder .. "/" .. file
			if not isfile(path) then
				return nil
			end

			local data = readfile(path)
			local success, decoded = pcall(httpService.JSONDecode, httpService, data)

			if not success then
				return nil
			end

			return decoded
		end

		function ThemeManager:SaveCustomTheme(file)
			if file:gsub(" ", "") == "" then
				return self.Library:Notify("Invalid file name for theme (empty)", 3)
			end

			local theme = {}
			local fields = { "FontColor", "MainColor", "AccentColor", "BackgroundColor", "OutlineColor" }

			for _, field in next, fields do
				local option = Options[field]

				theme[field] = {
					type = "ColorPicker",
					hue = option.Hue,
					sat = option.Sat,
					vib = option.Vib,
					transparency = option.Transparency,
					rainbow = option.Rainbow,
				}
			end

			writefile(self.Folder .. "/" .. file .. ".json", httpService:JSONEncode(theme))
		end

		function ThemeManager:ReloadCustomThemes()
			local list = listfiles(self.Folder)

			local out = {}
			for i = 1, #list do
				local file = list[i]
				if file:sub(-5) == ".json" then
					-- i hate this but it has to be done ...

					local pos = file:find(".json", 1, true)
					local char = file:sub(pos, pos)

					while char ~= "/" and char ~= "\\" and char ~= "" do
						pos = pos - 1
						char = file:sub(pos, pos)
					end

					if char == "/" or char == "\\" then
						table.insert(out, file:sub(pos + 1))
					end
				end
			end

			return out
		end

		function ThemeManager:SetLibrary(lib)
			self.Library = lib
		end

		function ThemeManager:BuildFolderTree()
			makefolder(self.Folder)
		end

		function ThemeManager:SetFolder(folder)
			self.Folder = folder
			self:BuildFolderTree()
		end

		function ThemeManager:CreateGroupBox(tab)
			assert(self.Library, "Must set ThemeManager.Library first!")
			return tab:AddLeftGroupbox("Theme Manager")
		end

		function ThemeManager:ApplyToTab(tab)
			assert(self.Library, "Must set ThemeManager.Library first!")
			local groupbox = self:CreateGroupBox(tab)
			self:CreateThemeManager(groupbox)
		end

		function ThemeManager:ApplyToGroupbox(groupbox)
			assert(self.Library, "Must set ThemeManager.Library first!")
			self:CreateThemeManager(groupbox)
		end

		ThemeManager:BuildFolderTree()
	end

	return ThemeManager
end)()

end)
__bundle_register("Menu/ExploitTab", function(require, _LOADED, __bundle_register, __bundle_modules)
-- ExploitTab module.
local ExploitTab = {}

---@module Features.Game.Teleport
local Teleport = require("Features/Game/Teleport")

---Initialize Mob Exploits section.
---@param groupbox table
function ExploitTab.initMobExploitsSection(groupbox)
	local voidMobsToggle = groupbox:AddToggle("VoidMobs", {
		Text = "Void Mobs",
		Tooltip = "Teleport nearby mobs and send them to the void.",
		Default = false,
	})

	voidMobsToggle:AddKeyPicker("VoidMobsKeyBind", { Default = "N/A", SyncToggleState = true, Text = "Void Mobs" })
end

---Initialize Local Character Exploits section.
---@param groupbox table
function ExploitTab.initLocalCharacterExploitsSection(groupbox)
	local moveWhileKnockedToggle = groupbox:AddToggle("MoveWhileKnocked", {
		Text = "Move While Knocked",
		Tooltip = "Move your character while in a knocked down state.",
		Default = false,
	})

	moveWhileKnockedToggle:AddKeyPicker(
		"MoveWhileKnockedKeyBind",
		{ Default = "N/A", SyncToggleState = true, Text = "Move While Knocked" }
	)

	local pathfindBreakerToggle = groupbox:AddToggle("PathfindBreaker", {
		Text = "Pathfind Breaker",
		Tooltip = "Visibly break the pathfinding for humanoid mobs by attempting to spoof your vertical velocity.",
		Default = false,
	})

	pathfindBreakerToggle:AddKeyPicker(
		"PathfindBreakerKeyBind",
		{ Default = "N/A", SyncToggleState = true, Text = "Pathfind Breaker" }
	)

	local pbDepBox = groupbox:AddDependencyBox()

	pbDepBox:AddToggle("AggressiveMode", {
		Text = "Aggressive Mode",
		Tooltip = "Enable this to make the pathfinding breaker more aggressive by luring mobs towards you.",
		Default = false,
	})

	local pbHighlightToggle = pbDepBox:AddToggle("PathfindBreakerHighlight", {
		Text = "Show Highlight",
		Tooltip = "Because this feature can be very visible, you can enable a visual highlight to see if it is on.",
		Default = false,
	})

	pbHighlightToggle:AddColorPicker("PathfindBreakerHighlightColor", {
		Default = Color3.fromRGB(200, 0, 255),
		Text = "Highlight Color",
	})

	pbHighlightToggle:AddColorPicker("PathfindBreakerHighlightOutlineColor", {
		Default = Color3.fromRGB(255, 152, 234),
		Text = "Outline Color",
	})

	pbDepBox:SetupDependencies({
		{ pathfindBreakerToggle, true },
	})
end

---Add teleport button with disclaimer.
---@param groupbox table
---@param text string
---@param dest string
local function addTeleportButton(groupbox, text, dest)
	groupbox:AddButton({
		Text = text,
		Tooltip = "All teleports can bug out and cause death. They also may be very visible to other players.",
		DoubleClick = true,
		DoubleClickText = "Use at your own risk?",
		Func = function()
			Teleport.start(dest)
		end,
	})
end

---Initialize Teleports section.
---@param tabbox table
function ExploitTab.initTeleportsSection(tabbox)
	local teleportsTab = tabbox:AddTab("Teleports")
	local guildDoorTab = tabbox:AddTab("Guild Door")

	if game.PlaceId == 6032399813 then
		addTeleportButton(teleportsTab, "Teleport to Eastern Luminant", "EasternLuminant")
		addTeleportButton(teleportsTab, "Teleport to Trial Of One", "TrialOfOne")
	end

	if game.PlaceId == 6473861193 then
		addTeleportButton(teleportsTab, "Teleport to Etrean Luminant", "EtreanLuminant")
	end

	addTeleportButton(teleportsTab, "Teleport to Depths", "Depths")
	addTeleportButton(teleportsTab, "Teleport to Voidheart", "Voidheart")

	teleportsTab:AddButton("Stop Teleporting", Teleport.stop)

	guildDoorTab:AddInput("GuildDoorName", {
		Text = "Guild Door Name",
		Placeholder = "Exact or partial name of door.",
	})

	addTeleportButton(guildDoorTab, "Teleport To Guild Door", "GuildDoor")
end

---Initialize tab.
---@param window table
function ExploitTab.init(window)
	-- Create tab.
	local tab = window:AddTab("Exploit")

	-- Fetch realm information.
	local replicatedStorage = game:GetService("ReplicatedStorage")
	local info = replicatedStorage:WaitForChild("Info")
	local realmInfo = info:WaitForChild("RealmInfo")
	local realmInfoModule = require(realmInfo)
	local currentWorld = realmInfoModule.CurrentWorld or "N/A"

	-- Initialize sections.
	ExploitTab.initMobExploitsSection(tab:AddDynamicGroupbox("Mob Exploits"))
	ExploitTab.initLocalCharacterExploitsSection(tab:AddDynamicGroupbox("Local Character Exploits"))

	if currentWorld == "Depths" or currentWorld == "Mission" or currentWorld == "Dungeon" then
		return
	end

	ExploitTab.initTeleportsSection(tab:AddDynamicTabbox("Teleports"))
end

-- Return ExploitTab module.
return ExploitTab

end)
__bundle_register("Menu/VisualsTab", function(require, _LOADED, __bundle_register, __bundle_modules)
---@module Utility.Logger
local Logger = require("Utility/Logger")

---@module Utility.Configuration
local Configuration = require("Utility/Configuration")

---@module Features.Visuals.Visuals
local Visuals = require("Features/Visuals/Visuals")

---@module Utility.JSON
local JSON = require("Utility/JSON")

---@module Features.Visuals.Objects.BuilderData
local BuilderData = require("Features/Visuals/Objects/BuilderData")

-- Visuals tab.
local VisualsTab = {}

---Initialize ESP Customization section.
---@param groupbox table
function VisualsTab.initESPCustomization(groupbox)
	groupbox:AddSlider("FontSize", {
		Text = "ESP Font Size",
		Default = 16,
		Min = 4,
		Max = 24,
		Rounding = 0,
	})

	groupbox:AddSlider("ESPSplitLineLength", {
		Text = "ESP Split Line Length",
		Tooltip = "The total length of a ESP label line before it splits into a new line.",
		Default = 30,
		Min = 10,
		Max = 100,
		Rounding = 0,
	})

	local fonts = {}

	for _, font in next, Enum.Font:GetEnumItems() do
		if font == Enum.Font.Unknown then
			continue
		end

		table.insert(fonts, font.Name)
	end

	groupbox:AddDropdown("Font", { Text = "ESP Fonts", Default = 1, Values = fonts })
end

---Initialize ESP Optimizations section.
---@param groupbox table
function VisualsTab.initESPOptimizations(groupbox)
	groupbox:AddToggle("ESPLimitUpdates", {
		Text = "ESP Limit Updates",
		Tooltip = "Limit when ESP updates can happen in a given amount of frames.",
		Default = true,
	})

	local eluDepBox = groupbox:AddDependencyBox()

	eluDepBox:AddSlider("ESPRefreshRate", {
		Text = "ESP Refresh Rate",
		Tooltip = "The frames that the ESP will attempt to update in.",
		Suffix = "f",
		Default = 30,
		Min = 1,
		Max = 144,
		Rounding = 0,
	})

	eluDepBox:SetupDependencies({
		{ Toggles.ESPLimitUpdates, true },
	})

	groupbox:AddToggle("ESPSplitUpdates", {
		Text = "ESP Split Updates",
		Tooltip = "This is an optimization where the ESP will split updating the object pool into multiple frames.",
		Default = false,
	})

	local esuDepBox = groupbox:AddDependencyBox()

	esuDepBox:AddSlider("ESPSplitFrames", {
		Text = "ESP Split Frames",
		Tooltip = "How many frames we have to split the object pool into.",
		Suffix = "f",
		Default = 32,
		Min = 1,
		Max = 64,
		Rounding = 0,
	})

	esuDepBox:SetupDependencies({
		{ Toggles.ESPSplitUpdates, true },
	})

	groupbox:AddToggle("NoPersisentESP", {
		Text = "No Persistent ESP",
		Tooltip = "Disable ESP models from being persistent and never being streamed out.",
		Default = false,
	})
end

---Initialize World Visuals section.
---@param groupbox table
function VisualsTab.initWorldVisualsSection(groupbox)
	groupbox:AddToggle("ModifyFieldOfView", {
		Text = "Modify Field Of View",
		Default = false,
	})

	local fovDepBox = groupbox:AddDependencyBox()

	fovDepBox:AddSlider("FieldOfView", {
		Text = "Field Of View Slider",
		Default = 90,
		Min = 0,
		Max = 120,
		Suffix = "°",
		Rounding = 0,
	})

	fovDepBox:SetupDependencies({
		{ Toggles.ModifyFieldOfView, true },
	})

	local modifyAmbienceToggle = groupbox:AddToggle("ModifyAmbience", {
		Text = "Modify Ambience",
		Tooltip = "Modify the ambience of the game.",
		Default = false,
	})

	modifyAmbienceToggle:AddColorPicker("AmbienceColor", {
		Default = Color3.fromHex("FFFFFF"),
	})

	local oacDepBox = groupbox:AddDependencyBox()

	oacDepBox:AddToggle("OriginalAmbienceColor", {
		Text = "Original Ambience Color",
		Tooltip = "Use the game's original ambience color instead of a custom one.",
		Default = false,
	})

	local umacDepBox = oacDepBox:AddDependencyBox()

	umacDepBox:AddSlider("OriginalAmbienceColorBrightness", {
		Text = "Original Ambience Brightness",
		Default = 0,
		Min = 0,
		Max = 255,
		Suffix = "+",
		Rounding = 0,
	})

	oacDepBox:SetupDependencies({
		{ Toggles.ModifyAmbience, true },
	})

	umacDepBox:SetupDependencies({
		{ Toggles.OriginalAmbienceColor, true },
	})
end

---Initialize Visual Assistance section.
---@param groupbox table
function VisualsTab.initVisualAssistanceSection(groupbox)
	groupbox:AddToggle("ChainOfPerfectionTracker", {
		Text = "Chain Of Perfection Tracker",
		Tooltip = "Create a tracker marking how many stacks you have in your current Chain of Perfection.",
		Default = false,
	})

	groupbox:AddToggle("SanityTracker", {
		Text = "Sanity Tracker",
		Tooltip = "Create a tracker marking how much sanity you have left.",
		Default = false,
	})

	local buildAssistanceToggle = groupbox:AddToggle("BuildAssistance", {
		Text = "Build Assistance",
		Tooltip = "Visual assistance for selecting talents, progressing a build, and more.",
		Default = false,
	})

	local buildAssistanceDepBox = groupbox:AddDependencyBox()

	local sdoToggle = buildAssistanceDepBox:AddToggle("ShrineDetectionOverride", {
		Text = "Shrine Detection Override",
		Tooltip = "Auto-detection for shrine can be wrong especially when it refunds your points. You can use this to override the current state.",
		Default = true,
	})

	local sdoDepBox = buildAssistanceDepBox:AddDependencyBox()

	sdoDepBox:AddDropdown("ShrineOverrideState", {
		Text = "Shrine Override State",
		Tooltip = "The shrine state to override to.",
		Default = 1,
		Values = { "Pre-Shrine", "Post-Shrine", "Must Shrine" },
	})

	sdoDepBox:SetupDependencies({
		{ sdoToggle, true },
	})

	buildAssistanceDepBox:AddInput("BuildAssistanceLink", {
		Text = "Build Assistance Link",
		Tooltip = "The builder link that will be used to assist with builds.",
		Placeholder = "Enter your builder link here.",
		Finished = true,
		Callback = function(value)
			local dresponse = request({
				Url = "https://deepwoken.co/api/proxy?url=https://api.deepwoken.co/get?type=all",
				Method = "GET",
				Headers = { ["Content-Type"] = "application/json" },
			})

			if not dresponse or not dresponse.Success or not dresponse.Body then
				return Logger.notify("Invalid response while fetching data response.")
			end

			local dsuccess, dresult = pcall(JSON.decode, dresponse.Body)
			if not dsuccess or not dresult then
				return Logger.notify("JSON error '%s' while deserializing data response.", dresult)
			end

			Logger.notify("Successfully fetched Deepwoken data.")

			local id = value:gsub("https://deepwoken.co/builder%?id=", ""):gsub(" ", ""):gsub("\n", "")
			local bresponse = request({
				Url = ("https://deepwoken.co/api/proxy?url=https://api.deepwoken.co/build?id=%s"):format(id),
				Method = "GET",
				Headers = { ["Content-Type"] = "application/json" },
			})

			if not bresponse or not bresponse.Success or not bresponse.Body then
				return Logger.notify("Invalid response while fetching builder response.")
			end

			local bsuccess, bresult = pcall(JSON.decode, bresponse.Body)
			if not bsuccess or not bresult then
				return Logger.notify("JSON error '%s' while deserializing builder response.", bresult)
			end

			Logger.notify("Successfully created BuilderData object.")

			Visuals.bdata = BuilderData.new(bresult, dresult)
		end,
	})

	buildAssistanceDepBox:SetupDependencies({
		{ buildAssistanceToggle, true },
	})
end

---Initialize Visual Removals section.
---@param groupbox table
function VisualsTab.initVisualRemovalsSection(groupbox)
	groupbox:AddToggle("NoFog", {
		Text = "No Fog",
		Tooltip = "Atmosphere and Fog effects are hidden.",
		Default = false,
	})

	groupbox:AddToggle("NoBlind", {
		Text = "No Blind",
		Tooltip = "Blinding effects are hidden.",
		Default = false,
	})

	groupbox:AddToggle("NoBlur", {
		Text = "No Blur",
		Tooltip = "Blurry effects are hidden.",
		Default = false,
	})

	groupbox:AddToggle("NoShadows", {
		Text = "No Shadows",
		Tooltip = "Shadow effects are hidden.",
		Default = false,
	})

	groupbox:AddToggle("NoAnimatedSea", {
		Text = "No Animated Sea",
		Tooltip = "Disable the script(s) that animate the sea.",
		Default = false,
	})
end

---Initialize Base ESP section.
---@note: Every ESP object has access to these options.
---@param identifier string
---@param groupbox table
---@return string, table
function VisualsTab.initBaseESPSection(identifier, groupbox)
	local enableToggle = groupbox
		:AddToggle(Configuration.identify(identifier, "Enable"), {
			Text = "Enable ESP",
			Default = false,
		})
		:AddKeyPicker(Configuration.identify(identifier, "Keybind"), {
			Default = "N/A",
			SyncToggleState = true,
			NoUI = true,
			Text = groupbox.Name,
		})

	enableToggle:AddColorPicker(Configuration.identify(identifier, "Color"), {
		Default = Color3.new(1, 1, 1),
	})

	local enableDepBox = groupbox:AddDependencyBox()

	enableDepBox:AddToggle(Configuration.identify(identifier, "ShowDistance"), {
		Text = "Show Distance",
		Default = false,
	})

	enableDepBox:AddSlider(Configuration.identify(identifier, "MaxDistance"), {
		Text = "Distance Threshold",
		Tooltip = "If the distance is greater than this value, the ESP object will not be shown.",
		Default = 2000,
		Min = 0,
		Max = 100000,
		Suffix = "studs",
		Rounding = 0,
	})

	enableDepBox:SetupDependencies({
		{ enableToggle, true },
	})

	return identifier, enableDepBox
end

---Add Chest ESP section.
---@param identifier string
---@param depbox table
---@return string, table
function VisualsTab.addChestESP(identifier, depbox)
	depbox:AddToggle(Configuration.identify(identifier, "HideIfOpened"), {
		Text = "Hide If Opened",
		Default = false,
	})

	return identifier, depbox
end

---Add Obelisk ESP section.
---@param identifier string
---@param depbox table
---@return string, table
function VisualsTab.addObeliskESP(identifier, depbox)
	depbox:AddToggle(Configuration.identify(identifier, "HideIfTurnedOn"), {
		Text = "Hide If Turned On",
		Default = false,
	})

	return identifier, depbox
end

---Add Bone Altar ESP section.
---@param identifier string
---@param depbox table
---@return string, table
function VisualsTab.addBoneAltarESP(identifier, depbox)
	depbox:AddToggle(Configuration.identify(identifier, "HideIfBoneInside"), {
		Text = "Hide If Bone Inside",
		Default = false,
	})

	return identifier, depbox
end

---Add Entity ESP section.
---@param identifier string
---@param depbox table
---@return string, table
function VisualsTab.addEntityESP(identifier, depbox)
	local hbToggle = depbox:AddToggle(Configuration.identify(identifier, "HealthBar"), {
		Text = "Show Health Bar",
		Default = false,
	})

	hbToggle:AddColorPicker(Configuration.identify(identifier, "FullColor"), {
		Default = Color3.new(0, 1, 0),
	})

	hbToggle:AddColorPicker(Configuration.identify(identifier, "EmptyColor"), {
		Default = Color3.new(1, 0, 0),
	})

	depbox:AddToggle(Configuration.identify(identifier, "BoundingBox"), {
		Text = "Show Bounding Box",
		Default = false,
	})

	depbox:AddToggle(Configuration.identify(identifier, "ShowHealthChanges"), {
		Text = "Show Health Changes",
		Default = false,
	})

	return identifier, depbox
end

---Add Player ESP section.
---@param identifier string
---@param depbox table
---@return string, table
function VisualsTab.addPlayerESP(identifier, depbox)
	local markAlliesToggle = depbox:AddToggle(Configuration.identify(identifier, "MarkAllies"), {
		Text = "Mark Allies",
		Default = false,
	})

	markAlliesToggle:AddColorPicker(Configuration.identify(identifier, "AllyColor"), {
		Default = Color3.new(1, 1, 1),
	})

	local maDepBox = depbox:AddDependencyBox()

	maDepBox
		:AddToggle(Configuration.identify(identifier, "HideIfAlly"), {
			Text = "Hide Allies On ESP",
			Default = false,
		})
		:AddKeyPicker(Configuration.identify(identifier, "HideIfAllyKeybind"), {
			Default = "N/A",
			SyncToggleState = true,
			NoUI = true,
			Text = "Hide Allies On ESP",
		})

	maDepBox:SetupDependencies({
		{ markAlliesToggle, true },
	})

	local markSackToggle = depbox:AddToggle(Configuration.identify(identifier, "MarkSackUsers"), {
		Text = "Mark Users Holding Sack",
		Default = false,
	})

	markSackToggle:AddColorPicker(Configuration.identify(identifier, "SackColor"), {
		Default = Color3.new(1, 1, 1),
	})

	local markOathToggle = depbox:AddToggle(Configuration.identify(identifier, "MarkOathUsers"), {
		Text = "Mark Oath Users",
		Default = false,
	})

	markOathToggle:AddColorPicker(Configuration.identify(identifier, "OathColor"), {
		Default = Color3.new(1, 1, 1),
	})

	depbox:AddToggle(Configuration.identify(identifier, "ShowHealthComparison"), {
		Text = "Show Health Comparison",
		Default = false,
	})

	depbox:AddToggle(Configuration.identify(identifier, "ShowDangerTime"), {
		Text = "Show Danger Time",
		Default = false,
	})

	local armorBar = depbox:AddToggle(Configuration.identify(identifier, "ArmorBar"), {
		Text = "Show Armor Bar",
		Default = false,
	})

	armorBar:AddColorPicker(Configuration.identify(identifier, "ArmorBarColor"), {
		Default = Color3.new(0.388235, 0.686274, 0.984313),
	})

	local bloodBar = depbox:AddToggle(Configuration.identify(identifier, "BloodBar"), {
		Text = "Show Blood Bar",
		Default = false,
	})

	bloodBar:AddColorPicker(Configuration.identify(identifier, "BloodBarColor"), {
		Default = Color3.new(0.8, 0, 0),
	})

	local sanityBar = depbox:AddToggle(Configuration.identify(identifier, "SanityBar"), {
		Text = "Show Sanity Bar",
		Default = false,
	})

	sanityBar:AddColorPicker(Configuration.identify(identifier, "SanityBarColor"), {
		Default = Color3.new(0.6, 0, 0.8),
	})

	local tempoBar = depbox:AddToggle(Configuration.identify(identifier, "TempoBar"), {
		Text = "Show Tempo Bar",
		Default = false,
	})

	tempoBar:AddColorPicker(Configuration.identify(identifier, "TempoBarColor"), {
		Default = Color3.new(0, 1, 1),
	})

	local postureBar = depbox:AddToggle(Configuration.identify(identifier, "PostureBar"), {
		Text = "Show Posture Bar",
		Default = false,
	})

	postureBar:AddColorPicker(Configuration.identify(identifier, "PostureBarColor"), {
		Default = Color3.new(1, 0.8, 0),
	})

	depbox:AddDropdown(Configuration.identify(identifier, "PlayerNameType"), {
		Text = "Player Name Type",
		Default = 1,
		Values = { "Character Name", "Roblox Display Name", "Roblox Username" },
	})

	return identifier, depbox
end

---Add Filtered ESP section.
---@param identifier string
---@param depbox table
---@return string, table
function VisualsTab.addFilterESP(identifier, depbox)
	local filterObjectsToggle = depbox:AddToggle(Configuration.identify(identifier, "FilterObjects"), {
		Text = "Filter Objects",
		Default = false,
	})

	local foDepBox = depbox:AddDependencyBox()

	local filterLabelList = foDepBox:AddDropdown(Configuration.identify(identifier, "FilterLabelList"), {
		Text = "Filter Label List",
		Default = {},
		SaveValues = true,
		Multi = true,
		Values = {},
	})

	local filterLabel = foDepBox:AddInput(Configuration.identify(identifier, "FilterLabel"), {
		Text = "Filter Label",
		Placeholder = "Partial or exact object label.",
	})

	foDepBox:AddDropdown(Configuration.identify(identifier, "FilterLabelListType"), {
		Text = "Filter List Type",
		Default = 1,
		Values = { "Hide Labels Out Of List", "Hide Labels In List" },
	})

	foDepBox:AddButton("Add Name To Filter", function()
		local filterLabelValue = filterLabel.Value

		if #filterLabelValue <= 0 then
			return Logger.notify("Please enter a valid filter name.")
		end

		local filterLabelListValues = filterLabelList.Values

		if not table.find(filterLabelListValues, filterLabelValue) then
			table.insert(filterLabelListValues, filterLabelValue)
		end

		filterLabelList:SetValues(filterLabelListValues)
		filterLabelList:SetValue({})
		filterLabelList:Display()
	end)

	foDepBox:AddButton("Remove Selected Names", function()
		local filterLabelListValues = filterLabelList.Values
		local selectedFilterNames = filterLabelList.Value

		for selectedFilterName, _ in next, selectedFilterNames do
			local selectedIndex = table.find(filterLabelListValues, selectedFilterName)
			if not selectedIndex then
				return Logger.notify("The selected filter name %s does not exist in the list", selectedFilterName)
			end

			table.remove(filterLabelListValues, selectedIndex)
		end

		filterLabelList:SetValues(filterLabelListValues)
		filterLabelList:SetValue({})
		filterLabelList:Display()
	end)

	foDepBox:SetupDependencies({
		{ filterObjectsToggle, true },
	})

	return identifier, depbox
end

---Initialize tab.
---@param window table
function VisualsTab.init(window)
	-- Create tab.
	local tab = window:AddTab("Visuals")

	-- Initialize sections.
	VisualsTab.initESPCustomization(tab:AddDynamicGroupbox("ESP Customization"))
	VisualsTab.initESPOptimizations(tab:AddDynamicGroupbox("ESP Optimizations"))
	VisualsTab.initWorldVisualsSection(tab:AddDynamicGroupbox("World Visuals"))
	VisualsTab.initVisualRemovalsSection(tab:AddDynamicGroupbox("Visual Removals"))
	VisualsTab.initVisualAssistanceSection(tab:AddDynamicGroupbox("Visual Assistance"))

	-- Player ESP.
	VisualsTab.addPlayerESP(
		VisualsTab.addEntityESP(VisualsTab.initBaseESPSection("Player", tab:AddDynamicGroupbox("Player ESP")))
	)

	-- Mob ESP.
	VisualsTab.addFilterESP(
		VisualsTab.addEntityESP(VisualsTab.initBaseESPSection("Mob", tab:AddDynamicGroupbox("Mob ESP")))
	)

	-- Other ESPs.
	VisualsTab.initBaseESPSection("NPC", tab:AddDynamicGroupbox("NPC ESP"))
	VisualsTab.addChestESP(VisualsTab.initBaseESPSection("Chest", tab:AddDynamicGroupbox("Chest ESP")))
	VisualsTab.initBaseESPSection("BagDrop", tab:AddDynamicGroupbox("Bag ESP"))
	VisualsTab.addFilterESP(VisualsTab.initBaseESPSection("AreaMarker", tab:AddDynamicGroupbox("Area Marker ESP")))
	VisualsTab.initBaseESPSection("VOIBoundaryESP", tab:AddDynamicGroupbox("VOI Boundary ESP"))
	VisualsTab.initBaseESPSection("VOIWeaponESP", tab:AddDynamicGroupbox("VOI Weapon ESP"))
	VisualsTab.initBaseESPSection("ShopESP", tab:AddDynamicGroupbox("Shop ESP"))
	VisualsTab.initBaseESPSection("JobBoard", tab:AddDynamicGroupbox("Job Board ESP"))
	VisualsTab.initBaseESPSection("Artifact", tab:AddDynamicGroupbox("Artifact ESP"))
	VisualsTab.initBaseESPSection("WindrunnerOrb", tab:AddDynamicGroupbox("Windrunner Orb ESP"))
	VisualsTab.initBaseESPSection("Whirlpool", tab:AddDynamicGroupbox("Whirlpool ESP"))
	VisualsTab.initBaseESPSection("ExplosiveBarrel", tab:AddDynamicGroupbox("Explosive Barrel ESP"))
	VisualsTab.initBaseESPSection("MinistryCacheIndicator", tab:AddDynamicGroupbox("Ministry Cache ESP"))
	VisualsTab.initBaseESPSection("OwlFeathers", tab:AddDynamicGroupbox("Owl Feathers ESP"))
	VisualsTab.initBaseESPSection("GuildDoor", tab:AddDynamicGroupbox("Guild Door ESP"))
	VisualsTab.initBaseESPSection("GuildBanner", tab:AddDynamicGroupbox("Guild Banner ESP"))
	VisualsTab.addObeliskESP(VisualsTab.initBaseESPSection("Obelisk", tab:AddDynamicGroupbox("Obelisk ESP")))
	VisualsTab.addBoneAltarESP(VisualsTab.initBaseESPSection("BoneAltar", tab:AddDynamicGroupbox("Bone Altar ESP")))
	VisualsTab.addFilterESP(VisualsTab.initBaseESPSection("Ingredient", tab:AddDynamicGroupbox("Ingredient ESP")))
	VisualsTab.initBaseESPSection("BoneSpear", tab:AddDynamicGroupbox("Bone Spear ESP"))
	VisualsTab.initBaseESPSection("ArmorBrick", tab:AddDynamicGroupbox("Armor Brick ESP"))
	VisualsTab.initBaseESPSection("BellMeteor", tab:AddDynamicGroupbox("Bell Meteor ESP"))
	VisualsTab.initBaseESPSection("RareObelisk", tab:AddDynamicGroupbox("Rare Obelisk ESP"))
	VisualsTab.initBaseESPSection("HealBrick", tab:AddDynamicGroupbox("Heal Brick ESP"))
	VisualsTab.initBaseESPSection("MantraObelisk", tab:AddDynamicGroupbox("Mantra Obelisk ESP"))
	VisualsTab.initBaseESPSection("BRWeapon", tab:AddDynamicGroupbox("BR Weapon ESP"))
	VisualsTab.initBaseESPSection("BellKey", tab:AddDynamicGroupbox("Bell Key ESP"))
end

-- Return VisualsTab module.
return VisualsTab

end)
__bundle_register("Features/Visuals/Objects/BuilderData", function(require, _LOADED, __bundle_register, __bundle_modules)
---@module Features.Visuals.Objects.DeepwokenData
local DeepwokenData = require("Features/Visuals/Objects/DeepwokenData")

---@module Features.Visuals.Objects.AttributeData
local AttributeData = require("Features/Visuals/Objects/AttributeData")

---@module Utility.Configuration
local Configuration = require("Utility/Configuration")

---@class BuilderData
---@field ddata DeepwokenData
---@field talents string[]
---@field mantras string[]
---@field pre AttributeData
---@field post AttributeData
---@field traits table<string, number>
local BuilderData = {}
BuilderData.__index = BuilderData

---Fetch attributes based on data replicated info.
---@param drinfo table
---@return AttributeData
function BuilderData:attributes(drinfo)
	return (self:ipre(drinfo) == 0) and self.pre or self.post
end

---Calculate whether or not we are in the pre-shrine state. Zero if pre-shrine, one if post-shrine. Two if we must shrine.
---@param drinfo table
---@return number
function BuilderData:ipre(drinfo)
	local currentInvestedPoints = 0

	for idx, value in next, drinfo do
		if typeof(idx) ~= "string" or not idx:match("Stat") then
			continue
		end

		if typeof(value) ~= "number" then
			continue
		end

		currentInvestedPoints = currentInvestedPoints + value
	end

	local pointsToGetToShrine = self.pre:points()
	local shrineOverrideState = Configuration.expectOptionValue("ShrineOverrideState")

	if not Configuration.expectToggleValue("ShrineDetectionOverride") then
		shrineOverrideState = nil
	end

	if shrineOverrideState == "Pre-Shrine" then
		return 0
	end

	if shrineOverrideState == "Post-Shrine" then
		return 1
	end

	if shrineOverrideState == "Must Shrine" then
		return 2
	end

	if not self:dshrine() then
		return 1
	end

	if currentInvestedPoints < pointsToGetToShrine then
		return 0
	end

	if currentInvestedPoints == pointsToGetToShrine then
		return 2
	end

	return 1
end

---Did the builder data even shrine of order at all?
---@note: No specific tag, but if they did not shrine of order, then post and pre are the same.
---@return boolean
function BuilderData:dshrine()
	return not self.pre:compare(self.post)
end

---Load from partial values.
---@param values table
function BuilderData:load(values)
	if typeof(values.talents) == "table" then
		self.talents = values.talents
	end

	if typeof(values.mantras) == "table" then
		self.mantras = values.mantras
	end

	-- Replace mapping(s) if they have tags to ones without brackets.
	for idx, talent in next, self.talents do
		local cleaned = talent:gsub("%s*%[.-%]$", "")

		if cleaned ~= talent then
			self.talents[idx] = cleaned
		end
	end

	for idx, mantra in next, self.mantras do
		local cleaned = mantra:gsub("%s*%[.-%]$", "")

		if cleaned ~= mantra then
			self.mantras[idx] = cleaned
		end
	end

	if typeof(values.preShrine) == "table" then
		self.pre:load(values.preShrine)
	end

	if typeof(values.attributes) == "table" then
		self.post:load(values.attributes)
	end

	local stats = values.stats

	if typeof(stats) ~= "table" then
		return
	end

	local traits = stats.traits

	if typeof(traits) ~= "table" then
		return
	end

	self.traits["Vitality"] = traits["Vitality"] or 0
	self.traits["Erudition"] = traits["Erudition"] or 0
	self.traits["Proficiency"] = traits["Proficiency"] or 0
	self.traits["Songchant"] = traits["Songchant"] or 0
end

---Create new BuilderData object.
---@param bvalues table?
---@param dvalues table?
---@return BuilderData
function BuilderData.new(bvalues, dvalues)
	local self = setmetatable({}, BuilderData)

	self.ddata = DeepwokenData.new(dvalues)
	self.talents = {}
	self.mantras = {}
	self.pre = AttributeData.new()
	self.post = AttributeData.new()
	self.traits = {
		["Vitality"] = 0,
		["Erudition"] = 0,
		["Proficiency"] = 0,
		["Songchant"] = 0,
	}

	if bvalues then
		self:load(bvalues)
	end

	return self
end

-- Return BuilderData module.
return BuilderData

end)
__bundle_register("Features/Visuals/Objects/AttributeData", function(require, _LOADED, __bundle_register, __bundle_modules)
---@class AttributeData
---@field weapon table<string, number>
---@field attunement table<string, number>
---@field base table<string, number>
local AttributeData = {}
AttributeData.__index = AttributeData

---Is it possible to meet the requirements for a specific talent or mantra?
---@note: Expects the data to be formatted correctly from DeepwokenData
---@param reqs table
---@return boolean
function AttributeData:possible(reqs)
	local mind = math.max(self.base["Intelligence"], self.base["Willpower"], self.base["Charisma"])
	local body = math.max(self.base["Strength"], self.base["Fortitude"], self.base["Agility"])

	for idx, value in pairs(reqs) do
		if self.weapon[idx] and self.weapon[idx] < value then
			return false
		end

		if self.attunement[idx] and self.attunement[idx] < value then
			return false
		end

		if self.base[idx] and self.base[idx] < value then
			return false
		end

		if idx == "Mind" and mind < value then
			return false
		end

		if idx == "Body" and body < value then
			return false
		end
	end

	return true
end

---Tally up attribute points.
---@return number
function AttributeData:points()
	local points = 0

	for _, value in pairs(self.weapon) do
		points = points + value
	end

	for _, value in pairs(self.attunement) do
		points = points + value
	end

	for _, value in pairs(self.base) do
		points = points + value
	end

	return points
end

---Compare to another AttributeData object.
---@param other AttributeData
function AttributeData:compare(other)
	for idx, value in pairs(self.weapon) do
		if other.weapon[idx] == value then
			continue
		end

		return false
	end

	for idx, value in pairs(self.attunement) do
		if other.attunement[idx] == value then
			continue
		end

		return false
	end

	for idx, value in pairs(self.base) do
		if other.base[idx] == value then
			continue
		end

		return false
	end

	return true
end

---Load from partial values.
---@param values table
function AttributeData:load(values)
	if typeof(values.weapon) == "table" then
		self.weapon = values.weapon
	end

	if typeof(values.attunement) == "table" then
		self.attunement = values.attunement
	end

	if typeof(values.base) == "table" then
		self.base = values.base
	end
end

---Create new AttributeData object.
---@param values table?
---@return AttributeData
function AttributeData.new(values)
	local self = setmetatable({}, AttributeData)

	self.weapon = {}
	self.attunement = {}
	self.base = {}

	if values then
		self:load(values)
	end

	return self
end

--- Return AttributeData module.
return AttributeData

end)
__bundle_register("Features/Visuals/Objects/DeepwokenData", function(require, _LOADED, __bundle_register, __bundle_modules)
---@class DeepwokenData
---@field talents table
---@field mantras table
local DeepwokenData = {}
DeepwokenData.__index = DeepwokenData

---Get data for a specific talent or mantra.
---@param name string
function DeepwokenData:get(name)
	return self.talents[string.lower(name)] or self.mantras[string.lower(name)]
end

---Are we able to get a specified talent or mantra with the passed in attribute data?
---@param name string
---@param adata AttributeData
---@return boolean
function DeepwokenData:possible(name, adata)
	local data = self:get(name)
	if not data then
		return false
	end

	local reqs = data.reqs
	if not reqs then
		return false
	end

	---@note: Format this table for clean requirement parsing
	local formatted = {}

	for idx, value in pairs(reqs.base) do
		formatted[idx] = value
	end

	for idx, value in pairs(reqs.weapon) do
		formatted[idx] = value
	end

	for idx, value in pairs(reqs.attunement) do
		formatted[idx] = value
	end

	return adata:possible(formatted)
end

---Load from partial values.
---@param values table
function DeepwokenData:load(values)
	if typeof(values.talents) == "table" then
		self.talents = values.talents
	end

	if typeof(values.mantras) == "table" then
		self.mantras = values.mantras
	end
end

---Create new DeepwokenData object.
---@param values table?
---@return DeepwokenData
function DeepwokenData.new(values)
	local self = setmetatable({}, DeepwokenData)

	self.talents = {}
	self.mantras = {}

	if values then
		self:load(values)
	end

	return self
end

-- Return DeepwokenData module.
return DeepwokenData

end)
__bundle_register("Menu/BuilderTab", function(require, _LOADED, __bundle_register, __bundle_modules)
---@module Game.Timings.SaveManager
local SaveManager = require("Game/Timings/SaveManager")

---@module Menu.Objects.AnimationBuilderSection
local AnimationBuilderSection = require("Menu/Objects/AnimationBuilderSection")

---@module Menu.Objects.SoundBuilderSection
local SoundBuilderSection = require("Menu/Objects/SoundBuilderSection")

---@module Menu.Objects.EffectBuilderSection
local EffectBuilderSection = require("Menu/Objects/EffectBuilderSection")

---@module Menu.Objects.PartBuilderSection
local PartBuilderSection = require("Menu/Objects/PartBuilderSection")

---@module Game.Timings.AnimationTiming
local AnimationTiming = require("Game/Timings/AnimationTiming")

---@module Game.Timings.EffectTiming
local EffectTiming = require("Game/Timings/EffectTiming")

---@module Game.Timings.PartTiming
local PartTiming = require("Game/Timings/PartTiming")

---@module Game.Timings.SoundTiming
local SoundTiming = require("Game/Timings/SoundTiming")

---@module Game.Timings.ModuleManager
local ModuleManager = require("Game/Timings/ModuleManager")

---@module Features.Game.AnimationVisualizer
local AnimationVisualizer = require("Features/Game/AnimationVisualizer")

---@module GUI.Library
local Library = require("GUI/Library")

---@module Utility.Maid
local Maid = require("Utility/Maid")

---@module Utility.Signal
local Signal = require("Utility/Signal")

---@module Utility.Configuration
local Configuration = require("Utility/Configuration")

---@module Utility.InstanceWrapper
local InstanceWrapper = require("Utility/InstanceWrapper")

-- Services.
local runService = game:GetService("RunService")
local players = game:GetService("Players")

-- Simulation state.
local builderMaid = Maid.new()
local simulationMaid = Maid.new()

local function runSimulationStep()
	if not Configuration.expectToggleValue("ShowHitboxSimulation") then
		return simulationMaid:clean()
	end

	local character = players.LocalPlayer.Character
	if not character then
		return
	end

	local root = character:FindFirstChild("HumanoidRootPart")
	if not root then
		return
	end

	local type = Configuration.expectOptionValue("HS_HitboxType") or "Block"
	local size = Vector3.new(
		Configuration.expectOptionValue("HS_HitboxSizeX") or 4,
		Configuration.expectOptionValue("HS_HitboxSizeY") or 4,
		Configuration.expectOptionValue("HS_HitboxSizeZ") or 4
	)

	local fd = Configuration.expectToggleValue("HS_FacingOffset")
	local soffset = Configuration.expectOptionValue("HS_ShiftOffset") or 0
	local cframe = root.CFrame

	-- Calculate CFrame.
	local usedCFrame = cframe

	if fd then
		usedCFrame = usedCFrame * CFrame.new(0, 0, -(size.Z / 2))
	end

	if soffset and soffset ~= 0 then
		usedCFrame = usedCFrame * CFrame.new(0, 0, soffset)
	end

	-- Visualize.
	local simulationPart = InstanceWrapper.create(simulationMaid, "SimulationPart", "Part", workspace)
	simulationPart.Anchored = true
	simulationPart.CanCollide = false
	simulationPart.CanQuery = false
	simulationPart.Size = size
	simulationPart.CanTouch = false
	simulationPart.Material = Enum.Material.ForceField
	simulationPart.CastShadow = false
	simulationPart.Transparency = 0.5
	simulationPart.Parent = workspace

	if type == "Block" then
		simulationPart.Shape = Enum.PartType.Block
		simulationPart.CFrame = usedCFrame
	elseif type == "Ball" then
		simulationPart.Shape = Enum.PartType.Ball
		simulationPart.CFrame = usedCFrame
	elseif type == "Cylinder" then
		simulationPart.Shape = Enum.PartType.Cylinder
		simulationPart.CFrame = usedCFrame * CFrame.Angles(0, 0, math.rad(90))
	end

	-- Detection.
	local instances = {}
	local live = workspace:WaitForChild("Live")

	for _, child in next, live:GetChildren() do
		if child == character then
			continue
		end

		instances[#instances + 1] = child
	end

	local overlapParams = OverlapParams.new()
	overlapParams.FilterDescendantsInstances = instances
	overlapParams.FilterType = Enum.RaycastFilterType.Include

	local parts = workspace:GetPartsInPart(simulationPart, overlapParams)

	if #parts > 0 then
		simulationPart.Color = Color3.fromRGB(0, 255, 0)
	else
		simulationPart.Color = Color3.fromRGB(255, 0, 0)
	end
end

-- BuilderTab module.
local BuilderTab = {
	abs = nil,
	ebs = nil,
	pbs = nil,
	sbs = nil,
}

---Refresh builder lists.
function BuilderTab.refresh()
	if BuilderTab.abs then
		BuilderTab.abs:reset()
		BuilderTab.abs:refresh()
	end

	if BuilderTab.ebs then
		BuilderTab.ebs:reset()
		BuilderTab.ebs:refresh()
	end

	if BuilderTab.pbs then
		BuilderTab.pbs:reset()
		BuilderTab.pbs:refresh()
	end

	if BuilderTab.sbs then
		BuilderTab.sbs:reset()
		BuilderTab.sbs:refresh()
	end
end

---Initialize save manager section.
---@param groupbox table
function BuilderTab.initSaveManagerSection(groupbox)
	local pasToggle = groupbox:AddToggle("PeriodicAutoSave", {
		Text = "Auto Save Periodically",
		Default = true,
	})

	local pasDepBox = groupbox:AddDependencyBox()

	pasDepBox:AddSlider("PeriodicAutoSaveInterval", {
		Text = "Auto Save Interval",
		Min = 1,
		Max = 240,
		Rounding = 0,
		Suffix = "s",
		Default = 60,
	})

	pasDepBox:SetupDependencies({
		{ pasToggle, true },
	})

	local configName = groupbox:AddInput("ConfigName", {
		Text = "Config Name",
	})

	local configList = groupbox:AddDropdown("ConfigList", {
		Text = "Config List",
		Values = SaveManager.list(),
		AllowNull = true,
	})

	groupbox
		:AddButton("Create Config", function()
			SaveManager.create(configName.Value)
			SaveManager.refresh(configList)
		end)
		:AddButton({
			Text = "Load Config",
			DoubleClick = true,
			Func = function()
				SaveManager.load(configList.Value)
				BuilderTab.refresh()
			end,
		})

	groupbox:AddButton({
		Text = "Overwrite Config",
		DoubleClick = true,
		Func = function()
			SaveManager.save(configList.Value)
		end,
	})

	groupbox:AddButton({
		Text = "Clear Config",
		DoubleClick = true,
		Func = function()
			SaveManager.clear(configList.Value)
		end,
	})

	groupbox:AddButton("Refresh List", function()
		SaveManager.refresh(configList)

		if Options.MergeConfigList then
			SaveManager.refresh(Options.MergeConfigList)
		end

		BuilderTab.refresh()
	end)

	groupbox:AddButton("Set To Auto Load", function()
		SaveManager.autoload(configList.Value)
	end)
end

---Initialize logger section.
---@param groupbox table
function BuilderTab.initLoggerSection(groupbox)
	local animVisualizerToggle = groupbox:AddToggle("ShowAnimationVisualizer", {
		Text = "Show Animation Visualizer",
		Default = false,
		Callback = AnimationVisualizer.visible,
	})

	animVisualizerToggle:AddKeyPicker(
		"AnimationVisualizerKeyBind",
		{ Default = "N/A", SyncToggleState = true, Text = "Animation Visualizer" }
	)

	local showLoggerToggle = groupbox:AddToggle("ShowLoggerWindow", {
		Text = "Show Logger Window",
		Default = false,
		Callback = function(value)
			Library.InfoLoggerFrame.Visible = value
		end,
	})

	showLoggerToggle:AddKeyPicker(
		"ShowLoggerWindowKeyBind",
		{ Default = "N/A", SyncToggleState = true, Text = "Logger Window" }
	)

	groupbox:AddSlider("MinimumLoggerDistance", {
		Text = "Minimum Logger Distance",
		Min = 0,
		Max = 100,
		Rounding = 0,
		Suffix = "m",
		Default = 0,
	})

	groupbox:AddSlider("MaximumLoggerDistance", {
		Text = "Maximum Logger Distance",
		Min = 0,
		Max = 1000,
		Rounding = 0,
		Suffix = "m",
		Default = 0,
	})

	local blacklistedKeys = groupbox:AddDropdown("BlacklistedKeys", {
		Text = "Blacklisted Keys",
		Default = {},
		Values = Library:KeyBlacklists(),
		Multi = true,
	})

	groupbox:AddButton("Remove Selected Keys", function()
		for selected, _ in next, blacklistedKeys.Value do
			Library.InfoLoggerData.KeyBlacklistList[selected] = nil
		end

		blacklistedKeys:SetValues(Library:KeyBlacklists())
		blacklistedKeys:SetValue({})
		blacklistedKeys:Display()
	end)
end

---Initialize Module Manager section.
---@param groupbox table
function BuilderTab.initModuleManagerSection(groupbox)
	local moduleList = groupbox:AddDropdown("ModuleList", {
		Text = "Module List",
		Values = ModuleManager.loaded(),
		AllowNull = true,
		Multi = false,
	})

	groupbox:AddButton("Refresh List", function()
		-- Refresh manager.
		ModuleManager.refresh()

		-- Set loaded modules.
		moduleList:SetValues(ModuleManager.loaded())
		moduleList:SetValue(nil)
		moduleList:Display()
	end)
end

---Initialize Hitbox Simulation section.
---@param groupbox table
function BuilderTab.initHitboxSimulationSection(groupbox)
	groupbox:AddToggle("ShowHitboxSimulation", {
		Text = "Show Hitbox Simulation",
		Default = false,
	})

	groupbox:AddDropdown("HS_HitboxType", {
		Text = "Hitbox Type",
		Values = { "Block", "Ball", "Cylinder" },
		Default = "Block",
	})

	groupbox:AddSlider("HS_HitboxSizeX", {
		Text = "Hitbox Size X",
		Min = 0.1,
		Max = 100,
		Default = 4,
		Rounding = 1,
	})

	groupbox:AddSlider("HS_HitboxSizeY", {
		Text = "Hitbox Size Y",
		Min = 0.1,
		Max = 100,
		Default = 4,
		Rounding = 1,
	})

	groupbox:AddSlider("HS_HitboxSizeZ", {
		Text = "Hitbox Size Z",
		Min = 0.1,
		Max = 100,
		Default = 4,
		Rounding = 1,
	})

	groupbox:AddToggle("HS_FacingOffset", {
		Text = "Hitbox Facing Offset",
		Default = false,
	})

	groupbox:AddSlider("HS_ShiftOffset", {
		Text = "Hitbox Shift Offset",
		Min = -10,
		Max = 10,
		Default = 0,
		Rounding = 1,
	})
end

---Initialize tab.
---@param window table
function BuilderTab.init(window)
	-- Create tab.
	local tab = window:AddTab("Builder")

	-- Initialize sections.
	BuilderTab.initSaveManagerSection(tab:AddDynamicGroupbox("Save Manager"))
	BuilderTab.initModuleManagerSection(tab:AddDynamicGroupbox("Module Manager"))
	BuilderTab.initLoggerSection(tab:AddDynamicGroupbox("Logger"))
	BuilderTab.initHitboxSimulationSection(tab:AddDynamicGroupbox("Hitbox Simulation"))

	-- Create builder sections.
	BuilderTab.abs =
		AnimationBuilderSection.new("Animation", tab:AddDynamicTabbox(), SaveManager.as, AnimationTiming.new())
	BuilderTab.pbs = PartBuilderSection.new("Part", tab:AddDynamicTabbox(), SaveManager.ps, PartTiming.new())
	BuilderTab.ebs = EffectBuilderSection.new("Effect", tab:AddDynamicTabbox(), SaveManager.es, EffectTiming.new())
	BuilderTab.sbs = SoundBuilderSection.new("Sound", tab:AddDynamicTabbox(), SaveManager.ss, SoundTiming.new())

	-- Initialize builder sections.
	BuilderTab.abs:init()
	BuilderTab.ebs:init()
	BuilderTab.pbs:init()
	BuilderTab.sbs:init()

	-- Signals.
	local renderStepped = Signal.new(runService.RenderStepped)
	builderMaid:mark(renderStepped:connect("BuilderTab_RunSimulationStep", runSimulationStep))
end

---Detach tab.
function BuilderTab.detach()
	builderMaid:clean()
	simulationMaid:clean()
end

-- Return CombatTab module.
return BuilderTab

end)
__bundle_register("Menu/Objects/PartBuilderSection", function(require, _LOADED, __bundle_register, __bundle_modules)
---@module Menu.Objects.BuilderSection
local BuilderSection = require("Menu/Objects/BuilderSection")

---@module Utility.Logger
local Logger = require("Utility/Logger")

---@module Game.Timings.PartTiming
local PartTiming = require("Game/Timings/PartTiming")

---@class PartBuilderSection: BuilderSection
---@field partName table
---@field timingDelay table
---@field initialMinimumDistance table
---@field initialMaximumDistance table
---@field timing PartTiming
local PartBuilderSection = setmetatable({}, { __index = BuilderSection })
PartBuilderSection.__index = PartBuilderSection

---Check before writing.
---@return boolean
function PartBuilderSection:check()
	if not BuilderSection.check(self) then
		return false
	end

	if not self.partName.Value or #self.partName.Value <= 0 then
		return Logger.longNotify("Please enter a valid part name.")
	end

	if self.pair:index(self.partName.Value) then
		return Logger.longNotify("The timing ID '%s' is already in the list.", self.partName.Value)
	end

	return true
end

---Load the extra elements. Override me.
---@param timing Timing
function PartBuilderSection:exload(timing)
	self.useHitboxCFrame:SetRawValue(timing.uhc)
	self.partName:SetRawValue(timing.pname)
end

---Reset the elements. Extend me.
function PartBuilderSection:reset()
	BuilderSection.reset(self)
	self.partName:SetRawValue("")
end

---Set creation timing properties. Override me.
---@param timing PartTiming
function PartBuilderSection:cset(timing)
	timing.name = self.timingName.Value
	timing.pname = self.partName.Value
end

---Create new timing. Override me.
---@return PartTiming
function PartBuilderSection:create()
	local timing = PartTiming.new()
	self:cset(timing)
	return timing
end

---Create timing ID element. Override me.
---@param tab table
function PartBuilderSection:tide(tab)
	self.partName = tab:AddInput(nil, {
		Text = "Part Name",
	})
end

---Initialize extra tab.
---@param tab table
function PartBuilderSection:extra(tab)
	self.useHitboxCFrame = tab:AddToggle(nil, {
		Text = "Use Hitbox CFrame",
		Tooltip = "Should the hitbox face where it was originally supposed to?",
		Default = true,
		Callback = self:tnc(function(timing, value)
			timing.uhc = value
		end),
	})
end

---Initialize PartBuilderSection object.
function PartBuilderSection:init()
	self:timing()
	self:builder()
	self:action()
end

---Create new PartBuilderSection object.
---@param name string
---@param tabbox table
---@param pair TimingContainerPair
---@param timing PartTiming
---@return PartBuilderSection
function PartBuilderSection.new(name, tabbox, pair, timing)
	return setmetatable(BuilderSection.new(name, tabbox, pair, timing), PartBuilderSection)
end

-- Return PartBuilderSection module.
return PartBuilderSection

end)
__bundle_register("Menu/Objects/BuilderSection", function(require, _LOADED, __bundle_register, __bundle_modules)
---@module Game.Timings.Action
local Action = require("Game/Timings/Action")

---@module Utility.Logger
local Logger = require("Utility/Logger")

---@module Game.Timings.Timing
local Timing = require("Game/Timings/Timing")

---@class BuilderSection
---@note: We assume that all elements will exist in callbacks. This is why they are not explicitly set in the constructor.
---@field tabbox table
---@field pair TimingContainerPair
---@field name string
---@field timingList table
---@field timingName table
---@field timingTag table
---@field hitboxLength table
---@field hitboxWidth table
---@field hitboxHeight table
---@field timingType table
---@field punishableWindow table
---@field afterWindow table
---@field delayUntilInHitbox table
---@field initialMinimumDistance table
---@field initialMaximumDistance table
---@field actionList table
---@field actionName table
---@field actionDelay table
---@field actionType table
local BuilderSection = {}
BuilderSection.__index = BuilderSection

-- Services.
local stats = game:GetService("Stats")

---Create timing ID element. Override me.
---@param tab table
function BuilderSection:tide(tab) end

---Create extra elements. Override me.
---@param tab table
function BuilderSection:extra(tab) end

---Load the extra elements. Override me.
---@param timing Timing
function BuilderSection:exload(timing) end

---Load the extra action elements. Override me.
---@param action Action
function BuilderSection:exaload(action) end

---Action delay. Override me.
---@param base table
function BuilderSection:daction(base)
	-- The user can accidently click this input through the dropdown and override the delay.
	-- It has been moved and set to "Finished" to prevent this.
	self.actionDelay = base:AddInput(nil, {
		Text = "Action Delay",
		Numeric = true,
		Finished = true,
		Callback = self:anc(function(action, value)
			action._when = tonumber(value)
		end),
	})
end

---Reset elements. Extend me.
function BuilderSection:reset()
	-- Reset timing elements.
	self.timingName:SetRawValue("")
	self.timingType:SetRawValue("Config")
	self.timingTag:SetRawValue("Undefined")
	self.initialMaximumDistance:SetRawValue(0)
	self.punishableWindow:SetRawValue(0)
	self.afterWindow:SetRawValue(0)
	self.initialMinimumDistance:SetRawValue(0)
	self.delayUntilInHitbox:SetRawValue(false)
	self.timingHitboxHeight:SetRawValue(0)
	self.timingHitboxLength:SetRawValue(0)
	self.timingHitboxWidth:SetRawValue(0)
	self.repeatParryDelay:SetRawValue(0)
	self.repeatStartDelay:SetRawValue(0)
	self.repeatUntilParryEnd:SetRawValue(false)
	self.useModuleOverActions:SetRawValue(false)
	self.skipModuleNotification:SetRawValue(false)
	self.selectedModule:SetRawValue("")
	self.skipRepeatNotification:SetRawValue(false)
	self.noDashFallback:SetRawValue(false)
	self.noVentFallback:SetRawValue(false)
	self.hitboxFacingOffset:SetRawValue(true)
	self.hitboxShiftOffset:SetRawValue(0)
	self.blockFallbackHoldTime:SetRawValue(0.3)
	self.noBlockFallback:SetRawValue(false)

	-- Reset action list.
	self:arefresh(nil)

	-- Reset action elements.
	self:raction()
end

---Check before creating new timing. Override me.
---@return boolean
function BuilderSection:check()
	if not self.timingName.Value or #self.timingName.Value <= 0 then
		return Logger.longNotify("Please enter a valid timing name.")
	end

	if self.pair:find(self.timingName.Value) then
		return Logger.longNotify("The timing '%s' already exists in the list.", self.timingName.Value)
	end

	return true
end

---Check before creating new action. Override me.
---@param timing Timing
---@return boolean
function BuilderSection:acheck(timing)
	if not self.actionName.Value or #self.actionName.Value <= 0 then
		return Logger.longNotify("Please enter a valid action name.")
	end

	if timing.actions:find(self.actionName.Value) then
		return Logger.longNotify("The action '%s' already exists in the list.", self.actionName.Value)
	end

	return true
end

---Set creation timing properties. Override me.
---@param timing Timing
function BuilderSection:cset(timing)
	timing.name = self.timingName.Value
end

---Create new timing. Override me.
---@return Timing
function BuilderSection:create()
	local timing = Timing.new()
	self:cset(timing)
	return timing
end

---Initialize action tab.
function BuilderSection:action()
	local tab = self.tabbox:AddTab("Action")

	self.repeatUntilParryEnd = tab:AddToggle(nil, {
		Text = "Repeat Parry Until End",
		Default = false,
		Callback = self:tnc(function(timing, value)
			timing.rpue = value
		end),
	})

	local depBoxOn = tab:AddDependencyBox()

	self.repeatStartDelay = depBoxOn:AddInput(nil, {
		Text = "Repeat Start Delay",
		Numeric = true,
		Finished = true,
		Callback = self:tnc(function(timing, value)
			timing._rsd = tonumber(value) or 0
		end),
	})

	self.repeatParryDelay = depBoxOn:AddInput(nil, {
		Text = "Repeat Parry Delay",
		Numeric = true,
		Finished = true,
		Callback = self:tnc(function(timing, value)
			timing._rpd = tonumber(value) or 0
		end),
	})

	local depBoxOff = tab:AddDependencyBox()

	self:baction(depBoxOff)

	depBoxOn:SetupDependencies({
		{ self.repeatUntilParryEnd, true },
	})

	depBoxOff:SetupDependencies({
		{ self.repeatUntilParryEnd, false },
	})
end

---Reset action elements.
function BuilderSection:raction()
	self.actionName:SetRawValue("")
	self.actionDelay:SetRawValue(0)
	self.actionType:SetRawValue("Parry")
	self.hitboxHeight:SetRawValue(0)
	self.hitboxLength:SetRawValue(0)
	self.hitboxWidth:SetRawValue(0)
end

---Refresh timing list.
function BuilderSection:refresh()
	local values = self.timingType.Value == "Internal" and self.pair.internal:names() or self.pair.config:names()
	self.timingList:SetValues(values)
	self.timingList:SetValue(nil)
	self.timingList:Display()
end

---Refresh action list.
---@param timing Timing?
function BuilderSection:arefresh(timing)
	self.actionList:SetValues(timing and timing.actions:names() or {})
	self.actionList:SetValue(nil)
	self.actionList:Display()
end

---Wrap a callback that needs a timing. This will check for internal timings.
---@param callback function(Timing, ...)
---@return function(...)
function BuilderSection:tnc(callback)
	return function(...)
		-- If no value, return.
		if not self.timingList.Value then
			return Logger.warn("No timing selected.")
		end

		-- Find timing.
		local timing = self.pair:find(self.timingList.Value)
		if not timing then
			return Logger.longNotify("You must select a valid timing to perform this action.")
		end

		-- Check timing type.
		if self.timingType.Value == "Internal" then
			return Logger.longNotify("Internal timing. Changes not replicated. You must clone it to the config first.")
		end

		-- Fire callback.
		callback(timing, ...)
	end
end

---Wrap a callback that needs both an action and a timing.
---@note: This will check for internal timings.
---@param callback function(Timing, Action, ...)
---@return function
function BuilderSection:tanc(callback)
	return function(...)
		-- If no value, return.
		if not self.timingList.Value then
			return Logger.warn("No timing selected.")
		end

		-- Find timing.
		local timing = self.pair:find(self.timingList.Value)
		if not timing then
			return Logger.longNotify("You must select a valid timing to perform this action.")
		end

		-- If no value, return.
		if not self.actionList.Value then
			return Logger.warn("No action selected.")
		end

		-- Find action.
		local action = timing.actions:find(self.actionList.Value)
		if not action then
			return Logger.longNotify("You must select a valid action to perform this action.")
		end

		-- Check timing type.
		if self.timingType.Value == "Internal" then
			return Logger.longNotify("Internal timing. Changes not replicated. You must clone it to the config first.")
		end

		-- Fire callback.
		callback(timing, action, ...)
	end
end

---Wrap a callback that needs a action. This will check for internal timings.
---@param callback function(Action, ...)
---@return function
function BuilderSection:anc(callback)
	return function(...)
		-- If no value, return.
		if not self.timingList.Value then
			return Logger.warn("No timing selected.")
		end

		-- Find timing.
		local timing = self.pair:find(self.timingList.Value)
		if not timing then
			return Logger.longNotify("You must select a valid timing to perform this action.")
		end

		-- If no value, return.
		if not self.actionList.Value then
			return Logger.warn("No action selected.")
		end

		-- Find action.
		local action = timing.actions:find(self.actionList.Value)
		if not action then
			return Logger.longNotify("You must select a valid action to perform this action.")
		end

		-- Check timing type.
		if self.timingType.Value == "Internal" then
			return Logger.longNotify("Internal timing. Changes not replicated. You must clone it to the config first.")
		end

		-- Fire callback.
		callback(action, ...)
	end
end

---Initialize action base.
---@param base table
function BuilderSection:baction(base)
	self.actionList = base:AddDropdown(nil, {
		Text = "Action List",
		Values = {},
		AllowNull = true,
		Callback = self:tnc(function(timing, value)
			-- Reset action elements.
			self:raction()

			-- Check if value exists.
			if not value then
				return Logger.warn("No action value.")
			end

			-- Find action.
			local action = timing.actions:find(value)
			if not action then
				return Logger.longNotify("The selected action '%s' does not exist in the list.", value)
			end

			-- Set action elements.
			self.actionName:SetRawValue(action.name)
			self.actionDelay:SetRawValue(action._when or 0)
			self.actionType:SetRawValue(action._type)
			self.hitboxWidth:SetRawValue(action.hitbox.X)
			self.hitboxHeight:SetRawValue(action.hitbox.Y)
			self.hitboxLength:SetRawValue(action.hitbox.Z)

			-- Load extra action elements.
			self:exaload(action)
		end),
	})

	self.actionType = base:AddDropdown(nil, {
		Text = "Action Type",
		Values = {
			"Parry",
			"Dodge",
			"Forced Full Dodge",
			"Jump",
			"Start Block",
			"End Block",
			"Teleport Up",
			"Start Slide",
			"End Slide",
			"Start Crouch",
			"End Crouch",
		},
		Default = 1,
		Callback = self:anc(function(action, value)
			action._type = value
		end),
	})

	self:daction(base)

	self.hitboxLength = base:AddSlider(nil, {
		Text = "Hitbox Length",
		Min = 0,
		Max = 300,
		Suffix = "s",
		Default = 0,
		Rounding = 0,
		Callback = self:anc(function(action, value)
			action.hitbox = Vector3.new(action.hitbox.X, action.hitbox.Y, value)
		end),
	})

	self.hitboxWidth = base:AddSlider(nil, {
		Text = "Hitbox Width",
		Min = 0,
		Max = 300,
		Suffix = "s",
		Default = 0,
		Rounding = 0,
		Callback = self:anc(function(action, value)
			action.hitbox = Vector3.new(value, action.hitbox.Y, action.hitbox.Z)
		end),
	})

	self.hitboxHeight = base:AddSlider(nil, {
		Text = "Hitbox Height",
		Min = 0,
		Max = 300,
		Suffix = "s",
		Default = 0,
		Rounding = 0,
		Callback = self:anc(function(action, value)
			action.hitbox = Vector3.new(action.hitbox.X, value, action.hitbox.Z)
		end),
	})

	base:AddDivider()

	self.actionName = base:AddInput(nil, {
		Text = "Action Name",
	})

	base:AddButton(
		"Create New Action",
		self:tnc(function(timing)
			-- Fetch actions.
			local actions = timing.actions

			-- Check.
			if not self:acheck(timing) then
				return
			end

			-- Create new action.
			local action = Action.new()
			action.name = self.actionName.Value
			action._type = "Parry"

			-- Record ping for telemetry.
			local network = stats:FindFirstChild("Network")
			local serverStatsItem = network and network:FindFirstChild("ServerStatsItem")
			local dataPingItem = serverStatsItem and serverStatsItem:FindFirstChild("Data Ping")

			if dataPingItem then
				action.ping = dataPingItem:GetValue()
			end

			-- Push action.
			actions:push(action)

			-- Refresh action list.
			self:arefresh(timing)

			-- Set action list value.
			self.actionList:SetValue(action.name)
			self.actionList:Display()
		end)
	)

	base:AddButton(
		"Duplicate Selected Action",
		self:tanc(function(timing, action)
			-- Fetch actions.
			local actions = timing.actions

			-- Check.
			if not self:acheck(timing) then
				return
			end

			-- Create new action.
			local newAction = action:clone()
			newAction.name = self.actionName.Value

			-- Record ping for telemetry.
			local network = stats:FindFirstChild("Network")
			local serverStatsItem = network and network:FindFirstChild("ServerStatsItem")
			local dataPingItem = serverStatsItem and serverStatsItem:FindFirstChild("Data Ping")

			if dataPingItem then
				newAction.ping = dataPingItem:GetValue()
			end

			-- Push action.
			actions:push(newAction)

			-- Refresh action list.
			self:arefresh(timing)

			-- Set action list value.
			self.actionList:SetValue(newAction.name)
			self.actionList:Display()
		end)
	)

	base:AddButton(
		"Remove Selected Action",
		self:tnc(function(timing)
			-- Get selected value.
			local selected = self.actionList.Value
			if not selected then
				return Logger.longNotify("Please select an action to remove.")
			end

			-- Fetch actions.
			local actions = timing.actions

			-- Find action.
			local action = actions:find(selected)
			if not action then
				return Logger.longNotify("The selected action '%s' does not exist in the list.", selected)
			end

			-- Remove action.
			actions:remove(action)

			-- Refresh action list.
			self:arefresh(timing)
		end)
	)
end

---Initialize timing tab.
function BuilderSection:timing()
	local tab = self.tabbox:AddTab("Timings")

	self.timingType = tab:AddDropdown(nil, {
		Text = "Timing Type",
		Values = { "Config", "Internal" },
		Default = 1,
		Callback = function()
			-- Refresh timing list.
			self:refresh()

			-- Reset elements.
			self:reset()
		end,
	})

	self.timingList = tab:AddDropdown(nil, {
		Text = "Timing List",
		Values = self.timingType.Value == "Internal" and self.pair.internal:names() or self.pair.config:names(),
		AllowNull = true,
		Callback = function(value)
			-- Reset elements.
			self:reset()

			-- Check if value exists.
			if not value then
				return Logger.warn("No timing value.")
			end

			-- Fetch timing.
			local found = self.pair:find(value)
			if not found then
				return Logger.longNotify("The selected timing '%s' does not exist in the list.", value)
			end

			-- Set timing elements.
			self.timingName:SetRawValue(found.name)
			self.timingTag:SetRawValue(found.tag)
			self.initialMaximumDistance:SetRawValue(found.imxd)
			self.initialMinimumDistance:SetRawValue(found.imdd)
			self.delayUntilInHitbox:SetRawValue(found.duih)
			self.timingHitboxLength:SetRawValue(found.hitbox.Z)
			self.timingHitboxWidth:SetRawValue(found.hitbox.X)
			self.timingHitboxHeight:SetRawValue(found.hitbox.Y)
			self.punishableWindow:SetRawValue(found.punishable)
			self.afterWindow:SetRawValue(found.after)
			self.useModuleOverActions:SetRawValue(found.umoa)
			self.skipModuleNotification:SetRawValue(found.smn)
			self.selectedModule:SetRawValue(found.smod)
			self.skipRepeatNotification:SetRawValue(found.srpn)
			self.hitboxFacingOffset:SetRawValue(found.fhb)
			self.hitboxShiftOffset:SetRawValue(found.hso)
			self.noDashFallback:SetRawValue(found.ndfb)
			self.noVentFallback:SetRawValue(found.nvfb)
			self.blockFallbackHoldTime:SetRawValue(found.bfht)
			self.noBlockFallback:SetRawValue(found.nbfb)
			self.repeatParryDelay:SetRawValue(found._rpd)
			self.repeatStartDelay:SetRawValue(found._rsd)
			self.repeatUntilParryEnd:SetRawValue(found.rpue)

			-- Load extra elements.
			self:exload(found)

			-- Refresh action list.
			self:arefresh(found)
		end,
	})

	tab:AddDivider()

	self.timingName = tab:AddInput(nil, {
		Text = "Timing Name",
		Finished = true,
	})

	self:tide(tab)

	local configDepBox = tab:AddDependencyBox()

	configDepBox:AddButton("Create New Timing", function()
		-- Fetch config.
		local config = self.pair.config

		-- Check if we can successfully create a timing from the given data.
		if not self:check() then
			return
		end

		-- Create new timing.
		local timing = self:create()

		-- Push new timing.
		config:push(timing)

		-- Refresh timing list.
		self:refresh()

		-- Set timing list value.
		self.timingList:SetValue(timing.name)
		self.timingList:Display()
	end)

	configDepBox:AddButton(
		"Duplicate Selected Timing",
		self:tnc(function(found)
			-- Fetch config.
			local config = self.pair.config

			-- Check if we can successfully create a timing from the given data.
			if not self:check() then
				return
			end

			-- Clone new timing.
			local timing = found:clone()

			-- Set creation properties.
			self:cset(timing)

			-- Push new timing.
			config:push(timing)

			-- Refresh timing list.
			self:refresh()

			-- Set timing list value.
			self.timingList:SetValue(timing.name)
			self.timingList:Display()
		end)
	)

	local internalDepBox = tab:AddDependencyBox()

	internalDepBox:AddButton("Clone To Config", function()
		-- Fetch name.
		local name = self.timingList.Value
		if not name then
			return Logger.longNotify("Please select a timing to clone.")
		end

		-- Fetch data.
		local internal = self.pair.internal
		local config = self.pair.config

		-- Fetch the currently selected timing.
		local found = internal:find(name)
		if not found then
			return Logger.longNotify("The selected timing '%s' does not exist in the list.", name)
		end

		-- Check for existing ID.
		if config.timings[found:id()] then
			return Logger.longNotify("The timing ID '%s' already exists in the config.", found:id())
		end

		-- Check for existing timing.
		if config:find(found.name) then
			return Logger.longNotify("The timing name '%s' already exists in the config.", found.name)
		end

		-- Clone timing.
		---@note: No need to refresh after this. It's in the other timing list!
		config:push(internal:clone(found))
	end)

	tab:AddButton("Remove Selected Timing", function()
		-- Fetch name.
		local name = self.timingList.Value
		if not name then
			return Logger.longNotify("Please select a timing to remove.")
		end

		-- Fetch data.
		local internal = self.pair.internal
		local config = self.pair.config
		local found = config:find(name)

		-- Check if internal.
		---@todo: Implement functionality to remove internal timings.
		if internal:find(name) then
			return Logger.longNotify("You cannot remove internal timings, only override them.")
		end

		-- Check if found.
		if not found then
			return Logger.longNotify("The selected timing '%s' does not exist in the list.", name)
		end

		-- Remove timing.
		config:remove(found)

		-- Refresh timing list.
		self:refresh()
	end)

	configDepBox:SetupDependencies({
		{ self.timingType, "Config" },
	})

	internalDepBox:SetupDependencies({
		{ self.timingType, "Internal" },
	})
end

---Initialize builder tab.
function BuilderSection:builder()
	local tab = self.tabbox:AddTab(string.format("%s", self.name))

	self.timingTag = tab:AddDropdown(nil, {
		Text = "Timing Tag",
		Values = { "Undefined", "Critical", "Mantra", "M1" },
		Default = 1,
		Callback = self:tnc(function(timing, value)
			timing.tag = value
		end),
	})

	self.initialMinimumDistance = tab:AddSlider(nil, {
		Text = "Initial Minimum Distance",
		Min = 0,
		Max = 300,
		Suffix = "s",
		Default = 0,
		Rounding = 0,
		Callback = self:tnc(function(timing, value)
			timing.imdd = value
		end),
	})

	self.initialMaximumDistance = tab:AddSlider(nil, {
		Text = "Initial Maximum Distance",
		Min = 0,
		Max = 2500,
		Suffix = "s",
		Default = 1000,
		Rounding = 0,
		Callback = self:tnc(function(timing, value)
			timing.imxd = value
		end),
	})

	self.punishableWindow = tab:AddSlider(nil, {
		Text = "Punishable Window",
		Min = 0,
		Max = 2,
		Default = 0.6,
		Suffix = "s",
		Rounding = 1,
		Callback = self:tnc(function(timing, value)
			timing.punishable = value
		end),
	})

	self.afterWindow = tab:AddSlider(nil, {
		Text = "After Window",
		Min = 0,
		Max = 1,
		Default = 0.1,
		Suffix = "s",
		Rounding = 2,
		Callback = self:tnc(function(timing, value)
			timing.after = value
		end),
	})

	self.blockFallbackHoldTime = tab:AddSlider(nil, {
		Text = "Block Fallback Hold Time",
		Min = 0,
		Max = 5,
		Suffix = "s",
		Default = 0.3,
		Rounding = 2,
		Callback = self:tnc(function(timing, value)
			timing.bfht = value
		end),
	})

	self.hitboxShiftOffset = tab:AddSlider(nil, {
		Text = "Hitbox Backwards Offset",
		Min = -50,
		Max = 50,
		Suffix = "s",
		Default = 0,
		Rounding = 0,
		Tooltip = "At the end of everything, how much should the hitbox be shifted forwards / backwards?",
		Callback = self:tnc(function(timing, value)
			timing.hso = value
		end),
	})

	self.delayUntilInHitbox = tab:AddToggle(nil, {
		Text = "Delay Until In Hitbox",
		Default = false,
		Callback = self:tnc(function(timing, value)
			timing.duih = value
		end),
	})

	local duihDepBox = tab:AddDependencyBox()

	self.timingHitboxLength = duihDepBox:AddSlider(nil, {
		Text = "Hitbox Length",
		Min = 0,
		Max = 300,
		Suffix = "s",
		Default = 0,
		Rounding = 0,
		Callback = self:tnc(function(timing, value)
			timing.hitbox = Vector3.new(timing.hitbox.X, timing.hitbox.Y, value)
		end),
	})

	self.timingHitboxWidth = duihDepBox:AddSlider(nil, {
		Text = "Hitbox Width",
		Min = 0,
		Max = 300,
		Suffix = "s",
		Default = 0,
		Rounding = 0,
		Callback = self:tnc(function(timing, value)
			timing.hitbox = Vector3.new(value, timing.hitbox.Y, timing.hitbox.Z)
		end),
	})

	self.timingHitboxHeight = duihDepBox:AddSlider(nil, {
		Text = "Hitbox Height",
		Min = 0,
		Max = 300,
		Suffix = "s",
		Default = 0,
		Rounding = 0,
		Callback = self:tnc(function(timing, value)
			timing.hitbox = Vector3.new(timing.hitbox.X, value, timing.hitbox.Z)
		end),
	})

	duihDepBox:SetupDependencies({
		{ self.delayUntilInHitbox, true },
	})

	self.useModuleOverActions = tab:AddToggle(nil, {
		Text = "Use Module Over Actions",
		Default = false,
		Callback = self:tnc(function(timing, value)
			timing.umoa = value
		end),
	})

	local umoaDepBox = tab:AddDependencyBox()

	self.skipModuleNotification = umoaDepBox:AddToggle(nil, {
		Text = "Skip Module Notification",
		Default = false,
		Callback = self:tnc(function(timing, value)
			timing.smn = value
		end),
	})

	self.selectedModule = umoaDepBox:AddInput(nil, {
		Text = "Selected Module",
		Finished = true,
		Callback = self:tnc(function(timing, value)
			timing.smod = value
		end),
	})

	umoaDepBox:SetupDependencies({
		{ self.useModuleOverActions, true },
	})

	self.skipRepeatNotification = tab:AddToggle(nil, {
		Text = "Skip Repeat Notification",
		Default = false,
		Callback = self:tnc(function(timing, value)
			timing.srpn = value
		end),
	})

	self.hitboxFacingOffset = tab:AddToggle(nil, {
		Text = "Hitbox Facing Offset",
		Tooltip = "Should the hitbox be offset towards the facing direction?",
		Default = true,
		Callback = self:tnc(function(timing, value)
			timing.fhb = value
		end),
	})

	self.noDashFallback = tab:AddToggle(nil, {
		Text = "No Dash Fallback",
		Tooltip = "If enabled, the timing will not fallback to a dash if the parry action is not available.",
		Default = false,
		Callback = self:tnc(function(timing, value)
			timing.ndfb = value
		end),
	})

	self.noVentFallback = tab:AddToggle(nil, {
		Text = "No Vent Fallback",
		Tooltip = "If enabled, the timing will not fallback to a vent.",
		Default = false,
		Callback = self:tnc(function(timing, value)
			timing.nvfb = value
		end),
	})

	self.noBlockFallback = tab:AddToggle(nil, {
		Text = "No Block Fallback",
		Tooltip = "If enabled, the timing will not fallback to a block.",
		Default = false,
		Callback = self:tnc(function(timing, value)
			timing.nbfb = value
		end),
	})

	self:extra(tab)
end

---Initialize BuilderSection object.
function BuilderSection:init()
	self:timing()
	self:builder()
	self:action()
end

---Create new BuilderSection object.
---@param name string
---@param tabbox table
---@param pair TimingContainerPair
---@param timing Timing
---@return BuilderSection
function BuilderSection.new(name, tabbox, pair, timing)
	local self = setmetatable({}, BuilderSection)
	self.name = name
	self.tabbox = tabbox
	self.pair = pair
	return self
end

-- Return BuilderSection module.
return BuilderSection

end)
__bundle_register("Menu/Objects/EffectBuilderSection", function(require, _LOADED, __bundle_register, __bundle_modules)
---@module Menu.Objects.BuilderSection
local BuilderSection = require("Menu/Objects/BuilderSection")

---@module Utility.Logger
local Logger = require("Utility/Logger")

---@module Game.Timings.EffectTiming
local EffectTiming = require("Game/Timings/EffectTiming")

---@class EffectBuilderSection: BuilderSection
---@field effectName table
---@field repeatStartDelay table
---@field repeatUntilParryEnd table
---@field repeatParryDelay table
---@field timing EffectTiming
local EffectBuilderSection = setmetatable({}, { __index = BuilderSection })
EffectBuilderSection.__index = EffectBuilderSection

---Create timing ID element. Override me.
---@param tab table
function EffectBuilderSection:tide(tab)
	self.effectName = tab:AddInput(nil, {
		Text = "Effect Name",
	})
end

---Load the extra elements. Override me.
---@param timing Timing
function EffectBuilderSection:exload(timing)
	self.effectName:SetRawValue(timing.ename)
	self.ignoreLocalPlayer:SetRawValue(timing.ilp)
	self.forceLocalPlayer:SetRawValue(timing.flp)
end

---Reset the elements. Extend me.
function EffectBuilderSection:reset()
	BuilderSection.reset(self)
	self.effectName:SetRawValue("")
	self.hitboxFacingOffset:SetRawValue(true)
	self.ignoreLocalPlayer:SetRawValue(false)
	self.forceLocalPlayer:SetRawValue(false)
end

---Check before creating new timing. Override me.
---@return boolean
function EffectBuilderSection:check()
	if not BuilderSection.check(self) then
		return false
	end

	if not self.effectName.Value or #self.effectName.Value <= 0 then
		return Logger.longNotify("Please enter a valid effect name.")
	end

	if self.pair:index(self.effectName.Value) then
		return Logger.longNotify("The timing ID '%s' is already in the list.", self.effectName.Value)
	end

	return true
end

---Set creation timing properties. Override me.
---@param timing EffectTiming
function EffectBuilderSection:cset(timing)
	timing.name = self.timingName.Value
	timing.ename = self.effectName.Value
end

---Create new timing. Override me.
---@return Timing
function EffectBuilderSection:create()
	local timing = EffectTiming.new()
	self:cset(timing)
	return timing
end

---Initialize extra tab.
---@param tab table
function EffectBuilderSection:extra(tab)
	self.ignoreLocalPlayer = tab:AddToggle(nil, {
		Text = "Ignore Local Player",
		Default = true,
		Tooltip = "If enabled, the effect will not react when it is applied to the local player.",
		Callback = self:tnc(function(timing, value)
			timing.ilp = value
		end),
	})

	self.forceLocalPlayer = tab:AddToggle(nil, {
		Text = "Force Local Player",
		Default = false,
		Tooltip = "If enabled, the effect will always react when it is applied to the local player, even if ignored.",
		Callback = self:tnc(function(timing, value)
			timing.flp = value
		end),
	})
end

---Create new EffectBuilderSection object.
---@param name string
---@param tabbox table
---@param pair TimingContainerPair
---@param timing EffectTiming
---@return EffectBuilderSection
function EffectBuilderSection.new(name, tabbox, pair, timing)
	return setmetatable(BuilderSection.new(name, tabbox, pair, timing), EffectBuilderSection)
end

-- Return EffectBuilderSection module.
return EffectBuilderSection

end)
__bundle_register("Menu/Objects/SoundBuilderSection", function(require, _LOADED, __bundle_register, __bundle_modules)
---@module Menu.Objects.BuilderSection
local BuilderSection = require("Menu/Objects/BuilderSection")

---@module Utility.Logger
local Logger = require("Utility/Logger")

---@module Game.Timings.SoundTiming
local SoundTiming = require("Game/Timings/SoundTiming")

---@class SoundBuilderSection: BuilderSection
---@field soundId table
---@field repeatStartDelay table
---@field repeatUntilParryEnd table
---@field repeatParryDelay table
---@field timing SoundTiming
---@field allowLocalPlayer table
local SoundBuilderSection = setmetatable({}, { __index = BuilderSection })
SoundBuilderSection.__index = SoundBuilderSection

---Create timing ID element. Override me.
---@param tab table
function SoundBuilderSection:tide(tab)
	self.soundId = tab:AddInput(nil, {
		Text = "Sound ID",
	})
end

---Load the extra elements. Override me.
---@param timing Timing
function SoundBuilderSection:exload(timing)
	self.soundId:SetRawValue(timing._id)
	self.allowLocalPlayer:SetRawValue(timing.alp)
end

---Reset the elements. Extend me.
function SoundBuilderSection:reset()
	BuilderSection.reset(self)
	self.soundId:SetRawValue("")
	self.allowLocalPlayer:SetRawValue(false)
end

---Check before creating new timing. Override me.
---@return boolean
function SoundBuilderSection:check()
	if not BuilderSection.check(self) then
		return false
	end

	if not self.soundId.Value or #self.soundId.Value <= 0 then
		return Logger.longNotify("Please enter a valid sound ID.")
	end

	if self.pair:index(self.soundId.Value) then
		return Logger.longNotify("The timing ID '%s' is already in the list.", self.soundId.Value)
	end

	return true
end

---Set creation timing properties. Override me.
---@param timing SoundTiming
function SoundBuilderSection:cset(timing)
	timing.name = self.timingName.Value
	timing._id = self.soundId.Value
end

---Create new timing. Override me.
---@return Timing
function SoundBuilderSection:create()
	local timing = SoundTiming.new()
	self:cset(timing)
	return timing
end

---Initialize extra tab.
---@param tab table
function SoundBuilderSection:extra(tab)
	self.allowLocalPlayer = tab:AddToggle(nil, {
		Text = "Allow Local Player",
		Default = false,
		Callback = self:tnc(function(timing, value)
			timing.alp = value
		end),
	})
end

---Create new SoundBuilderSection object.
---@param name string
---@param tabbox table
---@param pair TimingContainerPair
---@param timing SoundTiming
---@return SoundBuilderSection
function SoundBuilderSection.new(name, tabbox, pair, timing)
	return setmetatable(BuilderSection.new(name, tabbox, pair, timing), SoundBuilderSection)
end

-- Return SoundBuilderSection module.
return SoundBuilderSection

end)
__bundle_register("Menu/Objects/AnimationBuilderSection", function(require, _LOADED, __bundle_register, __bundle_modules)
---@module Menu.Objects.BuilderSection
local BuilderSection = require("Menu/Objects/BuilderSection")

---@module Utility.Logger
local Logger = require("Utility/Logger")

---@module Game.Timings.AnimationTiming
local AnimationTiming = require("Game/Timings/AnimationTiming")

---@class AnimationBuilderSection: BuilderSection
---@field animationId table
---@field repeatStartDelay table
---@field repeatUntilParryEnd table
---@field repeatParryDelay table
---@field timing AnimationTiming
local AnimationBuilderSection = setmetatable({}, { __index = BuilderSection })
AnimationBuilderSection.__index = AnimationBuilderSection

---Create timing ID element. Override me.
---@param tab table
function AnimationBuilderSection:tide(tab)
	self.animationId = tab:AddInput(nil, {
		Text = "Animation ID",
	})
end

---Load the extra elements. Override me.
---@param timing AnimationTiming
function AnimationBuilderSection:exload(timing)
	self.animationId:SetRawValue(timing._id)
	self.hyperarmor:SetRawValue(timing.ha)
	self.ignoreAnimationEnd:SetRawValue(timing.iae)
	self.ignoreEarlyAnimationEnd:SetRawValue(timing.ieae)
	self.maxAnimationTimeout:SetRawValue(timing.mat)
	self.pastHitboxDetection:SetRawValue(timing.phd)
	self.predictFacingHitboxes:SetRawValue(timing.pfh)
	self.historySeconds:SetRawValue(timing.phds)
	self.extrapolationTime:SetRawValue(timing.pfht)
end

---Reset the elements. Extend me.
function AnimationBuilderSection:reset()
	BuilderSection.reset(self)
	self.animationId:SetRawValue("")
	self.hyperarmor:SetRawValue(false)
	self.hitboxFacingOffset:SetRawValue(true)
	self.ignoreAnimationEnd:SetRawValue(false)
	self.ignoreEarlyAnimationEnd:SetRawValue(false)
	self.maxAnimationTimeout:SetRawValue(2000)
	self.pastHitboxDetection:SetRawValue(false)
	self.historySeconds:SetRawValue(0.5)
	self.predictFacingHitboxes:SetRawValue(false)
	self.extrapolationTime:SetRawValue(0.15)
end

---Check before creating new timing. Override me.
---@return boolean
function AnimationBuilderSection:check()
	if not BuilderSection.check(self) then
		return false
	end

	if not self.animationId.Value or #self.animationId.Value <= 0 then
		return Logger.longNotify("Please enter a valid animation ID.")
	end

	local timing = self.pair:index(self.animationId.Value)
	if timing then
		return Logger.longNotify("The timing ID '%s' (%s) is already in the list.", self.animationId.Value, timing.name)
	end

	return true
end

---Set creation timing properties. Override me.
---@param timing AnimationTiming
function AnimationBuilderSection:cset(timing)
	timing.name = self.timingName.Value
	timing._id = self.animationId.Value
end

---Create new timing. Override me.
---@return Timing
function AnimationBuilderSection:create()
	local timing = AnimationTiming.new()
	self:cset(timing)
	return timing
end

---Initialize extra tab.
---@param tab table
function AnimationBuilderSection:extra(tab)
	self.hyperarmor = tab:AddToggle(nil, {
		Text = "Hyperarmor Flag",
		Tooltip = "Is this timing not able to be interrupted by attacks during the animation?",
		Default = false,
		Callback = self:tnc(function(timing, value)
			timing.ha = value
		end),
	})

	self.ignoreAnimationEnd = tab:AddToggle(nil, {
		Text = "Ignore Animation End",
		Tooltip = "Should the timing ignore the end of the animation?",
		Default = false,
		Callback = self:tnc(function(timing, value)
			timing.iae = value
		end),
	})

	local depBoxEnd = tab:AddDependencyBox()

	self.maxAnimationTimeout = depBoxEnd:AddInput(nil, {
		Text = "Max Animation Timeout",
		Tooltip = "The maximum time (in milliseconds) that the animation is allowed to run with no end check.",
		Default = 2000,
		Numeric = true,
		Callback = self:tnc(function(timing, value)
			timing.mat = tonumber(value)
		end),
	})

	depBoxEnd:SetupDependencies({
		{ self.ignoreAnimationEnd, true },
	})

	self.ignoreEarlyAnimationEnd = tab:AddToggle(nil, {
		Text = "Ignore Early Animation End",
		Tooltip = "Should the timing ignore the early end of the animation?",
		Default = false,
		Callback = self:tnc(function(timing, value)
			timing.ieae = value
		end),
	})

	self.pastHitboxDetection = tab:AddToggle(nil, {
		Text = "Past Hitbox Detection",
		Default = false,
		Tooltip = "Should the hitbox detection track the past hitboxes too?",
		Callback = self:tnc(function(timing, value)
			timing.phd = value
		end),
	})

	local pfdOffDepBox = tab:AddDependencyBox()

	self.historySeconds = pfdOffDepBox:AddSlider(nil, {
		Text = "History Seconds",
		Tooltip = "How far back in seconds should we fetch history?",
		Default = 0.5,
		Min = 0,
		Max = 3.0,
		Rounding = 2,
		Numeric = true,
		Callback = self:tnc(function(timing, value)
			timing.phds = tonumber(value) or 0
		end),
	})

	pfdOffDepBox:SetupDependencies({
		{ self.pastHitboxDetection, true },
	})

	self.predictFacingHitboxes = tab:AddToggle(nil, {
		Text = "Predict Facing Hitboxes",
		Default = false,
		Tooltip = "Should we make a prediction on the facing direction and make a hitbox on that?",
		Callback = self:tnc(function(timing, value)
			timing.pfh = value
		end),
	})

	self.disablePrediction = tab:AddToggle(nil, {
		Text = "Disable Prediction",
		Default = false,
		Tooltip = "Should we disable prediction?",
		Callback = self:tnc(function(timing, value)
			timing.dp = value
		end),
	})

	self.extrapolationTime = tab:AddSlider(nil, {
		Text = "Extrapolation Time",
		Tooltip = "The time (in seconds) to extrapolate by.",
		Default = 0.15,
		Min = 0,
		Max = 2.0,
		Rounding = 3,
		Numeric = true,
		Callback = self:tnc(function(timing, value)
			timing.pfht = tonumber(value)
		end),
	})
end

---Create new AnimationBuilderSection object.
---@param name string
---@param tabbox table
---@param pair TimingContainerPair
---@param timing AnimationTiming
---@return AnimationBuilderSection
function AnimationBuilderSection.new(name, tabbox, pair, timing)
	return setmetatable(BuilderSection.new(name, tabbox, pair, timing), AnimationBuilderSection)
end

-- Return AnimationBuilderSection module.
return AnimationBuilderSection

end)
__bundle_register("Menu/AutomationTab", function(require, _LOADED, __bundle_register, __bundle_modules)
-- AutomationTab module.
local AutomationTab = {}

---@module Utility.Logger
local Logger = require("Utility/Logger")

---@module Features.Automation.EchoFarm
local EchoFarm = require("Features/Automation/EchoFarm")

---@module Features.Automation.JoyFarm
local JoyFarm = require("Features/Automation/JoyFarm")

---@module Game.QueuedBlocking
local QueuedBlocking = require("Game/QueuedBlocking")

---@module Game.KeyHandling
local KeyHandling = require("Game/KeyHandling")

---@module Features.Game.Tweening
local Tweening = require("Features/Game/Tweening")

---Attribute section.
---@param groupbox table
function AutomationTab.initAttributeSection(groupbox)
	groupbox
		:AddToggle("AutoCharisma", {
			Text = "Auto Charisma Farm",
			Default = false,
			Tooltip = "Using the 'How To Make Friends' book, the script will automatically train the 'Charisma' attribute.",
		})
		:AddKeyPicker("AutoCharismaKeybind", {
			Default = "N/A",
			SyncToggleState = true,
			Text = "Auto Charisma Farm",
		})

	groupbox:AddInput("CharismaCap", {
		Text = "Charisma Cap",
		Tooltip = "When this cap is reached, the farm will stop training the 'Charisma' attribute.",
		Numeric = true,
		MaxLength = 3,
		Default = "75",
	})

	groupbox
		:AddToggle("AutoIntelligence", {
			Text = "Auto Intelligence Farm",
			Tooltip = "Using the 'Math Textbook' book, the script will automatically train the 'Intelligence' attribute.",
			Default = false,
		})
		:AddKeyPicker("AutoIntelligenceKeybind", {
			Default = "N/A",
			SyncToggleState = true,
			Text = "Auto Intelligence",
		})

	groupbox:AddInput("IntelligenceCap", {
		Text = "Intelligence Cap",
		Tooltip = "When this cap is reached, the farm will stop training the 'Intelligence' attribute.",
		Numeric = true,
		MaxLength = 3,
		Default = "75",
	})
end

---Initialize Fish Farm section.
---@param groupbox table
function AutomationTab.initFishFarmSection(groupbox)
	groupbox
		:AddToggle("AutoFish", {
			Text = "Auto Fish Farm",
			Tooltip = "Automatically farm fish. Non-AFKable yet. Work-in progress.",
			Default = false,
		})
		:AddKeyPicker("AutoFishKeybind", {
			Default = "N/A",
			SyncToggleState = true,
			Text = "Auto Fish Farm",
		})
end

---Initialize Auto Loot section.
---@param groupbox table
function AutomationTab.initAutoLootSection(groupbox)
	groupbox
		:AddToggle("AutoLoot", {
			Text = "Auto Loot",
			Tooltip = "Automatically loot items from choice prompts with filtering options.",
			Default = false,
		})
		:AddKeyPicker("AutoLootKeybind", {
			Default = "N/A",
			SyncToggleState = true,
			Text = "Auto Loot",
		})

	local autoLootDepBox = groupbox:AddDependencyBox()

	autoLootDepBox:AddToggle("AutoLootAll", {
		Text = "Loot All Items",
		Tooltip = "Loot all items from choice prompts. This will ignore filtering options.",
		Default = false,
	})

	local autoLootAllDepBox = autoLootDepBox:AddDependencyBox()

	autoLootAllDepBox:AddSlider("AutoLootStarsMin", {
		Text = "Minimum Stars",
		Tooltip = "The minimum number of stars an item must have to be looted.",
		Min = 0,
		Max = 3,
		Rounding = 0,
		Suffix = "★",
		Default = 0,
	})

	autoLootAllDepBox:AddSlider("AutoLootStarsMax", {
		Text = "Maximum Stars",
		Tooltip = "The maximum number of stars an item can have to be looted.",
		Min = 0,
		Max = 3,
		Rounding = 0,
		Suffix = "★",
		Default = 0,
	})

	local itemNameList = autoLootAllDepBox:AddDropdown("ItemNameList", {
		Text = "Item Name List",
		Values = {},
		SaveValues = true,
		Multi = true,
		AllowNull = true,
	})

	local itemNameInput = autoLootAllDepBox:AddInput("ItemNameInput", {
		Text = "Item Name Input",
		Placeholder = "Exact or partial names.",
	})

	autoLootAllDepBox:AddButton("Add Item Name To Filter", function()
		local itemName = itemNameInput.Value
		if #itemName <= 0 then
			return Logger.longNotify("Please enter a valid item name.")
		end

		local values = itemNameList.Values
		if not table.find(values, itemName) then
			table.insert(values, itemName)
		end

		itemNameList:SetValues(values)
		itemNameList:SetValue({})
		itemNameList:Display()
	end)

	autoLootAllDepBox:AddButton("Remove Selected Item Names", function()
		local values = itemNameList.Values
		local value = itemNameList.Value

		for selected, _ in next, value do
			local index = table.find(values, selected)
			if not index then
				continue
			end

			table.remove(values, index)
		end

		itemNameList:SetValues(values)
		itemNameList:SetValue({})
		itemNameList:Display()
	end)

	autoLootAllDepBox:SetupDependencies({
		{ Toggles.AutoLootAll, false },
	})

	autoLootDepBox:SetupDependencies({
		{ Toggles.AutoLoot, true },
	})
end

---Initialize Joy Farm section.
---@param groupbox table
function AutomationTab.initJoyFarmSection(groupbox)
	groupbox:AddButton({
		Text = "Start Joy Farm",
		Tooltip = "Make sure that you are at the start of a cycle.",
		Func = JoyFarm.start,
	})

	groupbox:AddButton("Stop Joy Farm", JoyFarm.stop)
end

---Initialize Effect Automation section.
---@param groupbox table
function AutomationTab.initEffectAutomation(groupbox)
	groupbox:AddToggle("AutoExtinguishFire", {
		Text = "Auto Extinguish Fire",
		Tooltip = "Attempt to remove 'Burning' effects through automatic sliding.",
		Default = false,
	})
end

---Initialize Debugging section.
---@param groupbox table
function AutomationTab.initDebuggingSection(groupbox)
	groupbox:AddButton("Start Echo Farm", EchoFarm.invoke)
	groupbox:AddButton("Stop Echo Farm", EchoFarm.stop)

	groupbox:AddButton("Start Deflect", function()
		QueuedBlocking.invoke(QueuedBlocking.BLOCK_TYPE_DEFLECT, "StartDeflect", nil)
	end)

	groupbox:AddButton("Start Deflect 0.1s", function()
		QueuedBlocking.invoke(QueuedBlocking.BLOCK_TYPE_DEFLECT, "StartDeflect", 0.1)
	end)

	groupbox:AddButton("Start Block 0.3s", function()
		QueuedBlocking.invoke(QueuedBlocking.BLOCK_TYPE_NORMAL, "StartBlock", 0.3)
	end)

	groupbox:AddButton("Start Block", function()
		QueuedBlocking.invoke(QueuedBlocking.BLOCK_TYPE_NORMAL, "StartBlock", nil)
	end)

	groupbox:AddButton("Stop All Block", function()
		QueuedBlocking.empty()
	end)

	groupbox:AddButton("Raw Start Block", function()
		local blockRemote = KeyHandling.getRemote("Block")
		if not blockRemote then
			return
		end

		blockRemote:FireServer()
	end)

	groupbox:AddButton("Raw Stop Block", function()
		local unblockRemote = KeyHandling.getRemote("Unblock")
		if not unblockRemote then
			return
		end

		unblockRemote:FireServer()
	end)

	groupbox:AddButton("Test Tween", function()
		local positions = {
			CFrame.new(2414.70, 442.28, -5595.58),
			CFrame.new(2424.78, 408.30, -5501.38),
			CFrame.new(2429.86, 408.30, -5495.80),
			CFrame.new(2507.99, 414.60, -5560.85),
			CFrame.new(600.33, 983.29, -7643.66),
			CFrame.new(669.22, 979.31, -7668.61),
			CFrame.new(2960.38, 404.16, -5604.14),
		}

		for idx, position in next, positions do
			Tweening.goal(string.format("TweenToTest_%i", idx), position, true)
		end
	end)

	groupbox:AddButton("Cancel Tween", function()
		for idx = 1, 7 do
			Tweening.stop(string.format("TweenToTest_%i", idx))
		end
	end)
end

---Initialize tab.
---@param window table
function AutomationTab.init(window)
	-- Create tab.
	local tab = window:AddTab("Auto")

	-- Initialize sections.
	AutomationTab.initFishFarmSection(tab:AddDynamicGroupbox("Fish Farm"))
	AutomationTab.initAttributeSection(tab:AddDynamicGroupbox("Attribute Farm"))
	AutomationTab.initEffectAutomation(tab:AddDynamicGroupbox("Effect Automation"))
	AutomationTab.initAutoLootSection(tab:AddLeftGroupbox("Auto Loot"))

	if game.PlaceId == 8668476218 then
		AutomationTab.initJoyFarmSection(tab:AddLeftGroupbox("Joy Farm"))
	end

	if LRM_UserNote then
		return
	end

	AutomationTab.initDebuggingSection(tab:AddRightGroupbox("Debugging"))
end

-- Return AutomationTab module.
return AutomationTab

end)
__bundle_register("Menu/GameTab", function(require, _LOADED, __bundle_register, __bundle_modules)
-- GameTab module.
local GameTab = {}

---@module Features.Game.Spoofing
local Spoofing = require("Features/Game/Spoofing")

---@module Utility.Configuration
local Configuration = require("Utility/Configuration")

---@module Utility.Logger
local Logger = require("Utility/Logger")

---@module Game.KeyHandling
local KeyHandling = require("Game/KeyHandling")

-- Services.
local players = game:GetService("Players")

---@module Features.Game.Tweening
local Tweening = require("Features/Game/Tweening")

---Initialize local character section.
---@param groupbox table
function GameTab.initLocalCharacterSection(groupbox)
	local speedHackToggle = groupbox:AddToggle("Speedhack", {
		Text = "Speedhack",
		Tooltip = "Modify your character's velocity while moving.",
		Default = false,
	})

	speedHackToggle:AddKeyPicker("SpeedhackKeybind", { Default = "N/A", SyncToggleState = true, Text = "Speedhack" })

	local speedDepBox = groupbox:AddDependencyBox()

	speedDepBox:AddSlider("SpeedhackSpeed", {
		Text = "Speedhack Speed",
		Default = 200,
		Min = 0,
		Max = 300,
		Suffix = "/s",
		Rounding = 0,
	})

	local cframeSpeedToggle = groupbox:AddToggle("CFrameSpeed", {
		Text = "CFrame Speed",
		Tooltip = "Use CFrame-based movement. Recommend on low speed, this feature will help your fight and make your combo/movement smoother.",
		Default = false,
	})

	cframeSpeedToggle:AddKeyPicker("CFrameSpeedKeybind", { Default = "N/A", SyncToggleState = true, Text = "CFrame Speed" })

	local cfsDepBox = groupbox:AddDependencyBox()

	cfsDepBox:AddSlider("CFrameSpeedMultiplier", {
		Text = "CFrame Speed Multiplier",
		Default = 1,
		Min = 1,
		Max = 20,
		Suffix = "x",
		Rounding = 1,
	})

	local flyToggle = groupbox:AddToggle("Fly", {
		Text = "Fly",
		Tooltip = "Set your character's velocity while moving to imitate flying.",
		Default = false,
	})

	flyToggle:AddKeyPicker("FlyKeybind", { Default = "N/A", SyncToggleState = true, Text = "Fly" })

	local flyDepBox = groupbox:AddDependencyBox()

	flyDepBox:AddSlider("FlySpeed", {
		Text = "Fly Speed",
		Default = 200,
		Min = 0,
		Max = 450,
		Suffix = "/s",
		Rounding = 0,
	})

	flyDepBox:AddSlider("FlyUpSpeed", {
		Text = "Spacebar Fly Speed",
		Default = 150,
		Min = 0,
		Max = 450,
		Suffix = "/s",
		Rounding = 0,
	})

	local noclipToggle = groupbox:AddToggle("NoClip", {
		Text = "NoClip",
		Tooltip = "Disable collision(s) for your character.",
		Default = false,
	})

	noclipToggle:AddKeyPicker("NoClipKeybind", { Default = "N/A", SyncToggleState = true, Text = "NoClip" })

	local noclipDepBox = groupbox:AddDependencyBox()

	noclipDepBox:AddToggle("NoClipCollisionsKnocked", {
		Text = "Collisions While Knocked",
		Tooltip = "Enable collisions while knocked.",
		Default = false,
	})

	local ttbToggle = groupbox:AddToggle("TweenToBack", {
		Text = "Tween To Back",
		Tooltip = "Start following the nearest entity based on a distance and height offset.",
		Default = false,
		Callback = function(state)
			if state then
				return
			end

			Tweening.stop("TweenToBack")
		end,
	})

	ttbToggle:AddKeyPicker("TweenToBackKeybind", { Default = "N/A", SyncToggleState = true, Text = "Tween To Back" })

	local ttbDepBox = groupbox:AddDependencyBox()

	ttbDepBox:AddToggle("StickyAttach", {
		Text = "Sticky Attach",
		Tooltip = "Continue following the entity until it dies.",
		Default = false,
	})

	ttbDepBox:AddToggle("AttachIgnorePlayers", {
		Text = "Ignore Players",
		Tooltip = "Do not attach to players.",
		Default = true,
	})

	ttbDepBox:AddSlider("BackOffset", {
		Text = "Distance To Entity",
		Default = 5,
		Min = -100,
		Max = 100,
		Suffix = "studs",
		Rounding = 0,
	})

	ttbDepBox:AddSlider("HeightOffset", {
		Text = "Height Offset",
		Default = 0,
		Min = -100,
		Max = 30,
		Suffix = "studs",
		Rounding = 0,
	})

	local infJumpToggle = groupbox:AddToggle("InfiniteJump", {
		Text = "Infinite Jump",
		Tooltip = "Boost your velocity while the jump key is held.",
		Default = false,
	})

	infJumpToggle:AddKeyPicker(
		"InfiniteJumpKeybind",
		{ Default = "N/A", SyncToggleState = true, Text = "Infinite Jump" }
	)

	local infiniteJumpDepBox = groupbox:AddDependencyBox()

	infiniteJumpDepBox:AddSlider("InfiniteJumpBoost", {
		Text = "Infinite Jump Boost",
		Default = 50,
		Min = 0,
		Max = 500,
		Suffix = "/s",
		Rounding = 0,
	})

	groupbox:AddToggle("AgilitySpoof", {
		Text = "Agility Spoofer",
		Tooltip = "Set your Agility investment points to boost movement.",
		Default = false,
	})

	local agilitySpoofDepBox = groupbox:AddDependencyBox()

	agilitySpoofDepBox:AddToggle("BoostAgilityDirectly", {
		Text = "Boost Agility Directly",
		Tooltip = "Boost your Agility directly instead of using investment points.",
		Default = false,
	})

	agilitySpoofDepBox:AddSlider("AgilitySpoof", {
		Text = "Agility Value",
		Default = 0,
		Min = 0,
		Max = 400,
		Suffix = "pts",
		Rounding = 0,
	})

	groupbox:AddToggle("AutoSprint", {
		Text = "Auto Sprint",
		Tooltip = "Instantly invoke a sprint when pressing a key in any direction.",
		Default = false,
	})

	local asDepBox = groupbox:AddDependencyBox()

	asDepBox:AddToggle("AutoSprintOnCrouch", {
		Text = "Auto Sprint On Crouch",
		Tooltip = "Allow 'Auto Sprint' to run even while crouching.",
		Default = false,
	})

	asDepBox:AddToggle("AutoSprintDelay", {
		Text = "Auto Sprint Delay",
		Tooltip = "Delay the automated sprint activation after pressing a key.",
		Default = false,
	})

	local asdDepBox = asDepBox:AddDependencyBox()

	asdDepBox:AddSlider("AutoSprintDelayTime", {
		Text = "Auto Sprint Delay Time",
		Default = 0.2,
		Min = 0,
		Max = 5,
		Suffix = "s",
		Rounding = 2,
	})

	groupbox:AddToggle("FreestylersBandSpoof", {
		Text = "Freestylers Band Spoofer",
		Tooltip = "Use the Freestylers Band without equipping it.",
		Default = false,
	})

	groupbox:AddToggle("KongaClutchRingSpoof", {
		Text = "Konga Clutch Ring Spoofer",
		Tooltip = "Use the Konga Clutch Ring without equipping it.",
		Default = false,
	})

	groupbox:AddToggle("EmoteSpoofer", {
		Text = "Emote Spoofer",
		Tooltip = "Unlock all emotes and use them without owning them.",
		Default = false,
	})

	groupbox:AddToggle("MaxMomentumSpoof", {
		Text = "Max Momentum Spoofer",
		Tooltip = "Spoof your character's momentum to the maximum value.",
		Default = false,
	})

	groupbox:AddButton({
		Text = "Respawn Character",
		DoubleClick = true,
		Func = function()
			local character = players.LocalPlayer.Character
			if not character then
				return
			end

			local humanoidRootPart = character:FindFirstChild("HumanoidRootPart")
			if not humanoidRootPart then
				return
			end

			character:PivotTo(humanoidRootPart.CFrame * CFrame.new(0, 10000000, 0))
		end,
	})

	groupbox:AddButton({
		Text = "Deal Fall Damage To Self",
		DoubleClick = true,
		Func = function()
			local remote = KeyHandling.getRemote("FallDamage")
			if not remote then
				return Logger.notify("Failed to find fall damage remote.")
			end

			remote:FireServer(Configuration.expectOptionValue("FallDamageAmount") or 0.0, false)
		end,
	})

	groupbox:AddSlider("FallDamageAmount", {
		Text = "Fall Damage Amount",
		Default = 50,
		Min = 0,
		Max = 1000,
		Suffix = "hp",
		Rounding = 0,
	})

	agilitySpoofDepBox:SetupDependencies({
		{ Toggles.AgilitySpoof, true },
	})

	asdDepBox:SetupDependencies({
		{ Toggles.AutoSprintDelay, true },
	})

	asDepBox:SetupDependencies({
		{ Toggles.AutoSprint, true },
	})

	infiniteJumpDepBox:SetupDependencies({
		{ Toggles.InfiniteJump, true },
	})

	speedDepBox:SetupDependencies({
		{ Toggles.Speedhack, true },
	})

	cfsDepBox:SetupDependencies({
		{ Toggles.CFrameSpeed, true },
	})

	flyDepBox:SetupDependencies({
		{ Toggles.Fly, true },
	})

	noclipDepBox:SetupDependencies({
		{ Toggles.NoClip, true },
	})

	ttbDepBox:SetupDependencies({
		{ Toggles.TweenToBack, true },
	})
end

---Initialize player monitoring section.
---@param groupbox table
function GameTab.initPlayerMonitoringSection(groupbox)
	groupbox:AddToggle("NotifyMod", {
		Text = "Mod Notifications",
		Default = true,
	})

	local nmDepBox = groupbox:AddDependencyBox()

	nmDepBox:AddToggle("NotifyModSound", {
		Text = "Mod Notification Sound",
		Tooltip = "Use a sound along with the mod notification.",
		Default = false,
	})

	local nmbDepBox = nmDepBox:AddDependencyBox()

	nmbDepBox:AddSlider("NotifyModSoundVolume", {
		Text = "Sound Volume",
		Default = 10,
		Min = 0,
		Max = 20,
		Suffix = "v",
		Rounding = 2,
	})

	nmbDepBox:SetupDependencies({
		{ Toggles.NotifyModSound, true },
	})

	nmDepBox:SetupDependencies({
		{ Toggles.NotifyMod, true },
	})

	groupbox:AddToggle("NotifyVoidWalker", {
		Text = "Void Walker Notifications",
		Tooltip = "This will notify you when a player has a Void Walker contract.",
		Default = false,
	})

	local niToggle = groupbox:AddToggle("NotifyItems", {
		Text = "Item Notifications",
		Tooltip = "This will notify you when a player has any listed item in their inventory.",
		Default = false,
	})

	local niDepBox = groupbox:AddDependencyBox()

	local notifyItemsList = niDepBox:AddDropdown("NotifyItemsList", {
		Text = "Item List",
		Default = {},
		SaveValues = true,
		Multi = true,
		Values = {},
	})

	local itemLabel = niDepBox:AddInput("NotifyItemsLabel", {
		Text = "Item Name",
		Placeholder = "Partial or exact item name.",
	})

	niDepBox:AddButton("Add Name To Filter", function()
		local itemLabelValue = itemLabel.Value

		if #itemLabelValue <= 0 then
			return Logger.notify("Please enter a valid item name.")
		end

		local notifyItemsListValues = notifyItemsList.Values

		if not table.find(notifyItemsListValues, itemLabelValue) then
			table.insert(notifyItemsListValues, itemLabelValue)
		end

		notifyItemsList:SetValues(notifyItemsListValues)
		notifyItemsList:SetValue({})
		notifyItemsList:Display()
	end)

	niDepBox:AddButton("Remove Selected Names", function()
		local notifyItemsListValues = notifyItemsList.Values
		local selectedNotifyItems = notifyItemsList.Value

		for selectedNotifyItem, _ in next, selectedNotifyItems do
			local selectedIndex = table.find(notifyItemsListValues, selectedNotifyItem)
			if not selectedIndex then
				return Logger.notify("The selected item name %s does not exist in the list", selectedNotifyItem)
			end

			table.remove(notifyItemsListValues, selectedIndex)
		end

		notifyItemsList:SetValues(notifyItemsListValues)
		notifyItemsList:SetValue({})
		notifyItemsList:Display()
	end)

	niDepBox:SetupDependencies({
		{ niToggle, true },
	})

	groupbox:AddToggle("PlayerSpectating", {
		Text = "Player List Spectating",
		Tooltip = "Click on a player on the player list to spectate them.",
		Default = false,
	})

	groupbox:AddToggle("BuildStealer", {
		Text = "Build Stealer",
		Tooltip = "Steal builds by hovering on them in the player list and pressing 'P' on your keyboard.",
		Default = false,
	})

	groupbox:AddToggle("ShowHiddenPlayers", {
		Text = "Show Hidden Players",
		Tooltip = "Show hidden players on the player list.",
		Default = false,
	})

	groupbox:AddToggle("ShowRobloxChat", {
		Text = "Show Roblox Chat",
		Default = false,
	})

	groupbox:AddToggle("ShowOwnership", {
		Text = "Show Network Ownership",
		Default = false,
	})

	groupbox:AddToggle("PlayerProximity", {
		Text = "Player Proximity Notifications",
		Tooltip = "When other players are within specified distance, notify the user.",
		Default = false,
	})

	local ppDepBox = groupbox:AddDependencyBox()

	ppDepBox:AddSlider("PlayerProximityRange", {
		Text = "Player Proximity Distance",
		Default = 1000,
		Min = 50,
		Max = 2500,
		Suffix = "studs",
		Rounding = 0,
	})

	ppDepBox:AddToggle("PlayerProximityVW", {
		Text = "Only Allow Voidwalkers",
		Tooltip = "The other players must have a Voidwalker Contract for us to be warned.",
		Default = false,
	})

	ppDepBox:AddToggle("PlayerProximityBeep", {
		Text = "Play Beep Sound",
		Tooltip = "Use a beep sound along with the proximity notification.",
		Default = false,
	})

	local ppbDepBox = ppDepBox:AddDependencyBox()

	ppbDepBox:AddSlider("PlayerProximityBeepVolume", {
		Text = "Beep Sound Volume",
		Default = 0.1,
		Min = 0,
		Max = 10,
		Suffix = "v",
		Rounding = 2,
	})

	ppbDepBox:SetupDependencies({
		{ Toggles.PlayerProximityBeep, true },
	})

	ppDepBox:SetupDependencies({
		{ Toggles.PlayerProximity, true },
	})
end

---Initialize effect removals section.
---@param groupbox table
function GameTab.initEffectRemovalsSection(groupbox)
	groupbox:AddToggle("NoStun", {
		Text = "No Stun",
		Tooltip = "Remove any incoming 'Stun' effects from the server.",
		Default = false,
	})

	groupbox:AddToggle("NoSpeedDebuff", {
		Text = "No Speed Debuff",
		Tooltip = "Remove any incoming 'Speed Debuff' effects from the server.",
		Default = false,
	})

	local noFallToggle = groupbox:AddToggle("NoFallDamage", {
		Text = "No Fall Damage",
		Tooltip = "Remove any 'Fall Damage' requests to the server.",
		Default = false,
	})

	noFallToggle:AddKeyPicker(
		"NoFallDamageKeybind",
		{ Default = "N/A", SyncToggleState = true, Text = "No Fall Damage" }
	)

	groupbox:AddToggle("NoAcidWater", {
		Text = "No Acid Water",
		Tooltip = "Remove any 'Acid Water Damage' requests to the server.",
		Default = false,
	})

	groupbox:AddToggle("NoWind", {
		Text = "No Wind",
		Tooltip = "Remove any 'Wind' effects from the server.",
		Default = false,
	})

	groupbox:AddToggle("NoAttackingClientChecks", {
		Text = "No Attacking Client Checks",
		Default = false,
		Tooltip = "Remove any 'Attacking' effects from the server.",
	})

	groupbox:AddToggle("AlwaysAllowJump", {
		Text = "Always Allow Jump",
		Tooltip = "Remove any 'No Jump' effects from the server.",
		Default = false,
	})
end

---Initialize instance removals.
---@param groupbox table
function GameTab.initInstanceRemovalsSection(groupbox)
	groupbox:AddToggle("NoEchoModifiers", {
		Text = "No Echo Modifiers",
		Tooltip = "Remove any 'Echo Modifiers' instances on the client.",
		Default = false,
	})

	groupbox:AddToggle("NoKillBricks", {
		Text = "No Kill Bricks",
		Tooltip = "Remove any 'Kill Brick' parts on the client.",
		Default = false,
	})

	groupbox:AddToggle("NoDamageBricks", {
		Text = "No Damage Bricks",
		Tooltip = "Disable any 'Damage Brick' parts on the client.",
		Default = false,
	})

	groupbox:AddToggle("NoCastleLightBarrier", {
		Text = "No Castle Light Barrier",
		Tooltip = "Remove any 'Castle Light Barrier' parts on the client.",
		Default = false,
	})

	groupbox:AddToggle("NoYunShulBarrier", {
		Text = "No Yun Shul Barrier",
		Tooltip = "Remove any 'Yun Shul Barrier' parts on the client.",
		Default = false,
	})

	groupbox:AddToggle("NoHiveGate", {
		Text = "No Hive Gate",
		Tooltip = "Remove any 'Hive Gate' parts on the client.",
		Default = false,
	})
end

---Debugging section.
---@param groupbox table
function GameTab.initDebuggingSection(groupbox)
	groupbox:AddToggle("ShowDebugInformation", {
		Text = "Show Debug Information",
		Default = false,
	})

	groupbox:AddToggle("EffectLogging", {
		Text = "Effect Logging",
		Default = false,
	})

	groupbox:AddToggle("StopGameLogging", {
		Text = "Stop Game Logging",
		Default = false,
	})
end

---Info spoofing section.
---@param groupbox table
function GameTab.initInfoSpoofingSection(groupbox)
	local hasEverBeenEnabled = true

	groupbox:AddToggle("InfoSpoofing", {
		Text = "Enable Info Spoofing",
		Default = false,
		Callback = function(value)
			-- Only refresh if we've ever enabled this feature or we're currently enabling it.
			if value or hasEverBeenEnabled then
				Spoofing.rics()
			end

			-- We don't need to mark if we're disabling it.
			if not value then
				return
			end

			-- Spoof UI.
			Spoofing.sss(Configuration.expectOptionValue("SpoofedSlotString"))
			Spoofing.sds(Configuration.expectOptionValue("SpoofedDateString"))
			Spoofing.sgv(Configuration.expectOptionValue("SpoofedGameVersion"))

			-- Mark that we've enabled this atleast once...
			hasEverBeenEnabled = true
		end,
	})

	local isDepBox = groupbox:AddDependencyBox()

	isDepBox:AddToggle("SpoofOtherPlayers", {
		Text = "Spoof Other Players",
		Default = false,
		Callback = Spoofing.rics,
	})

	isDepBox:AddToggle("HideDeathInformation", {
		Text = "Hide Death Information",
		Default = false,
	})

	isDepBox:AddInput("SpoofedSlotString", {
		Text = "Spoofed Slot String",
		Default = "1234567890:Z|1 [Lv. 1]",
		Finished = true,
		Callback = Spoofing.sss,
	})

	isDepBox:AddInput("SpoofedDateString", {
		Text = "Spoofed Date String",
		Default = "Linoria, 1970 CE",
		Finished = true,
		Callback = Spoofing.sds,
	})

	isDepBox:AddInput("SpoofedGameVersion", {
		Text = "Spoofed Game Version",
		Default = "pv_JAN_01_00:00z",
		Finished = true,
		Callback = Spoofing.sgv,
	})

	local function refreshHandler()
		if not Configuration.expectToggleValue("InfoSpoofing") then
			return
		end

		Spoofing.rics()
	end

	isDepBox:AddInput("SpoofedFirstName", {
		Text = "Spoofed First Name",
		Default = "Linoria V2",
		Finished = true,
		Callback = refreshHandler,
	})

	isDepBox:AddInput("SpoofedLastName", {
		Text = "Spoofed Last Name",
		Default = "On Top",
		Finished = true,
		Callback = refreshHandler,
	})

	isDepBox:AddInput("SpoofedGuildName", {
		Text = "Spoofed Guild Name",
		Default = "discord.gg/lyc",
		Finished = true,
		Callback = refreshHandler,
	})

	isDepBox:AddInput("SpoofedServerName", {
		Text = "Spoofed Server Name",
		Default = "Linoria V2",
		Finished = true,
		Callback = refreshHandler,
	})

	isDepBox:AddInput("SpoofedServerRegion", {
		Text = "Spoofed Server Region",
		Default = "discord.gg/lyc",
		Finished = true,
		Callback = refreshHandler,
	})

	isDepBox:AddInput("SpoofedServerAge", {
		Text = "Spoofed Server Age",
		Default = "???",
		Finished = true,
		Callback = refreshHandler,
	})

	isDepBox:SetupDependencies({
		{ Toggles.InfoSpoofing, true },
	})
end

---Tweening section.
---@param groupbox table
function GameTab.initTweeningSection(groupbox)
	groupbox:AddSlider("TweenStudsPerSecond", {
		Text = "Tween Speed",
		Default = 200,
		Min = 50,
		Max = 450,
		Suffix = "/s",
		Rounding = 0,
	})
end

---Initialize tab.
function GameTab.init(window)
	-- Create tab.
	local tab = window:AddTab("Game")

	-- Initialize sections.
	GameTab.initDebuggingSection(tab:AddDynamicGroupbox("Debugging"))
	GameTab.initLocalCharacterSection(tab:AddDynamicGroupbox("Local Character"))
	GameTab.initEffectRemovalsSection(tab:AddDynamicGroupbox("Effect Removals"))
	GameTab.initInstanceRemovalsSection(tab:AddDynamicGroupbox("Instance Removals"))
	GameTab.initPlayerMonitoringSection(tab:AddDynamicGroupbox("Player Monitoring"))
	GameTab.initInfoSpoofingSection(tab:AddDynamicGroupbox("Info Spoofing"))
	GameTab.initTweeningSection(tab:AddDynamicGroupbox("Tweening Customization"))
end

-- Return GameTab module.
return GameTab

end)
__bundle_register("Menu/CombatTab", function(require, _LOADED, __bundle_register, __bundle_modules)
-- CombatTab module.
local CombatTab = {}

---@module Utility.Logger
local Logger = require("Utility/Logger")

---@module Features.Combat.Defense
local Defense = require("Features/Combat/Defense")

---@module Utility.Configuration
local Configuration = require("Utility/Configuration")

---@module GUI.Library
local Library = require("GUI/Library")

---@module Game.Timings.SaveManager
local SaveManager = require("Game/Timings/SaveManager")

-- Initialize combat targeting section.
---@param tab table
function CombatTab.initCombatTargetingSection(tab)
	tab:AddDropdown("PlayerSelectionType", {
		Text = "Player Selection Type",
		Values = {
			"Closest In Distance",
			"Closest To Crosshair",
			"Least Health",
		},
		Default = 1,
	})

	tab:AddSlider("FOVLimit", {
		Text = "Player FOV Limit",
		Min = 0,
		Max = 180,
		Default = 180,
		Suffix = "°",
		Rounding = 0,
	})

	tab:AddSlider("DistanceLimit", {
		Text = "Distance Limit",
		Min = 0,
		Max = 10000,
		Default = 3000,
		Suffix = "s",
		Rounding = 0,
	})

	tab:AddSlider("MaxTargets", {
		Text = "Max Targets",
		Min = 1,
		Max = 64,
		Default = 4,
		Rounding = 0,
	})

	tab:AddToggle("CheckTargetingValue", {
		Text = "Check Mob Targeting Value",
		Default = false,
		Tooltip = "If a mob is found with a valid target, the script will check if we're currently being targeted.",
	})

	tab:AddToggle("IgnorePlayers", {
		Text = "Ignore Players",
		Default = false,
	})

	tab:AddToggle("IgnoreMobs", {
		Text = "Ignore Mobs",
		Default = false,
	})

	tab:AddToggle("IgnoreAllies", {
		Text = "Ignore Allies",
		Default = false,
	})
end

-- Initialize combat whitelist section.
---@param groupbox table
function CombatTab.initCombatWhitelistSection(groupbox)
	groupbox:AddToggle("PlayerListWhitelisting", {
		Text = "Player List Whitelisting",
		Tooltip = "Click your 'L' key on players in the player list to add/remove them from the whitelist.",
		Default = false,
	})

	local usernameList = groupbox:AddDropdown("UsernameList", {
		Text = "Username List",
		Values = {},
		SaveValues = true,
		Multi = true,
		AllowNull = true,
	})

	local usernameInput = groupbox:AddInput("UsernameInput", {
		Text = "Username Input",
		Placeholder = "Display name or username.",
	})

	groupbox:AddButton("Add Username To Whitelist", function()
		local username = usernameInput.Value
		if #username <= 0 then
			return Logger.longNotify("Please enter a valid username.")
		end

		local values = usernameList.Values
		if not table.find(values, username) then
			table.insert(values, username)
		end

		usernameList:SetValues(values)
		usernameList:SetValue({})
		usernameList:Display()
	end)

	groupbox:AddButton("Remove Selected Usernames", function()
		local values = usernameList.Values
		local value = usernameList.Value

		for selected, _ in next, value do
			local index = table.find(values, selected)
			if not index then
				continue
			end

			table.remove(values, index)
		end

		usernameList:SetValues(values)
		usernameList:SetValue({})
		usernameList:Display()
	end)
end

-- Initialize auto defense section.
---@param groupbox table
function CombatTab.initAutoDefenseSection(groupbox)
	local autoDefenseToggle = groupbox:AddToggle("EnableAutoDefense", {
		Text = "Enable Auto Defense",
		Default = false,
	})

	autoDefenseToggle:AddKeyPicker(
		"EnableAutoDefenseKeybind",
		{ Default = "N/A", SyncToggleState = true, Text = "Auto Defense" }
	)

	local autoDefenseDepBox = groupbox:AddDependencyBox()

	autoDefenseDepBox:AddToggle("EnableNotifications", {
		Text = "Enable Notifications",
		Default = false,
	})

	autoDefenseDepBox:AddToggle("EnableVisualizations", {
		Text = "Enable Visualizations",
		Default = false,
		Callback = Defense.visualizations,
	})

	autoDefenseDepBox:AddToggle("RollOnParryCooldown", {
		Text = "Roll On Parry Cooldown",
		Default = false,
	})

	autoDefenseDepBox:AddToggle("VentFallback", {
		Text = "Vent Fallback",
		Default = false,
		Tooltip = "This is used as a last resort which takes priority after 'Deflect Block Fallback' if it is on.",
	})

	autoDefenseDepBox:AddToggle("DeflectBlockFallback", {
		Text = "Deflect Block Fallback",
		Default = false,
		Tooltip = "If enabled, the auto defense will fallback to block frames if parry action and/or fallback is not available as a last resort.",
	})

	autoDefenseDepBox:AddToggle("UseIFrames", {
		Text = "Use Invincibility Frames",
		Default = false,
		Tooltip = "If enabled, the auto defense will ignore parry, block and dodge action if there's already an existing invincibility frame.",
	})

	autoDefenseDepBox:AddToggle("UseAutoParryFrames", {
		Text = "Use Auto Parry Frames",
		Default = false,
		Tooltip = "If enabled, the auto defense will ignore parry actions if there is AP frames.",
	})

	autoDefenseDepBox:AddToggle("ValidateIncomingAnimations", {
		Text = "Validate Incoming Animations",
		Default = true,
		Tooltip = "If enabled, the auto defense will check the incoming attack's animation for any abnormalities to prevent AP breaking.",
	})

	autoDefenseDepBox:AddToggle("ParryOnly", {
		Text = "Parry Dodgeables",
		Default = false,
		Tooltip = "If enabled, the auto defense will change dodge actions to parry actions.",
	})

	autoDefenseDepBox:AddToggle("UsePrediction", {
		Text = "Use Prediction",
		Default = false,
		Tooltip = "Use Prediction mantra instead of parry/dodge when available and off cooldown. Can be used together with Punishment (Prediction takes priority).",
	})

	autoDefenseDepBox:AddToggle("UsePunishment", {
		Text = "Use Punishment",
		Default = false,
		Tooltip = "Use Punishment mantra instead of parry/dodge when available and off cooldown. Can be used together with Prediction (Prediction takes priority).",
	})

	local blatantRollToggle = autoDefenseDepBox:AddToggle("BlatantRoll", {
		Text = "Blatant Roll",
		Default = false,
		Tooltip = "If enabled, we will call the roll remotes directly without running any checks, specific-movement, etc.",
	})

	local rollCancelTgDepBox = autoDefenseDepBox:AddDependencyBox()

	local rollCancelToggle = autoDefenseDepBox:AddToggle("RollCancel", {
		Text = "Roll Cancel",
		Default = false,
	})

	local rollCancelDepBox = autoDefenseDepBox:AddDependencyBox()

	rollCancelDepBox:AddSlider("RollCancelDelay", {
		Text = "Roll Cancel Delay",
		Default = 0.05,
		Min = 0,
		Max = 2,
		Suffix = "s",
		Rounding = 2,
	})

	rollCancelDepBox:SetupDependencies({
		{ rollCancelToggle, true },
	})

	rollCancelTgDepBox:SetupDependencies({
		{ blatantRollToggle, true },
	})

	local afToggle = autoDefenseDepBox:AddToggle("AllowFailure", {
		Text = "Allow Failure",
		Default = false,
		Tooltip = "If enabled, the auto defense will sometimes intentionally fail to parry/deflect.",
	})

	local afDepBox = autoDefenseDepBox:AddDependencyBox()

	afDepBox:AddSlider("FailureRate", {
		Text = "Failure Rate",
		Min = 0,
		Max = 100,
		Default = 0,
		Suffix = "%",
		Rounding = 2,
	})

	afDepBox:AddSlider("DashInsteadOfParryRate", {
		Text = "Dash Instead Of Parry Rate",
		Min = 0,
		Max = 100,
		Default = 0,
		Suffix = "%",
		Rounding = 2,
	})

	afDepBox:AddSlider("IgnoreAnimationEndRate", {
		Text = "Ignore Animation End Rate",
		Min = 0,
		Max = 100,
		Default = 0,
		Suffix = "%",
		Rounding = 2,
	})

	afDepBox:SetupDependencies({
		{ afToggle, true },
	})

	autoDefenseDepBox:AddDropdown("AutoDefenseFilters", {
		Text = "Auto Defense Filters",
		Values = {
			"Filter Out M1s",
			"Filter Out Mantras",
			"Filter Out Criticals",
			"Filter Out Undefined",
			"Disable When Textbox Focused",
			"Disable When Window Not Active",
			"Disable While Holding Block",
			"Disable While Using Sightless Beam",
			"Disable During Chime Countdown",
		},
		Multi = true,
		AllowNull = true,
		Default = {},
	})

	autoDefenseDepBox:SetupDependencies({
		{ autoDefenseToggle, true },
	})
end

---Create timing override callback.
---@param callback function
---@return function
local function timingOverrideCallback(callback)
	return function()
		local overrideData = Library.OverrideData
		if not overrideData then
			return false
		end

		local selectedTo = Configuration.expectOptionValue("TimingOverrideList")
		if not selectedTo or #selectedTo == 0 then
			return false
		end

		local override = overrideData[selectedTo]
		if not override then
			return false
		end

		callback(override)
	end
end

---Refresh timing override list.
local function refreshTimingOverrideList()
	local overrideData = Library.OverrideData
	if not overrideData then
		return
	end

	local timingList = Options["TimingOverrideList"]
	if not timingList then
		return
	end

	local values = {}

	for rname, _ in next, overrideData do
		values[#values + 1] = rname
	end

	timingList:SetValues(values)
end

---Initialize timings section.
---@param groupbox table
function CombatTab:initTimingsSection(groupbox)
	self.tol = groupbox:AddDropdown("TimingOverrideList", {
		Text = "Timing Override List",
		Values = {},
		SaveValues = false,
		Multi = false,
		AllowNull = true,
		Callback = function()
			self.dashInsteadOfParryRate:SetRawValue(0)
			self.failureRate:SetRawValue(0)
			self.ignoreAnimationEndRate:SetRawValue(0)

			local overrideData = Library.OverrideData
			if not overrideData then
				return false
			end

			local selectedTo = Configuration.expectOptionValue("TimingOverrideList")
			if not selectedTo or #selectedTo == 0 then
				return false
			end

			local override = overrideData[selectedTo]
			if not override then
				return false
			end

			self.dashInsteadOfParryRate:SetRawValue(override.dipr or 0)
			self.failureRate:SetRawValue(override.fr or 0)
			self.ignoreAnimationEndRate:SetRawValue(override.iaer or 0)
		end,
	})

	groupbox:AddDivider()

	local names = {}
	local plist = { SaveManager.as, SaveManager.es, SaveManager.ss, SaveManager.ps }

	---@todo: There should be a specific method for this; I mean as far as I'm aware THERE IS ONE. But, I'm too lazy.
	for _, pair in next, plist do
		for _, timing in next, pair:list() do
			names[#names + 1] = PP_SCRAMBLE_STR(timing.name)
		end
	end

	table.sort(names)

	self.ti = groupbox:AddDropdown("TimingOverrideTimingList", {
		Text = "Timing List",
		Values = names,
		Multi = false,
		AllowNull = true,
	})

	groupbox:AddButton("Add Timing Override", function()
		if Library.OverrideData[self.ti.Value] then
			return Logger.notify("A timing override with that name already exists.")
		end

		-- Add data.
		local override = {
			fr = self.failureRate.Value,
			dipr = self.dashInsteadOfParryRate.Value,
			iaer = self.ignoreAnimationEndRate.Value,
		}

		Library.OverrideData[self.ti.Value] = override

		-- Refresh timing list.
		refreshTimingOverrideList()

		-- Set timing list value.
		self.tol:SetValue(self.ti.Value)
		self.tol:Display()
	end)

	groupbox:AddButton("Remove Selected Override", function()
		-- Remove data.
		Library.OverrideData[self.tol.Value] = nil

		-- Refresh timing list.
		refreshTimingOverrideList()

		-- Set timing list value.
		self.tol:SetValue(nil)
		self.tol:Display()
	end)

	-- Initial refresh.
	refreshTimingOverrideList()
end

---Initialize probabilities section.
---@param groupbox table
function CombatTab:initProbabilitiesSection(groupbox)
	self.failureRate = groupbox:AddSlider("TP_FailureRate", {
		Text = "Failure Rate",
		Min = 0,
		Max = 100,
		Default = 0,
		Suffix = "%",
		Rounding = 2,
		Callback = timingOverrideCallback(function(override)
			override.fr = self.failureRate.Value
		end),
	})

	self.dashInsteadOfParryRate = groupbox:AddSlider("TP_DashInsteadOfParryRate", {
		Text = "Dash Instead Of Parry Rate",
		Min = 0,
		Max = 100,
		Default = 0,
		Suffix = "%",
		Rounding = 2,
		Callback = timingOverrideCallback(function(override)
			override.dipr = self.dashInsteadOfParryRate.Value
		end),
	})

	self.ignoreAnimationEndRate = groupbox:AddSlider("TP_IgnoreAnimationEndRate", {
		Text = "Ignore Animation End Rate",
		Min = 0,
		Max = 100,
		Default = 0,
		Suffix = "%",
		Rounding = 2,
		Callback = timingOverrideCallback(function(override)
			override.iaer = self.ignoreAnimationEndRate.Value
		end),
	})
end

---Initialize attack assistance section.
---@param groupbox table
function CombatTab.initAttackAssistanceSection(groupbox)
	local afToggle = groupbox:AddToggle("AutoFeint", {
		Text = "Auto Feint",
		Default = false,
		Tooltip = "Attempt to automatically feint your attacks before the parry timing to prevent swing-throughs.",
	})

	local afDepBox = groupbox:AddDependencyBox()

	afDepBox:AddDropdown("AutoFeintType", {
		Text = "Auto Feint Type",
		Values = {
			"Passive",
			"Aggressive",
		},
		Default = 1,
	})

	afDepBox:SetupDependencies({
		{ afToggle, true },
	})
end

---Initialize combat assistance section.
---@param groupbox table
function CombatTab.initCombatAssistance(groupbox)
	local awToggle = groupbox:AddToggle("AutoWisp", {
		Text = "Auto Wisp",
		Default = false,
		Tooltip = "Automatically cast your Wisp for you without pressing the buttons.",
	})

	local awDepBox = groupbox:AddDependencyBox()

	awDepBox:AddSlider("AutoWispDelay", {
		Text = "Auto Wisp Delay",
		Default = 0.4,
		Min = 0,
		Max = 1,
		Suffix = "s",
		Rounding = 2,
	})

	awDepBox:SetupDependencies({
		{ awToggle, true },
	})

	local agtToggle = groupbox:AddToggle("AutoGoldenTongue", {
		Text = "Auto Golden Tongue",
		Default = false,
		Tooltip = "Automatically say a hidden message when your 'Golden Tongue' talent is on cooldown.",
	})

	local agtDepBox = groupbox:AddDependencyBox()

	agtDepBox:AddToggle("CheckIfInCombat", {
		Text = "Check If In Combat",
		Default = false,
		Tooltip = "Only send the message if we're currently in combat.",
	})

	agtDepBox:SetupDependencies({
		{ agtToggle, true },
	})

	local amfToggle = groupbox:AddToggle("AutoMantraFollowup", {
		Text = "Auto Mantra Followup",
		Default = false,
		Tooltip = "Automatically press the followup button while using a mantra.",
	})

	local amfDepBox = groupbox:AddDependencyBox()

	amfDepBox:AddToggle("CheckIfMoveHit", {
		Text = "Check If Move Hit",
		Default = false,
		Tooltip = "Only press the followup button if a 'DamagedAnother' effect is detected.",
	})

	amfDepBox:SetupDependencies({
		{ amfToggle, true },
	})

	groupbox:AddToggle("AutoArdour", {
		Text = "Auto Ardour",
		Default = false,
		Tooltip = "Automatically activate Ardour when you have a weapon equipped and the buff is not active. Requires the 'Murmur: Ardour' talent.",
	})

	groupbox:AddToggle("AutoFlowState", {
		Text = "Auto Flow State",
		Default = false,
		Tooltip = "Detect what Silentheart moves would be thrown out and use flow-state beforehand.",
	})

	groupbox:AddToggle("DelayedFeints", {
		Text = "Delayed Feints",
		Default = false,
		Tooltip = "When you feint during a move, it will attempt to delay it to be as late as possible.",
	})

	local ascToggle = groupbox:AddToggle("AnimationSpeedChanger", {
		Text = "Animation Speed Changer",
		Default = false,
		Tooltip = "Should we change the animation speed of animations when they play?",
	})

	local ascDepBox = groupbox:AddDependencyBox()

	ascDepBox:AddToggle("LimitToAPAnimations", {
		Text = "Limit To AP Animations",
		Default = false,
		Tooltip = "Only change the animation speed of animations that are inside of the 'Auto Parry' animations list.",
	})

	ascDepBox:AddToggle("SwitchBetweenSpeeds", {
		Text = "Switch Between Speeds",
		Default = false,
		Tooltip = "Only switch between values around minimum and maximum animation speeds instead of a random value in between.",
	})

	ascDepBox:AddSlider("AnimationSpeedMinimum", {
		Text = "Animation Speed Minimum",
		Default = 1.0,
		Min = 0.1,
		Max = 5,
		Suffix = "x",
		Rounding = 2,
	})

	ascDepBox:AddSlider("AnimationSpeedMaximum", {
		Text = "Animation Speed Maximum",
		Default = 1.25,
		Min = 0.1,
		Max = 5,
		Suffix = "x",
		Rounding = 2,
	})

	ascDepBox:SetupDependencies({
		{ ascToggle, true },
	})

	local arToggle = groupbox:AddToggle("ActionRolling", {
		Text = "Action Rolling",
		Default = false,
		Tooltip = "Automatically roll when performing certain actions.",
	})

	local arDepBox = groupbox:AddDependencyBox()

	arDepBox:AddDropdown("ActionRollingActions", {
		Text = "Action Rolling Actions",
		Values = {
			"Roll On M1",
			"Roll On Critical",
			"Roll On Cast",
			"Roll On Parry",
		},
		Multi = true,
		AllowNull = true,
		Default = {},
	})

	arDepBox:AddSlider("ActionRollCancelDelay", {
		Text = "Action Roll Cancel Delay",
		Default = 0.1,
		Min = 0,
		Max = 2,
		Suffix = "s",
		Rounding = 2,
	})

	arDepBox:AddSlider("ActionRollCooldown", {
		Text = "Action Roll Cooldown",
		Default = 2,
		Min = 0,
		Max = 5,
		Suffix = "s",
		Rounding = 2,
	})

	arDepBox:SetupDependencies({
		{ arToggle, true },
	})

	groupbox:AddToggle("M1Hold", {
		Text = "M1 Hold",
		Default = false,
	})

	groupbox:AddToggle("AutoRagdollRecover", {
		Text = "Auto Ragdoll Recover",
		Default = false,
		Tooltip = "Automatically recover from ragdoll state.",
	})

	groupbox:AddToggle("FeintFlourish", {
		Text = "Feint Flourish",
		Default = false,
		Tooltip = "Allow yourself to feint your flourish attacks. You need a mantra.",
	})
end

---Initialize debugging section.
---@param groupbox table
function CombatTab.initDebuggingSection(groupbox)
	groupbox:AddToggle("BlockParryState", {
		Text = "Block Parry State",
		Default = false,
	})

	groupbox:AddToggle("BlockDodgeState", {
		Text = "Block Dodge State",
		Default = false,
	})

	groupbox:AddToggle("BlockVentState", {
		Text = "Block Vent State",
		Default = false,
	})

	groupbox:AddToggle("NoBlockingState", {
		Text = "No Blocking State",
		Default = false,
	})
end

---Initialize tab.
---@param window table
function CombatTab.init(window)
	-- Create tab.
	local tab = window:AddTab("Combat")

	-- Initialize sections.
	CombatTab.initAutoDefenseSection(tab:AddDynamicGroupbox("Auto Defense"))
	-- Create targeting section tab box.
	local tabbox = tab:AddDynamicTabbox()
	CombatTab.initCombatTargetingSection(tabbox:AddTab("Targeting"))
	CombatTab.initCombatWhitelistSection(tabbox:AddTab("Whitelisting"))

	-- Initialize other sections.
	CombatTab.initAttackAssistanceSection(tab:AddDynamicGroupbox("Attack Assistance"))
	CombatTab.initCombatAssistance(tab:AddDynamicGroupbox("Combat Assistance"))

	-- Create timing probability section tab box.
	local tpTabbox = tab:AddDynamicTabbox()
	CombatTab:initTimingsSection(tpTabbox:AddTab("Timings"))
	CombatTab:initProbabilitiesSection(tpTabbox:AddTab("Probabilities"))

	-- Initialize debugging section.
	if not LRM_UserNote then
		CombatTab.initDebuggingSection(tab:AddDynamicGroupbox("Debugging"))
	end
end

-- Return CombatTab module.
return CombatTab

end)
__bundle_register("Game/Hooking", function(require, _LOADED, __bundle_register, __bundle_modules)
-- Hooking related stuff is handled here.
local Hooking = {}

---@module Game.KeyHandling
local KeyHandling = require("Game/KeyHandling")

---@module Utility.Logger
local Logger = require("Utility/Logger")

---@module Utility.Configuration
local Configuration = require("Utility/Configuration")

---@module Game.InputClient
local InputClient = require("Game/InputClient")

---@module Features.Combat.StateListener
local StateListener = require("Features/Combat/StateListener")

---@module Game.LeaderboardClient
local LeaderboardClient = require("Game/LeaderboardClient")

---@module Features.Game.Spoofing
local Spoofing = require("Features/Game/Spoofing")

---@module Game.Objects.DodgeOptions
local DodgeOptions = require("Game/Objects/DodgeOptions")

---@module Utility.TaskSpawner
local TaskSpawner = require("Utility/TaskSpawner")

-- Services.
local playersService = game:GetService("Players")
local replicatedStorage = game:GetService("ReplicatedStorage")
local lighting = game:GetService("Lighting")

-- Cached IsA.
local isA = game.IsA

-- Old hooked functions.
local oldFireServer = nil
local oldUnreliableFireServer = nil
local oldNameCall = nil
local oldNewIndex = nil
local oldTick = nil
local oldToString = nil
local oldIndex = nil
local oldPrint = nil
local oldWarn = nil
local oldHasEffect = nil

-- InputClient caching.
local lastCallingFunction = nil
local lastFunctionCacheAttempt = 0

-- Action rolling.
local lastActionRoll = nil

-- Ban remotes table.
local banRemotes = {}

-- Input types.
local INPUT_LEFT_CLICK = 1
local INPUT_RIGHT_CLICK = 2
local INPUT_CRITICAL = 3
local INPUT_CAST = 4
local INPUT_BLOCK = 5

-- Input types two.
local INPUT_TYPE_BEFORE = 1
local INPUT_TYPE_AFTER = 2

---Handle flow state.
---@param type number
local handleFlowState = LPH_NO_VIRTUALIZE(function(type)
	local effectReplicator = replicatedStorage:FindFirstChild("EffectReplicator")
	if not effectReplicator then
		return
	end

	local effectReplicatorModule = require(effectReplicator)
	if not effectReplicatorModule then
		return
	end

	local localPlayer = playersService.LocalPlayer
	if not localPlayer then
		return
	end

	local backpack = localPlayer:FindFirstChild("Backpack")
	if not backpack then
		return
	end

	local flowStateTool = backpack:FindFirstChild("Talent:Flow State")
	if not flowStateTool then
		return
	end

	local flowStateRemote = flowStateTool:FindFirstChild("ActivateRt")
	if not flowStateRemote then
		return
	end

	local flowStateCooldown = false
	local shUpperCooldown = false
	local shDashCooldown = false
	local shGapCloserCooldown = false

	for _, effect in next, effectReplicatorModule.Effects do
		local index = rawget(effect, "index")
		if not index then
			continue
		end

		if index.Class == "ToolCD" and index.Value == "Talent: Flow State" then
			flowStateCooldown = true
		end

		if index.Class:match("SHUpper") and index.Class:match("CD") then
			shUpperCooldown = true
		end

		if index.Class:match("SHDash") and index.Class:match("CD") then
			shDashCooldown = true
		end

		if index.Class:match("SHGap") and index.Class:match("CD") then
			shGapCloserCooldown = true
		end
	end

	Logger.warn(
		"(%s, %s, %s, %s, %s) Current cooldown state...",
		shUpperCooldown and "SHUpperCD" or "SHUpperReady",
		shDashCooldown and "SHDashCD" or "SHDashReady",
		shGapCloserCooldown and "SHGapCloserCD" or "SHGapCloserReady",
		effectReplicatorModule:FindEffect("SlideAttackCD") and "SlideAttackCD" or "SlideAttackReady",
		flowStateCooldown and "FlowStateCD" or "FlowStateReady"
	)

	if flowStateCooldown then
		return Logger.warn("Flow state is on cooldown.")
	end

	Logger.warn("(%i) Attempting to detect Silentheart moves for input type.", type)

	if
		effectReplicatorModule:FindEffect("Sliding")
		and not effectReplicatorModule:FindEffect("SlideAttackCD")
		and type == INPUT_LEFT_CLICK
	then
		Logger.warn("Detected 'Ankle Cutter' move.")

		flowStateRemote:FireServer()
	end

	if effectReplicatorModule:FindEffect("SHDash") and not shDashCooldown and type == INPUT_LEFT_CLICK then
		Logger.warn("Detected 'Mayhem' move.")

		flowStateRemote:FireServer()
	end

	-- If we've done an aerial attack -- (aerial cooldown effect)
	-- If we've attacked also -- (light attack effect)
	if
		effectReplicatorModule:FindEffect("AerialCD")
		and effectReplicatorModule:FindEffect("LightAttack")
		and not shGapCloserCooldown
		and type == INPUT_LEFT_CLICK
	then
		Logger.warn("Detected 'Relentless Hunt' move.")

		flowStateRemote:FireServer()
	end

	if
		(
			effectReplicatorModule:FindEffect("Sliding")
			or effectReplicatorModule:FindEffect("ClientCrouch")
			or effectReplicatorModule:FindEffect("Crouching")
		)
		and not shUpperCooldown
		and type == INPUT_RIGHT_CLICK
	then
		Logger.warn("Detected 'Rising Star' move.")

		flowStateRemote:FireServer()
	end
end)

---Handle action rolling.
---@param type number
local handleActionRolling = LPH_NO_VIRTUALIZE(function(type)
	local actionRollTypes = Configuration.expectOptionValue("ActionRollingActions") or {}
	local actionRollInputs = {
		[INPUT_LEFT_CLICK] = actionRollTypes["Roll On M1"],
		[INPUT_CRITICAL] = actionRollTypes["Roll On Critical"],
		[INPUT_CAST] = actionRollTypes["Roll On Cast"],
		[INPUT_BLOCK] = actionRollTypes["Roll On Parry"],
	}

	if not actionRollInputs[type] then
		return
	end

	if type ~= INPUT_CAST then
		local effectReplicator = replicatedStorage:FindFirstChild("EffectReplicator")
		if not effectReplicator then
			return
		end

		local effectReplicatorModule = require(effectReplicator)
		if not effectReplicatorModule then
			return
		end

		if not effectReplicatorModule:HasEffect("Equipped") then
			return
		end
	end

	if type == INPUT_CAST then
		local lMantraActivated = StateListener.lMantraActivated
		if not lMantraActivated then
			return
		end

		if lMantraActivated.Name:match("Wisp") then
			return
		end
	end

	if
		lastActionRoll
		and os.clock() - lastActionRoll < (Configuration.expectOptionValue("ActionRollCooldown") or 2.0)
	then
		return
	end

	-- Timestamp it.
	lastActionRoll = os.clock()

	-- Wait.
	if type ~= INPUT_BLOCK then
		task.wait(0.1)
	end

	-- Perform options.
	local options = DodgeOptions.new()
	options.rollCancel = true
	options.rollCancelDelay = Configuration.expectOptionValue("ActionRollCancelDelay") or 0.1
	options.actionRolling = true

	-- Dodge.
	Logger.warn("(%i) Performing action roll dodge.", type)

	if type == INPUT_CAST then
		TaskSpawner.spawn("ActionRolling_CastDodge", InputClient.dodge, options)
	else
		InputClient.dodge(options)
	end
end)

---Handle delayed feints.
local handleDelayedFeints = LPH_NO_VIRTUALIZE(function()
	local lAnimTrack = StateListener.lAnimationValidTrack
	if not lAnimTrack then
		return Logger.warn("No valid animation track for delayed feint.")
	end

	local lAnimFaction = StateListener.lAnimFaction
	if not lAnimFaction then
		return Logger.warn("No animation faction for delayed feint.")
	end

	if not lAnimTrack.IsPlaying then
		return Logger.warn("Non playing animation track for delayed feint.")
	end

	if not StateListener.cfeint() then
		return Logger.warn("Unable to feint for delayed feint.")
	end

	local laTimestamp = StateListener.lAnimTimestamp
	if not laTimestamp then
		return Logger.warn("No animation timestamp for delayed feint.")
	end

	local laLatency = StateListener.lAnimLatency
	if not laLatency then
		return Logger.warn("No animation latency for delayed feint.")
	end

	local delayed = (lAnimFaction:when() - (os.clock() - laTimestamp)) - laLatency

	Logger.warn("Delaying for %.2f seconds before sending the feint remote.", delayed)

	task.wait(delayed)
end)

---On intercepted input.
---@param type number
---@param state number
local onInterceptedInput = LPH_NO_VIRTUALIZE(function(type, state)
	if Configuration.expectToggleValue("AutoFlowState") and state == INPUT_TYPE_BEFORE and type ~= INPUT_CAST then
		handleFlowState(type)
	end

	if Configuration.expectToggleValue("ActionRolling") and state == INPUT_TYPE_AFTER then
		handleActionRolling(type)
	end

	if
		Configuration.expectToggleValue("DelayedFeints")
		and state == INPUT_TYPE_BEFORE
		and type == INPUT_RIGHT_CLICK
		and StateListener.lAnimationValidTrack
	then
		handleDelayedFeints()
	end
end)

---Recursively find first valid InputClient stack.
---@return table?
local findInputClientStack = LPH_NO_VIRTUALIZE(function()
	for level = 1, math.huge do
		-- Get info.
		local success, info = pcall(debug.getinfo, level)
		if not success or not info then
			break
		end

		-- Check source.
		if not info.source:match("InputClient") then
			continue
		end

		-- Check if CClosure.
		if iscclosure(info.func) then
			continue
		end

		-- Fetch alternative stack - on Wave, this will fail. You cannot wrap debug.getstack(...) in pcall.
		local ssuccess, stack = pcall(debug.getstack, level)

		-- Return stack.
		return ssuccess and stack or debug.getstack(level - 1)
	end
end)

---Find function level of InputClient.
---@return number?, table?
local findInputClientLevel = LPH_NO_VIRTUALIZE(function()
	for level = 1, math.huge do
		-- Get info.
		local success, info = pcall(debug.getinfo, level)
		if not success or not info then
			break
		end

		-- Check source.
		if not info.source:match("InputClient") then
			continue
		end

		-- Return level, debug information.
		return level, info
	end
end)

---Stop gesture animations.
---@param animator Animator
local stopGestureAnimations = LPH_NO_VIRTUALIZE(function(animator)
	for _, animationTrack in pairs(animator:GetPlayingAnimationTracks()) do
		if not animationTrack.Animation or animationTrack.Animation.Parent.Name ~= "Gestures" then
			continue
		end

		animationTrack:Stop()
	end
end)

---Replicate gesture.
---@param gestureName string
local replicateGesture = LPH_NO_VIRTUALIZE(function(gestureName)
	local assets = replicatedStorage:FindFirstChild("Assets")
	local anims = assets and assets:FindFirstChild("Anims")
	local gestures = anims and anims:FindFirstChild("Gestures")
	local gesture = gestures and gestures:FindFirstChild(gestureName)
	if not gesture then
		return
	end

	local localPlayer = playersService.LocalPlayer
	if not localPlayer then
		return
	end

	local character = localPlayer.Character
	if not character then
		return
	end

	local humanoid = character:FindFirstChild("Humanoid")
	if not humanoid then
		return
	end

	local animator = humanoid:FindFirstChildWhichIsA("Animator")
	if not animator then
		return
	end

	local effectReplicator = replicatedStorage:FindFirstChild("EffectReplicator")
	local effectReplicatorModule = effectReplicator and require(effectReplicator)
	if not effectReplicatorModule then
		return
	end

	if effectReplicatorModule:FindEffect("Gesturing") then
		return
	end

	-- Create animation objects.
	local actionEffect = effectReplicatorModule:CreateEffect("Action")
	local gesturingEffect = effectReplicatorModule:CreateEffect("Gesturing")
	local mobileActionEffect = effectReplicatorModule:CreateEffect("MobileAction")
	local gestureAnimation = animator:LoadAnimation(gesture)

	-- Play animation.
	stopGestureAnimations(animator)
	gestureAnimation:Play()

	-- Wait for movement to cancel.
	repeat
		task.wait()
	until humanoid.MoveDirection.Magnitude > 0

	-- Wait a bit...
	task.wait(0.5)

	-- Remove effects.
	actionEffect:Remove()
	gesturingEffect:Remove()
	mobileActionEffect:Remove()

	-- Stop animations.
	stopGestureAnimations(animator)
end)

---Modify ambience color.
---@param value Color3
local modifyAmbienceColor = LPH_NO_VIRTUALIZE(function(value)
	local ambienceColor = Configuration.expectOptionValue("AmbienceColor")
	local shouldUseOriginalAmbienceColor = Configuration.expectToggleValue("OriginalAmbienceColor")

	if not shouldUseOriginalAmbienceColor and ambienceColor then
		return ambienceColor
	end

	local brightness = Configuration.expectOptionValue("OriginalAmbienceColorBrightness") or 0.0
	local red, green, blue = value.R, value.G, value.B

	red = math.min(red + brightness, 255)
	green = math.min(green + brightness, 255)
	blue = math.min(blue + brightness, 255)

	return Color3.fromRGB(red, green, blue)
end)

---On print.
---@return any
local onPrint = LPH_NO_VIRTUALIZE(function(...)
	if checkcaller() then
		return oldPrint(...)
	end

	if Configuration.expectToggleValue("StopGameLogging") then
		return
	end

	return oldPrint(...)
end)

---On warn.
---@return any
local onWarn = LPH_NO_VIRTUALIZE(function(...)
	if checkcaller() then
		return oldWarn(...)
	end

	if Configuration.expectToggleValue("StopGameLogging") then
		return
	end

	return oldWarn(...)
end)

---On tick.
---@return any
local onTick = LPH_NO_VIRTUALIZE(function(...)
	if checkcaller() then
		return oldTick(...)
	end

	if not Configuration.expectToggleValue("AutoSprint") then
		return oldTick(...)
	end

	local level, info = findInputClientLevel()
	if not level or not info then
		return oldTick(...)
	end

	local stack = findInputClientStack()
	if not stack then
		return error("Stack is nil.")
	end

	local firstConstantSuccess, firstConstant = pcall(debug.getconstant, info.func, 1)
	if not firstConstantSuccess then
		return oldTick(...)
	end

	if firstConstant ~= "UserInputType" then
		return oldTick(...)
	end

	---@note: Filter for any other spots that might be using tick() through the stack.
	if
		not table.find(stack, "W")
		and not table.find(stack, "A")
		and not table.find(stack, "S")
		and not table.find(stack, "D")
	then
		return oldTick(...)
	end

	---@note: We can indeed set a delay in here. The active thread is InputClient.
	if Configuration.expectToggleValue("AutoSprintDelay") then
		task.wait(Configuration.expectOptionValue("AutoSprintDelayTime"))
	end

	local effectReplicator = replicatedStorage:FindFirstChild("EffectReplicator")
	if not effectReplicator then
		return
	end

	local effectReplicatorModule = require(effectReplicator)
	if not effectReplicatorModule then
		return
	end

	if
		not Configuration.expectToggleValue("AutoSprintOnCrouch") and effectReplicatorModule:HasEffect("ClientCrouch")
	then
		return oldTick(...)
	end

	---@note: Set the timestamp set by sprinting to -math.huge so it's always over 0.25s.
	return -math.huge
end)

---On index.
---@return any
local onIndex = LPH_NO_VIRTUALIZE(function(...)
	if checkcaller() then
		return oldIndex(...)
	end

	local args = { ... }
	local index = args[2]

	---@note: Patch out InputClient detection for __index hooking to prevent annoying errors.
	if typeof(args[2]) == "table" then
		return error("InputClient - Lycoris On Top")
	end

	if Spoofing.force or not Configuration.expectToggleValue("InfoSpoofing") then
		return oldIndex(...)
	end

	local self = args[1]

	if typeof(self) == "Instance" and typeof(index) == "string" then
		if index == "Value" then
			if self.Name == "SERVER_NAME" then
				return Configuration.expectOptionValue("SpoofedServerName")
			end

			if self.Name == "SERVER_REGION" then
				return Configuration.expectOptionValue("SpoofedServerRegion")
			end

			if self.Name == "SERVER_AGE" then
				return Configuration.expectOptionValue("SpoofedServerAge")
			end
		end

		if isA(self, "Player") then
			if index == "DisplayName" then
				return "Linoria V2 On Top"
			end

			if index == "Name" then
				return "Linoria V2 On Top"
			end

			if index == "UserId" then
				return 000000000
			end
		end
	end

	return oldIndex(...)
end)

---On name call.
---@return any
local onNameCall = LPH_NO_VIRTUALIZE(function(...)
	if not LeaderboardClient.calling and checkcaller() then
		return oldNameCall(...)
	end

	local args = { ... }
	local self = args[1]

	if banRemotes[self] then
		return Logger.warn("(%s) Anticheat is referencing a ban remote.", self.Name)
	end

	if typeof(self) ~= "Instance" then
		return oldNameCall(...)
	end

	local method = getnamecallmethod()
	local name = self.Name

	if method == "Create" then
		---@note: Fix object if we're using a lighting template.
		local lightingTemplate = args[4]

		if typeof(lightingTemplate) == "table" then
			if
				lightingTemplate["FogStart"]
				and lightingTemplate["FogEnd"]
				and Configuration.expectToggleValue("NoFog")
			then
				lightingTemplate["FogStart"] = 9e9
				lightingTemplate["FogEnd"] = 9e9
			end

			if lightingTemplate["Ambient"] and Configuration.expectToggleValue("ModifyAmbience") then
				lightingTemplate["Ambient"] = modifyAmbienceColor(lightingTemplate["Ambient"])
			end

			if lightingTemplate["Density"] and Configuration.expectToggleValue("NoFog") then
				lightingTemplate["Density"] = 0
			end

			return oldNameCall(unpack(args))
		end
	end

	if Configuration.expectToggleValue("InfoSpoofing") then
		if typeof(args[2]) == "string" and method == "GetAttribute" and not Spoofing.force then
			local character = playersService.LocalPlayer.Character
			local humanoid = game.FindFirstChild(character, "Humanoid")
			local foreign = true

			if character and humanoid and (self.Parent == character or self.Parent == humanoid) then
				foreign = false
			end

			if foreign and not Configuration.expectToggleValue("SpoofOtherPlayers") then
				return oldNameCall(...)
			end

			if args[2] == "FirstName" then
				return foreign and "Linoria V2" or Configuration.expectOptionValue("SpoofedFirstName")
			end

			if args[2] == "LastName" then
				return foreign and "On Top" or Configuration.expectOptionValue("SpoofedLastName")
			end

			if args[2] == "CharacterName" then
				local characterName = Configuration.expectOptionValue("SpoofedFirstName")
					.. " "
					.. Configuration.expectOptionValue("SpoofedLastName")

				return foreign and "Linoria V2 On Top" or characterName
			end

			if args[2] == "Guild" then
				return foreign and "discord.gg/lyc" or Configuration.expectOptionValue("SpoofedGuild")
			end

			if args[2] == "GuildRich" then
				return foreign and "discord.gg/lyc" or Configuration.expectOptionValue("SpoofedGuildName")
			end
		end
	end

	if name == "ActivateMantra" and getnamecallmethod() == "FireServer" then
		-- State.
		StateListener.lMantraActivated = args[2]

		-- Before.
		onInterceptedInput(INPUT_CAST, INPUT_TYPE_BEFORE)

		-- Now.
		local result = oldNameCall(...)

		-- After.
		onInterceptedInput(INPUT_CAST, INPUT_TYPE_AFTER)

		-- Return.
		return result
	end

	if name == "Gesture" and Configuration.expectToggleValue("EmoteSpoofer") and typeof(args[2]) == "string" then
		return replicateGesture(args[2])
	end

	return oldNameCall(...)
end)

---On unreliable fire server.
---@return any
local onUnreliableFireServer = LPH_NO_VIRTUALIZE(function(...)
	local args = { ... }
	local self = args[1]

	if banRemotes[self] then
		return Logger.warn("(%s) Anticheat is calling a unreliable ban remote.", self.Name)
	end

	local leftClickRemote = KeyHandling.getRemote("LeftClick")
	local criticalRemote = KeyHandling.getRemote("CriticalClick")
	local feintClickRemote = KeyHandling.getRemote("FeintClick")
	local offhandAttackRemote = KeyHandling.getRemote("OffhandAttack")

	local inputType = nil

	if criticalRemote and self == criticalRemote then
		inputType = INPUT_CRITICAL
	end

	if leftClickRemote and self == leftClickRemote then
		inputType = INPUT_LEFT_CLICK
	end

	if (feintClickRemote and self == feintClickRemote) or (offhandAttackRemote and self == offhandAttackRemote) then
		inputType = INPUT_RIGHT_CLICK
	end

	if inputType then
		-- Before.
		onInterceptedInput(inputType, INPUT_TYPE_BEFORE)

		-- Now.
		local result = oldUnreliableFireServer(...)

		-- After.
		onInterceptedInput(inputType, INPUT_TYPE_AFTER)

		-- Return.
		return result
	end

	if checkcaller() then
		return oldUnreliableFireServer(...)
	end

	return oldUnreliableFireServer(...)
end)

---On fire server.
---@return any
local onFireServer = LPH_NO_VIRTUALIZE(function(...)
	local args = { ... }
	local self = args[1]

	if banRemotes[self] then
		return Logger.warn("(%s) Anticheat is calling a ban remote.", self.Name)
	end

	local blockRemote = KeyHandling.getRemote("Block")

	local inputType = nil

	if blockRemote and self == blockRemote then
		inputType = INPUT_BLOCK
	end

	if inputType then
		-- Before.
		onInterceptedInput(inputType, INPUT_TYPE_BEFORE)

		-- Now.
		local result = oldFireServer(...)

		-- After.
		onInterceptedInput(inputType, INPUT_TYPE_AFTER)

		-- Return.
		return result
	end

	return oldFireServer(...)
end)

---On new index.
---@return any
local onNewIndex = LPH_NO_VIRTUALIZE(function(...)
	if checkcaller() then
		return oldNewIndex(...)
	end

	local args = { ... }
	local self = args[1]
	local index = args[2]
	local value = args[3]

	if typeof(self) ~= "Instance" then
		return oldNewIndex(...)
	end

	if Configuration.expectToggleValue("InfoSpoofing") then
		if game.IsA(self, "TextLabel") and index == "Text" and not Spoofing.force then
			if self.Name == "Slot" and self.Parent.Name == "CharacterInfo" then
				return oldNewIndex(self, index, Configuration.expectOptionValue("SpoofedSlotString"))
			end

			if self.Name == "GameVersion" then
				return oldNewIndex(self, index, Configuration.expectOptionValue("SpoofedGameVersion"))
			end

			if self.Name == "Date" then
				return oldNewIndex(self, index, Configuration.expectOptionValue("SpoofedDateString"))
			end
		end
	end

	if Configuration.expectToggleValue("NoClip") and Configuration.expectToggleValue("Fly") then
		if index == "ActiveController" then
			if self.Parent then
				local airController = self.Parent:FindFirstChild("AirController")
				return oldNewIndex(self, index, airController or value)
			end
		end
	end

	if index == "MouseIconEnabled" then
		return oldNewIndex(self, index, true)
	end

	if index == "Ambient" then
		if self == lighting and Configuration.expectToggleValue("ModifyAmbience") then
			return oldNewIndex(self, index, modifyAmbienceColor(value))
		end
	end

	return oldNewIndex(...)
end)

---On to string.
---@return any
local onToString = LPH_NO_VIRTUALIZE(function(...)
	if os.clock() - lastFunctionCacheAttempt <= 0.5 then
		return oldToString(...)
	end

	local level, info = findInputClientLevel()
	if not level or not info then
		return oldToString(...)
	end

	if info.func == lastCallingFunction then
		return oldToString(...)
	end

	lastFunctionCacheAttempt = os.clock()

	-- Cache InputClient data.
	local success = InputClient.cache()

	-- Update last calling function. Only do this if we successfully cached; else we need to wait for the next frame.
	if success then
		lastCallingFunction = info.func
	end

	-- Continue.
	return oldToString(...)
end)

---On has effect.
---@return any
local onHasEffect = LPH_NO_VIRTUALIZE(function(...)
	if checkcaller() then
		return oldHasEffect(...)
	end

	local args = { ... }
	local class = args[2]

	local attackEffects = {
		"LightAttack",
		"HeavyAttack",
		"OffhandAttack",
		"UsingAbility",
		"CastingSpell",
	}

	if Configuration.expectToggleValue("NoAttackingClientChecks") and table.find(attackEffects, class) then
		return false
	end

	if Configuration.expectToggleValue("NoFallDamage") and class == "NoFall" then
		return true
	end

	return oldHasEffect(...)
end)

---Hooking initialization.
function Hooking.init()
	local localPlayer = playersService.LocalPlayer

	---@improvement: Add a listener for this script.
	local playerScripts = localPlayer:WaitForChild("PlayerScripts")
	local clientActor = playerScripts:WaitForChild("ClientActor")
	local clientManager = clientActor:WaitForChild("ClientManager")
	local requests = replicatedStorage:WaitForChild("Requests")

	---@note: Crucial part because of the actor and the error detection.
	clientManager.Enabled = false

	---@note: Dynamically get the ban remotes.
	local banRemoteCount = 0

	for _, request in next, requests:GetChildren() do
		local hasChangedConnection = #getconnections(request.Changed)
		if hasChangedConnection <= 0 then
			continue
		end

		banRemoteCount = banRemoteCount + 1
		banRemotes[request] = true
	end

	-- Did we execute with a standalone AC bypass?
	local nulledBanRemotes = {}

	for _, instance in next, getnilinstances() do
		if instance.Name ~= "NulledBanRemote" then
			continue
		end

		nulledBanRemotes[#nulledBanRemotes + 1] = instance
	end

	if #nulledBanRemotes ~= 2 then
		if banRemoteCount ~= 2 then
			return error("Anticheat has less or more than two ban remotes.")
		end
	end

	oldFireServer = hookfunction(Instance.new("RemoteEvent").FireServer, onFireServer)
	oldUnreliableFireServer = hookfunction(Instance.new("UnreliableRemoteEvent").FireServer, onUnreliableFireServer)
	oldToString = hookfunction(tostring, onToString)
	oldIndex = hookfunction(getrawmetatable(game).__index, onIndex)
	oldNameCall = hookfunction(getrawmetatable(game).__namecall, onNameCall)
	oldNewIndex = hookfunction(getrawmetatable(game).__newindex, onNewIndex)
	oldTick = hookfunction(tick, onTick)
	oldWarn = hookfunction(warn, onWarn)
	oldPrint = hookfunction(print, onPrint)

	local effectReplicator = replicatedStorage:WaitForChild("EffectReplicator")
	local effectReplicatorModule = require(effectReplicator)

	oldHasEffect = effectReplicatorModule.HasEffect

	effectReplicatorModule.HasEffect = onHasEffect

	-- Okay, we're done.
	Logger.warn("Client-side anticheat has been penetrated.")
end

---Hooking detach.
function Hooking.detach()
	local localPlayer = playersService.LocalPlayer

	if oldPrint then
		hookfunction(print, oldPrint)
	end

	if oldWarn then
		hookfunction(warn, oldWarn)
	end

	if oldTick then
		hookfunction(tick, oldTick)
	end

	if oldToString then
		hookfunction(tostring, oldToString)
	end

	if oldIndex then
		hookfunction(getrawmetatable(game).__index, oldIndex)
	end

	if oldNameCall then
		hookfunction(getrawmetatable(game).__namecall, oldNameCall)
	end

	if oldNewIndex then
		hookfunction(getrawmetatable(game).__newindex, oldNewIndex)
	end

	if oldFireServer then
		hookfunction(Instance.new("RemoteEvent").FireServer, oldFireServer)
	end

	if oldUnreliableFireServer then
		hookfunction(Instance.new("UnreliableRemoteEvent").FireServer, oldUnreliableFireServer)
	end

	local effectReplicator = replicatedStorage:FindFirstChild("EffectReplicator")
	local effectReplicatorModule = effectReplicator and require(effectReplicator)

	if oldHasEffect and effectReplicatorModule then
		effectReplicatorModule.HasEffect = oldHasEffect
		oldHasEffect = nil
	end

	local playerScripts = localPlayer:FindFirstChild("PlayerScripts")
	local clientActor = playerScripts and playerScripts:FindFirstChild("ClientActor")
	local clientManager = clientActor and clientActor:FindFirstChild("ClientManager")

	if clientManager then
		clientManager.Enabled = true
	end

	Logger.warn("Pulled out of client-side anticheat.")
end

-- Return Hooking module.
return Hooking

end)
return __bundle_require("__root")